globalThis.__nitro_main__ = import.meta.url;
import { b as NodeResponse, s as serve } from "./_libs/srvx.mjs";
import { d as defineHandler, H as HTTPError, t as toEventHandler, a as defineLazyEventHandler, b as H3Core } from "./_libs/h3.mjs";
import { d as decodePath, w as withLeadingSlash, a as withoutTrailingSlash, j as joinURL } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "./_libs/rou3.mjs";
function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const headers = ((m) => function headersRouteRule(event) {
  for (const [key2, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key2, value);
  }
});
const assets = {
  "/assets/Admin-BQus1giS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3aec-t05fZr4kQlyJr/pxcB0oOEw1Ick"',
    "mtime": "2026-10-08T22:32:15.633Z",
    "size": 15084,
    "path": "../public/assets/Admin-BQus1giS.js"
  },
  "/assets/arrow-left-CentdfpL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a6-BUAEabeuXgALPj2Pho7TPeuKA1k"',
    "mtime": "2026-10-08T22:32:15.633Z",
    "size": 166,
    "path": "../public/assets/arrow-left-CentdfpL.js"
  },
  "/assets/Auth-Bpb1TLHn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"477f-Hp7M7Q86yuRuOcnUzEhQiewqNCI"',
    "mtime": "2026-10-08T22:32:15.632Z",
    "size": 18303,
    "path": "../public/assets/Auth-Bpb1TLHn.js"
  },
  "/assets/badge-aJ7aE0FY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2c5-JHbdOiF5ufRQ8mjrgYCIs+nC25w"',
    "mtime": "2026-10-08T22:32:15.659Z",
    "size": 709,
    "path": "../public/assets/badge-aJ7aE0FY.js"
  },
  "/assets/card-DGZ8Ejf6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3c6-4gUfpxjSuBZYRIXTN3LeOys/+Ig"',
    "mtime": "2026-10-08T22:32:15.633Z",
    "size": 966,
    "path": "../public/assets/card-DGZ8Ejf6.js"
  },
  "/assets/film-Daj1J3iG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"198-rOjThYBwgczHKVMJM7xJaZe+k5Y"',
    "mtime": "2026-10-08T22:32:15.633Z",
    "size": 408,
    "path": "../public/assets/film-Daj1J3iG.js"
  },
  "/assets/index-Bq0oa5dc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-DfrM3Kyo9OiLcaLUbDKGd7ctq6Q"',
    "mtime": "2026-10-08T22:32:15.629Z",
    "size": 95,
    "path": "../public/assets/index-Bq0oa5dc.js"
  },
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": '"8abb-wljenl7NqjvcPlxpOEnM5wORGVY"',
    "mtime": "2026-10-08T21:54:54.504Z",
    "size": 35515,
    "path": "../public/favicon.ico"
  },
  "/assets/Monetization-zqTuS9nj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2ff4-rpnB6tRx8w3p844hQ4n9vQVGOEM"',
    "mtime": "2026-10-08T22:32:15.633Z",
    "size": 12276,
    "path": "../public/assets/Monetization-zqTuS9nj.js"
  },
  "/assets/NotFound-CIDzd3xk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5e6-vY7jEo2xkWYjhJsRBpA39wXGB5U"',
    "mtime": "2026-10-08T22:32:15.635Z",
    "size": 1510,
    "path": "../public/assets/NotFound-CIDzd3xk.js"
  },
  "/assets/Profile-CnBkoqTC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"433c-5n0Z9t85jxyamYpro8AEUFR7z8I"',
    "mtime": "2026-10-08T22:32:15.632Z",
    "size": 17212,
    "path": "../public/assets/Profile-CnBkoqTC.js"
  },
  "/assets/shield-off-C4wPgd2X.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"191-ne45Pv3ltYaRSlaa9xWMpU8vlC8"',
    "mtime": "2026-10-08T22:32:15.634Z",
    "size": 401,
    "path": "../public/assets/shield-off-C4wPgd2X.js"
  },
  "/assets/Stats-ClqWYkkx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"61bf8-139HKpdG196/bZ6TvKmuF9Ep0MU"',
    "mtime": "2026-10-08T22:32:15.633Z",
    "size": 400376,
    "path": "../public/assets/Stats-ClqWYkkx.js"
  },
  "/assets/use-follow-BZmf5L0h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3d4-wClGXeFCZbCNkWKLmYEU2QwrzW4"',
    "mtime": "2026-10-08T22:32:15.632Z",
    "size": 980,
    "path": "../public/assets/use-follow-BZmf5L0h.js"
  },
  "/assets/users-B1E40-L2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1b2-vjLyAEDqPhSZ4/dA5nKzO9eOPFw"',
    "mtime": "2026-10-08T22:32:15.633Z",
    "size": 434,
    "path": "../public/assets/users-B1E40-L2.js"
  },
  "/assets/Watch-BueAOnQN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"617b-Qg5mydgphP6KjaMXxERppMxvypY"',
    "mtime": "2026-10-08T22:32:15.633Z",
    "size": 24955,
    "path": "../public/assets/Watch-BueAOnQN.js"
  },
  "/assets/_-Bq0oa5dc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f-DfrM3Kyo9OiLcaLUbDKGd7ctq6Q"',
    "mtime": "2026-10-08T22:32:15.631Z",
    "size": 95,
    "path": "../public/assets/_-Bq0oa5dc.js"
  },
  "/assets/styles-BDIS4Z8o.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"17b69-nMqvEzjtPsJaZyttBU/FWSi/llA"',
    "mtime": "2026-10-08T22:32:15.628Z",
    "size": 97129,
    "path": "../public/assets/styles-BDIS4Z8o.css"
  },
  "/assets/index-BS8Y-n20.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d48d4-f1vBt5a3YfTv83qqGALj2nWxub8"',
    "mtime": "2026-10-08T22:32:15.634Z",
    "size": 870612,
    "path": "../public/assets/index-BS8Y-n20.js"
  }
};
function readAsset(id) {
  const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
  return promises.readFile(resolve(serverDir, assets[id].path));
}
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
function getAsset(id) {
  return assets[id];
}
const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = {
  gzip: ".gz",
  br: ".br",
  zstd: ".zst"
};
const _9Vn84h = defineHandler((event) => {
  if (event.req.method && !METHODS.has(event.req.method)) {
    return;
  }
  let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
  let asset;
  const encodingHeader = event.req.headers.get("accept-encoding") || "";
  const encodings = [...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.res.headers.delete("Cache-Control");
      throw new HTTPError({ status: 404 });
    }
    return;
  }
  if (encodings.length > 1) {
    event.res.headers.append("Vary", "Accept-Encoding");
  }
  const ifNotMatch = event.req.headers.get("if-none-match") === asset.etag;
  if (ifNotMatch) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  const ifModifiedSinceH = event.req.headers.get("if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  if (asset.type) {
    event.res.headers.set("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.headers.has("ETag")) {
    event.res.headers.set("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.headers.has("Last-Modified")) {
    event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.res.headers.has("Content-Encoding")) {
    event.res.headers.set("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.res.headers.has("Content-Length")) {
    event.res.headers.set("Content-Length", asset.size.toString());
  }
  return readAsset(id);
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_yZzpT_ = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_yZzpT_ };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const globalMiddleware = [
  toEventHandler(_9Vn84h)
].filter(Boolean);
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
function createNitroApp() {
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({ error, context: errorCtx });
      }
    }
  };
  const h3App = createH3App({
    onError(error, event) {
      return errorHandler(error, event);
    }
  });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  return {
    fetch: appHandler,
    h3: h3App,
    hooks: void 0,
    captureError
  };
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~middleware"].push(...globalMiddleware);
  h3App["~getMiddleware"] = (event, route) => {
    const pathname = event.url.pathname;
    const method = event.req.method;
    const middleware = [];
    const routeRules = getRouteRules(method, pathname);
    event.context.routeRules = routeRules?.routeRules;
    if (routeRules?.routeRuleMiddleware.length) {
      middleware.push(...routeRules.routeRuleMiddleware);
    }
    middleware.push(...h3App["~middleware"]);
    if (route?.data?.middleware?.length) {
      middleware.push(...route.data.middleware);
    }
    return middleware;
  };
  return h3App;
}
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
  process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
  process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
const tracingSrvxPlugins = [];
const _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
const port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
const host = process.env.NITRO_HOST || process.env.HOST;
const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
serve({
  port,
  hostname: host,
  tls: cert && key ? {
    cert,
    key
  } : void 0,
  fetch: nitroApp.fetch,
  plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
const nodeServer = {};
export {
  nodeServer as default
};
