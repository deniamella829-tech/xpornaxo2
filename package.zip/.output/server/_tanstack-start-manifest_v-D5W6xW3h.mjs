const tsrStartManifest = () => ({ routes: { __root__: { filePath: "C:/Users/alfre/Desktop/guardian-stream-studio-main/guardian-stream-studio-main/src/routes/__root.tsx", children: ["/", "/$"], preloads: ["/assets/index-BS8Y-n20.js"], scripts: [{ attrs: { type: "module", async: true, src: "/assets/index-BS8Y-n20.js" } }] }, "/": { filePath: "C:/Users/alfre/Desktop/guardian-stream-studio-main/guardian-stream-studio-main/src/routes/index.tsx", children: void 0, preloads: ["/assets/index-Bq0oa5dc.js"] }, "/$": { filePath: "C:/Users/alfre/Desktop/guardian-stream-studio-main/guardian-stream-studio-main/src/routes/$.tsx", children: void 0, preloads: ["/assets/_-Bq0oa5dc.js"] } } });
export {
  tsrStartManifest
};
