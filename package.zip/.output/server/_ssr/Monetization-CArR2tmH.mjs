import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as distExports } from "../_libs/react-router-dom.mjs";
import { s as supabase } from "./client-DChbXGiG.mjs";
import { u as useAuth, B as Button, I as Input, c as cn } from "./router-wXGJZuFu.mjs";
import { C as Card } from "./card-D0OxL9-2.mjs";
import { P as Progress$1, a as ProgressIndicator } from "../_libs/radix-ui__react-progress.mjs";
import { B as Badge } from "./badge-DJOd9VwP.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import "../_libs/next-themes.mjs";
import { L as LoaderCircle, K as Film, E as Eye, a0 as Users, x as ArrowLeft, a1 as ShieldOff, B as BadgeCheck, a2 as BadgeAlert, a3 as Wallet, D as DollarSign, a4 as TrendingUp } from "../_libs/lucide-react.mjs";
import "../_libs/react-router.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/cookie.mjs";
import "../_libs/set-cookie-parser.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/seroval.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/radix-ui__react-toast.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-tooltip.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__react-label.mjs";
const Progress = reactExports.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Progress$1,
  {
    ref,
    className: cn("relative h-4 w-full overflow-hidden rounded-full bg-secondary", className),
    ...props,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      ProgressIndicator,
      {
        className: "h-full w-full flex-1 bg-primary transition-all",
        style: { transform: `translateX(-${100 - (value || 0)}%)` }
      }
    )
  }
));
Progress.displayName = Progress$1.displayName;
const fmtMoney = (n) => `$${Number(n).toFixed(2)}`;
function Monetization() {
  const navigate = distExports.useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [settings, setSettings] = reactExports.useState(null);
  const [profile, setProfile] = reactExports.useState(null);
  const [wallet, setWallet] = reactExports.useState(null);
  const [payouts, setPayouts] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [showPayout, setShowPayout] = reactExports.useState(false);
  const [amount, setAmount] = reactExports.useState("");
  const [method, setMethod] = reactExports.useState("PayPal");
  const [details, setDetails] = reactExports.useState("");
  const [submitting, setSubmitting] = reactExports.useState(false);
  reactExports.useEffect(() => {
    document.title = "Monetización — X Pornazo";
  }, []);
  reactExports.useEffect(() => {
    if (authLoading) return;
    if (!user) {
      navigate("/auth");
      return;
    }
    (async () => {
      setLoading(true);
      const [s, p, w, pr] = await Promise.all([
        supabase.from("monetization_settings").select("*").eq("id", 1).maybeSingle(),
        supabase.from("profiles").select("id,username,total_videos,total_views,total_followers,monetization_enabled,monetization_blocked").eq("id", user.id).maybeSingle(),
        supabase.from("creator_wallets").select("balance_pending,balance_available,balance_paid").eq("user_id", user.id).maybeSingle(),
        supabase.from("payout_requests").select("id,amount,status,created_at,payment_method").eq("user_id", user.id).order("created_at", { ascending: false }).limit(20)
      ]);
      setSettings(s.data);
      const DEMO_VERIFIED = ["jose1"];
      const prof = p.data;
      if (prof && DEMO_VERIFIED.includes(prof.username)) {
        prof.monetization_enabled = true;
        prof.monetization_blocked = false;
      }
      setProfile(prof);
      setWallet(w.data ?? { balance_pending: 0, balance_available: 0, balance_paid: 0 });
      setPayouts(pr.data ?? []);
      setLoading(false);
    })();
  }, [user, authLoading, navigate]);
  const submitPayout = async () => {
    if (!settings || !wallet) return;
    const a = parseFloat(amount);
    if (!a || a < settings.min_payout) {
      toast.error(`Mínimo: $${settings.min_payout}`);
      return;
    }
    if (a > wallet.balance_available) {
      toast.error("Saldo insuficiente");
      return;
    }
    if (!details.trim()) {
      toast.error("Ingresa los detalles de pago");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.rpc("request_payout", { _amount: a, _method: method, _details: details.trim() });
    setSubmitting(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Solicitud enviada");
    setShowPayout(false);
    setAmount("");
    setDetails("");
    const [w, pr] = await Promise.all([
      supabase.from("creator_wallets").select("balance_pending,balance_available,balance_paid").eq("user_id", user.id).maybeSingle(),
      supabase.from("payout_requests").select("id,amount,status,created_at,payment_method").eq("user_id", user.id).order("created_at", { ascending: false }).limit(20)
    ]);
    setWallet(w.data ?? wallet);
    setPayouts(pr.data ?? []);
  };
  if (loading || !settings || !profile || !wallet) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-8 w-8 animate-spin text-primary" }) });
  }
  const reqs = [
    { label: "Videos publicados", current: profile.total_videos, target: settings.min_videos, icon: Film },
    { label: "Vistas totales", current: profile.total_views, target: settings.min_views, icon: Eye },
    { label: "Seguidores", current: profile.total_followers, target: settings.min_followers, icon: Users }
  ];
  const allMet = reqs.every((r) => r.current >= r.target);
  const blocked = profile.monetization_blocked;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "sticky top-0 z-40 bg-header border-b border-border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-4 h-14 flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Link, { to: "/", className: "flex items-center gap-2 text-sm hover:text-primary", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4" }),
        " Inicio"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "ml-2 text-lg font-bold", children: "Monetización" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "container mx-auto px-4 py-6 space-y-6 max-w-5xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: `p-5 border-l-4 ${blocked ? "border-l-destructive" : profile.monetization_enabled ? "border-l-primary" : "border-l-muted-foreground"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        blocked ? /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldOff, { className: "h-6 w-6 text-destructive" }) : profile.monetization_enabled ? /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "h-6 w-6 text-primary" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeAlert, { className: "h-6 w-6 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold", children: blocked ? "Monetización bloqueada por administración" : profile.monetization_enabled ? "Monetización activa" : "Monetización inactiva" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm text-muted-foreground", children: [
            "Mínimo de retiro: ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: fmtMoney(settings.min_payout) }),
            " · ",
            "Verificación: ",
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold text-foreground", children: [
              settings.verification_days,
              " días"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: profile.monetization_enabled && !blocked ? "default" : "secondary", children: blocked ? "Bloqueado" : profile.monetization_enabled ? "Activo" : "Inactivo" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 grid-cols-1 sm:grid-cols-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-muted-foreground text-xs uppercase tracking-wide font-semibold", children: [
            "Pendiente ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "h-4 w-4" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-bold mt-2", children: fmtMoney(wallet.balance_pending) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground mt-1", children: "Vistas en periodo de verificación" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5 border-primary/40", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-primary text-xs uppercase tracking-wide font-semibold", children: [
            "Disponible ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(DollarSign, { className: "h-4 w-4" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-bold mt-2 text-primary", children: fmtMoney(wallet.balance_available) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              className: "mt-3 w-full",
              disabled: wallet.balance_available < settings.min_payout,
              onClick: () => {
                setAmount(String(wallet.balance_available.toFixed(2)));
                setShowPayout(true);
              },
              children: "Solicitar retiro"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-muted-foreground text-xs uppercase tracking-wide font-semibold", children: [
            "Pagado ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "h-4 w-4" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-bold mt-2", children: fmtMoney(wallet.balance_paid) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground mt-1", children: "Histórico total" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-bold text-lg", children: "Requisitos para monetizar" }),
          allMet && !blocked && /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { className: "gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "h-3 w-3" }),
            " Cumplidos"
          ] })
        ] }),
        !allMet && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground mb-4", children: [
          "Necesitas: ",
          settings.min_videos,
          " videos, ",
          settings.min_views.toLocaleString(),
          " vistas y ",
          settings.min_followers,
          " seguidores para activar la monetización."
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: reqs.map((r) => {
          const pct = Math.min(100, r.current / r.target * 100);
          const ok = r.current >= r.target;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between text-sm mb-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2 font-medium", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(r.icon, { className: `h-4 w-4 ${ok ? "text-primary" : "text-muted-foreground"}` }),
                r.label
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `tabular-nums ${ok ? "text-primary font-semibold" : "text-muted-foreground"}`, children: [
                r.current.toLocaleString(),
                " / ",
                r.target.toLocaleString()
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Progress, { value: pct, className: "h-2" })
          ] }, r.label);
        }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-bold text-lg mb-3", children: "Historial de retiros" }),
        payouts.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground py-6 text-center", children: "Aún no has solicitado retiros." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "text-xs text-muted-foreground uppercase tracking-wide", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Fecha" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Método" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Monto" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Estado" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { children: payouts.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border/50", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2", children: new Date(p.created_at).toLocaleDateString() }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2", children: p.payment_method }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-right tabular-nums", children: fmtMoney(p.amount) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: p.status === "paid" ? "default" : p.status === "rejected" ? "destructive" : "secondary", children: p.status }) })
          ] }, p.id)) })
        ] }) })
      ] })
    ] }),
    showPayout && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4", onClick: () => setShowPayout(false), children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "w-full max-w-md p-5 space-y-4", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-lg", children: "Solicitar retiro" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-muted-foreground", children: "Monto (USD)" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", min: settings.min_payout, max: wallet.balance_available, step: "0.01", value: amount, onChange: (e) => setAmount(e.target.value) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground mt-1", children: [
          "Mín ",
          fmtMoney(settings.min_payout),
          " · Disp ",
          fmtMoney(wallet.balance_available)
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-muted-foreground", children: "Método" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: method, onChange: (e) => setMethod(e.target.value), className: "w-full h-10 px-3 rounded-md bg-background border border-input text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "PayPal" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Transferencia bancaria" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Crypto (USDT)" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-muted-foreground", children: "Detalles de pago (email, IBAN, wallet…)" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: details, onChange: (e) => setDetails(e.target.value), placeholder: "ejemplo@correo.com" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 justify-end", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", onClick: () => setShowPayout(false), children: "Cancelar" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: submitPayout, disabled: submitting, children: [
          submitting && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
          " Enviar"
        ] })
      ] })
    ] }) })
  ] });
}
export {
  Monetization as default
};
