import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as distExports } from "../_libs/react-router-dom.mjs";
import { s as supabase } from "./client-DChbXGiG.mjs";
import { u as useAuth, f as useIsAdmin, B as Button, I as Input } from "./router-wXGJZuFu.mjs";
import { C as Card } from "./card-D0OxL9-2.mjs";
import { B as Badge } from "./badge-DJOd9VwP.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import "../_libs/next-themes.mjs";
import { L as LoaderCircle, a1 as ShieldOff, x as ArrowLeft, h as ShieldCheck, a5 as RefreshCw, S as Search, B as BadgeCheck, D as DollarSign, X, a6 as CircleCheck } from "../_libs/lucide-react.mjs";
import "../_libs/react-router.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/cookie.mjs";
import "../_libs/set-cookie-parser.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/seroval.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/radix-ui__react-toast.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-tooltip.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__react-label.mjs";
function Admin() {
  const navigate = distExports.useNavigate();
  const { user, loading } = useAuth();
  const { isAdmin, checked } = useIsAdmin();
  const [tab, setTab] = reactExports.useState("users");
  const [profiles, setProfiles] = reactExports.useState([]);
  const [payouts, setPayouts] = reactExports.useState([]);
  const [fraud, setFraud] = reactExports.useState([]);
  const [settings, setSettings] = reactExports.useState(null);
  const [ledger, setLedger] = reactExports.useState([]);
  const [search, setSearch] = reactExports.useState("");
  reactExports.useEffect(() => {
    document.title = "Admin — X Pornazo";
  }, []);
  const loadAll = async () => {
    const [p, pr, fr, st, wl, ce] = await Promise.all([
      supabase.from("profiles").select("id,username,created_at,total_videos,total_views,total_followers,monetization_enabled,monetization_blocked,is_verified").order("total_views", { ascending: false }).limit(500),
      supabase.from("payout_requests").select("*").order("created_at", { ascending: false }).limit(100),
      supabase.from("video_views").select("id,video_id,ip_hash,rejection_reason,created_at,status").or("status.eq.rejected").order("created_at", { ascending: false }).limit(100),
      supabase.from("monetization_settings").select("*").eq("id", 1).maybeSingle(),
      supabase.from("creator_wallets").select("user_id,balance_pending,balance_available,balance_paid"),
      supabase.from("creator_earnings").select("id,user_id,video_id,verified_views,rate_per_view,amount,status,created_at").order("created_at", { ascending: false }).limit(500)
    ]);
    const earningsByUser = /* @__PURE__ */ new Map();
    (ce.data ?? []).forEach((e) => {
      earningsByUser.set(e.user_id, (earningsByUser.get(e.user_id) ?? 0) + Number(e.amount));
    });
    const walletByUser = /* @__PURE__ */ new Map();
    (wl.data ?? []).forEach((w) => {
      walletByUser.set(w.user_id, { p: Number(w.balance_pending), a: Number(w.balance_available), pa: Number(w.balance_paid) });
    });
    const merged = (p.data ?? []).map((row) => {
      const w = walletByUser.get(row.id);
      return {
        ...row,
        earnings_total: earningsByUser.get(row.id) ?? 0,
        balance_pending: w?.p ?? 0,
        balance_available: w?.a ?? 0,
        balance_paid: w?.pa ?? 0
      };
    });
    setProfiles(merged);
    const ledgerUserIds = Array.from(new Set((ce.data ?? []).map((x) => x.user_id)));
    const ledgerNameMap = /* @__PURE__ */ new Map();
    if (ledgerUserIds.length) {
      const { data: profs2 } = await supabase.from("profiles").select("id,username").in("id", ledgerUserIds);
      (profs2 ?? []).forEach((x) => ledgerNameMap.set(x.id, x.username));
    }
    setLedger((ce.data ?? []).map((x) => ({ ...x, username: ledgerNameMap.get(x.user_id) ?? null })));
    const userIds = Array.from(new Set((pr.data ?? []).map((x) => x.user_id)));
    const map = /* @__PURE__ */ new Map();
    if (userIds.length) {
      const { data: profs } = await supabase.from("profiles").select("id,username").in("id", userIds);
      (profs ?? []).forEach((x) => map.set(x.id, x.username));
    }
    setPayouts((pr.data ?? []).map((x) => ({ ...x, username: map.get(x.user_id) ?? null })));
    setFraud(fr.data ?? []);
    setSettings(st.data);
  };
  reactExports.useEffect(() => {
    if (loading || !checked) return;
    if (!user) {
      navigate("/auth");
      return;
    }
    if (!isAdmin) return;
    loadAll();
  }, [user, isAdmin, checked, loading, navigate]);
  if (loading || !checked) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-8 w-8 animate-spin text-primary" }) });
  }
  if (!isAdmin) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen flex flex-col items-center justify-center gap-3 text-center px-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldOff, { className: "h-12 w-12 text-muted-foreground" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-bold", children: "Acceso restringido" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Necesitas ser administrador para ver este panel." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Link, { to: "/", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { children: "Volver" }) })
    ] });
  }
  const toggleMon = async (p, enabled, blocked) => {
    const { error } = await supabase.rpc("admin_set_monetization", { _user_id: p.id, _enabled: enabled, _blocked: blocked });
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Actualizado");
    loadAll();
  };
  const toggleVerified = async (p) => {
    const { error } = await supabase.rpc("admin_set_verified", { _user_id: p.id, _verified: !p.is_verified });
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(p.is_verified ? "Verificación retirada" : "Cuenta verificada");
    loadAll();
  };
  const setPayoutStatus = async (id, status, notes = "") => {
    const { error } = await supabase.rpc("admin_set_payout_status", { _payout_id: id, _new_status: status, _notes: notes });
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Pago actualizado");
    loadAll();
  };
  const runVerify = async () => {
    const { data, error } = await supabase.rpc("verify_pending_views");
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`Verificado: ${JSON.stringify(data)}`);
    loadAll();
  };
  const saveSettings = async () => {
    if (!settings) return;
    const { error } = await supabase.from("monetization_settings").update({
      rate_per_view: settings.rate_per_view,
      min_payout: settings.min_payout,
      verification_days: settings.verification_days,
      min_videos: settings.min_videos,
      min_views: settings.min_views,
      min_followers: settings.min_followers,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", 1);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Ajustes guardados");
  };
  const filteredProfiles = profiles.filter((p) => p.username.toLowerCase().includes(search.toLowerCase()));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "sticky top-0 z-40 bg-header border-b border-border", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-4 h-14 flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Link, { to: "/", className: "flex items-center gap-2 text-sm hover:text-primary", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4" }),
          " Inicio"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "ml-2 text-lg font-bold flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "h-5 w-5 text-primary" }),
          " Panel Admin"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", onClick: runVerify, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "h-4 w-4" }),
          " Verificar vistas"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "border-t border-border bg-card", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container mx-auto px-4 h-10 flex items-center gap-6 text-sm font-medium", children: ["users", "ledger", "payouts", "fraud", "settings"].map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setTab(t), className: tab === t ? "text-primary" : "text-muted-foreground hover:text-primary", children: t === "users" ? "Usuarios" : t === "ledger" ? "Ganancias" : t === "payouts" ? "Pagos" : t === "fraud" ? "Fraude" : "Ajustes" }, t)) }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "container mx-auto px-4 py-6 max-w-6xl", children: [
      tab === "users" && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1 max-w-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "Buscar usuario…", value: search, onChange: (e) => setSearch(e.target.value), className: "pl-9" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "text-xs uppercase text-muted-foreground tracking-wide", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Usuario" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Registrado" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Videos" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Vistas" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Seguidores" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Ganado total" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Disponible" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-center py-2", children: "Estado" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Acciones" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { children: filteredProfiles.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border/50", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Link, { to: `/u/${p.username}`, className: "hover:text-primary font-medium inline-flex items-center gap-1", children: [
              "@",
              p.username,
              p.is_verified && /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "h-4 w-4 text-primary fill-primary/20" })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-xs text-muted-foreground", children: new Date(p.created_at).toLocaleDateString() }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-right tabular-nums", children: p.total_videos }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-right tabular-nums", children: p.total_views.toLocaleString() }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-right tabular-nums", children: p.total_followers }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-2 text-right tabular-nums font-medium", children: [
              "$",
              (p.earnings_total ?? 0).toFixed(2)
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-2 text-right tabular-nums text-primary", children: [
              "$",
              (p.balance_available ?? 0).toFixed(2)
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-center", children: p.monetization_blocked ? /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "destructive", children: "Bloqueado" }) : p.monetization_enabled ? /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { children: "Activo" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "secondary", children: "Inactivo" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-2 text-right space-x-1 whitespace-nowrap", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: p.is_verified ? "default" : "outline", onClick: () => toggleVerified(p), title: p.is_verified ? "Quitar verificación" : "Verificar", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "h-4 w-4" }),
                " ",
                p.is_verified ? "Verificado" : "Verificar"
              ] }),
              p.monetization_blocked ? /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "outline", onClick: () => toggleMon(p, false, false), children: "Desbloquear" }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "outline", onClick: () => toggleMon(p, !p.monetization_enabled, false), children: p.monetization_enabled ? "Desactivar" : "Activar" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "destructive", onClick: () => toggleMon(p, false, true), children: "Bloquear" })
              ] })
            ] })
          ] }, p.id)) })
        ] }) })
      ] }),
      tab === "ledger" && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-semibold mb-3 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(DollarSign, { className: "h-4 w-4 text-primary" }),
          " Historial de ganancias (ledger)"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "text-xs uppercase text-muted-foreground tracking-wide", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Fecha" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Usuario" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Video" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Vistas verif." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Tasa" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Monto" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-center py-2", children: "Estado" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
            ledger.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 7, className: "text-center py-8 text-muted-foreground", children: 'Sin movimientos. Ejecuta "Verificar vistas".' }) }),
            ledger.map((e) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border/50", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2", children: new Date(e.created_at).toLocaleString() }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2", children: e.username ? /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Link, { className: "hover:text-primary", to: `/u/${e.username}`, children: [
                "@",
                e.username
              ] }) : "—" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2", children: e.video_id ? /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Link, { to: `/v/${e.video_id}`, className: "hover:text-primary font-mono text-xs", children: [
                e.video_id.slice(0, 8),
                "…"
              ] }) : "—" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-right tabular-nums", children: e.verified_views.toLocaleString() }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-2 text-right tabular-nums text-xs text-muted-foreground", children: [
                "$",
                Number(e.rate_per_view).toFixed(4)
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-2 text-right tabular-nums font-medium", children: [
                "$",
                Number(e.amount).toFixed(2)
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: e.status === "available" ? "default" : e.status === "paid" ? "secondary" : "outline", children: e.status }) })
            ] }, e.id))
          ] })
        ] }) })
      ] }),
      tab === "payouts" && /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "text-xs uppercase text-muted-foreground tracking-wide", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Fecha" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Usuario" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Monto" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Método" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Detalles" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-center py-2", children: "Estado" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right py-2", children: "Acciones" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
          payouts.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 7, className: "text-center py-8 text-muted-foreground", children: "Sin solicitudes." }) }),
          payouts.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border/50", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2", children: new Date(p.created_at).toLocaleDateString() }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2", children: p.username ? /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Link, { className: "hover:text-primary", to: `/u/${p.username}`, children: [
              "@",
              p.username
            ] }) : "—" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-2 text-right tabular-nums", children: [
              "$",
              Number(p.amount).toFixed(2)
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2", children: p.payment_method }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 max-w-[200px] truncate", title: p.payment_details, children: p.payment_details }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: p.status === "paid" ? "default" : p.status === "rejected" ? "destructive" : "secondary", children: p.status }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-2 text-right space-x-1", children: [
              p.status === "pending" && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", onClick: () => setPayoutStatus(p.id, "approved"), children: "Aprobar" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "destructive", onClick: () => setPayoutStatus(p.id, "rejected", "Rechazado"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-3 w-3" }) })
              ] }),
              p.status === "approved" && /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", onClick: () => setPayoutStatus(p.id, "paid"), children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-4 w-4" }),
                " Marcar pagado"
              ] })
            ] })
          ] }, p.id))
        ] })
      ] }) }) }),
      tab === "fraud" && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold mb-3", children: "Vistas rechazadas recientes" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "text-xs uppercase text-muted-foreground tracking-wide", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Fecha" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Video" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "IP hash" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-left py-2", children: "Razón" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
            fraud.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 4, className: "text-center py-8 text-muted-foreground", children: "Sin vistas rechazadas." }) }),
            fraud.map((f) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border/50", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2", children: new Date(f.created_at).toLocaleString() }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Link, { to: `/v/${f.video_id}`, className: "hover:text-primary", children: [
                f.video_id.slice(0, 8),
                "…"
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-2 font-mono text-xs", children: [
                f.ip_hash.slice(0, 12),
                "…"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "destructive", children: f.rejection_reason ?? "—" }) })
            ] }, f.id))
          ] })
        ] }) })
      ] }),
      tab === "settings" && settings && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "p-5 max-w-xl space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold", children: "Configuración global" }),
        [
          { k: "rate_per_view", l: "Tasa por vista (USD)", step: "0.0001" },
          { k: "min_payout", l: "Mínimo retiro (USD)", step: "1" },
          { k: "verification_days", l: "Días de verificación", step: "1" },
          { k: "min_videos", l: "Mínimo de videos", step: "1" },
          { k: "min_views", l: "Mínimo de vistas", step: "1" },
          { k: "min_followers", l: "Mínimo de seguidores", step: "1" }
        ].map(({ k, l, step }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-muted-foreground", children: l }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Input,
            {
              type: "number",
              step,
              value: settings[k],
              onChange: (e) => setSettings({ ...settings, [k]: parseFloat(e.target.value) })
            }
          )
        ] }, k)),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: saveSettings, children: "Guardar" })
      ] })
    ] })
  ] });
}
export {
  Admin as default
};
