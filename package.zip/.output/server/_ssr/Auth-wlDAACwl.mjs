import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as distExports } from "../_libs/react-router-dom.mjs";
import { s as supabase } from "./client-DChbXGiG.mjs";
import { I as Input, B as Button, c as cn } from "./router-wXGJZuFu.mjs";
import { $ as $t, N as Nt } from "../_libs/input-otp.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import "../_libs/next-themes.mjs";
import { X, E as Eye, r as EyeOff, L as LoaderCircle, s as Dot } from "../_libs/lucide-react.mjs";
import "../_libs/react-router.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/cookie.mjs";
import "../_libs/set-cookie-parser.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/seroval.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/radix-ui__react-toast.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-tooltip.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__react-label.mjs";
const InputOTP = reactExports.forwardRef(
  ({ className, containerClassName, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
    $t,
    {
      ref,
      containerClassName: cn("flex items-center gap-2 has-[:disabled]:opacity-50", containerClassName),
      className: cn("disabled:cursor-not-allowed", className),
      ...props
    }
  )
);
InputOTP.displayName = "InputOTP";
const InputOTPGroup = reactExports.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref, className: cn("flex items-center", className), ...props })
);
InputOTPGroup.displayName = "InputOTPGroup";
const InputOTPSlot = reactExports.forwardRef(({ index, className, ...props }, ref) => {
  const inputOTPContext = reactExports.useContext(Nt);
  const { char, hasFakeCaret, isActive } = inputOTPContext.slots[index];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      ref,
      className: cn(
        "relative flex h-10 w-10 items-center justify-center border-y border-r border-input text-sm transition-all first:rounded-l-md first:border-l last:rounded-r-md",
        isActive && "z-10 ring-2 ring-ring ring-offset-background",
        className
      ),
      ...props,
      children: [
        char,
        hasFakeCaret && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute inset-0 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "animate-caret-blink h-4 w-px bg-foreground duration-1000" }) })
      ]
    }
  );
});
InputOTPSlot.displayName = "InputOTPSlot";
const InputOTPSeparator = reactExports.forwardRef(
  ({ ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref, role: "separator", ...props, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Dot, {}) })
);
InputOTPSeparator.displayName = "InputOTPSeparator";
const Auth = () => {
  const navigate = distExports.useNavigate();
  const [mode, setMode] = reactExports.useState("login");
  const [email, setEmail] = reactExports.useState("");
  const [password, setPassword] = reactExports.useState("");
  const [username, setUsername] = reactExports.useState("");
  const [loading, setLoading] = reactExports.useState(false);
  const [otpOpen, setOtpOpen] = reactExports.useState(false);
  const [otp, setOtp] = reactExports.useState("");
  const [verifying, setVerifying] = reactExports.useState(false);
  const [resending, setResending] = reactExports.useState(false);
  const [showPwd, setShowPwd] = reactExports.useState(false);
  const [sendingReset, setSendingReset] = reactExports.useState(false);
  reactExports.useEffect(() => {
    document.title = "Iniciar sesión — X Pornazo";
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) navigate("/", { replace: true });
    });
  }, [navigate]);
  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/`,
            data: { username: username.trim() || void 0 }
          }
        });
        if (error) throw error;
        toast.success("¡Cuenta creada!");
        navigate("/", { replace: true });
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        if (!data.session) throw new Error("No se pudo iniciar sesión. Inténtalo de nuevo.");
        toast.success("¡Bienvenido!");
        setTimeout(() => navigate("/", { replace: true }), 50);
      }
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };
  const verifyOtp = async (code) => {
    setVerifying(true);
    try {
      const { error } = await supabase.auth.verifyOtp({ email, token: code, type: "signup" });
      if (error) throw error;
      toast.success("¡Cuenta verificada!");
      setOtpOpen(false);
      navigate("/");
    } catch (err) {
      toast.error(err.message);
      setOtp("");
    } finally {
      setVerifying(false);
    }
  };
  const resend = async () => {
    setResending(true);
    try {
      const { error } = await supabase.auth.resend({ type: "signup", email });
      if (error) throw error;
      toast.success("Reenviado");
    } catch (err) {
      toast.error(err.message);
    } finally {
      setResending(false);
    }
  };
  const forgotPassword = async () => {
    if (!email) {
      toast.error("Introduce tu correo para recuperar la contraseña");
      return;
    }
    setSendingReset(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth`
      });
      if (error) throw error;
      toast.success("Te enviamos un enlace para restablecer tu contraseña");
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSendingReset(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen flex items-center justify-center p-4 bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-sm bg-card rounded-xl p-7 sm:p-8 border border-border shadow-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => navigate(-1),
          className: "absolute right-3 top-3 p-1 text-muted-foreground hover:text-foreground",
          "aria-label": "Cerrar",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-5 w-5" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Link, { to: "/", className: "flex items-center gap-1 justify-center mb-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-3xl font-extrabold text-primary leading-none", children: "X" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-md bg-primary px-2 py-0.5 text-2xl font-extrabold text-primary-foreground leading-none", children: "Pornazo" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-center text-xl sm:text-2xl font-bold mb-1", children: mode === "login" ? "Iniciar sesión de miembro" : "Crear cuenta nueva" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-center text-sm text-muted-foreground mb-6", children: mode === "login" ? "Accede a tu cuenta de X Pornazo" : "Únete a la comunidad de X Pornazo" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: submit, className: "space-y-3", children: [
        mode === "signup" && /* @__PURE__ */ jsxRuntimeExports.jsx(
          Input,
          {
            placeholder: "Nombre de usuario",
            value: username,
            onChange: (e) => setUsername(e.target.value),
            required: true,
            className: "h-12 bg-secondary/60 border-border rounded-md"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Input,
          {
            type: "email",
            placeholder: "Correo electrónico",
            value: email,
            onChange: (e) => setEmail(e.target.value),
            required: true,
            className: "h-12 bg-secondary/60 border-border rounded-md"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Input,
            {
              type: showPwd ? "text" : "password",
              placeholder: "Contraseña",
              value: password,
              onChange: (e) => setPassword(e.target.value),
              required: true,
              minLength: 6,
              className: "h-12 pr-11 bg-secondary/60 border-border rounded-md"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setShowPwd((v) => !v),
              className: "absolute right-3 top-1/2 -translate-y-1/2 p-1 text-muted-foreground hover:text-foreground",
              "aria-label": showPwd ? "Ocultar contraseña" : "Mostrar contraseña",
              children: showPwd ? /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-4 w-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "h-4 w-4" })
            }
          )
        ] }),
        mode === "login" && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: forgotPassword,
            disabled: sendingReset,
            className: "block text-sm text-foreground/80 hover:text-primary text-left pt-1",
            children: sendingReset ? "Enviando…" : "¿Olvidó su contraseña?"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3 pt-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              type: "button",
              variant: "outline",
              size: "lg",
              onClick: () => navigate(-1),
              className: "h-12 rounded-md font-semibold",
              children: "Volver"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              type: "submit",
              disabled: loading,
              size: "lg",
              className: "h-12 rounded-md font-semibold",
              children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : mode === "login" ? "Entrar" : "Crear cuenta"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-center text-sm text-muted-foreground", children: mode === "login" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "¿Aún no tienes una cuenta?",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setMode("signup"),
            className: "text-primary font-semibold hover:underline",
            children: "Registrarse aquí"
          }
        )
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "¿Ya tienes una cuenta?",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setMode("login"),
            className: "text-primary font-semibold hover:underline",
            children: "Inicia sesión"
          }
        )
      ] }) })
    ] }),
    otpOpen && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-sm rounded-2xl border border-border bg-card p-8 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => setOtpOpen(false),
          className: "absolute right-4 top-4 text-muted-foreground hover:text-foreground",
          "aria-label": "Cerrar",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-5 w-5" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 flex items-center justify-center gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl font-extrabold", children: "X" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-md bg-primary px-2 py-0.5 text-2xl font-extrabold text-primary-foreground", children: "Pornazo" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mb-4 text-lg font-bold", children: "Confirme su correo electrónico" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Se envió un código de verificación a:" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 mb-4 text-sm font-semibold uppercase tracking-wide", children: email }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mb-5 text-sm text-muted-foreground", children: [
        "Introdúzcalo a continuación para verificar",
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        " su cuenta"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-5 flex justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        InputOTP,
        {
          maxLength: 6,
          value: otp,
          onChange: (v) => {
            setOtp(v);
            if (v.length === 6) verifyOtp(v);
          },
          disabled: verifying,
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(InputOTPGroup, { children: [0, 1, 2, 3, 4, 5].map((i) => /* @__PURE__ */ jsxRuntimeExports.jsx(InputOTPSlot, { index: i, className: "h-11 w-11 text-lg" }, i)) })
        }
      ) }),
      verifying && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "mx-auto mb-3 h-4 w-4 animate-spin text-muted-foreground" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground", children: [
        "¿No recibiste un código?",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: resend,
            disabled: resending,
            className: "text-primary underline underline-offset-2 hover:opacity-80",
            children: "Reenviar"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "o",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => setOtpOpen(false),
            className: "text-primary underline underline-offset-2 hover:opacity-80",
            children: "Cambiar el correo electrónico"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-5 text-xs text-muted-foreground", children: "Necesitas confirmar tu dirección de correo electrónico dentro de 15 días, o tu cuenta será eliminada." })
    ] }) })
  ] });
};
export {
  Auth as default
};
