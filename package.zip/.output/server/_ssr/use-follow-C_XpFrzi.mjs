import { r as reactExports } from "../_libs/react.mjs";
import { s as supabase } from "./client-DChbXGiG.mjs";
import { u as useAuth } from "./router-wXGJZuFu.mjs";
function useFollow(targetUserId) {
  const { user } = useAuth();
  const [isFollowing, setIsFollowing] = reactExports.useState(false);
  const [loading, setLoading] = reactExports.useState(false);
  const [count, setCount] = reactExports.useState(0);
  reactExports.useEffect(() => {
    if (!targetUserId) return;
    (async () => {
      const { count: c } = await supabase.from("follows").select("*", { count: "exact", head: true }).eq("followed_id", targetUserId);
      setCount(c ?? 0);
      if (user) {
        const { data } = await supabase.from("follows").select("follower_id").eq("follower_id", user.id).eq("followed_id", targetUserId).maybeSingle();
        setIsFollowing(!!data);
      }
    })();
  }, [targetUserId, user]);
  const toggle = async () => {
    if (!user || !targetUserId || user.id === targetUserId) return;
    setLoading(true);
    if (isFollowing) {
      const { error } = await supabase.from("follows").delete().eq("follower_id", user.id).eq("followed_id", targetUserId);
      if (!error) {
        setIsFollowing(false);
        setCount((c) => Math.max(0, c - 1));
      }
    } else {
      const { error } = await supabase.from("follows").insert({
        follower_id: user.id,
        followed_id: targetUserId
      });
      if (!error) {
        setIsFollowing(true);
        setCount((c) => c + 1);
      }
    }
    setLoading(false);
  };
  return { isFollowing, count, loading, toggle, canFollow: !!user && user.id !== targetUserId };
}
export {
  useFollow as u
};
