import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useAuth, B as Button, S as SignedImg, I as Input, V as VideoCard, L as Label, T as Textarea } from "./router-wXGJZuFu.mjs";
import { d as distExports } from "../_libs/react-router-dom.mjs";
import { s as supabase } from "./client-DChbXGiG.mjs";
import { u as useFollow } from "./use-follow-C_XpFrzi.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import "../_libs/next-themes.mjs";
import { L as LoaderCircle, G as Globe, t as Instagram, u as Twitter, v as Music2, Y as Youtube, w as Link, p as Send, x as ArrowLeft, g as ChartColumn, y as Coins, z as LogOut, U as User, c as Upload, B as BadgeCheck, a as Pencil, J as MapPin, R as Rss, l as MessageCircle, K as Film } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/seroval.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/radix-ui__react-toast.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-tooltip.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/react-router.mjs";
import "../_libs/cookie.mjs";
import "../_libs/set-cookie-parser.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
const SOCIALS = [
  { key: "website_url", label: "Sitio web", placeholder: "https://tu-sitio.com", icon: Globe },
  { key: "instagram_url", label: "Instagram", placeholder: "https://instagram.com/usuario", icon: Instagram },
  { key: "twitter_url", label: "X / Twitter", placeholder: "https://x.com/usuario", icon: Twitter },
  { key: "tiktok_url", label: "TikTok", placeholder: "https://tiktok.com/@usuario", icon: Music2 },
  { key: "youtube_url", label: "YouTube", placeholder: "https://youtube.com/@canal", icon: Youtube },
  { key: "onlyfans_url", label: "OnlyFans", placeholder: "https://onlyfans.com/usuario", icon: Link },
  { key: "telegram_url", label: "Telegram", placeholder: "https://t.me/usuario", icon: Send }
];
function formatNumber(n) {
  if (n < 1e3) return n.toString();
  if (n < 1e6) return (n / 1e3).toFixed(n < 1e4 ? 1 : 0) + "K";
  if (n < 1e9) return (n / 1e6).toFixed(1) + "M";
  return (n / 1e9).toFixed(1) + "B";
}
function normalizeUrl(v) {
  const t = v.trim();
  if (!t) return "";
  if (/^https?:\/\//i.test(t)) return t;
  return `https://${t}`;
}
const Profile = () => {
  const { username = "" } = distExports.useParams();
  const navigate = distExports.useNavigate();
  const { user, profile, setProfile } = useAuth();
  const [target, setTarget] = reactExports.useState(null);
  const [videos, setVideos] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [editingName, setEditingName] = reactExports.useState(false);
  const [newName, setNewName] = reactExports.useState("");
  const [uploadingAvatar, setUploadingAvatar] = reactExports.useState(false);
  const fileInput = reactExports.useRef(null);
  const [tab, setTab] = reactExports.useState("videos");
  const { isFollowing, count: followers, loading: followLoading, toggle, canFollow } = useFollow(target?.id);
  const [followingCount, setFollowingCount] = reactExports.useState(0);
  reactExports.useEffect(() => {
    if (!target?.id) return;
    (async () => {
      const { count } = await supabase.from("follows").select("*", { count: "exact", head: true }).eq("follower_id", target.id);
      setFollowingCount(count ?? 0);
    })();
  }, [target?.id]);
  const [editingAbout, setEditingAbout] = reactExports.useState(false);
  const [savingAbout, setSavingAbout] = reactExports.useState(false);
  const [form, setForm] = reactExports.useState({
    bio: "",
    location: "",
    website_url: "",
    instagram_url: "",
    twitter_url: "",
    tiktok_url: "",
    youtube_url: "",
    onlyfans_url: "",
    telegram_url: ""
  });
  reactExports.useEffect(() => {
    document.title = `@${username} — X Pornazo`;
    (async () => {
      setLoading(true);
      const { data: p } = await supabase.from("profiles").select("*").eq("username", username).maybeSingle();
      if (!p) {
        setLoading(false);
        return;
      }
      const row = p;
      setTarget(row);
      setNewName(row.username);
      setForm({
        bio: row.bio ?? "",
        location: row.location ?? "",
        website_url: row.website_url ?? "",
        instagram_url: row.instagram_url ?? "",
        twitter_url: row.twitter_url ?? "",
        tiktok_url: row.tiktok_url ?? "",
        youtube_url: row.youtube_url ?? "",
        onlyfans_url: row.onlyfans_url ?? "",
        telegram_url: row.telegram_url ?? ""
      });
      const { data: vs } = await supabase.from("videos").select("id,title,description,video_url,views,created_at,user_id,tags,duration_seconds,monetized").eq("user_id", row.id).order("created_at", { ascending: false });
      const mapped = (vs ?? []).map((v) => ({
        ...v,
        uploader: { username: row.username, avatar_url: row.avatar_url }
      }));
      setVideos(mapped);
      setLoading(false);
    })();
  }, [username]);
  const isOwn = !!(user && target && user.id === target.id);
  const handleAvatar = async (e) => {
    const f = e.target.files?.[0];
    if (!f || !user) return;
    setUploadingAvatar(true);
    try {
      const ext = f.name.split(".").pop();
      const path = `${user.id}/avatar-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("avatars").upload(path, f, { contentType: f.type, upsert: true });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("avatars").getPublicUrl(path);
      const { error } = await supabase.from("profiles").update({ avatar_url: pub.publicUrl }).eq("id", user.id);
      if (error) throw error;
      setTarget({ ...target, avatar_url: pub.publicUrl });
      if (profile) setProfile({ ...profile, avatar_url: pub.publicUrl });
      toast.success("Foto actualizada");
    } catch (err) {
      toast.error(err.message);
    } finally {
      setUploadingAvatar(false);
    }
  };
  const handleSaveName = async () => {
    if (!user || !newName.trim()) return;
    const clean = newName.trim().toLowerCase().replace(/[^a-z0-9_]/g, "");
    if (!clean) {
      toast.error("Nombre inválido");
      return;
    }
    const { error } = await supabase.from("profiles").update({ username: clean }).eq("id", user.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    if (profile) setProfile({ ...profile, username: clean });
    toast.success("Nombre actualizado");
    setEditingName(false);
    navigate(`/u/${clean}`, { replace: true });
  };
  const handleSaveAbout = async () => {
    if (!user || !target) return;
    setSavingAbout(true);
    const payload = {
      bio: form.bio.trim() || null,
      location: form.location.trim() || null
    };
    for (const s of SOCIALS) {
      const v = form[s.key].trim();
      payload[s.key] = v ? normalizeUrl(v) : null;
    }
    const { error } = await supabase.from("profiles").update(payload).eq("id", user.id);
    setSavingAbout(false);
    if (error) {
      toast.error(error.message.includes("column") ? "Falta ejecutar la migración SQL en Supabase." : error.message);
      return;
    }
    setTarget({ ...target, ...payload });
    setEditingAbout(false);
    toast.success("Perfil actualizado");
  };
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-8 w-8 animate-spin text-primary" }) });
  }
  if (!target) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen flex flex-col items-center justify-center gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "Usuario no encontrado." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Link, { to: "/", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { children: "Volver" }) })
    ] });
  }
  const joined = new Date(target.created_at).toLocaleDateString(void 0, { year: "numeric", month: "long" });
  const activeSocials = SOCIALS.filter((s) => target[s.key]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "sticky top-0 z-40 bg-header border-b border-border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-4 h-14 flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Link, { to: "/", className: "flex items-center gap-2 text-sm hover:text-primary", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4" }),
        " Inicio"
      ] }),
      isOwn && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ml-auto flex items-center gap-1.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Link, { to: "/stats", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            variant: "ghost",
            size: "sm",
            className: "h-9 px-3 gap-2 rounded-full border border-border/60 bg-card/40 backdrop-blur-sm text-foreground/90 hover:bg-card hover:border-primary/40 hover:text-foreground transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ChartColumn, { className: "h-4 w-4 text-primary" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium tracking-tight", children: "Estadísticas" })
            ]
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Link, { to: "/monetization", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            variant: "ghost",
            size: "sm",
            className: "h-9 px-3 gap-2 rounded-full border border-border/60 bg-card/40 backdrop-blur-sm text-foreground/90 hover:bg-card hover:border-primary/40 hover:text-foreground transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Coins, { className: "h-4 w-4 text-primary" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium tracking-tight", children: "Monetización" })
            ]
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            variant: "ghost",
            size: "sm",
            onClick: async () => {
              await supabase.auth.signOut();
              navigate("/");
            },
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4" }),
              " Salir"
            ]
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "container mx-auto px-4 pt-6 md:pt-8 pb-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-5xl mx-auto bg-card border border-border rounded-2xl overflow-hidden shadow-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-40 sm:h-56 md:h-64 bg-secondary", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "absolute inset-0",
            style: {
              background: "radial-gradient(ellipse at 20% 30%, hsl(var(--primary) / 0.55), transparent 60%), radial-gradient(ellipse at 80% 60%, hsl(var(--primary) / 0.25), transparent 65%), linear-gradient(135deg, #101010, #1c1c1c)"
            }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-card via-card/20 to-transparent" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 sm:px-8 md:px-10 pb-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex flex-col sm:flex-row sm:items-end justify-between -mt-14 sm:-mt-16 gap-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-4 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative shrink-0 w-fit", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-28 h-28 sm:w-32 sm:h-32 rounded-2xl bg-secondary overflow-hidden flex items-center justify-center ring-4 ring-card shadow-xl", children: target.avatar_url ? /* @__PURE__ */ jsxRuntimeExports.jsx(SignedImg, { src: target.avatar_url, alt: target.username, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-12 w-12 text-muted-foreground" }) }),
              isOwn && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    onClick: () => fileInput.current?.click(),
                    disabled: uploadingAvatar,
                    className: "absolute -bottom-1 -right-1 bg-primary text-primary-foreground rounded-full p-2 shadow-lg hover:scale-110 transition-transform",
                    "aria-label": "Cambiar foto",
                    children: uploadingAvatar ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("input", { ref: fileInput, type: "file", accept: "image/*", className: "hidden", onChange: handleAvatar })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-w-0", children: editingName ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: newName, onChange: (e) => setNewName(e.target.value), className: "max-w-xs" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", onClick: handleSaveName, children: "Guardar" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "ghost", onClick: () => setEditingName(false), children: "Cancelar" })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 flex-wrap", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl md:text-4xl font-bold text-foreground tracking-tight truncate", children: target.username }),
                target.is_verified && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline-flex items-center justify-center w-6 h-6 bg-primary rounded-full", "aria-label": "Verificado", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "w-4 h-4 text-primary-foreground" }) }),
                isOwn && /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "ghost", className: "h-7 px-2 text-xs", onClick: () => setEditingName(true), children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-3 w-3" }),
                  " Editar"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground mt-1 font-medium", children: [
                "@",
                target.username,
                " · Miembro desde ",
                joined,
                target.location ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                  " · ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "inline h-3.5 w-3.5 -mt-0.5" }),
                  " ",
                  target.location
                ] }) : null
              ] })
            ] }) })
          ] }),
          !isOwn && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 items-center sm:mb-1 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                onClick: toggle,
                disabled: !canFollow || followLoading,
                size: "sm",
                className: `px-6 h-10 rounded-full font-semibold text-sm shadow-lg ${isFollowing ? "bg-secondary hover:bg-secondary/80 text-foreground border border-border" : "bg-primary hover:bg-primary/90 text-primary-foreground shadow-primary/20"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Rss, { className: "h-4 w-4" }),
                  isFollowing ? "Siguiendo" : "Seguir"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Button,
              {
                variant: "outline",
                size: "icon",
                disabled: true,
                className: "h-10 w-10 rounded-full bg-secondary/60 border border-border opacity-70",
                "aria-label": "Mensaje",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "h-4 w-4" })
              }
            )
          ] })
        ] }),
        target.bio && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm sm:text-base leading-relaxed text-foreground/85 max-w-2xl whitespace-pre-wrap", children: target.bio }) }),
        activeSocials.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-5 flex flex-wrap gap-2", children: activeSocials.map(({ key, label, icon: Icon }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: target[key],
            target: "_blank",
            rel: "noopener noreferrer",
            className: "inline-flex items-center gap-1.5 text-xs font-medium bg-secondary/60 hover:bg-secondary border border-border rounded-full px-3 py-1.5 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-3.5 w-3.5 text-primary" }),
              label
            ]
          },
          key
        )) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-7 flex flex-wrap gap-x-10 gap-y-4 items-center py-4 border-y border-border", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(StatInline, { value: formatNumber(followers), label: "Seguidores" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(StatInline, { value: formatNumber(followingCount), label: "Siguiendo" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(StatInline, { value: formatNumber(videos.length || target.total_videos), label: "Videos" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(StatInline, { value: formatNumber(target.total_views), label: "Reproducciones" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex gap-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TabBtn, { active: tab === "videos", onClick: () => setTab("videos"), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Film, { className: "h-4 w-4" }),
            " Videos"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TabBtn, { active: tab === "about", onClick: () => setTab("about"), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-4 w-4" }),
            " Acerca de"
          ] })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "container mx-auto px-4 py-6", children: [
      tab === "videos" && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-baseline justify-between mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-bold", children: [
            "Videos de ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-primary", children: target.username })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-muted-foreground", children: [
            "Mostrando ",
            videos.length,
            " ",
            videos.length === 1 ? "video" : "videos"
          ] })
        ] }),
        videos.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-20 text-center border border-dashed border-border rounded-lg", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Film, { className: "h-10 w-10 text-muted-foreground mx-auto mb-2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "Aún no hay videos publicados." })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-5 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4", children: videos.map((v) => /* @__PURE__ */ jsxRuntimeExports.jsx(VideoCard, { video: v }, v.id)) })
      ] }),
      tab === "about" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid md:grid-cols-3 gap-6 max-w-5xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "md:col-span-2 bg-card border border-border rounded-lg p-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between mb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-lg font-bold", children: [
              "Acerca de ",
              target.username
            ] }),
            isOwn && !editingAbout && /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", variant: "outline", onClick: () => setEditingAbout(true), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-3.5 w-3.5" }),
              " Editar"
            ] })
          ] }),
          editingAbout ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "bio", children: "Biografía" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Textarea,
                {
                  id: "bio",
                  value: form.bio,
                  maxLength: 500,
                  rows: 4,
                  onChange: (e) => setForm({ ...form, bio: e.target.value }),
                  placeholder: "Cuéntale a tus seguidores sobre ti..."
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[11px] text-muted-foreground mt-1", children: [
                form.bio.length,
                "/500"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "location", children: "Ubicación" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  id: "location",
                  value: form.location,
                  maxLength: 80,
                  onChange: (e) => setForm({ ...form, location: e.target.value }),
                  placeholder: "Ciudad, país"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 pt-2 border-t border-border", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold", children: "Enlaces y redes" }),
              SOCIALS.map(({ key, label, placeholder, icon: Icon }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { htmlFor: key, className: "flex items-center gap-1.5 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-3.5 w-3.5 text-primary" }),
                  " ",
                  label
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Input,
                  {
                    id: key,
                    value: form[key],
                    onChange: (e) => setForm({ ...form, [key]: e.target.value }),
                    placeholder,
                    maxLength: 300
                  }
                )
              ] }, key))
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 pt-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: handleSaveAbout, disabled: savingAbout, children: [
                savingAbout && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
                " Guardar"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", onClick: () => setEditingAbout(false), disabled: savingAbout, children: "Cancelar" })
            ] })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            target.bio ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-foreground/90 leading-relaxed whitespace-pre-wrap", children: target.bio }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground italic", children: isOwn ? "Aún no has añadido una biografía. Pulsa Editar para presentarte." : "Este creador aún no ha añadido una biografía." }),
            activeSocials.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 pt-5 border-t border-border", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold mb-3", children: "Enlaces" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid sm:grid-cols-2 gap-2", children: activeSocials.map(({ key, label, icon: Icon }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "a",
                {
                  href: target[key],
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "flex items-center gap-2 text-sm bg-secondary/40 hover:bg-secondary border border-border rounded-md px-3 py-2 transition-colors group",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-4 w-4 text-primary shrink-0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", children: label }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-auto text-xs text-muted-foreground truncate max-w-[160px] group-hover:text-foreground", children: target[key].replace(/^https?:\/\//, "") })
                  ]
                },
                key
              )) })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { className: "bg-card border border-border rounded-lg p-6 space-y-3 text-sm h-fit", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "Usuario", value: `@${target.username}` }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "Miembro desde", value: joined }),
          target.location && /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "Ubicación", value: target.location }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "Reproducciones", value: formatNumber(target.total_views) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "Seguidores", value: formatNumber(followers) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "Videos", value: String(videos.length) })
        ] })
      ] })
    ] })
  ] });
};
const StatInline = ({ value, label }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground font-bold text-xl leading-none", children: value }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground text-[10px] uppercase tracking-[0.15em] font-semibold mt-1.5", children: label })
] });
const TabBtn = ({ active, onClick, children }) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  "button",
  {
    onClick,
    className: `flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 -mb-px transition-colors ${active ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`,
    children
  }
);
const Row = ({ label, value }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between gap-3 border-b border-border/60 pb-2 last:border-0", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: label }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-right", children: value })
] });
export {
  Profile as default
};
