import { Q as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { Q as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { c as createRouter, a as createRootRouteWithContext, b as createFileRoute, l as lazyRouteComponent, H as HeadContent, S as Scripts, u as useRouter, L as Link } from "../_libs/tanstack__react-router.mjs";
import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as distExports } from "../_libs/react-router-dom.mjs";
import { z } from "../_libs/next-themes.mjs";
import { t as toast$1, T as Toaster$2 } from "../_libs/sonner.mjs";
import { T as ToastViewport$1, a as Toast$1, b as ToastAction$1, c as ToastClose$1, d as ToastTitle$1, e as ToastDescription$1, f as ToastProvider$1 } from "../_libs/radix-ui__react-toast.mjs";
import { c as cva } from "../_libs/class-variance-authority.mjs";
import { c as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { T as TooltipContent$1, a as TooltipProvider$1 } from "../_libs/radix-ui__react-tooltip.mjs";
import { s as supabase } from "./client-DChbXGiG.mjs";
import { S as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { D as DialogOverlay$1, a as DialogPortal$1, b as DialogContent$1, c as DialogClose, d as DialogTitle$1, e as DialogDescription$1, f as Dialog$1 } from "../_libs/radix-ui__react-dialog.mjs";
import { S as Switch$1, a as SwitchThumb } from "../_libs/radix-ui__react-switch.mjs";
import { L as Label$1 } from "../_libs/radix-ui__react-label.mjs";
import { X, P as Play, a as Pencil, E as Eye, U as User, C as Clock, I as Image, L as LoaderCircle, T as Trash2, b as Cookie, M as Menu, S as Search, c as Upload, V as Video, d as Camera, e as LogIn, f as ChevronDown, g as ChartColumn, D as DollarSign, h as ShieldCheck, i as Star, j as Compass, Z as Zap, k as Sparkles, A as Award, F as Flame, H as Heart, l as MessageCircle, m as ChevronLeft, n as ChevronRight, W as WandSparkles, o as ImagePlus, p as Send, q as ThumbsUp, B as BadgeCheck } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/seroval.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/react-router.mjs";
import "../_libs/cookie.mjs";
import "../_libs/set-cookie-parser.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
const appCss = "/assets/styles-BDIS4Z8o.css";
const Toaster$1 = ({ ...props }) => {
  const { theme = "system" } = z();
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Toaster$2,
    {
      theme,
      className: "toaster group",
      toastOptions: {
        classNames: {
          toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
        }
      },
      ...props
    }
  );
};
const TOAST_LIMIT = 1;
const TOAST_REMOVE_DELAY = 1e6;
let count = 0;
function genId() {
  count = (count + 1) % Number.MAX_SAFE_INTEGER;
  return count.toString();
}
const toastTimeouts = /* @__PURE__ */ new Map();
const addToRemoveQueue = (toastId) => {
  if (toastTimeouts.has(toastId)) {
    return;
  }
  const timeout = setTimeout(() => {
    toastTimeouts.delete(toastId);
    dispatch({
      type: "REMOVE_TOAST",
      toastId
    });
  }, TOAST_REMOVE_DELAY);
  toastTimeouts.set(toastId, timeout);
};
const reducer = (state2, action) => {
  switch (action.type) {
    case "ADD_TOAST":
      return {
        ...state2,
        toasts: [action.toast, ...state2.toasts].slice(0, TOAST_LIMIT)
      };
    case "UPDATE_TOAST":
      return {
        ...state2,
        toasts: state2.toasts.map((t) => t.id === action.toast.id ? { ...t, ...action.toast } : t)
      };
    case "DISMISS_TOAST": {
      const { toastId } = action;
      if (toastId) {
        addToRemoveQueue(toastId);
      } else {
        state2.toasts.forEach((toast2) => {
          addToRemoveQueue(toast2.id);
        });
      }
      return {
        ...state2,
        toasts: state2.toasts.map(
          (t) => t.id === toastId || toastId === void 0 ? {
            ...t,
            open: false
          } : t
        )
      };
    }
    case "REMOVE_TOAST":
      if (action.toastId === void 0) {
        return {
          ...state2,
          toasts: []
        };
      }
      return {
        ...state2,
        toasts: state2.toasts.filter((t) => t.id !== action.toastId)
      };
  }
};
const listeners$1 = [];
let memoryState = { toasts: [] };
function dispatch(action) {
  memoryState = reducer(memoryState, action);
  listeners$1.forEach((listener) => {
    listener(memoryState);
  });
}
function toast({ ...props }) {
  const id = genId();
  const update = (props2) => dispatch({
    type: "UPDATE_TOAST",
    toast: { ...props2, id }
  });
  const dismiss = () => dispatch({ type: "DISMISS_TOAST", toastId: id });
  dispatch({
    type: "ADD_TOAST",
    toast: {
      ...props,
      id,
      open: true,
      onOpenChange: (open) => {
        if (!open) dismiss();
      }
    }
  });
  return {
    id,
    dismiss,
    update
  };
}
function useToast() {
  const [state2, setState2] = reactExports.useState(memoryState);
  reactExports.useEffect(() => {
    listeners$1.push(setState2);
    return () => {
      const index = listeners$1.indexOf(setState2);
      if (index > -1) {
        listeners$1.splice(index, 1);
      }
    };
  }, [state2]);
  return {
    ...state2,
    toast,
    dismiss: (toastId) => dispatch({ type: "DISMISS_TOAST", toastId })
  };
}
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
const ToastProvider = ToastProvider$1;
const ToastViewport = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  ToastViewport$1,
  {
    ref,
    className: cn(
      "fixed top-0 z-[100] flex max-h-screen w-full flex-col-reverse p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]",
      className
    ),
    ...props
  }
));
ToastViewport.displayName = ToastViewport$1.displayName;
const toastVariants = cva(
  "group pointer-events-auto relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-md border p-6 pr-8 shadow-lg transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-top-full data-[state=open]:sm:slide-in-from-bottom-full",
  {
    variants: {
      variant: {
        default: "border bg-background text-foreground",
        destructive: "destructive group border-destructive bg-destructive text-destructive-foreground"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
const Toast = reactExports.forwardRef(({ className, variant, ...props }, ref) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Toast$1, { ref, className: cn(toastVariants({ variant }), className), ...props });
});
Toast.displayName = Toast$1.displayName;
const ToastAction = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  ToastAction$1,
  {
    ref,
    className: cn(
      "inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium ring-offset-background transition-colors group-[.destructive]:border-muted/40 hover:bg-secondary group-[.destructive]:hover:border-destructive/30 group-[.destructive]:hover:bg-destructive group-[.destructive]:hover:text-destructive-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 group-[.destructive]:focus:ring-destructive disabled:pointer-events-none disabled:opacity-50",
      className
    ),
    ...props
  }
));
ToastAction.displayName = ToastAction$1.displayName;
const ToastClose = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  ToastClose$1,
  {
    ref,
    className: cn(
      "absolute right-2 top-2 rounded-md p-1 text-foreground/50 opacity-0 transition-opacity group-hover:opacity-100 group-[.destructive]:text-red-300 hover:text-foreground group-[.destructive]:hover:text-red-50 focus:opacity-100 focus:outline-none focus:ring-2 group-[.destructive]:focus:ring-red-400 group-[.destructive]:focus:ring-offset-red-600",
      className
    ),
    "toast-close": "",
    ...props,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" })
  }
));
ToastClose.displayName = ToastClose$1.displayName;
const ToastTitle = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(ToastTitle$1, { ref, className: cn("text-sm font-semibold", className), ...props }));
ToastTitle.displayName = ToastTitle$1.displayName;
const ToastDescription = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(ToastDescription$1, { ref, className: cn("text-sm opacity-90", className), ...props }));
ToastDescription.displayName = ToastDescription$1.displayName;
function Toaster() {
  const { toasts } = useToast();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(ToastProvider, { children: [
    toasts.map(function({ id, title, description, action, ...props }) {
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(Toast, { ...props, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-1", children: [
          title && /* @__PURE__ */ jsxRuntimeExports.jsx(ToastTitle, { children: title }),
          description && /* @__PURE__ */ jsxRuntimeExports.jsx(ToastDescription, { children: description })
        ] }),
        action,
        /* @__PURE__ */ jsxRuntimeExports.jsx(ToastClose, {})
      ] }, id);
    }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(ToastViewport, {})
  ] });
}
const TooltipProvider = TooltipProvider$1;
const TooltipContent = reactExports.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  TooltipContent$1,
  {
    ref,
    sideOffset,
    className: cn(
      "z-50 overflow-hidden rounded-md border bg-popover px-3 py-1.5 text-sm text-popover-foreground shadow-md animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
      className
    ),
    ...props
  }
));
TooltipContent.displayName = TooltipContent$1.displayName;
function parseStorageUrl(url) {
  if (!url) return null;
  const m = url.match(/\/storage\/v1\/object\/(?:public|sign)\/([^/]+)\/(.+?)(?:\?.*)?$/);
  if (!m) return null;
  return { bucket: m[1], path: decodeURIComponent(m[2]) };
}
const cache = /* @__PURE__ */ new Map();
async function getPlayableUrl(url, expiresIn = 60 * 60) {
  if (!url) return url;
  const parsed = parseStorageUrl(url);
  if (!parsed) return url;
  const key = `${parsed.bucket}/${parsed.path}`;
  const now = Date.now();
  const hit = cache.get(key);
  if (hit && hit.expiresAt > now + 3e4) return hit.url;
  const { data, error } = await supabase.storage.from(parsed.bucket).createSignedUrl(parsed.path, expiresIn);
  if (error || !data?.signedUrl) return url;
  cache.set(key, { url: data.signedUrl, expiresAt: now + expiresIn * 1e3 });
  return data.signedUrl;
}
function useSignedMediaUrl(url) {
  const [signed, setSigned] = reactExports.useState("");
  reactExports.useEffect(() => {
    let cancel = false;
    if (!url) {
      setSigned("");
      return;
    }
    getPlayableUrl(url).then((u) => {
      if (!cancel) setSigned(u);
    }).catch(() => {
      if (!cancel) setSigned(url);
    });
    return () => {
      cancel = true;
    };
  }, [url]);
  return signed;
}
const SignedImg = ({ src, ...rest }) => {
  const url = useSignedMediaUrl(src ?? "");
  if (!url) return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: rest.className });
  return /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: url, ...rest });
};
let state = { session: null, user: null, profile: null, loading: true };
const listeners = /* @__PURE__ */ new Set();
let initialized = false;
const setState = (patch) => {
  state = { ...state, ...patch };
  listeners.forEach((l) => l(state));
};
const fetchProfile = async (uid) => {
  const { data } = await supabase.from("profiles").select("*").eq("id", uid).maybeSingle();
  setState({ profile: data ?? null });
};
const init = () => {
  if (initialized) return;
  initialized = true;
  supabase.auth.getSession().then(({ data: { session } }) => {
    setState({
      session,
      user: session?.user ?? null,
      loading: false
    });
    if (session?.user) fetchProfile(session.user.id);
  });
  supabase.auth.onAuthStateChange((event, s) => {
    if (event === "TOKEN_REFRESHED") {
      setState({ session: s });
      return;
    }
    setState({
      session: s,
      user: s?.user ?? null,
      profile: s ? state.profile : null,
      loading: false
    });
    if (s?.user) setTimeout(() => fetchProfile(s.user.id), 0);
  });
};
function useAuth() {
  const [snap, setSnap] = reactExports.useState(state);
  reactExports.useEffect(() => {
    init();
    listeners.add(setSnap);
    setSnap(state);
    return () => {
      listeners.delete(setSnap);
    };
  }, []);
  return {
    ...snap,
    setProfile: (p) => setState({ profile: p })
  };
}
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = reactExports.forwardRef(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Comp, { className: cn(buttonVariants({ variant, size, className })), ref, ...props });
  }
);
Button.displayName = "Button";
const Input = reactExports.forwardRef(
  ({ className, type, ...props }, ref) => {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      "input",
      {
        type,
        className: cn(
          "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className
        ),
        ref,
        ...props
      }
    );
  }
);
Input.displayName = "Input";
const Textarea = reactExports.forwardRef(({ className, ...props }, ref) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "textarea",
    {
      className: cn(
        "flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
        className
      ),
      ref,
      ...props
    }
  );
});
Textarea.displayName = "Textarea";
const EditVideoModal = ({ video, userId, onClose, onUpdated, onDeleted }) => {
  const [title, setTitle] = reactExports.useState(video.title);
  const [description, setDescription] = reactExports.useState(video.description ?? "");
  const [tags, setTags] = reactExports.useState(video.tags ?? []);
  const [tagInput, setTagInput] = reactExports.useState("");
  const [saving, setSaving] = reactExports.useState(false);
  const [deleting, setDeleting] = reactExports.useState(false);
  const [coverFile, setCoverFile] = reactExports.useState(null);
  const [coverPreview, setCoverPreview] = reactExports.useState(null);
  const currentCover = useSignedMediaUrl(video.thumbnail_url ?? null);
  reactExports.useEffect(() => {
    if (!coverFile) {
      setCoverPreview(null);
      return;
    }
    const url = URL.createObjectURL(coverFile);
    setCoverPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [coverFile]);
  const addTag = (raw) => {
    const t = raw.trim().toLowerCase().replace(/^#/, "").replace(/[^a-z0-9áéíóúñ_-]/gi, "");
    if (!t || tags.includes(t) || tags.length >= 10) return;
    setTags([...tags, t]);
  };
  const onTagKey = (e) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addTag(tagInput);
      setTagInput("");
    } else if (e.key === "Backspace" && !tagInput && tags.length) setTags(tags.slice(0, -1));
  };
  const handleSave = async (e) => {
    e.preventDefault();
    if (!title.trim()) {
      toast$1.error("El título no puede estar vacío");
      return;
    }
    setSaving(true);
    try {
      let thumbnail_url = video.thumbnail_url ?? null;
      if (coverFile) {
        const cext = (coverFile.name.split(".").pop() || "jpg").toLowerCase();
        const cpath = `${userId}/${crypto.randomUUID()}.${cext}`;
        const { error: cErr } = await supabase.storage.from("videos").upload(cpath, coverFile, { contentType: coverFile.type });
        if (cErr) throw cErr;
        thumbnail_url = supabase.storage.from("videos").getPublicUrl(cpath).data.publicUrl;
      }
      const finalTags = [...tags];
      if (tagInput.trim()) {
        const t = tagInput.trim().toLowerCase().replace(/^#/, "");
        if (t && !finalTags.includes(t)) finalTags.push(t);
      }
      const payload = {
        title: title.trim(),
        description: description.trim() || null,
        tags: finalTags,
        thumbnail_url
      };
      const { error } = await supabase.from("videos").update(payload).eq("id", video.id).eq("user_id", userId);
      if (error) throw error;
      toast$1.success("Video actualizado");
      onUpdated?.({ id: video.id, ...payload });
      onClose();
    } catch (err) {
      toast$1.error(err.message);
    } finally {
      setSaving(false);
    }
  };
  const handleDelete = async () => {
    if (!confirm("¿Eliminar este video? Esta acción no se puede deshacer.")) return;
    setDeleting(true);
    try {
      const { error } = await supabase.from("videos").delete().eq("id", video.id).eq("user_id", userId);
      if (error) throw error;
      toast$1.success("Video eliminado");
      onDeleted?.(video.id);
      onClose();
    } catch (err) {
      toast$1.error(err.message);
    } finally {
      setDeleting(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 overflow-y-auto", onClick: onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-lg bg-card rounded-lg p-6 my-8", onClick: (e) => e.stopPropagation(), children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onClose, className: "absolute top-3 right-3 p-1 hover:bg-secondary rounded", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-5 w-5" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-xl font-bold mb-4 flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-5 w-5 text-primary" }),
      " Editar video"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSave, className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "Título", value: title, onChange: (e) => setTitle(e.target.value), required: true }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { placeholder: "Descripción (opcional)", value: description, onChange: (e) => setDescription(e.target.value), rows: 3 }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-1.5 p-2 bg-secondary/40 border border-border rounded-md min-h-[42px]", children: [
          tags.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-xs bg-primary/20 text-primary px-2 py-1 rounded-full", children: [
            "#",
            t,
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setTags(tags.filter((x) => x !== t)), className: "hover:text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-3 w-3" }) })
          ] }, t)),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              value: tagInput,
              onChange: (e) => setTagInput(e.target.value),
              onKeyDown: onTagKey,
              placeholder: tags.length ? "" : "Etiquetas (Enter)",
              className: "flex-1 min-w-[100px] bg-transparent outline-none text-sm"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "Máx 10. Enter o coma para añadir." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 p-3 border border-border rounded-md bg-secondary/20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "text-sm font-medium flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "h-4 w-4 text-primary" }),
          " Portada"
        ] }),
        (coverPreview || currentCover) && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: coverPreview || currentCover || "", alt: "Portada", className: "w-full aspect-video object-cover rounded-md" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "file",
              accept: "image/*",
              className: "hidden",
              onChange: (e) => setCoverFile(e.target.files?.[0] ?? null)
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "cursor-pointer text-center text-sm py-2 px-3 border border-border rounded-md hover:bg-secondary transition-colors", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "h-4 w-4 inline mr-1" }),
            " ",
            coverFile ? "Cambiar imagen" : "Elegir nueva portada"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 pt-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", disabled: saving || deleting, className: "flex-1", size: "lg", children: saving ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
          " Guardando..."
        ] }) : "Guardar cambios" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            type: "button",
            variant: "destructive",
            size: "lg",
            disabled: saving || deleting,
            onClick: handleDelete,
            title: "Eliminar video",
            children: deleting ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" })
          }
        )
      ] })
    ] })
  ] }) });
};
function formatNumber(n) {
  if (n < 1e3) return n.toString();
  if (n < 1e6) return (n / 1e3).toFixed(n < 1e4 ? 1 : 0) + "K";
  return (n / 1e6).toFixed(1) + "M";
}
const VideoCard = ({ video }) => {
  const navigate = distExports.useNavigate();
  const { user } = useAuth();
  const [hovering, setHovering] = reactExports.useState(false);
  const [editing, setEditing] = reactExports.useState(false);
  const [current, setCurrent] = reactExports.useState(video);
  reactExports.useEffect(() => setCurrent(video), [video]);
  const previewRef = reactExports.useRef(null);
  const src = useSignedMediaUrl(current.video_url);
  const poster = useSignedMediaUrl(current.thumbnail_url ?? null);
  const isOwner = !!(user && current.user_id && user.id === current.user_id);
  const [deleted, setDeleted] = reactExports.useState(false);
  reactExports.useEffect(() => {
    const v = previewRef.current;
    if (!v) return;
    if (hovering) {
      v.currentTime = 0;
      v.play().catch(() => {
      });
    } else {
      v.pause();
    }
  }, [hovering]);
  const timeAgo = (() => {
    const diff = Date.now() - new Date(current.created_at).getTime();
    const m = Math.floor(diff / 6e4);
    if (m < 1) return "ahora";
    if (m < 60) return `hace ${m} min`;
    const h = Math.floor(m / 60);
    if (h < 24) return `hace ${h} h`;
    return `hace ${Math.floor(h / 24)} d`;
  })();
  const goWatch = () => navigate(`/v/${current.id}`);
  if (deleted) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "article",
      {
        className: "group cursor-pointer",
        onClick: goWatch,
        onMouseEnter: () => setHovering(true),
        onMouseLeave: () => setHovering(false),
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative aspect-video bg-black overflow-hidden rounded-md", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("video", { ref: previewRef, src: src || void 0, poster: poster || void 0, muted: true, playsInline: true, preload: "metadata", className: "w-full h-full object-cover" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-primary/90 rounded-full p-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "h-6 w-6 text-primary-foreground fill-current" }) }) }),
            isOwner && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: (e) => {
                  e.stopPropagation();
                  setEditing(true);
                },
                className: "absolute top-2 right-2 bg-black/70 hover:bg-primary text-white rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity",
                title: "Editar video",
                "aria-label": "Editar video",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-3.5 w-3.5" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute bottom-2 right-2 bg-black/80 text-white text-xs font-semibold px-1.5 py-0.5 rounded flex items-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-3 w-3" }),
              " ",
              formatNumber(current.views)
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex gap-2", children: [
            current.uploader && /* @__PURE__ */ jsxRuntimeExports.jsx(
              distExports.Link,
              {
                to: `/u/${current.uploader.username}`,
                onClick: (e) => e.stopPropagation(),
                className: "shrink-0 w-9 h-9 rounded-full bg-secondary overflow-hidden flex items-center justify-center hover:ring-2 hover:ring-primary",
                children: current.uploader.avatar_url ? /* @__PURE__ */ jsxRuntimeExports.jsx(SignedImg, { src: current.uploader.avatar_url, alt: current.uploader.username, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-4 w-4 text-muted-foreground" })
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold line-clamp-2 leading-snug group-hover:text-primary transition-colors", children: current.title }),
              current.uploader ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
                distExports.Link,
                {
                  to: `/u/${current.uploader.username}`,
                  onClick: (e) => e.stopPropagation(),
                  className: "block mt-0.5 text-xs font-medium text-foreground/80 hover:text-primary",
                  children: [
                    "@",
                    current.uploader.username
                  ]
                }
              ) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block mt-0.5 text-xs font-medium text-muted-foreground", children: "Anónimo" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mt-1 text-xs text-muted-foreground", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-3 w-3" }),
                  " ",
                  formatNumber(current.views),
                  " ",
                  current.views === 1 ? "visita" : "visitas"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-3 w-3" }),
                  " ",
                  timeAgo
                ] })
              ] }),
              current.tags && current.tags.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1.5 flex flex-wrap gap-1", children: current.tags.slice(0, 3).map((t) => /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] px-1.5 py-0.5 rounded-full bg-secondary text-muted-foreground", children: [
                "#",
                t
              ] }, t)) })
            ] })
          ] })
        ]
      }
    ),
    editing && user && /* @__PURE__ */ jsxRuntimeExports.jsx(
      EditVideoModal,
      {
        video: current,
        userId: user.id,
        onClose: () => setEditing(false),
        onUpdated: (patch) => setCurrent((c) => ({ ...c, ...patch })),
        onDeleted: () => setDeleted(true)
      }
    )
  ] });
};
const UploadModal = ({ userId, onClose }) => {
  const [title, setTitle] = reactExports.useState("");
  const [description, setDescription] = reactExports.useState("");
  const [file, setFile] = reactExports.useState(null);
  const [uploading, setUploading] = reactExports.useState(false);
  const [tagInput, setTagInput] = reactExports.useState("");
  const [tags, setTags] = reactExports.useState([]);
  const [coverFile, setCoverFile] = reactExports.useState(null);
  const [coverPreview, setCoverPreview] = reactExports.useState(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = reactExports.useState(null);
  const [capturing, setCapturing] = reactExports.useState(false);
  const videoRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    if (!file) {
      setVideoPreviewUrl(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setVideoPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);
  reactExports.useEffect(() => {
    if (!coverFile) {
      setCoverPreview(null);
      return;
    }
    const url = URL.createObjectURL(coverFile);
    setCoverPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [coverFile]);
  const addTag = (raw) => {
    const t = raw.trim().toLowerCase().replace(/^#/, "").replace(/[^a-z0-9áéíóúñ_-]/gi, "");
    if (!t || tags.includes(t) || tags.length >= 10) return;
    setTags([...tags, t]);
  };
  const onTagKey = (e) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addTag(tagInput);
      setTagInput("");
    } else if (e.key === "Backspace" && !tagInput && tags.length) {
      setTags(tags.slice(0, -1));
    }
  };
  const captureFrame = async () => {
    if (!videoPreviewUrl) {
      toast$1.error("Selecciona primero el video");
      return;
    }
    setCapturing(true);
    try {
      const v = document.createElement("video");
      v.src = videoPreviewUrl;
      v.crossOrigin = "anonymous";
      v.muted = true;
      v.playsInline = true;
      await new Promise((resolve, reject) => {
        v.onloadedmetadata = () => resolve();
        v.onerror = () => reject(new Error("No se pudo leer el video"));
      });
      v.currentTime = Math.min(1, (v.duration || 2) / 2);
      await new Promise((resolve, reject) => {
        v.onseeked = () => resolve();
        v.onerror = () => reject(new Error("No se pudo capturar el frame"));
      });
      const canvas = document.createElement("canvas");
      canvas.width = v.videoWidth;
      canvas.height = v.videoHeight;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Canvas no disponible");
      ctx.drawImage(v, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise(
        (resolve, reject) => canvas.toBlob((b) => b ? resolve(b) : reject(new Error("Sin blob")), "image/jpeg", 0.85)
      );
      setCoverFile(new File([blob], "cover.jpg", { type: "image/jpeg" }));
      toast$1.success("Portada capturada del video");
    } catch (err) {
      toast$1.error(err.message);
    } finally {
      setCapturing(false);
    }
  };
  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file || !title.trim()) {
      toast$1.error("Añade un título y selecciona un video");
      return;
    }
    setUploading(true);
    try {
      const ext = file.name.split(".").pop();
      const path = `${userId}/${crypto.randomUUID()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("videos").upload(path, file, { contentType: file.type });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("videos").getPublicUrl(path);
      let thumbnailUrl = null;
      if (coverFile) {
        const cext = (coverFile.name.split(".").pop() || "jpg").toLowerCase();
        const cpath = `${userId}/${crypto.randomUUID()}.${cext}`;
        const { error: cErr } = await supabase.storage.from("videos").upload(cpath, coverFile, { contentType: coverFile.type });
        if (cErr) throw cErr;
        thumbnailUrl = supabase.storage.from("videos").getPublicUrl(cpath).data.publicUrl;
      }
      const finalTags = [...tags];
      if (tagInput.trim()) {
        const t = tagInput.trim().toLowerCase().replace(/^#/, "");
        if (t && !finalTags.includes(t)) finalTags.push(t);
      }
      const { error: insErr } = await supabase.from("videos").insert({
        title: title.trim(),
        description: description.trim() || null,
        video_url: pub.publicUrl,
        storage_path: path,
        user_id: userId,
        tags: finalTags,
        thumbnail_url: thumbnailUrl
      });
      if (insErr) throw insErr;
      toast$1.success("¡Video publicado!");
      onClose();
    } catch (err) {
      toast$1.error(err.message);
    } finally {
      setUploading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 overflow-y-auto", onClick: onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-lg bg-card rounded-lg p-6 my-8", onClick: (e) => e.stopPropagation(), children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onClose, className: "absolute top-3 right-3 p-1 hover:bg-secondary rounded", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-5 w-5" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-xl font-bold mb-4 flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-5 w-5 text-primary" }),
      " Subir un video"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleUpload, className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "Título del video", value: title, onChange: (e) => setTitle(e.target.value), required: true }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { placeholder: "Descripción (opcional)", value: description, onChange: (e) => setDescription(e.target.value), rows: 3 }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-1.5 p-2 bg-secondary/40 border border-border rounded-md min-h-[42px]", children: [
          tags.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 text-xs bg-primary/20 text-primary px-2 py-1 rounded-full", children: [
            "#",
            t,
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setTags(tags.filter((x) => x !== t)), className: "hover:text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-3 w-3" }) })
          ] }, t)),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              value: tagInput,
              onChange: (e) => setTagInput(e.target.value),
              onKeyDown: onTagKey,
              placeholder: tags.length ? "" : "Etiquetas (presiona Enter)",
              className: "flex-1 min-w-[100px] bg-transparent outline-none text-sm"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "Presiona Enter o coma para añadir. Máx 10." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-sm font-medium mb-1 block", children: "Video" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "file", accept: "video/*", onChange: (e) => setFile(e.target.files?.[0] ?? null), required: true })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 p-3 border border-border rounded-md bg-secondary/20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "text-sm font-medium flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "h-4 w-4 text-primary" }),
          " Portada del video"
        ] }),
        coverPreview ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: coverPreview, alt: "Portada", className: "w-full aspect-video object-cover rounded-md" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setCoverFile(null),
              className: "absolute top-2 right-2 bg-black/60 hover:bg-black/80 p-1 rounded",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4 text-white" })
            }
          )
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Elige una imagen o captura un frame del video. Si no eliges, se usará una vista previa automática." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "file",
                accept: "image/*",
                className: "hidden",
                onChange: (e) => setCoverFile(e.target.files?.[0] ?? null)
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "cursor-pointer text-center text-sm py-2 px-3 border border-border rounded-md hover:bg-secondary transition-colors", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "h-4 w-4 inline mr-1" }),
              " Elegir imagen"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Button,
            {
              type: "button",
              variant: "secondary",
              size: "sm",
              className: "flex-1",
              disabled: !file || capturing,
              onClick: captureFrame,
              children: [
                capturing ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(WandSparkles, { className: "h-4 w-4" }),
                "Capturar del video"
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", disabled: uploading, className: "w-full", size: "lg", children: uploading ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
        " Subiendo..."
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" }),
        " Publicar"
      ] }) })
    ] }),
    videoRef.current && null
  ] }) });
};
const PhotoUploadModal = ({
  userId,
  onClose,
  onUploaded
}) => {
  const [title, setTitle] = reactExports.useState("");
  const [description, setDescription] = reactExports.useState("");
  const [file, setFile] = reactExports.useState(null);
  const [preview, setPreview] = reactExports.useState(null);
  const [uploading, setUploading] = reactExports.useState(false);
  const onPick = (f) => {
    setFile(f);
    setPreview(f ? URL.createObjectURL(f) : null);
  };
  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) {
      toast$1.error("Selecciona una foto");
      return;
    }
    if (!file.type.startsWith("image/")) {
      toast$1.error("El archivo debe ser una imagen");
      return;
    }
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${userId}/${crypto.randomUUID()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("photos").upload(path, file, { contentType: file.type });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("photos").getPublicUrl(path);
      const { error: insErr } = await supabase.from("photos").insert({
        title: title.trim() || "Sin título",
        description: description.trim() || null,
        image_url: pub.publicUrl,
        storage_path: path,
        user_id: userId
      });
      if (insErr) throw insErr;
      toast$1.success("¡Foto publicada!");
      onUploaded?.();
      onClose();
    } catch (err) {
      toast$1.error(err.message);
    } finally {
      setUploading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4", onClick: onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full max-w-lg bg-card rounded-lg p-6", onClick: (e) => e.stopPropagation(), children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onClose, className: "absolute top-3 right-3 p-1 hover:bg-secondary rounded", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-5 w-5" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-xl font-bold mb-4 flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "h-5 w-5 text-primary" }),
      " Subir una foto"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleUpload, className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block", children: [
        preview ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: preview, alt: "", className: "w-full max-h-72 object-contain rounded-md bg-black/40 cursor-pointer" }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center gap-2 border-2 border-dashed border-border rounded-md py-10 cursor-pointer hover:bg-secondary/30", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ImagePlus, { className: "h-8 w-8 text-muted-foreground" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-muted-foreground", children: "Toca para seleccionar una imagen" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "file",
            accept: "image/*",
            className: "hidden",
            onChange: (e) => onPick(e.target.files?.[0] ?? null)
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "Título (opcional)", value: title, onChange: (e) => setTitle(e.target.value), maxLength: 120 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { placeholder: "Descripción (opcional)", value: description, onChange: (e) => setDescription(e.target.value), rows: 3, maxLength: 1e3 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", disabled: uploading || !file, className: "w-full", size: "lg", children: uploading ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
        " Subiendo..."
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "h-4 w-4" }),
        " Publicar foto"
      ] }) })
    ] })
  ] }) });
};
function PhotoCard({
  photo,
  likes,
  comments,
  onClick
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "button",
    {
      onClick,
      className: "group relative block w-full overflow-hidden rounded-lg bg-secondary/40 aspect-square text-left",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: photo.image_url,
            alt: photo.title,
            loading: "lazy",
            className: "w-full h-full object-cover transition-transform group-hover:scale-105"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-x-0 bottom-0 p-3 text-white opacity-0 group-hover:opacity-100 transition-opacity", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs mb-1", children: [
            photo.uploader?.avatar_url ? /* @__PURE__ */ jsxRuntimeExports.jsx(SignedImg, { src: photo.uploader.avatar_url, alt: "", className: "w-5 h-5 rounded-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-5 h-5 rounded-full bg-white/20 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-3 w-3" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "truncate font-semibold", children: [
              "@",
              photo.uploader?.username ?? "usuario"
            ] })
          ] }),
          photo.title && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-bold line-clamp-1 mb-1", children: photo.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "h-3.5 w-3.5" }),
              " ",
              likes
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "h-3.5 w-3.5" }),
              " ",
              comments
            ] })
          ] })
        ] })
      ]
    }
  );
}
function PhotoDetailModal({
  photo,
  onClose,
  onDeleted
}) {
  const { user } = useAuth();
  const navigate = distExports.useNavigate();
  const [likes, setLikes] = reactExports.useState(0);
  const [liked, setLiked] = reactExports.useState(false);
  const [busyLike, setBusyLike] = reactExports.useState(false);
  const [comments, setComments] = reactExports.useState([]);
  const [loadingC, setLoadingC] = reactExports.useState(true);
  const [text, setText] = reactExports.useState("");
  const [posting, setPosting] = reactExports.useState(false);
  reactExports.useEffect(() => {
    (async () => {
      const [{ count: count2 }, mine] = await Promise.all([
        supabase.from("photo_reactions").select("*", { count: "exact", head: true }).eq("photo_id", photo.id),
        user ? supabase.from("photo_reactions").select("user_id").eq("photo_id", photo.id).eq("user_id", user.id).maybeSingle() : Promise.resolve({ data: null })
      ]);
      setLikes(count2 ?? 0);
      setLiked(!!mine.data);
    })();
    loadComments();
  }, [photo.id, user]);
  const loadComments = async () => {
    setLoadingC(true);
    const { data } = await supabase.from("photo_comments").select("*").eq("photo_id", photo.id).order("created_at", { ascending: false });
    const ids = Array.from(new Set((data ?? []).map((c) => c.user_id)));
    const map = /* @__PURE__ */ new Map();
    if (ids.length) {
      const { data: profs } = await supabase.from("profiles").select("id,username,avatar_url").in("id", ids);
      (profs ?? []).forEach((p) => map.set(p.id, { username: p.username, avatar_url: p.avatar_url }));
    }
    setComments((data ?? []).map((c) => ({ ...c, author: map.get(c.user_id) ?? null })));
    setLoadingC(false);
  };
  const requireAuth = () => {
    if (!user) {
      toast$1.error("Inicia sesión para interactuar");
      navigate("/auth");
      return false;
    }
    return true;
  };
  const toggleLike = async () => {
    if (!requireAuth() || busyLike) return;
    setBusyLike(true);
    if (liked) {
      const { error } = await supabase.from("photo_reactions").delete().eq("photo_id", photo.id).eq("user_id", user.id);
      if (!error) {
        setLiked(false);
        setLikes((n) => Math.max(0, n - 1));
      }
    } else {
      const { error } = await supabase.from("photo_reactions").insert({
        photo_id: photo.id,
        user_id: user.id
      });
      if (!error) {
        setLiked(true);
        setLikes((n) => n + 1);
      }
    }
    setBusyLike(false);
  };
  const submitComment = async () => {
    if (!requireAuth()) return;
    const content = text.trim();
    if (!content) return;
    setPosting(true);
    const { error } = await supabase.from("photo_comments").insert({
      photo_id: photo.id,
      user_id: user.id,
      content
    });
    setPosting(false);
    if (error) {
      toast$1.error(error.message);
      return;
    }
    setText("");
    loadComments();
  };
  const deleteComment = async (id) => {
    const { error } = await supabase.from("photo_comments").delete().eq("id", id);
    if (error) {
      toast$1.error(error.message);
      return;
    }
    setComments((cs) => cs.filter((c) => c.id !== id));
  };
  const deletePhoto = async () => {
    if (!user || user.id !== photo.user_id) return;
    if (!confirm("¿Eliminar esta foto?")) return;
    const { error } = await supabase.from("photos").delete().eq("id", photo.id);
    if (error) {
      toast$1.error(error.message);
      return;
    }
    toast$1.success("Foto eliminada");
    onDeleted?.(photo.id);
    onClose();
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-2 sm:p-4", onClick: onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: "relative w-full max-w-5xl bg-card rounded-lg overflow-hidden flex flex-col md:flex-row max-h-[95vh]",
      onClick: (e) => e.stopPropagation(),
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onClose, className: "absolute top-2 right-2 z-10 p-1.5 bg-black/60 hover:bg-black/80 rounded-full text-white", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "md:flex-1 bg-black flex items-center justify-center min-h-[40vh] md:min-h-0 max-h-[60vh] md:max-h-none", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: photo.image_url, alt: photo.title, className: "max-w-full max-h-full object-contain" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "md:w-96 flex flex-col border-l border-border max-h-[55vh] md:max-h-none", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 border-b border-border", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                distExports.Link,
                {
                  to: photo.uploader ? `/u/${photo.uploader.username}` : "#",
                  className: "flex items-center gap-2 min-w-0",
                  children: [
                    photo.uploader?.avatar_url ? /* @__PURE__ */ jsxRuntimeExports.jsx(SignedImg, { src: photo.uploader.avatar_url, alt: "", className: "w-9 h-9 rounded-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-9 rounded-full bg-secondary flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-4 w-4 text-muted-foreground" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm font-semibold truncate", children: [
                        "@",
                        photo.uploader?.username ?? "usuario"
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: new Date(photo.created_at).toLocaleDateString() })
                    ] })
                  ]
                }
              ),
              user?.id === photo.user_id && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: deletePhoto, className: "p-2 text-muted-foreground hover:text-destructive rounded-md hover:bg-secondary", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
            ] }),
            photo.title && /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold mt-3", children: photo.title }),
            photo.description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground mt-1 whitespace-pre-wrap", children: photo.description }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  onClick: toggleLike,
                  disabled: busyLike,
                  className: `flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${liked ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-secondary/70"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: `h-4 w-4 ${liked ? "fill-current" : ""}` }),
                    likes
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1.5 text-sm text-muted-foreground", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "h-4 w-4" }),
                " ",
                comments.length
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 overflow-y-auto p-4 space-y-3", children: loadingC ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-5 w-5 animate-spin text-muted-foreground" }) }) : comments.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground text-center py-6", children: "Sé el primero en comentar." }) : comments.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
            c.author?.avatar_url ? /* @__PURE__ */ jsxRuntimeExports.jsx(SignedImg, { src: c.author.avatar_url, alt: "", className: "w-7 h-7 rounded-full object-cover shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-7 h-7 rounded-full bg-secondary shrink-0 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-3 w-3 text-muted-foreground" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold", children: [
                  "@",
                  c.author?.username ?? "usuario"
                ] }),
                " ",
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-muted-foreground", children: [
                  "· ",
                  new Date(c.created_at).toLocaleDateString()
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm whitespace-pre-wrap break-words", children: c.content })
            ] }),
            user?.id === c.user_id && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => deleteComment(c.id), className: "p-1 text-muted-foreground hover:text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-3.5 w-3.5" }) })
          ] }, c.id)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 border-t border-border", children: user ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-end gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Textarea,
              {
                value: text,
                onChange: (e) => setText(e.target.value),
                placeholder: "Escribe un comentario...",
                rows: 1,
                maxLength: 500,
                className: "min-h-[40px] resize-none",
                onKeyDown: (e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    submitComment();
                  }
                }
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", onClick: submitComment, disabled: posting || !text.trim(), children: posting ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "h-4 w-4" }) })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { className: "w-full", onClick: () => navigate("/auth"), children: "Inicia sesión para comentar" }) })
        ] })
      ]
    }
  ) });
}
const Sidebar = ({ onSelectFilter, isAdmin, loggedIn }) => {
  const sections = [
    {
      title: "Vídeos Porno",
      items: [
        { label: "Exclusivos", icon: Star, filter: { label: "Exclusivos", sort: "recientes" } },
        { label: "Explorar", icon: Compass, filter: { label: "Explorar", sort: "inicio" } },
        { label: "Shorts", icon: Zap, badge: "Beta", filter: { label: "Shorts", sort: "recientes", shortsOnly: true } },
        { label: "Los Mejores", icon: Sparkles, filter: { label: "Los Mejores", sort: "mas-vistos" } },
        { label: "Recomendado", icon: Award, filter: { label: "Recomendado", sort: "recomendados" } }
      ]
    },
    {
      title: "Categorías",
      items: [
        { label: "Maduras", filter: { label: "Maduras", keyword: "madura" } },
        { label: "Jovencitas", filter: { label: "Jovencitas", keyword: "joven" } },
        { label: "Transexual", filter: { label: "Transexual", keyword: "transexual" } },
        { label: "Gay", filter: { label: "Gay", keyword: "gay" } },
        { label: "Amateur", filter: { label: "Amateur", keyword: "amateur" } },
        { label: "Anal", filter: { label: "Anal", keyword: "anal" } },
        { label: "Lésbico", filter: { label: "Lésbico", keyword: "lesbico" } },
        { label: "POV", filter: { label: "POV", keyword: "pov" } },
        { label: "Hentai", filter: { label: "Hentai", keyword: "hentai" } },
        { label: "Latinas", filter: { label: "Latinas", keyword: "latina" } }
      ]
    },
    {
      title: "Fotos",
      items: [
        { label: "Nuevas Fotos", icon: Image, filter: { label: "Nuevas Fotos", mode: "fotos", photoSort: "nuevas" } },
        { label: "Recomendadas", icon: Flame, filter: { label: "Fotos Recomendadas", mode: "fotos", photoSort: "recomendadas" } },
        { label: "Más Vistas", icon: Eye, filter: { label: "Fotos Más Vistas", mode: "fotos", photoSort: "mas-vistas" } }
      ]
    }
  ];
  const accountSection = loggedIn ? {
    title: "Mi cuenta",
    items: [
      { label: "Estadísticas", icon: ChartColumn, to: "/stats" },
      { label: "Monetización", icon: DollarSign, to: "/monetization" },
      ...isAdmin ? [{ label: "Panel Admin", icon: ShieldCheck, to: "/admin" }] : []
    ]
  } : null;
  const renderItem = (it) => {
    const Inner = /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-3 px-3 py-2 rounded-md text-sm text-foreground/85 hover:bg-secondary hover:text-primary transition-colors w-full text-left cursor-pointer group", children: [
      it.icon && /* @__PURE__ */ jsxRuntimeExports.jsx(it.icon, { className: "h-4 w-4 shrink-0 text-muted-foreground group-hover:text-primary transition-colors" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1 truncate", children: it.label }),
      it.badge && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-bold px-1.5 py-0.5 rounded bg-primary text-primary-foreground uppercase", children: it.badge })
    ] });
    if (it.to) return /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Link, { to: it.to, children: Inner }, it.label);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        type: "button",
        onClick: () => it.filter && onSelectFilter?.(it.filter),
        className: "block w-full",
        children: Inner
      },
      it.label
    );
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("aside", { className: "w-full lg:w-60 shrink-0 lg:border-r border-border lg:bg-card/30", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:sticky lg:top-[6.5rem] lg:max-h-[calc(100vh-6.5rem)] lg:overflow-y-auto py-4 px-2", children: [
    accountSection && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "px-3 mb-1.5 text-[11px] font-bold tracking-widest uppercase text-muted-foreground", children: accountSection.title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-0.5", children: accountSection.items.map(renderItem) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-3 border-t border-border" })
    ] }),
    sections.map((s, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "px-3 mb-1.5 text-[11px] font-bold tracking-widest uppercase text-muted-foreground", children: s.title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-0.5", children: s.items.map(renderItem) }),
      idx < sections.length - 1 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "my-3 border-t border-border" })
    ] }, s.title))
  ] }) });
};
function fmt(n) {
  if (n < 1e3) return n.toString();
  if (n < 1e6) return (n / 1e3).toFixed(n < 1e4 ? 1 : 0) + "K";
  return (n / 1e6).toFixed(1) + "M";
}
function fmtDuration(s) {
  if (!s || s <= 0) return null;
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
}
function dailyShuffle(arr, keyFn) {
  const today = /* @__PURE__ */ new Date();
  const seed = `${today.getFullYear()}-${today.getMonth()}-${today.getDate()}`;
  const scored = arr.map((item) => {
    const str = seed + "|" + keyFn(item);
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return { item, score: h >>> 0 };
  });
  scored.sort((a, b) => a.score - b.score);
  return scored.map((s) => s.item);
}
const Card = ({ v }) => {
  const navigate = distExports.useNavigate();
  const [hover, setHover] = reactExports.useState(false);
  const ref = reactExports.useRef(null);
  const src = useSignedMediaUrl(v.video_url);
  reactExports.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (hover) {
      el.currentTime = 0;
      el.play().catch(() => {
      });
    } else {
      el.pause();
    }
  }, [hover]);
  const dur = fmtDuration(v.duration_seconds);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      onClick: () => navigate(`/v/${v.id}`),
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      className: "snap-start shrink-0 w-[170px] cursor-pointer group",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative aspect-[9/13] bg-black rounded-md overflow-hidden", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("video", { ref, src: src || void 0, muted: true, playsInline: true, preload: "metadata", className: "w-full h-full object-cover" }),
          dur && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-1.5 right-1.5 bg-black/85 text-white text-[10px] font-bold px-1.5 py-0.5 rounded", children: dur })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-1.5 text-[13px] font-semibold leading-tight line-clamp-2 group-hover:text-primary transition-colors", children: v.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-0.5 flex items-center gap-2 text-[11px] text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-0.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-3 w-3" }),
            fmt(v.views),
            " Vistas"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-0.5 text-primary", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "h-3 w-3" }),
            fmt(Math.max(1, Math.floor(v.views * 0.02)))
          ] })
        ] }),
        v.uploader && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-0.5 flex items-center gap-1 text-[11px] text-foreground/80", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: v.uploader.username }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "h-3 w-3 text-primary shrink-0" })
        ] })
      ]
    }
  );
};
function RecommendedRow({ videos }) {
  const scrollerRef = reactExports.useRef(null);
  const list = (() => {
    const byUser = /* @__PURE__ */ new Map();
    for (const v of videos) {
      const key = v.user_id ?? `anon-${v.id}`;
      const cur = byUser.get(key);
      if (!cur || v.views > cur.views) byUser.set(key, v);
    }
    return dailyShuffle(Array.from(byUser.values()), (v) => v.id).slice(0, 24);
  })();
  if (list.length === 0) return null;
  const scroll = (dir) => {
    scrollerRef.current?.scrollBy({ left: dir * 600, behavior: "smooth" });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "mb-6 -mx-3 sm:-mx-4 px-3 sm:px-4 relative group/row overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-bold mb-3", children: "Recomendados Para Ti" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: () => scroll(-1),
        className: "hidden md:flex absolute left-0 top-1/2 -translate-y-1/2 z-10 h-10 w-10 items-center justify-center rounded-full bg-background/80 border border-border opacity-0 group-hover/row:opacity-100 transition-opacity hover:bg-primary hover:text-primary-foreground",
        "aria-label": "Anterior",
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "h-5 w-5" })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        ref: scrollerRef,
        className: "flex gap-3 overflow-x-auto snap-x scroll-pl-4 pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
        children: list.map((v) => /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { v }, v.id))
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: () => scroll(1),
        className: "hidden md:flex absolute right-0 top-1/2 -translate-y-1/2 z-10 h-10 w-10 items-center justify-center rounded-full bg-background/80 border border-border opacity-0 group-hover/row:opacity-100 transition-opacity hover:bg-primary hover:text-primary-foreground",
        "aria-label": "Siguiente",
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-5 w-5" })
      }
    )
  ] });
}
function useIsAdmin() {
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = reactExports.useState(false);
  const [checked, setChecked] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (!user) {
      setIsAdmin(false);
      setChecked(true);
      return;
    }
    (async () => {
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", user.id).eq("role", "admin").maybeSingle();
      setIsAdmin(!!data);
      setChecked(true);
    })();
  }, [user]);
  return { isAdmin, checked };
}
const CATEGORIES = [
  { id: "inicio", label: "Inicio" },
  { id: "recientes", label: "Vídeos", hasMenu: true },
  { id: "mas-vistos", label: "Categorías", hasMenu: true },
  { id: "tendencias", label: "Tendencias" },
  { id: "recomendados", label: "Recomendados" },
  { id: "inicio", label: "Estrellas", hasMenu: true },
  { id: "inicio", label: "Comunidad" },
  { id: "inicio", label: "Fotos y GIFs", hasMenu: true }
];
const Index = () => {
  const navigate = distExports.useNavigate();
  const { user, profile } = useAuth();
  const { isAdmin } = useIsAdmin();
  const [videos, setVideos] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [search, setSearch] = reactExports.useState("");
  const [showUpload, setShowUpload] = reactExports.useState(false);
  const [showPhotoUpload, setShowPhotoUpload] = reactExports.useState(false);
  const [category, setCategory] = reactExports.useState("inicio");
  const [sideFilter, setSideFilter] = reactExports.useState(null);
  const [activeNav, setActiveNav] = reactExports.useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = reactExports.useState(false);
  const [photos, setPhotos] = reactExports.useState([]);
  const [photoStats, setPhotoStats] = reactExports.useState({});
  const [openPhoto, setOpenPhoto] = reactExports.useState(null);
  const searchRef = reactExports.useRef(null);
  const requireAuth = (action) => {
    if (!user) {
      navigate("/auth");
      return;
    }
    action();
  };
  const loadVideos = async () => {
    const { data, error } = await supabase.from("videos").select("*").order("created_at", { ascending: false });
    if (error) {
      toast$1.error(error.message);
      setLoading(false);
      return;
    }
    const ids = Array.from(new Set((data ?? []).map((v) => v.user_id).filter(Boolean)));
    const profMap = /* @__PURE__ */ new Map();
    if (ids.length) {
      const { data: profs } = await supabase.from("profiles").select("id,username,avatar_url").in("id", ids);
      (profs ?? []).forEach((p) => profMap.set(p.id, { username: p.username, avatar_url: p.avatar_url }));
    }
    setVideos((data ?? []).map((v) => ({ ...v, uploader: v.user_id ? profMap.get(v.user_id) ?? null : null })));
    setLoading(false);
  };
  const loadPhotos = async () => {
    const { data, error } = await supabase.from("photos").select("*").order("created_at", { ascending: false });
    if (error) {
      toast$1.error(error.message);
      return;
    }
    const ids = Array.from(new Set((data ?? []).map((p) => p.user_id)));
    const map = /* @__PURE__ */ new Map();
    if (ids.length) {
      const { data: profs } = await supabase.from("profiles").select("id,username,avatar_url").in("id", ids);
      (profs ?? []).forEach((p) => map.set(p.id, { username: p.username, avatar_url: p.avatar_url }));
    }
    const list = (data ?? []).map((p) => ({ ...p, uploader: map.get(p.user_id) ?? null }));
    setPhotos(list);
    if (list.length) {
      const photoIds = list.map((p) => p.id);
      const [{ data: rx }, { data: cm }] = await Promise.all([
        supabase.from("photo_reactions").select("photo_id").in("photo_id", photoIds),
        supabase.from("photo_comments").select("photo_id").in("photo_id", photoIds)
      ]);
      const stats = {};
      list.forEach((p) => {
        stats[p.id] = { likes: 0, comments: 0 };
      });
      (rx ?? []).forEach((r) => {
        if (stats[r.photo_id]) stats[r.photo_id].likes += 1;
      });
      (cm ?? []).forEach((c) => {
        if (stats[c.photo_id]) stats[c.photo_id].comments += 1;
      });
      setPhotoStats(stats);
    } else {
      setPhotoStats({});
    }
  };
  reactExports.useEffect(() => {
    document.title = "X Pornazo — Sube y mira videos";
    loadVideos();
    loadPhotos();
    const channel = supabase.channel("videos-changes").on("postgres_changes", { event: "*", schema: "public", table: "videos" }, () => loadVideos()).on("postgres_changes", { event: "*", schema: "public", table: "photos" }, () => loadPhotos()).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);
  const filtered = (() => {
    let list = videos.filter((v) => v.title.toLowerCase().includes(search.toLowerCase()));
    const now = Date.now();
    if (sideFilter?.keyword) {
      const norm = (s) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      const kw = norm(sideFilter.keyword);
      list = list.filter(
        (v) => norm(v.title).includes(kw) || norm(v.description ?? "").includes(kw) || (v.tags ?? []).some((t) => norm(t).includes(kw))
      );
    }
    if (sideFilter?.shortsOnly) {
      list = list.filter((v) => (v.duration_seconds ?? 999) <= 60);
    }
    const effectiveSort = sideFilter?.sort ?? category;
    switch (effectiveSort) {
      case "recientes":
        list = [...list].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        break;
      case "mas-vistos":
        list = [...list].sort((a, b) => b.views - a.views);
        break;
      case "tendencias": {
        const score = (v) => v.views / Math.max(1, (now - new Date(v.created_at).getTime()) / 36e5);
        list = [...list].sort((a, b) => score(b) - score(a));
        break;
      }
      case "recomendados": {
        const score = (v) => Math.log(v.views + 1) * 10 - Math.max(1, (now - new Date(v.created_at).getTime()) / 864e5) * 0.5;
        list = [...list].sort((a, b) => score(b) - score(a));
        break;
      }
      default:
        list = [...list].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    }
    return list;
  })();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen overflow-x-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "sticky top-0 z-40 bg-header border-b border-border", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-3 sm:px-4 h-16 flex items-center gap-2 sm:gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setMobileMenuOpen((v) => !v),
            className: "lg:hidden p-2 -ml-2 text-foreground hover:text-primary transition-colors",
            "aria-label": "Menú",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "h-6 w-6" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: "/",
            onClick: (e) => {
              e.preventDefault();
              window.location.assign("/");
            },
            className: "flex items-center gap-1 shrink-0",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl sm:text-3xl font-extrabold text-primary leading-none", children: "X" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xl sm:text-2xl font-bold text-foreground tracking-tight leading-none", children: "Pornazo" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "hidden md:flex flex-1 items-center max-w-2xl mx-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1 group", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Input,
            {
              ref: searchRef,
              placeholder: "Buscar en X Pornazo",
              value: search,
              onChange: (e) => setSearch(e.target.value),
              className: "pl-11 pr-12 h-10 bg-secondary/70 border border-border rounded-full focus-visible:ring-1 focus-visible:ring-primary"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => searchRef.current?.focus(),
              className: "absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:bg-primary/90 transition-colors",
              "aria-label": "Buscar",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "h-4 w-4" })
            }
          )
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "md:hidden flex-1" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            onClick: () => user ? setShowUpload(true) : navigate("/auth"),
            className: "rounded-full font-bold px-3 sm:px-4 h-10 shrink-0 shadow-[0_4px_14px_-2px_hsl(var(--primary)/0.4)]",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" }),
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden md:inline", children: "Subir" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden md:flex items-center gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => requireAuth(() => setShowUpload(true)),
              className: "relative h-10 w-10 rounded-full hover:bg-secondary flex items-center justify-center text-foreground/80 hover:text-primary transition-colors",
              "aria-label": "Subir vídeo",
              title: "Subir vídeo",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "h-5 w-5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center", children: "+" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => requireAuth(() => setShowPhotoUpload(true)),
              className: "relative h-10 w-10 rounded-full hover:bg-secondary flex items-center justify-center text-foreground/80 hover:text-primary transition-colors",
              "aria-label": "Subir foto",
              title: "Subir foto",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "h-5 w-5" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center", children: "+" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "a",
            {
              href: "https://x.com/xpornazo?s=21",
              target: "_blank",
              rel: "noopener noreferrer",
              className: "h-10 w-10 rounded-full hover:bg-secondary flex items-center justify-center text-foreground/80 hover:text-primary transition-colors",
              "aria-label": "Síguenos en X (Twitter)",
              title: "Síguenos en X",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", className: "h-5 w-5", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231 5.45-6.231Zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77Z" }) })
            }
          )
        ] }),
        user && profile ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          distExports.Link,
          {
            to: `/u/${profile.username}`,
            className: "shrink-0 w-10 h-10 rounded-full bg-secondary overflow-hidden flex items-center justify-center hover:ring-2 hover:ring-primary transition",
            title: `@${profile.username}`,
            children: profile.avatar_url ? /* @__PURE__ */ jsxRuntimeExports.jsx(SignedImg, { src: profile.avatar_url, alt: profile.username, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-5 w-5 text-muted-foreground" })
          }
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Link, { to: "/auth", className: "shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "ghost", size: "sm", className: "rounded-full", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LogIn, { className: "h-4 w-4" }),
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden md:inline", children: "Entrar" })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "md:hidden container mx-auto px-3 pb-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative group", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Input,
          {
            placeholder: "Buscar en X Pornazo",
            value: search,
            onChange: (e) => setSearch(e.target.value),
            className: "pl-11 pr-4 h-10 bg-secondary/70 border border-border rounded-full focus-visible:ring-1 focus-visible:ring-primary w-full"
          }
        )
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "bg-header", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container mx-auto px-3 sm:px-4 h-11 flex items-center justify-start md:justify-center gap-1 md:gap-2 overflow-x-auto no-scrollbar text-xs sm:text-sm font-bold uppercase tracking-wide", children: CATEGORIES.map((c, i) => {
        const active = activeNav === i;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              setActiveNav(i);
              setCategory(c.id);
              setSearch("");
              window.scrollTo({ top: 0, behavior: "smooth" });
            },
            className: `relative h-11 px-3 md:px-4 flex items-center gap-1 whitespace-nowrap transition-colors ${active ? "text-primary" : "text-foreground/80 hover:text-primary"}`,
            children: [
              c.label,
              c.hasMenu && /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "h-3 w-3 opacity-70" }),
              active && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-0 left-2 right-2 h-[3px] rounded-t-full bg-primary" })
            ]
          },
          `${c.label}-${i}`
        );
      }) }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full px-3 sm:px-4 flex gap-4 relative", children: [
      mobileMenuOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "fixed inset-0 bg-background/60 z-30 lg:hidden",
          onClick: () => setMobileMenuOpen(false)
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: `${mobileMenuOpen ? "fixed top-0 left-0 bottom-0 z-40 w-64 bg-card overflow-y-auto pt-4 shadow-2xl" : "hidden"} lg:static lg:block lg:w-60 lg:bg-transparent lg:shadow-none lg:overflow-visible lg:pt-0`,
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            Sidebar,
            {
              loggedIn: !!user,
              isAdmin,
              onSelectFilter: (f) => {
                setSideFilter(f);
                if (f.sort) setCategory(f.sort);
                setSearch("");
                setMobileMenuOpen(false);
                window.scrollTo({ top: 0, behavior: "smooth" });
              }
            }
          )
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "flex-1 min-w-0 py-4 sm:py-6", children: sideFilter?.mode === "fotos" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-lg sm:text-xl font-bold truncate min-w-0", children: sideFilter.label }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:gap-3 flex-wrap", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => {
                  setSideFilter(null);
                  setCategory("inicio");
                },
                className: "text-xs text-muted-foreground hover:text-primary underline",
                children: "Limpiar filtro"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                size: "sm",
                onClick: () => user ? setShowPhotoUpload(true) : navigate("/auth"),
                className: "rounded-full",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "h-4 w-4" }),
                  " ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Subir foto" })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs sm:text-sm text-muted-foreground", children: [
              photos.length,
              " fotos"
            ] })
          ] })
        ] }),
        (() => {
          let list = [...photos];
          if (sideFilter.photoSort === "mas-vistas") {
            list.sort((a, b) => (photoStats[b.id]?.likes ?? 0) - (photoStats[a.id]?.likes ?? 0));
          } else if (sideFilter.photoSort === "recomendadas") {
            list.sort((a, b) => {
              const sa = (photoStats[a.id]?.likes ?? 0) + (photoStats[a.id]?.comments ?? 0);
              const sb = (photoStats[b.id]?.likes ?? 0) + (photoStats[b.id]?.comments ?? 0);
              return sb - sa;
            });
          }
          if (list.length === 0) {
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-20", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground mb-4", children: "Aún no hay fotos." }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: () => user ? setShowPhotoUpload(true) : navigate("/auth"), children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "h-4 w-4" }),
                " Sube la primera"
              ] })
            ] });
          }
          return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5", children: list.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            PhotoCard,
            {
              photo: p,
              likes: photoStats[p.id]?.likes ?? 0,
              comments: photoStats[p.id]?.comments ?? 0,
              onClick: () => setOpenPhoto(p)
            },
            p.id
          )) });
        })()
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-lg sm:text-xl font-bold truncate min-w-0 max-w-full", children: search ? `Resultados: "${search}"` : sideFilter?.label ?? CATEGORIES.find((c) => c.id === category)?.label }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 sm:gap-3 flex-wrap", children: [
            sideFilter && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => {
                  setSideFilter(null);
                  setCategory("inicio");
                },
                className: "text-xs text-muted-foreground hover:text-primary underline",
                children: "Limpiar filtro"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs sm:text-sm text-muted-foreground", children: [
              filtered.length,
              " videos"
            ] })
          ] })
        ] }),
        !search && !sideFilter && category === "inicio" && !loading && videos.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(RecommendedRow, { videos }),
        loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-8 w-8 animate-spin text-primary" }) }) : filtered.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-20", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground mb-4", children: "No hay videos todavía." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: () => user ? setShowUpload(true) : navigate("/auth"), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" }),
            " Sube el primero"
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4", children: filtered.map((v) => /* @__PURE__ */ jsxRuntimeExports.jsx(VideoCard, { video: v }, v.id)) })
      ] }) })
    ] }),
    showUpload && user && /* @__PURE__ */ jsxRuntimeExports.jsx(UploadModal, { userId: user.id, onClose: () => setShowUpload(false) }),
    showPhotoUpload && user && /* @__PURE__ */ jsxRuntimeExports.jsx(PhotoUploadModal, { userId: user.id, onClose: () => setShowPhotoUpload(false), onUploaded: loadPhotos }),
    openPhoto && /* @__PURE__ */ jsxRuntimeExports.jsx(
      PhotoDetailModal,
      {
        photo: openPhoto,
        onClose: () => setOpenPhoto(null),
        onDeleted: () => loadPhotos()
      }
    )
  ] });
};
const STORAGE_KEY$1 = "xpornazo-age-confirmed";
const AgeGate = () => {
  const [confirmed, setConfirmed] = reactExports.useState(null);
  reactExports.useEffect(() => {
    setConfirmed(localStorage.getItem(STORAGE_KEY$1) === "1");
  }, []);
  if (confirmed === null || confirmed) return null;
  const accept = () => {
    localStorage.setItem(STORAGE_KEY$1, "1");
    setConfirmed(true);
  };
  const reject = () => {
    window.location.href = "https://www.google.com";
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-[100] bg-black flex items-center justify-center p-4 overflow-y-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-2xl bg-card border border-border rounded-lg p-8 md:p-10 text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 justify-center mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-4xl md:text-5xl font-extrabold text-primary", children: "X" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-3xl md:text-4xl font-bold tracking-tight text-foreground", children: "Pornazo" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl md:text-3xl font-bold mb-4 text-foreground", children: "Este es un Sitio Web para adultos" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        type: "button",
        className: "mb-6 inline-block border-2 border-primary text-primary font-semibold px-4 py-2 rounded hover:bg-primary hover:text-primary-foreground transition-colors",
        children: "Aviso a usuarios"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground leading-relaxed mb-4 text-sm md:text-base", children: "Este sitio web contiene material restringido a menores de edad, que incluye desnudez y representaciones explícitas de actividad sexual. Al entrar, afirma que tiene por lo menos 18 años de edad o la mayoría de edad en la jurisdicción desde que está accediendo el sitio web y que da consentimiento en ver contenido sexualmente explícito." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-primary font-semibold mb-8", children: "Aviso a las fuerzas del orden" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: accept,
          className: "border-2 border-primary bg-transparent hover:bg-primary hover:text-primary-foreground text-foreground font-bold py-4 px-4 rounded transition-colors",
          children: "Tengo 18 años o más - Entrar"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: reject,
          className: "border-2 border-border bg-transparent hover:bg-secondary text-foreground font-bold py-4 px-4 rounded transition-colors",
          children: "Soy menor de 18 años - Salir"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-muted-foreground text-sm mb-2", children: [
      "Nuestra ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-primary", children: "página de control parental" }),
      " explica cómo bloquear fácilmente el acceso a este sitio."
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-primary font-semibold mb-6", children: "Términos de Servicio" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "© X Pornazo, 2026" })
  ] }) });
};
const Dialog = Dialog$1;
const DialogPortal = DialogPortal$1;
const DialogOverlay = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  DialogOverlay$1,
  {
    ref,
    className: cn(
      "fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    ),
    ...props
  }
));
DialogOverlay.displayName = DialogOverlay$1.displayName;
const DialogContent = reactExports.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogPortal, { children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx(DialogOverlay, {}),
  /* @__PURE__ */ jsxRuntimeExports.jsxs(
    DialogContent$1,
    {
      ref,
      className: cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogClose, { className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity data-[state=open]:bg-accent data-[state=open]:text-muted-foreground hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Close" })
        ] })
      ]
    }
  )
] }));
DialogContent.displayName = DialogContent$1.displayName;
const DialogHeader = ({ className, ...props }) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className), ...props });
DialogHeader.displayName = "DialogHeader";
const DialogFooter = ({ className, ...props }) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className), ...props });
DialogFooter.displayName = "DialogFooter";
const DialogTitle = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  DialogTitle$1,
  {
    ref,
    className: cn("text-lg font-semibold leading-none tracking-tight", className),
    ...props
  }
));
DialogTitle.displayName = DialogTitle$1.displayName;
const DialogDescription = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription$1, { ref, className: cn("text-sm text-muted-foreground", className), ...props }));
DialogDescription.displayName = DialogDescription$1.displayName;
const Switch = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Switch$1,
  {
    className: cn(
      "peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors data-[state=checked]:bg-primary data-[state=unchecked]:bg-input focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50",
      className
    ),
    ...props,
    ref,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      SwitchThumb,
      {
        className: cn(
          "pointer-events-none block h-5 w-5 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0"
        )
      }
    )
  }
));
Switch.displayName = Switch$1.displayName;
const labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
const Label = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(Label$1, { ref, className: cn(labelVariants(), className), ...props }));
Label.displayName = Label$1.displayName;
const STORAGE_KEY = "xp_cookie_prefs_v1";
const getCookiePrefs = () => {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};
const applyPrefs = (prefs) => {
  if (typeof window === "undefined") return;
  window.__cookiePrefs = prefs;
  window.dispatchEvent(new CustomEvent("cookie-prefs-changed", { detail: prefs }));
};
const CookieConsent = () => {
  const [visible, setVisible] = reactExports.useState(false);
  const [openCustom, setOpenCustom] = reactExports.useState(false);
  const [analytics, setAnalytics] = reactExports.useState(true);
  const [marketing, setMarketing] = reactExports.useState(false);
  reactExports.useEffect(() => {
    const existing = getCookiePrefs();
    if (!existing) {
      const t = setTimeout(() => setVisible(true), 600);
      return () => clearTimeout(t);
    } else {
      applyPrefs(existing);
      setAnalytics(existing.analytics);
      setMarketing(existing.marketing);
    }
  }, []);
  const save = (prefs) => {
    const full = {
      necessary: true,
      analytics: prefs.analytics,
      marketing: prefs.marketing,
      acceptedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(full));
    applyPrefs(full);
    setVisible(false);
    setOpenCustom(false);
  };
  if (!visible && !openCustom) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    visible && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        role: "dialog",
        "aria-label": "Aviso de cookies",
        className: "fixed bottom-4 left-4 right-4 sm:left-6 sm:right-auto sm:bottom-6 sm:max-w-md z-[100] bg-card border border-border rounded-lg shadow-2xl p-4 sm:p-5 animate-in fade-in slide-in-from-bottom-4",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => save({ analytics: false, marketing: false }),
              "aria-label": "Cerrar",
              className: "absolute top-2 right-2 p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "shrink-0 mt-0.5 w-9 h-9 rounded-full bg-primary/15 text-primary flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Cookie, { className: "h-5 w-5" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 pr-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-foreground/90 leading-relaxed", children: [
                "Este sitio utiliza cookies para ayudar a mejorar su experiencia de usuario. Obtenga más información sobre cómo usamos las cookies en nuestro",
                " ",
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "a",
                  {
                    href: "#",
                    className: "text-primary hover:underline font-medium",
                    onClick: (e) => {
                      e.preventDefault();
                      setOpenCustom(true);
                    },
                    children: "Aviso sobre cookies"
                  }
                ),
                "."
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex flex-col sm:flex-row gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Button,
                  {
                    variant: "outline",
                    size: "sm",
                    onClick: () => setOpenCustom(true),
                    className: "rounded-md",
                    children: "Personalizar cookies"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Button,
                  {
                    size: "sm",
                    onClick: () => save({ analytics: true, marketing: true }),
                    className: "rounded-md",
                    children: "Ok"
                  }
                )
              ] })
            ] })
          ] })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: openCustom, onOpenChange: setOpenCustom, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "sm:max-w-lg", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: "Preferencias de cookies" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: "Elige qué cookies quieres permitir. Puedes cambiar estas preferencias en cualquier momento." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 py-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-4 p-3 rounded-md border border-border", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-semibold", children: "Necesarias" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "Imprescindibles para el funcionamiento del sitio (sesión, seguridad). No se pueden desactivar." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: true, disabled: true })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-4 p-3 rounded-md border border-border", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "ck-an", className: "text-sm font-semibold", children: "Analíticas" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "Nos ayudan a entender cómo usas el sitio para mejorarlo." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { id: "ck-an", checked: analytics, onCheckedChange: setAnalytics })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-4 p-3 rounded-md border border-border", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "ck-mk", className: "text-sm font-semibold", children: "Marketing" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "Permiten mostrar contenido y anuncios más relevantes." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { id: "ck-mk", checked: marketing, onCheckedChange: setMarketing })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogFooter, { className: "gap-2 sm:gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            variant: "outline",
            onClick: () => save({ analytics: false, marketing: false }),
            children: "Rechazar todo"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: () => save({ analytics, marketing }), children: "Guardar preferencias" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            variant: "secondary",
            onClick: () => save({ analytics: true, marketing: true }),
            children: "Aceptar todo"
          }
        )
      ] })
    ] }) })
  ] });
};
const Auth = reactExports.lazy(() => import("./Auth-wlDAACwl.mjs"));
const Profile = reactExports.lazy(() => import("./Profile-jMgXQKEj.mjs"));
const Watch = reactExports.lazy(() => import("./Watch-BboKgHcR.mjs"));
const Monetization = reactExports.lazy(() => import("./Monetization-CArR2tmH.mjs"));
const Stats = reactExports.lazy(() => import("./Stats-BkJBExPi.mjs"));
const Admin = reactExports.lazy(() => import("./Admin-BGTaHbBN.mjs"));
const NotFound = reactExports.lazy(() => import("./NotFound-q44gkQ1n.mjs"));
const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 3e4, refetchOnWindowFocus: false, retry: 1 }
  }
});
const RouteFallback = () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-8 w-8 animate-spin text-primary" }) });
const App = () => /* @__PURE__ */ jsxRuntimeExports.jsx(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TooltipProvider, { children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx(Toaster, {}),
  /* @__PURE__ */ jsxRuntimeExports.jsx(Toaster$1, {}),
  /* @__PURE__ */ jsxRuntimeExports.jsx(AgeGate, {}),
  /* @__PURE__ */ jsxRuntimeExports.jsx(CookieConsent, {}),
  /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.BrowserRouter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Suspense, { fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(RouteFallback, {}), children: /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Routes, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Route, { path: "/", element: /* @__PURE__ */ jsxRuntimeExports.jsx(Index, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Route, { path: "/auth", element: /* @__PURE__ */ jsxRuntimeExports.jsx(Auth, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Route, { path: "/u/:username", element: /* @__PURE__ */ jsxRuntimeExports.jsx(Profile, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Route, { path: "/v/:id", element: /* @__PURE__ */ jsxRuntimeExports.jsx(Watch, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Route, { path: "/monetization", element: /* @__PURE__ */ jsxRuntimeExports.jsx(Monetization, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Route, { path: "/stats", element: /* @__PURE__ */ jsxRuntimeExports.jsx(Stats, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Route, { path: "/admin", element: /* @__PURE__ */ jsxRuntimeExports.jsx(Admin, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Route, { path: "*", element: /* @__PURE__ */ jsxRuntimeExports.jsx(NotFound, {}) })
  ] }) }) })
] }) });
function NotFoundComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  console.error(error);
  const router2 = useRouter();
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-semibold tracking-tight text-foreground", children: "This page didn't load" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Something went wrong on our end. You can try refreshing or head back home." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const Route$2 = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Xpornazo" },
      { name: "description", content: "Xpornazo — plataforma de vídeo para adultos. Solo mayores de 18 años." },
      { name: "robots", content: "index, follow" },
      { name: "rating", content: "adult" },
      { property: "og:title", content: "Xpornazo" },
      { property: "og:description", content: "Xpornazo — plataforma de vídeo para adultos. Solo mayores de 18 años." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Xpornazo" },
      { name: "twitter:description", content: "Xpornazo — plataforma de vídeo para adultos. Solo mayores de 18 años." }
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss
      }
    ],
    scripts: [
      {
        async: true,
        src: "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8157843279313545",
        crossOrigin: "anonymous"
      }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "es", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { queryClient: queryClient2 } = Route$2.useRouteContext();
  const [mounted, setMounted] = reactExports.useState(false);
  reactExports.useEffect(() => {
    setMounted(true);
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(QueryClientProvider, { client: queryClient2, children: mounted ? /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) : null });
}
const $$splitComponentImporter$1 = () => import("./index-xJGBGZcv.mjs");
const Route$1 = createFileRoute()({
  component: lazyRouteComponent($$splitComponentImporter$1, "component"),
  ssr: false
});
const $$splitComponentImporter = () => import("../_-xJGBGZcv.mjs");
const Route = createFileRoute()({
  component: lazyRouteComponent($$splitComponentImporter, "component"),
  ssr: false
});
const IndexRoute = Route$1.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$2
});
const SplatRoute = Route.update({
  id: "/$",
  path: "/$",
  getParentRoute: () => Route$2
});
const rootRouteChildren = {
  IndexRoute,
  SplatRoute
};
const routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient2 = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient: queryClient2 },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  App as A,
  Button as B,
  Dialog as D,
  Input as I,
  Label as L,
  SignedImg as S,
  Textarea as T,
  VideoCard as V,
  DialogContent as a,
  DialogHeader as b,
  cn as c,
  DialogTitle as d,
  DialogFooter as e,
  useIsAdmin as f,
  getPlayableUrl as g,
  router as r,
  useAuth as u
};
