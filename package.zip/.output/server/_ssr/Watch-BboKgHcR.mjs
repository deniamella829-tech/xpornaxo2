import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useAuth, g as getPlayableUrl, B as Button, S as SignedImg, V as VideoCard, D as Dialog, a as DialogContent, b as DialogHeader, d as DialogTitle, T as Textarea, e as DialogFooter } from "./router-wXGJZuFu.mjs";
import { d as distExports } from "../_libs/react-router-dom.mjs";
import { s as supabase } from "./client-DChbXGiG.mjs";
import { B as Badge } from "./badge-DJOd9VwP.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { u as useFollow } from "./use-follow-C_XpFrzi.mjs";
import "../_libs/next-themes.mjs";
import { L as LoaderCircle, x as ArrowLeft, U as User, P as Play, E as Eye, B as BadgeCheck, N as ExternalLink, R as Rss, q as ThumbsUp, O as ThumbsDown, H as Heart, Q as Plus, _ as Share2, $ as Flag, l as MessageCircle, e as LogIn, T as Trash2 } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/seroval.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/radix-ui__react-toast.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-effect-event+[...].mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-tooltip.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/react-router.mjs";
import "../_libs/cookie.mjs";
import "../_libs/set-cookie-parser.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/supabase__functions-js.mjs";
const KEY = "xpz_visitor_id";
function uuid() {
  if (crypto?.randomUUID) return crypto.randomUUID();
  return "v-" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}
function getVisitorId() {
  if (typeof window === "undefined") return "";
  let id = "";
  try {
    id = localStorage.getItem(KEY) ?? "";
  } catch {
  }
  if (!id) {
    const m = document.cookie.match(/(?:^|;\s*)xpz_vid=([^;]+)/);
    if (m) id = decodeURIComponent(m[1]);
  }
  if (!id) id = uuid();
  try {
    localStorage.setItem(KEY, id);
  } catch {
  }
  document.cookie = `xpz_vid=${encodeURIComponent(id)}; max-age=${60 * 60 * 24 * 365}; path=/; SameSite=Lax`;
  return id;
}
const BrandIntro = ({ onFinish, duration = 3400 }) => {
  const [phase, setPhase] = reactExports.useState("in");
  const finishedRef = reactExports.useRef(false);
  reactExports.useEffect(() => {
    let ctx = null;
    const totalSec = duration / 1e3;
    const landSec = 0.95;
    const outSec = totalSec - 0.5;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      ctx = new AC();
      const now = ctx.currentTime;
      const master = ctx.createGain();
      master.gain.value = 0.9;
      master.connect(ctx.destination);
      const whooshDur = landSec;
      const noiseBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * whooshDur), ctx.sampleRate);
      const ndata = noiseBuf.getChannelData(0);
      for (let i = 0; i < ndata.length; i++) ndata[i] = Math.random() * 2 - 1;
      const noise = ctx.createBufferSource();
      noise.buffer = noiseBuf;
      const nFilt = ctx.createBiquadFilter();
      nFilt.type = "bandpass";
      nFilt.Q.value = 1.2;
      nFilt.frequency.setValueAtTime(300, now);
      nFilt.frequency.exponentialRampToValueAtTime(4500, now + whooshDur);
      const nGain = ctx.createGain();
      nGain.gain.setValueAtTime(1e-4, now);
      nGain.gain.exponentialRampToValueAtTime(0.45, now + whooshDur * 0.85);
      nGain.gain.exponentialRampToValueAtTime(1e-4, now + whooshDur + 0.05);
      noise.connect(nFilt).connect(nGain).connect(master);
      noise.start(now);
      noise.stop(now + whooshDur + 0.1);
      const riser = ctx.createOscillator();
      riser.type = "sawtooth";
      riser.frequency.setValueAtTime(80, now);
      riser.frequency.exponentialRampToValueAtTime(900, now + whooshDur);
      const riserGain = ctx.createGain();
      riserGain.gain.setValueAtTime(1e-4, now);
      riserGain.gain.exponentialRampToValueAtTime(0.18, now + whooshDur * 0.9);
      riserGain.gain.exponentialRampToValueAtTime(1e-4, now + whooshDur + 0.05);
      const riserFilt = ctx.createBiquadFilter();
      riserFilt.type = "lowpass";
      riserFilt.frequency.value = 1800;
      riser.connect(riserFilt).connect(riserGain).connect(master);
      riser.start(now);
      riser.stop(now + whooshDur + 0.1);
      const hit = now + landSec;
      const sub = ctx.createOscillator();
      sub.type = "sine";
      sub.frequency.setValueAtTime(220, hit);
      sub.frequency.exponentialRampToValueAtTime(40, hit + 0.45);
      const subGain = ctx.createGain();
      subGain.gain.setValueAtTime(1e-4, hit);
      subGain.gain.exponentialRampToValueAtTime(0.85, hit + 0.02);
      subGain.gain.exponentialRampToValueAtTime(1e-4, hit + 0.9);
      sub.connect(subGain).connect(master);
      sub.start(hit);
      sub.stop(hit + 0.95);
      const click = ctx.createOscillator();
      click.type = "square";
      click.frequency.setValueAtTime(1200, hit);
      click.frequency.exponentialRampToValueAtTime(400, hit + 0.1);
      const clickGain = ctx.createGain();
      clickGain.gain.setValueAtTime(0.3, hit);
      clickGain.gain.exponentialRampToValueAtTime(1e-4, hit + 0.12);
      click.connect(clickGain).connect(master);
      click.start(hit);
      click.stop(hit + 0.15);
      const impBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.25), ctx.sampleRate);
      const idata = impBuf.getChannelData(0);
      for (let i = 0; i < idata.length; i++) idata[i] = (Math.random() * 2 - 1) * (1 - i / idata.length);
      const imp = ctx.createBufferSource();
      imp.buffer = impBuf;
      const impGain = ctx.createGain();
      impGain.gain.value = 0.4;
      imp.connect(impGain).connect(master);
      imp.start(hit);
      const shimmerStart = hit + 0.25;
      const shimmerEnd = now + outSec;
      const shimmer = ctx.createOscillator();
      shimmer.type = "triangle";
      shimmer.frequency.value = 660;
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 1 / 1.2;
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = 80;
      lfo.connect(lfoGain).connect(shimmer.frequency);
      const shGain = ctx.createGain();
      shGain.gain.setValueAtTime(1e-4, shimmerStart);
      shGain.gain.exponentialRampToValueAtTime(0.08, shimmerStart + 0.3);
      shGain.gain.setValueAtTime(0.08, shimmerEnd - 0.2);
      shGain.gain.exponentialRampToValueAtTime(1e-4, shimmerEnd);
      shimmer.connect(shGain).connect(master);
      shimmer.start(shimmerStart);
      lfo.start(shimmerStart);
      shimmer.stop(shimmerEnd + 0.05);
      lfo.stop(shimmerEnd + 0.05);
      const outHit = now + outSec;
      const outOsc = ctx.createOscillator();
      outOsc.type = "sine";
      outOsc.frequency.setValueAtTime(120, outHit);
      outOsc.frequency.exponentialRampToValueAtTime(30, outHit + 0.5);
      const outGain = ctx.createGain();
      outGain.gain.setValueAtTime(1e-4, outHit);
      outGain.gain.exponentialRampToValueAtTime(0.45, outHit + 0.05);
      outGain.gain.exponentialRampToValueAtTime(1e-4, outHit + 0.55);
      outOsc.connect(outGain).connect(master);
      outOsc.start(outHit);
      outOsc.stop(outHit + 0.6);
    } catch {
    }
    const t1 = setTimeout(() => setPhase("hold"), landSec * 1e3);
    const t2 = setTimeout(() => setPhase("out"), duration - 500);
    const t3 = setTimeout(() => {
      if (!finishedRef.current) {
        finishedRef.current = true;
        onFinish();
      }
      ctx?.close().catch(() => {
      });
    }, duration);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      ctx?.close().catch(() => {
      });
    };
  }, [duration, onFinish]);
  const handleSkip = () => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    onFinish();
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      onClick: handleSkip,
      className: `absolute inset-0 z-20 flex items-center justify-center bg-black overflow-hidden cursor-pointer ${phase === "out" ? "intro-fade-out" : ""}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_center,hsl(var(--primary)/0.35),transparent_60%)] intro-pulse" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 intro-sweep bg-[linear-gradient(110deg,transparent_40%,hsl(var(--primary)/0.25)_50%,transparent_60%)]" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `relative flex items-center gap-2 md:gap-3 ${phase === "in" ? "intro-logo-in" : "intro-logo-hold"}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: "text-6xl md:text-8xl font-extrabold text-primary drop-shadow-[0_0_25px_hsl(var(--primary)/0.8)]",
              style: { letterSpacing: "-0.05em" },
              children: "X"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: "text-4xl md:text-6xl font-extrabold text-foreground tracking-tight",
              style: { textShadow: "0 0 20px rgba(255,255,255,0.4)" },
              children: "Pornazo"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: (e) => {
              e.stopPropagation();
              handleSkip();
            },
            className: "absolute bottom-4 right-4 text-xs text-white/60 hover:text-white px-3 py-1 rounded bg-white/10 hover:bg-white/20 transition",
            children: "Saltar intro"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("style", { children: `
        @keyframes introLogoIn {
          0%   { opacity: 0; transform: scale(0.3) rotate(-8deg); filter: blur(20px); }
          70%  { opacity: 1; transform: scale(1.18) rotate(0deg); filter: blur(0); }
          100% { opacity: 1; transform: scale(1); }
        }
        @keyframes introPulse {
          0%, 100% { opacity: 0.4; transform: scale(1); }
          50%      { opacity: 1;   transform: scale(1.15); }
        }
        @keyframes introSweep {
          0%   { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        @keyframes introFadeOut {
          to { opacity: 0; }
        }
        .intro-logo-in   { animation: introLogoIn 0.95s cubic-bezier(.2,.9,.25,1.2) both; }
        .intro-logo-hold { animation: introPulse 1.2s ease-in-out infinite; }
        .intro-pulse     { animation: introPulse 1.6s ease-in-out infinite; }
        .intro-sweep     { animation: introSweep 0.95s ease-out forwards; }
        .intro-fade-out  { animation: introFadeOut 0.5s ease-out forwards; }
      ` })
      ]
    }
  );
};
function VideoActions({ videoId }) {
  const { user } = useAuth();
  const navigate = distExports.useNavigate();
  const [counts, setCounts] = reactExports.useState({ likes: 0, dislikes: 0 });
  const [me, setMe] = reactExports.useState({ reaction: null, favorited: false });
  const [busy, setBusy] = reactExports.useState(false);
  const [reportOpen, setReportOpen] = reactExports.useState(false);
  const [reportReason, setReportReason] = reactExports.useState("Contenido inapropiado");
  const [reportDetails, setReportDetails] = reactExports.useState("");
  const [reporting, setReporting] = reactExports.useState(false);
  reactExports.useEffect(() => {
    (async () => {
      const [{ data: rx }, mine, fav] = await Promise.all([
        supabase.from("video_reactions").select("reaction").eq("video_id", videoId),
        user ? supabase.from("video_reactions").select("reaction").eq("video_id", videoId).eq("user_id", user.id).maybeSingle() : Promise.resolve({ data: null }),
        user ? supabase.from("video_favorites").select("video_id").eq("video_id", videoId).eq("user_id", user.id).maybeSingle() : Promise.resolve({ data: null })
      ]);
      const likes = (rx ?? []).filter((r) => r.reaction === "like").length;
      const dislikes = (rx ?? []).filter((r) => r.reaction === "dislike").length;
      setCounts({ likes, dislikes });
      setMe({
        reaction: mine.data?.reaction ?? null,
        favorited: !!fav.data
      });
    })();
  }, [videoId, user]);
  const requireAuth = () => {
    if (!user) {
      toast.error("Regístrate para interactuar");
      navigate("/auth");
      return false;
    }
    return true;
  };
  const react = async (kind) => {
    if (!requireAuth() || busy) return;
    setBusy(true);
    const prev = me.reaction;
    if (prev === kind) {
      const { error } = await supabase.from("video_reactions").delete().eq("video_id", videoId).eq("user_id", user.id);
      if (!error) {
        setMe({ ...me, reaction: null });
        setCounts((c) => ({ ...c, [kind === "like" ? "likes" : "dislikes"]: Math.max(0, c[kind === "like" ? "likes" : "dislikes"] - 1) }));
      }
    } else {
      const { error } = await supabase.from("video_reactions").upsert({ video_id: videoId, user_id: user.id, reaction: kind }, { onConflict: "video_id,user_id" });
      if (!error) {
        setMe({ ...me, reaction: kind });
        setCounts((c) => {
          const next = { ...c };
          if (kind === "like") {
            next.likes += 1;
            if (prev === "dislike") next.dislikes = Math.max(0, next.dislikes - 1);
          } else {
            next.dislikes += 1;
            if (prev === "like") next.likes = Math.max(0, next.likes - 1);
          }
          return next;
        });
      }
    }
    setBusy(false);
  };
  const toggleFav = async () => {
    if (!requireAuth() || busy) return;
    setBusy(true);
    if (me.favorited) {
      await supabase.from("video_favorites").delete().eq("video_id", videoId).eq("user_id", user.id);
      setMe({ ...me, favorited: false });
      toast.success("Quitado de favoritos");
    } else {
      await supabase.from("video_favorites").insert({ video_id: videoId, user_id: user.id });
      setMe({ ...me, favorited: true });
      toast.success("Añadido a favoritos");
    }
    setBusy(false);
  };
  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({ url, title: document.title });
      else {
        await navigator.clipboard.writeText(url);
        toast.success("Enlace copiado");
      }
    } catch {
    }
  };
  const submitReport = async () => {
    if (!requireAuth()) return;
    setReporting(true);
    const { error } = await supabase.from("video_reports").insert({
      video_id: videoId,
      user_id: user.id,
      reason: reportReason,
      details: reportDetails.trim() || null
    });
    setReporting(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Reporte enviado. Gracias.");
    setReportOpen(false);
    setReportDetails("");
  };
  const Btn = ({ active, onClick, children, title }) => /* @__PURE__ */ jsxRuntimeExports.jsx(
    "button",
    {
      onClick,
      title,
      className: `flex items-center gap-1.5 px-3 py-2 rounded-full text-sm font-medium transition-colors ${active ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-secondary/70 text-foreground"}`,
      children
    }
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex flex-wrap items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center bg-secondary rounded-full overflow-hidden", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => react("like"),
            className: `flex items-center gap-1.5 pl-4 pr-3 py-2 text-sm font-semibold transition-colors ${me.reaction === "like" ? "text-primary" : "hover:text-primary"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: `h-4 w-4 ${me.reaction === "like" ? "fill-current" : ""}` }),
              counts.likes
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-5 w-px bg-border" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => react("dislike"),
            className: `flex items-center gap-1.5 px-3 py-2 text-sm font-semibold transition-colors ${me.reaction === "dislike" ? "text-destructive" : "hover:text-destructive"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsDown, { className: `h-4 w-4 ${me.reaction === "dislike" ? "fill-current" : ""}` }),
              counts.dislikes > 0 && counts.dislikes
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Btn, { active: me.favorited, onClick: toggleFav, title: "Favoritos", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: `h-4 w-4 ${me.favorited ? "fill-current" : ""}` }),
        " Favoritos"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Btn, { onClick: () => requireAuth() && toggleFav(), title: "Añadir a", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
        " Añadir a"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Btn, { onClick: share, title: "Compartir", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { className: "h-4 w-4" }),
        " Compartir"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Btn, { onClick: () => requireAuth() && setReportOpen(true), title: "Informar", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Flag, { className: "h-4 w-4" }),
        " Informe"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: reportOpen, onOpenChange: setReportOpen, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: "Informar este video" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-muted-foreground", children: "Motivo" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: reportReason,
              onChange: (e) => setReportReason(e.target.value),
              className: "w-full h-10 px-3 rounded-md bg-background border border-input text-sm",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Contenido inapropiado" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Contenido ilegal" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Menores de edad" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Spam o engaño" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Derechos de autor" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Otro" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-muted-foreground", children: "Detalles (opcional)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Textarea,
            {
              maxLength: 1e3,
              value: reportDetails,
              onChange: (e) => setReportDetails(e.target.value),
              placeholder: "Cuéntanos más…"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogFooter, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", onClick: () => setReportOpen(false), children: "Cancelar" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: submitReport, disabled: reporting, children: [
          reporting && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
          " Enviar reporte"
        ] })
      ] })
    ] }) })
  ] });
}
const timeAgo = (iso) => {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 6e4);
  if (m < 1) return "ahora";
  if (m < 60) return `hace ${m} min`;
  const h = Math.floor(m / 60);
  if (h < 24) return `hace ${h} h`;
  const d = Math.floor(h / 24);
  if (d < 30) return `hace ${d} d`;
  return new Date(iso).toLocaleDateString();
};
function Comments({ videoId }) {
  const { user, profile, loading: authLoading } = useAuth();
  const navigate = distExports.useNavigate();
  const [comments, setComments] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [text, setText] = reactExports.useState("");
  const [posting, setPosting] = reactExports.useState(false);
  const load = async () => {
    setLoading(true);
    const { data: cs } = await supabase.from("video_comments").select("id,content,created_at,user_id").eq("video_id", videoId).order("created_at", { ascending: false }).limit(200);
    const list = cs ?? [];
    const ids = Array.from(new Set(list.map((c) => c.user_id)));
    const map = /* @__PURE__ */ new Map();
    if (ids.length) {
      const { data: profs } = await supabase.from("profiles").select("id,username,avatar_url").in("id", ids);
      (profs ?? []).forEach((p) => map.set(p.id, { username: p.username, avatar_url: p.avatar_url }));
    }
    setComments(list.map((c) => ({ ...c, author: map.get(c.user_id) ?? null })));
    setLoading(false);
  };
  reactExports.useEffect(() => {
    load();
  }, [videoId]);
  const handleSubmit = async () => {
    if (!user) {
      toast.error("Regístrate para comentar");
      navigate("/auth");
      return;
    }
    const clean = text.trim();
    if (!clean) return;
    if (clean.length > 1e3) {
      toast.error("Máximo 1000 caracteres");
      return;
    }
    setPosting(true);
    const { data, error } = await supabase.from("video_comments").insert({ video_id: videoId, user_id: user.id, content: clean }).select("id,content,created_at,user_id").single();
    setPosting(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setText("");
    setComments((prev) => [{
      ...data,
      author: profile ? { username: profile.username, avatar_url: profile.avatar_url } : null
    }, ...prev]);
  };
  const remove = async (id) => {
    const { error } = await supabase.from("video_comments").delete().eq("id", id);
    if (error) {
      toast.error(error.message);
      return;
    }
    setComments((prev) => prev.filter((c) => c.id !== id));
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "mt-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-bold mb-3 flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "h-5 w-5 text-primary" }),
      "Comentarios ",
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-muted-foreground text-sm font-normal", children: [
        "(",
        comments.length,
        ")"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-card border border-border rounded-lg p-3", children: authLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin text-muted-foreground" }) }) : user ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "shrink-0 w-9 h-9 rounded-full bg-secondary overflow-hidden flex items-center justify-center", children: profile?.avatar_url ? /* @__PURE__ */ jsxRuntimeExports.jsx(SignedImg, { src: profile.avatar_url, alt: profile.username, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-4 w-4 text-muted-foreground" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Textarea,
          {
            value: text,
            onChange: (e) => setText(e.target.value),
            placeholder: "Añade un comentario público…",
            maxLength: 1e3,
            rows: 2,
            className: "resize-none"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-muted-foreground", children: [
            text.length,
            "/1000"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
            text && /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: () => setText(""), children: "Cancelar" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", disabled: posting || !text.trim(), onClick: handleSubmit, children: [
              posting && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }),
              " Comentar"
            ] })
          ] })
        ] })
      ] })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3 flex-wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold", children: "Inicia sesión para comentar" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Solo los usuarios registrados pueden dejar comentarios." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: () => navigate("/auth"), size: "sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LogIn, { className: "h-4 w-4" }),
        " Registrarse / Entrar"
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 space-y-4", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-6 w-6 animate-spin text-primary" }) }) : comments.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-center text-muted-foreground text-sm py-6", children: "Sé el primero en comentar." }) : comments.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-3", children: [
      c.author ? /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Link, { to: `/u/${c.author.username}`, className: "shrink-0 w-9 h-9 rounded-full bg-secondary overflow-hidden flex items-center justify-center hover:ring-2 hover:ring-primary", children: c.author.avatar_url ? /* @__PURE__ */ jsxRuntimeExports.jsx(SignedImg, { src: c.author.avatar_url, alt: c.author.username, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-4 w-4 text-muted-foreground" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "shrink-0 w-9 h-9 rounded-full bg-secondary flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-4 w-4 text-muted-foreground" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm", children: [
          c.author ? /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Link, { to: `/u/${c.author.username}`, className: "font-semibold hover:text-primary", children: [
            "@",
            c.author.username
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-muted-foreground", children: "@usuario" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground", children: timeAgo(c.created_at) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-0.5 text-sm whitespace-pre-wrap break-words", children: c.content })
      ] }),
      user && user.id === c.user_id && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => remove(c.id),
          className: "shrink-0 text-muted-foreground hover:text-destructive p-1",
          title: "Eliminar",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" })
        }
      )
    ] }, c.id)) })
  ] });
}
const Watch = () => {
  const { id } = distExports.useParams();
  const navigate = distExports.useNavigate();
  const { user, profile } = useAuth();
  const videoRef = reactExports.useRef(null);
  const [video, setVideo] = reactExports.useState(null);
  const [playbackUrl, setPlaybackUrl] = reactExports.useState("");
  const [related, setRelated] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [started, setStarted] = reactExports.useState(false);
  const [introDone, setIntroDone] = reactExports.useState(false);
  const [views, setViews] = reactExports.useState(0);
  const [uploaderVideoCount, setUploaderVideoCount] = reactExports.useState(0);
  const countedRef = reactExports.useRef(false);
  reactExports.useEffect(() => {
    if (!id) return;
    setStarted(false);
    setIntroDone(false);
    countedRef.current = false;
    setLoading(true);
    (async () => {
      const { data, error } = await supabase.from("videos").select("*").eq("id", id).maybeSingle();
      if (error || !data) {
        toast.error("Video no encontrado");
        navigate("/");
        return;
      }
      let uploader = null;
      if (data.user_id) {
        const { data: p } = await supabase.from("profiles").select("username,avatar_url").eq("id", data.user_id).maybeSingle();
        if (p) uploader = p;
      }
      const v = { ...data, uploader };
      setVideo(v);
      setViews(v.views);
      document.title = `${v.title} — X Pornazo`;
      getPlayableUrl(v.video_url).then(setPlaybackUrl).catch(() => setPlaybackUrl(v.video_url));
      if (data.user_id) {
        const { count } = await supabase.from("videos").select("id", { count: "exact", head: true }).eq("user_id", data.user_id);
        setUploaderVideoCount(count ?? 0);
      } else {
        setUploaderVideoCount(0);
      }
      let rel = [];
      if (v.tags && v.tags.length) {
        const { data: r } = await supabase.from("videos").select("*").overlaps("tags", v.tags).neq("id", v.id).limit(12);
        rel = r ?? [];
      }
      if (rel.length < 8) {
        const { data: r2 } = await supabase.from("videos").select("*").neq("id", v.id).order("views", { ascending: false }).limit(12);
        const seen = new Set(rel.map((x) => x.id));
        for (const x of r2 ?? []) if (!seen.has(x.id)) rel.push(x);
      }
      const ids = Array.from(new Set(rel.map((x) => x.user_id).filter(Boolean)));
      const map = /* @__PURE__ */ new Map();
      if (ids.length) {
        const { data: profs } = await supabase.from("profiles").select("id,username,avatar_url").in("id", ids);
        (profs ?? []).forEach((p) => map.set(p.id, { username: p.username, avatar_url: p.avatar_url }));
      }
      setRelated(rel.slice(0, 12).map((x) => ({ ...x, uploader: x.user_id ? map.get(x.user_id) ?? null : null })));
      setLoading(false);
    })();
  }, [id, navigate]);
  const handlePlay = async () => {
    setStarted(true);
  };
  const handleIntroFinish = () => {
    setIntroDone(true);
    setTimeout(() => videoRef.current?.play().catch(() => {
    }), 50);
  };
  const trackedRef = reactExports.useRef(false);
  const watchStartRef = reactExports.useRef(0);
  const handleStarted = () => {
    if (watchStartRef.current === 0) watchStartRef.current = Date.now();
  };
  const handleTimeUpdate = async () => {
    if (trackedRef.current || !video || !videoRef.current) return;
    const v = videoRef.current;
    const watched = v.currentTime;
    const dur = v.duration || 0;
    const pct = dur > 0 ? watched / dur * 100 : 0;
    const qualifies = dur > 0 && dur < 30 ? pct >= 70 : watched >= 30;
    if (!qualifies) return;
    trackedRef.current = true;
    try {
      const url = `${"https://xmsgonlpqtfrdqwrxods.supabase.co"}/functions/v1/track-view`;
      const headers = {
        "Content-Type": "application/json",
        apikey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhtc2dvbmxwcXRmcmRxd3J4b2RzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI3NTY2OTcsImV4cCI6MjA5ODMzMjY5N30.aQrEwzYCF-7LwiJg0t-Y4Ba4JLxrDozgoJnZIu5uBro"
      };
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.access_token) headers["Authorization"] = `Bearer ${session.access_token}`;
      const res = await fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify({
          video_id: video.id,
          visitor_id: getVisitorId(),
          watch_seconds: Math.floor(watched),
          watch_percentage: Math.min(100, pct)
        })
      });
      const json = await res.json();
      if (json?.counted) setViews((n) => n + 1);
    } catch {
    }
  };
  const follow = useFollow(video?.user_id ?? null);
  if (loading || !video) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-8 w-8 animate-spin text-primary" }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "sticky top-0 z-40 bg-header border-b border-border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-4 h-14 flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "ghost", size: "sm", onClick: () => navigate(-1), children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4" }),
        " Volver"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Link, { to: "/", className: "flex items-center gap-2 ml-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl font-extrabold text-primary", children: "X" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xl font-bold", children: "Pornazo" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1" }),
      user && profile ? /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Link, { to: `/u/${profile.username}`, className: "w-9 h-9 rounded-full bg-secondary overflow-hidden flex items-center justify-center hover:ring-2 hover:ring-primary", children: profile.avatar_url ? /* @__PURE__ */ jsxRuntimeExports.jsx(SignedImg, { src: profile.avatar_url, alt: profile.username, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-5 w-5 text-muted-foreground" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Link, { to: "/auth", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", children: "Entrar" }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "container mx-auto px-4 py-6 grid gap-6 lg:grid-cols-[1fr_360px]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative aspect-video bg-black rounded-md overflow-hidden", children: !started ? /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: handlePlay, className: "absolute inset-0 group", "aria-label": "Reproducir video", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("video", { src: playbackUrl || void 0, muted: true, playsInline: true, preload: "metadata", className: "w-full h-full object-cover opacity-90" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-primary rounded-full p-6 shadow-2xl group-hover:scale-110 transition-transform", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "h-10 w-10 text-primary-foreground fill-current" }) }) })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "video",
            {
              ref: videoRef,
              src: playbackUrl || void 0,
              controls: true,
              onPlay: handleStarted,
              onTimeUpdate: handleTimeUpdate,
              onLoadedMetadata: (e) => {
                const d = e.target.duration;
                if (d && Number.isFinite(d) && !video.duration_seconds) {
                  supabase.from("videos").update({ duration_seconds: Math.floor(d) }).eq("id", video.id);
                }
              },
              className: "w-full h-full bg-black"
            }
          ),
          !introDone && /* @__PURE__ */ jsxRuntimeExports.jsx(BrandIntro, { onFinish: handleIntroFinish })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mt-4 text-xl md:text-2xl font-bold", children: video.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex items-center gap-4 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-4 w-4 text-primary" }),
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: views.toLocaleString() }),
            " vistas"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: new Date(video.created_at).toLocaleDateString() })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(VideoActions, { videoId: video.id }),
        video.uploader && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-center justify-between gap-3 bg-card border border-border rounded-lg p-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(distExports.Link, { to: `/u/${video.uploader.username}`, className: "flex items-center gap-3 group min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "shrink-0 w-12 h-12 rounded-full bg-secondary overflow-hidden flex items-center justify-center group-hover:ring-2 group-hover:ring-primary", children: video.uploader.avatar_url ? /* @__PURE__ */ jsxRuntimeExports.jsx(SignedImg, { src: video.uploader.avatar_url, alt: video.uploader.username, className: "w-full h-full object-cover" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-5 w-5 text-muted-foreground" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 font-bold group-hover:text-primary truncate", children: [
                video.uploader.username,
                /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "h-4 w-4 text-primary fill-primary/20 shrink-0" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground", children: [
                uploaderVideoCount,
                " ",
                uploaderVideoCount === 1 ? "Vídeo" : "Vídeos",
                " ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mx-1", children: "|" }),
                " ",
                follow.count,
                " ",
                follow.count === 1 ? "Seguidor" : "Seguidores"
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(distExports.Link, { to: `/u/${video.uploader.username}`, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "gap-1.5", children: [
              "Más de mí ",
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "h-3.5 w-3.5" })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Button,
              {
                variant: follow.isFollowing ? "secondary" : "outline",
                className: "gap-1.5",
                disabled: !follow.canFollow || follow.loading,
                onClick: follow.toggle,
                title: !follow.canFollow ? "Inicia sesión para seguir" : "",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Rss, { className: "h-4 w-4" }),
                  " ",
                  follow.isFollowing ? "Siguiendo" : "Seguir"
                ]
              }
            )
          ] })
        ] }),
        video.description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-sm text-foreground/90 whitespace-pre-wrap", children: video.description }),
        video.tags && video.tags.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide", children: "Etiquetas" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: video.tags.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: "secondary", className: "rounded-full px-3 py-1 hover:bg-primary hover:text-primary-foreground cursor-pointer", children: [
            "#",
            t
          ] }, t)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Comments, { videoId: video.id })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-sm font-bold uppercase tracking-wide text-muted-foreground mb-3", children: "Más videos" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-1", children: related.map((v) => /* @__PURE__ */ jsxRuntimeExports.jsx(VideoCard, { video: v }, v.id)) })
      ] })
    ] })
  ] });
};
export {
  Watch as default
};
