import { a as requireReact, c as commonjsGlobal } from "./react.mjs";
import { r as requireReactDom } from "./react-dom.mjs";
import { r as requireDist } from "./cookie.mjs";
import { r as requireSetCookie } from "./set-cookie-parser.mjs";
var domExport = {};
var chunkLVPI3KDG = {};
function commonjsRequire(path) {
  throw new Error('Could not dynamically require "' + path + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}
var chunkGR4NQCSD = {};
var hasRequiredChunkGR4NQCSD;
function requireChunkGR4NQCSD() {
  if (hasRequiredChunkGR4NQCSD) return chunkGR4NQCSD;
  hasRequiredChunkGR4NQCSD = 1;
  Object.defineProperty(chunkGR4NQCSD, "__esModule", { value: true });
  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};
      if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) {
            newObj[key] = obj[key];
          }
        }
      }
      newObj.default = obj;
      return newObj;
    }
  }
  function _nullishCoalesce(lhs, rhsFn) {
    if (lhs != null) {
      return lhs;
    } else {
      return rhsFn();
    }
  }
  function _optionalChain(ops) {
    let lastAccessLHS = void 0;
    let value = ops[0];
    let i = 1;
    while (i < ops.length) {
      const op = ops[i];
      const fn = ops[i + 1];
      i += 2;
      if ((op === "optionalAccess" || op === "optionalCall") && value == null) {
        return void 0;
      }
      if (op === "access" || op === "optionalAccess") {
        lastAccessLHS = value;
        value = fn(value);
      } else if (op === "call" || op === "optionalCall") {
        value = fn((...args) => value.call(lastAccessLHS, ...args));
        lastAccessLHS = void 0;
      }
    }
    return value;
  }
  var __typeError = (msg) => {
    throw TypeError(msg);
  };
  var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
  var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
  var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
  var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), member.set(obj, value), value);
  var ABSOLUTE_URL_REGEX = /^(?:[a-z][a-z0-9+.-]*:|[\\/]{2})/i;
  var PROTOCOL_RELATIVE_URL_REGEX = /^[\\/]{2}/;
  function normalizeProtocolRelativeUrl(url, protocol) {
    return protocol + url.replace(/\\/g, "/");
  }
  var Action = /* @__PURE__ */ ((Action2) => {
    Action2["Pop"] = "POP";
    Action2["Push"] = "PUSH";
    Action2["Replace"] = "REPLACE";
    return Action2;
  })(Action || {});
  var PopStateEventType = "popstate";
  function isLocation(obj) {
    return typeof obj === "object" && obj != null && "pathname" in obj && "search" in obj && "hash" in obj && "state" in obj && "key" in obj;
  }
  function createMemoryHistory(options = {}) {
    let { initialEntries = ["/"], initialIndex, v5Compat = false } = options;
    let entries;
    entries = initialEntries.map(
      (entry, index2) => createMemoryLocation(
        entry,
        typeof entry === "string" ? null : entry.state,
        index2 === 0 ? "default" : void 0,
        typeof entry === "string" ? void 0 : entry.mask
      )
    );
    let index = clampIndex(
      initialIndex == null ? entries.length - 1 : initialIndex
    );
    let action = "POP";
    let listener = null;
    function clampIndex(n) {
      return Math.min(Math.max(n, 0), entries.length - 1);
    }
    function getCurrentLocation() {
      return entries[index];
    }
    function createMemoryLocation(to, state = null, key, mask) {
      let location2 = createLocation(
        entries ? getCurrentLocation().pathname : "/",
        to,
        state,
        key,
        mask
      );
      warning(
        location2.pathname.charAt(0) === "/",
        `relative pathnames are not supported in memory history: ${JSON.stringify(
          to
        )}`
      );
      return location2;
    }
    function createHref(to) {
      return typeof to === "string" ? to : createPath(to);
    }
    let history = {
      get index() {
        return index;
      },
      get action() {
        return action;
      },
      get location() {
        return getCurrentLocation();
      },
      createHref,
      createURL(to) {
        return new URL(createHref(to), "http://localhost");
      },
      encodeLocation(to) {
        let path = typeof to === "string" ? parsePath(to) : to;
        return {
          pathname: path.pathname || "",
          search: path.search || "",
          hash: path.hash || ""
        };
      },
      push(to, state) {
        action = "PUSH";
        let nextLocation = isLocation(to) ? to : createMemoryLocation(to, state);
        index += 1;
        entries.splice(index, entries.length, nextLocation);
        if (v5Compat && listener) {
          listener({ action, location: nextLocation, delta: 1 });
        }
      },
      replace(to, state) {
        action = "REPLACE";
        let nextLocation = isLocation(to) ? to : createMemoryLocation(to, state);
        entries[index] = nextLocation;
        if (v5Compat && listener) {
          listener({ action, location: nextLocation, delta: 0 });
        }
      },
      go(delta) {
        action = "POP";
        let nextIndex = clampIndex(index + delta);
        let nextLocation = entries[nextIndex];
        index = nextIndex;
        if (listener) {
          listener({ action, location: nextLocation, delta });
        }
      },
      listen(fn) {
        listener = fn;
        return () => {
          listener = null;
        };
      }
    };
    return history;
  }
  function createBrowserHistory(options = {}) {
    function createBrowserLocation(window2, globalHistory) {
      let maskedLocation = _optionalChain([globalHistory, "access", (_2) => _2.state, "optionalAccess", (_3) => _3.masked]);
      let { pathname, search, hash } = maskedLocation || window2.location;
      return createLocation(
        "",
        { pathname, search, hash },
        // state defaults to `null` because `window.history.state` does
        globalHistory.state && globalHistory.state.usr || null,
        globalHistory.state && globalHistory.state.key || "default",
        maskedLocation ? {
          pathname: window2.location.pathname,
          search: window2.location.search,
          hash: window2.location.hash
        } : void 0
      );
    }
    function createBrowserHref(window2, to) {
      return typeof to === "string" ? to : createPath(to);
    }
    return getUrlBasedHistory(
      createBrowserLocation,
      createBrowserHref,
      null,
      options
    );
  }
  function createHashHistory(options = {}) {
    function createHashLocation(window2, globalHistory) {
      let {
        pathname = "/",
        search = "",
        hash = ""
      } = parsePath(window2.location.hash.substring(1));
      if (!pathname.startsWith("/") && !pathname.startsWith(".")) {
        pathname = "/" + pathname;
      }
      return createLocation(
        "",
        { pathname, search, hash },
        // state defaults to `null` because `window.history.state` does
        globalHistory.state && globalHistory.state.usr || null,
        globalHistory.state && globalHistory.state.key || "default"
      );
    }
    function createHashHref(window2, to) {
      let base = window2.document.querySelector("base");
      let href = "";
      if (base && base.getAttribute("href")) {
        let url = window2.location.href;
        let hashIndex = url.indexOf("#");
        href = hashIndex === -1 ? url : url.slice(0, hashIndex);
      }
      return href + "#" + (typeof to === "string" ? to : createPath(to));
    }
    function validateHashLocation(location2, to) {
      warning(
        location2.pathname.charAt(0) === "/",
        `relative pathnames are not supported in hash history.push(${JSON.stringify(
          to
        )})`
      );
    }
    return getUrlBasedHistory(
      createHashLocation,
      createHashHref,
      validateHashLocation,
      options
    );
  }
  function invariant(value, message) {
    if (value === false || value === null || typeof value === "undefined") {
      throw new Error(message);
    }
  }
  function warning(cond, message) {
    if (!cond) {
      if (typeof console !== "undefined") console.warn(message);
      try {
        throw new Error(message);
      } catch (e) {
      }
    }
  }
  function createKey() {
    return Math.random().toString(36).substring(2, 10);
  }
  function getHistoryState(location2, index) {
    return {
      usr: location2.state,
      key: location2.key,
      idx: index,
      masked: location2.mask ? {
        pathname: location2.pathname,
        search: location2.search,
        hash: location2.hash
      } : void 0
    };
  }
  function createLocation(current, to, state = null, key, mask) {
    let location2 = {
      pathname: typeof current === "string" ? current : current.pathname,
      search: "",
      hash: "",
      ...typeof to === "string" ? parsePath(to) : to,
      state,
      // TODO: This could be cleaned up.  push/replace should probably just take
      // full Locations now and avoid the need to run through this flow at all
      // But that's a pretty big refactor to the current test suite so going to
      // keep as is for the time being and just let any incoming keys take precedence
      key: to && to.key || key || createKey(),
      mask
    };
    return location2;
  }
  function createPath({
    pathname = "/",
    search = "",
    hash = ""
  }) {
    if (search && search !== "?")
      pathname += search.charAt(0) === "?" ? search : "?" + search;
    if (hash && hash !== "#")
      pathname += hash.charAt(0) === "#" ? hash : "#" + hash;
    return pathname;
  }
  function parsePath(path) {
    let parsedPath = {};
    if (path) {
      let hashIndex = path.indexOf("#");
      if (hashIndex >= 0) {
        parsedPath.hash = path.substring(hashIndex);
        path = path.substring(0, hashIndex);
      }
      let searchIndex = path.indexOf("?");
      if (searchIndex >= 0) {
        parsedPath.search = path.substring(searchIndex);
        path = path.substring(0, searchIndex);
      }
      if (path) {
        parsedPath.pathname = path;
      }
    }
    return parsedPath;
  }
  function getUrlBasedHistory(getLocation, createHref, validateLocation, options = {}) {
    let { window: window2 = document.defaultView, v5Compat = false } = options;
    let globalHistory = window2.history;
    let action = "POP";
    let listener = null;
    let index = getIndex();
    if (index == null) {
      index = 0;
      globalHistory.replaceState({ ...globalHistory.state, idx: index }, "");
    }
    function getIndex() {
      let state = globalHistory.state || { idx: null };
      return state.idx;
    }
    function handlePop() {
      action = "POP";
      let nextIndex = getIndex();
      let delta = nextIndex == null ? null : nextIndex - index;
      index = nextIndex;
      if (listener) {
        listener({ action, location: history.location, delta });
      }
    }
    function push(to, state) {
      action = "PUSH";
      let location2 = isLocation(to) ? to : createLocation(history.location, to, state);
      if (validateLocation) validateLocation(location2, to);
      index = getIndex() + 1;
      let historyState = getHistoryState(location2, index);
      let url = history.createHref(location2.mask || location2);
      try {
        globalHistory.pushState(historyState, "", url);
      } catch (error) {
        if (error instanceof DOMException && error.name === "DataCloneError") {
          throw error;
        }
        window2.location.assign(url);
      }
      if (v5Compat && listener) {
        listener({ action, location: history.location, delta: 1 });
      }
    }
    function replace2(to, state) {
      action = "REPLACE";
      let location2 = isLocation(to) ? to : createLocation(history.location, to, state);
      if (validateLocation) validateLocation(location2, to);
      index = getIndex();
      let historyState = getHistoryState(location2, index);
      let url = history.createHref(location2.mask || location2);
      globalHistory.replaceState(historyState, "", url);
      if (v5Compat && listener) {
        listener({ action, location: history.location, delta: 0 });
      }
    }
    function createURL(to) {
      return createBrowserURLImpl(window2, to);
    }
    let history = {
      get action() {
        return action;
      },
      get location() {
        return getLocation(window2, globalHistory);
      },
      listen(fn) {
        if (listener) {
          throw new Error("A history only accepts one active listener");
        }
        window2.addEventListener(PopStateEventType, handlePop);
        listener = fn;
        return () => {
          window2.removeEventListener(PopStateEventType, handlePop);
          listener = null;
        };
      },
      createHref(to) {
        return createHref(window2, to);
      },
      createURL,
      encodeLocation(to) {
        let url = createURL(to);
        return {
          pathname: url.pathname,
          search: url.search,
          hash: url.hash
        };
      },
      push,
      replace: replace2,
      go(n) {
        return globalHistory.go(n);
      }
    };
    return history;
  }
  function createBrowserURLImpl(windowImpl, to, isAbsolute = false) {
    let base = "http://localhost";
    if (windowImpl) {
      base = windowImpl.location.origin !== "null" ? windowImpl.location.origin : windowImpl.location.href;
    }
    invariant(base, "No window.location.(origin|href) available to create URL");
    let href = typeof to === "string" ? to : createPath(to);
    href = href.replace(/ $/, "%20");
    if (!isAbsolute && PROTOCOL_RELATIVE_URL_REGEX.test(href)) {
      href = base + href;
    }
    return new URL(href, base);
  }
  function createContext(defaultValue) {
    return { defaultValue };
  }
  var _map;
  var RouterContextProvider = class {
    /**
     * Create a new `RouterContextProvider` instance
     * @param init An optional initial context map to populate the provider with
     */
    constructor(init) {
      __privateAdd(this, _map, /* @__PURE__ */ new Map());
      if (init) {
        for (let [context, value] of init) {
          this.set(context, value);
        }
      }
    }
    /**
     * Access a value from the context. If no value has been set for the context,
     * it will return the context's `defaultValue` if provided, or throw an error
     * if no `defaultValue` was set.
     * @param context The context to get the value for
     * @returns The value for the context, or the context's `defaultValue` if no
     * value was set
     */
    get(context) {
      if (__privateGet(this, _map).has(context)) {
        return __privateGet(this, _map).get(context);
      }
      if (context.defaultValue !== void 0) {
        return context.defaultValue;
      }
      throw new Error("No value found for context");
    }
    /**
     * Set a value for the context. If the context already has a value set, this
     * will overwrite it.
     *
     * @param context The context to set the value for
     * @param value The value to set for the context
     * @returns {void}
     */
    set(context, value) {
      __privateGet(this, _map).set(context, value);
    }
  };
  _map = /* @__PURE__ */ new WeakMap();
  var unsupportedLazyRouteObjectKeys = /* @__PURE__ */ new Set([
    "lazy",
    "caseSensitive",
    "path",
    "id",
    "index",
    "children"
  ]);
  function isUnsupportedLazyRouteObjectKey(key) {
    return unsupportedLazyRouteObjectKeys.has(
      key
    );
  }
  var unsupportedLazyRouteFunctionKeys = /* @__PURE__ */ new Set([
    "lazy",
    "caseSensitive",
    "path",
    "id",
    "index",
    "middleware",
    "children"
  ]);
  function isUnsupportedLazyRouteFunctionKey(key) {
    return unsupportedLazyRouteFunctionKeys.has(
      key
    );
  }
  function isIndexRoute(route) {
    return route.index === true;
  }
  function convertRoutesToDataRoutes(routes, mapRouteProperties2, parentPath = [], manifest = {}, allowInPlaceMutations = false) {
    return routes.map((route, index) => {
      let treePath = [...parentPath, String(index)];
      let id = typeof route.id === "string" ? route.id : treePath.join("-");
      invariant(
        route.index !== true || !route.children,
        `Cannot specify children on an index route`
      );
      invariant(
        allowInPlaceMutations || !manifest[id],
        `Found a route id collision on id "${id}".  Route id's must be globally unique within Data Router usages`
      );
      if (isIndexRoute(route)) {
        let indexRoute = {
          ...route,
          id
        };
        manifest[id] = mergeRouteUpdates(
          indexRoute,
          mapRouteProperties2(indexRoute)
        );
        return indexRoute;
      } else {
        let pathOrLayoutRoute = {
          ...route,
          id,
          children: void 0
        };
        manifest[id] = mergeRouteUpdates(
          pathOrLayoutRoute,
          mapRouteProperties2(pathOrLayoutRoute)
        );
        if (route.children) {
          pathOrLayoutRoute.children = convertRoutesToDataRoutes(
            route.children,
            mapRouteProperties2,
            treePath,
            manifest,
            allowInPlaceMutations
          );
        }
        return pathOrLayoutRoute;
      }
    });
  }
  function mergeRouteUpdates(route, updates) {
    return Object.assign(route, {
      ...updates,
      ...typeof updates.lazy === "object" && updates.lazy != null ? {
        lazy: {
          ...route.lazy,
          ...updates.lazy
        }
      } : {}
    });
  }
  function matchRoutes(routes, locationArg, basename = "/") {
    return matchRoutesImpl(routes, locationArg, basename, false);
  }
  function matchRoutesImpl(routes, locationArg, basename, allowPartial, precomputedBranches) {
    let location2 = typeof locationArg === "string" ? parsePath(locationArg) : locationArg;
    let pathname = stripBasename(location2.pathname || "/", basename);
    if (pathname == null) {
      return null;
    }
    let branches = _nullishCoalesce(precomputedBranches, () => flattenAndRankRoutes(routes));
    let matches = null;
    let decoded = decodePath(pathname);
    for (let i = 0; matches == null && i < branches.length; ++i) {
      matches = matchRouteBranch(
        branches[i],
        decoded,
        allowPartial
      );
    }
    return matches;
  }
  function convertRouteMatchToUiMatch(match, loaderData) {
    let { route, pathname, params } = match;
    return {
      id: route.id,
      pathname,
      params,
      data: loaderData[route.id],
      loaderData: loaderData[route.id],
      handle: route.handle
    };
  }
  function flattenAndRankRoutes(routes) {
    let branches = flattenRoutes(routes);
    rankRouteBranches(branches);
    return branches;
  }
  function flattenRoutes(routes, branches = [], parentsMeta = [], parentPath = "", _hasParentOptionalSegments = false) {
    let flattenRoute = (route, index, hasParentOptionalSegments = _hasParentOptionalSegments, relativePath) => {
      let meta = {
        relativePath: relativePath === void 0 ? route.path || "" : relativePath,
        caseSensitive: route.caseSensitive === true,
        childrenIndex: index,
        route
      };
      if (meta.relativePath.startsWith("/")) {
        if (!meta.relativePath.startsWith(parentPath) && hasParentOptionalSegments) {
          return;
        }
        invariant(
          meta.relativePath.startsWith(parentPath),
          `Absolute route path "${meta.relativePath}" nested under path "${parentPath}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`
        );
        meta.relativePath = meta.relativePath.slice(parentPath.length);
      }
      let path = joinPaths([parentPath, meta.relativePath]);
      let routesMeta = parentsMeta.concat(meta);
      if (route.children && route.children.length > 0) {
        invariant(
          // Our types know better, but runtime JS may not!
          // @ts-expect-error
          route.index !== true,
          `Index routes must not have child routes. Please remove all child routes from route path "${path}".`
        );
        flattenRoutes(
          route.children,
          branches,
          routesMeta,
          path,
          hasParentOptionalSegments
        );
      }
      if (route.path == null && !route.index) {
        return;
      }
      branches.push({
        path,
        score: computeScore(path, route.index),
        routesMeta: routesMeta.map((meta2, i) => {
          let [matcher, params] = compilePath(
            meta2.relativePath,
            meta2.caseSensitive,
            i === routesMeta.length - 1
          );
          return {
            ...meta2,
            matcher,
            compiledParams: params
          };
        })
      });
    };
    routes.forEach((route, index) => {
      if (route.path === "" || !_optionalChain([route, "access", (_4) => _4.path, "optionalAccess", (_5) => _5.includes, "call", (_6) => _6("?")])) {
        flattenRoute(route, index);
      } else {
        for (let exploded of explodeOptionalSegments(route.path)) {
          flattenRoute(route, index, true, exploded);
        }
      }
    });
    return branches;
  }
  function explodeOptionalSegments(path) {
    let segments = path.split("/");
    if (segments.length === 0) return [];
    let [first, ...rest] = segments;
    let isOptional = first.endsWith("?");
    let required = first.replace(/\?$/, "");
    if (rest.length === 0) {
      return isOptional ? [required, ""] : [required];
    }
    let restExploded = explodeOptionalSegments(rest.join("/"));
    let result = [];
    result.push(
      ...restExploded.map(
        (subpath) => subpath === "" ? required : [required, subpath].join("/")
      )
    );
    if (isOptional) {
      result.push(...restExploded);
    }
    return result.map(
      (exploded) => path.startsWith("/") && exploded === "" ? "/" : exploded
    );
  }
  function rankRouteBranches(branches) {
    branches.sort(
      (a, b) => a.score !== b.score ? b.score - a.score : compareIndexes(
        a.routesMeta.map((meta) => meta.childrenIndex),
        b.routesMeta.map((meta) => meta.childrenIndex)
      )
    );
  }
  var paramRe = /^:[\w-]+$/;
  var dynamicSegmentValue = 3;
  var indexRouteValue = 2;
  var emptySegmentValue = 1;
  var staticSegmentValue = 10;
  var splatPenalty = -2;
  var isSplat = (s) => s === "*";
  function computeScore(path, index) {
    let segments = path.split("/");
    let initialScore = segments.length;
    if (segments.some(isSplat)) {
      initialScore += splatPenalty;
    }
    if (index) {
      initialScore += indexRouteValue;
    }
    return segments.filter((s) => !isSplat(s)).reduce(
      (score, segment) => score + (paramRe.test(segment) ? dynamicSegmentValue : segment === "" ? emptySegmentValue : staticSegmentValue),
      initialScore
    );
  }
  function compareIndexes(a, b) {
    let siblings = a.length === b.length && a.slice(0, -1).every((n, i) => n === b[i]);
    return siblings ? (
      // If two routes are siblings, we should try to match the earlier sibling
      // first. This allows people to have fine-grained control over the matching
      // behavior by simply putting routes with identical paths in the order they
      // want them tried.
      a[a.length - 1] - b[b.length - 1]
    ) : (
      // Otherwise, it doesn't really make sense to rank non-siblings by index,
      // so they sort equally.
      0
    );
  }
  function matchRouteBranch(branch, pathname, allowPartial = false) {
    let { routesMeta } = branch;
    let matchedParams = {};
    let matchedPathname = "/";
    let matches = [];
    for (let i = 0; i < routesMeta.length; ++i) {
      let meta = routesMeta[i];
      let end = i === routesMeta.length - 1;
      let remainingPathname = matchedPathname === "/" ? pathname : pathname.slice(matchedPathname.length) || "/";
      let pattern = {
        path: meta.relativePath,
        caseSensitive: meta.caseSensitive,
        end
      };
      let match = (
        // Use precomputed matcher if it exists
        meta.matcher && meta.compiledParams ? matchPathImpl(
          pattern,
          remainingPathname,
          meta.matcher,
          meta.compiledParams
        ) : matchPath(pattern, remainingPathname)
      );
      let route = meta.route;
      if (!match && end && allowPartial && !routesMeta[routesMeta.length - 1].route.index) {
        match = matchPath(
          {
            path: meta.relativePath,
            caseSensitive: meta.caseSensitive,
            end: false
          },
          remainingPathname
        );
      }
      if (!match) {
        return null;
      }
      Object.assign(matchedParams, match.params);
      matches.push({
        // TODO: Can this as be avoided?
        params: matchedParams,
        pathname: joinPaths([matchedPathname, match.pathname]),
        pathnameBase: normalizePathname(
          joinPaths([matchedPathname, match.pathnameBase])
        ),
        route
      });
      if (match.pathnameBase !== "/") {
        matchedPathname = joinPaths([matchedPathname, match.pathnameBase]);
      }
    }
    return matches;
  }
  function generatePath(originalPath, params = {}) {
    let path = originalPath;
    if (path.endsWith("*") && path !== "*" && !path.endsWith("/*")) {
      warning(
        false,
        `Route path "${path}" will be treated as if it were "${path.replace(/\*$/, "/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${path.replace(/\*$/, "/*")}".`
      );
      path = path.replace(/\*$/, "/*");
    }
    const prefix = path.startsWith("/") ? "/" : "";
    const stringify2 = (p) => p == null ? "" : typeof p === "string" ? p : String(p);
    const segments = path.split(/\/+/).map((segment, index, array) => {
      const isLastSegment = index === array.length - 1;
      if (isLastSegment && segment === "*") {
        return stringify2(params["*"]);
      }
      const keyMatch = segment.match(/^:([\w-]+)(\??)(.*)/);
      if (keyMatch) {
        const [, key, optional, suffix] = keyMatch;
        let param = params[key];
        invariant(optional === "?" || param != null, `Missing ":${key}" param`);
        return encodeURIComponent(stringify2(param)) + suffix;
      }
      return segment.replace(/\?$/g, "");
    }).filter((segment) => !!segment);
    return prefix + segments.join("/");
  }
  function matchPath(pattern, pathname) {
    if (typeof pattern === "string") {
      pattern = { path: pattern, caseSensitive: false, end: true };
    }
    let [matcher, compiledParams] = compilePath(
      pattern.path,
      pattern.caseSensitive,
      pattern.end
    );
    return matchPathImpl(pattern, pathname, matcher, compiledParams);
  }
  function matchPathImpl(pattern, pathname, matcher, compiledParams) {
    let match = pathname.match(matcher);
    if (!match) return null;
    let matchedPathname = match[0];
    let pathnameBase = removeTrailingSlash(matchedPathname, 1);
    let captureGroups = match.slice(1);
    let params = compiledParams.reduce(
      (memo2, { paramName, isOptional }, index) => {
        if (paramName === "*") {
          let splatValue = captureGroups[index] || "";
          pathnameBase = removeTrailingSlash(
            matchedPathname.slice(0, matchedPathname.length - splatValue.length),
            1
          );
        }
        const value = captureGroups[index];
        if (isOptional && !value) {
          memo2[paramName] = void 0;
        } else {
          memo2[paramName] = (value || "").replace(/%2F/g, "/");
        }
        return memo2;
      },
      {}
    );
    return {
      params,
      pathname: matchedPathname,
      pathnameBase,
      pattern
    };
  }
  function compilePath(path, caseSensitive = false, end = true) {
    warning(
      path === "*" || !path.endsWith("*") || path.endsWith("/*"),
      `Route path "${path}" will be treated as if it were "${path.replace(/\*$/, "/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${path.replace(/\*$/, "/*")}".`
    );
    let params = [];
    let regexpSource = "^" + path.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(
      /\/:([\w-]+)(\?)?/g,
      (match, paramName, isOptional, index, str) => {
        params.push({ paramName, isOptional: isOptional != null });
        if (isOptional) {
          let nextChar = str.charAt(index + match.length);
          if (nextChar && nextChar !== "/") {
            return "/([^\\/]*)";
          }
          return "(?:/([^\\/]*))?";
        }
        return "/([^\\/]+)";
      }
    ).replace(/\/([\w-]+)\?(\/|$)/g, "(/$1)?$2");
    if (path.endsWith("*")) {
      params.push({ paramName: "*" });
      regexpSource += path === "*" || path === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$";
    } else if (end) {
      regexpSource += "\\/*$";
    } else if (path !== "" && path !== "/") {
      regexpSource += "(?:(?=\\/|$))";
    } else ;
    let matcher = new RegExp(regexpSource, caseSensitive ? void 0 : "i");
    return [matcher, params];
  }
  function decodePath(value) {
    try {
      return value.split("/").map((v) => decodeURIComponent(v).replace(/\//g, "%2F")).join("/");
    } catch (error) {
      warning(
        false,
        `The URL path "${value}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${error}).`
      );
      return value;
    }
  }
  function stripBasename(pathname, basename) {
    if (basename === "/") return pathname;
    if (!pathname.toLowerCase().startsWith(basename.toLowerCase())) {
      return null;
    }
    let startIndex = basename.endsWith("/") ? basename.length - 1 : basename.length;
    let nextChar = pathname.charAt(startIndex);
    if (nextChar && nextChar !== "/") {
      return null;
    }
    return pathname.slice(startIndex) || "/";
  }
  function prependBasename({
    basename,
    pathname
  }) {
    return pathname === "/" ? basename : joinPaths([basename, pathname]);
  }
  var isAbsoluteUrl = (url) => ABSOLUTE_URL_REGEX.test(url);
  function resolvePath(to, fromPathname = "/") {
    let {
      pathname: toPathname,
      search = "",
      hash = ""
    } = typeof to === "string" ? parsePath(to) : to;
    let pathname;
    if (toPathname) {
      toPathname = removeDoubleSlashes(toPathname);
      if (toPathname.startsWith("/") || toPathname.startsWith("\\")) {
        pathname = resolvePathname(toPathname.substring(1), "/");
      } else {
        pathname = resolvePathname(toPathname, fromPathname);
      }
    } else {
      pathname = fromPathname;
    }
    return {
      pathname,
      search: normalizeSearch(search),
      hash: normalizeHash(hash)
    };
  }
  function resolvePathname(relativePath, fromPathname) {
    let segments = removeTrailingSlash(fromPathname).split("/");
    let relativeSegments = relativePath.split("/");
    relativeSegments.forEach((segment) => {
      if (segment === "..") {
        if (segments.length > 1) segments.pop();
      } else if (segment !== ".") {
        segments.push(segment);
      }
    });
    return segments.length > 1 ? segments.join("/") : "/";
  }
  function getInvalidPathError(char, field, dest, path) {
    return `Cannot include a '${char}' character in a manually specified \`to.${field}\` field [${JSON.stringify(
      path
    )}].  Please separate it out to the \`to.${dest}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`;
  }
  function getPathContributingMatches(matches) {
    return matches.filter(
      (match, index) => index === 0 || match.route.path && match.route.path.length > 0
    );
  }
  function getResolveToMatches(matches) {
    let pathMatches = getPathContributingMatches(matches);
    return pathMatches.map(
      (match, idx) => idx === pathMatches.length - 1 ? match.pathname : match.pathnameBase
    );
  }
  function resolveTo(toArg, routePathnames, locationPathname, isPathRelative = false) {
    let to;
    if (typeof toArg === "string") {
      to = parsePath(toArg);
    } else {
      to = { ...toArg };
      invariant(
        !to.pathname || !to.pathname.includes("?"),
        getInvalidPathError("?", "pathname", "search", to)
      );
      invariant(
        !to.pathname || !to.pathname.includes("#"),
        getInvalidPathError("#", "pathname", "hash", to)
      );
      invariant(
        !to.search || !to.search.includes("#"),
        getInvalidPathError("#", "search", "hash", to)
      );
    }
    let isEmptyPath = toArg === "" || to.pathname === "";
    let toPathname = isEmptyPath ? "/" : to.pathname;
    let from;
    if (toPathname == null) {
      from = locationPathname;
    } else {
      let routePathnameIndex = routePathnames.length - 1;
      if (!isPathRelative && toPathname.startsWith("..")) {
        let toSegments = toPathname.split("/");
        while (toSegments[0] === "..") {
          toSegments.shift();
          routePathnameIndex -= 1;
        }
        to.pathname = toSegments.join("/");
      }
      from = routePathnameIndex >= 0 ? routePathnames[routePathnameIndex] : "/";
    }
    let path = resolvePath(to, from);
    let hasExplicitTrailingSlash = toPathname && toPathname !== "/" && toPathname.endsWith("/");
    let hasCurrentTrailingSlash = (isEmptyPath || toPathname === ".") && locationPathname.endsWith("/");
    if (!path.pathname.endsWith("/") && (hasExplicitTrailingSlash || hasCurrentTrailingSlash)) {
      path.pathname += "/";
    }
    return path;
  }
  var removeDoubleSlashes = (path) => path.replace(/[\\/]{2,}/g, "/");
  var joinPaths = (paths) => removeDoubleSlashes(paths.join("/"));
  function removeTrailingSlash(path, minLength = 0) {
    let end = path.length;
    while (end > minLength && path.charCodeAt(end - 1) === 47) {
      end--;
    }
    return end === path.length ? path : path.slice(0, end);
  }
  var normalizePathname = (pathname) => removeTrailingSlash(pathname).replace(/^\/*/, "/");
  var normalizeSearch = (search) => !search || search === "?" ? "" : search.startsWith("?") ? search : "?" + search;
  var normalizeHash = (hash) => !hash || hash === "#" ? "" : hash.startsWith("#") ? hash : "#" + hash;
  var DataWithResponseInit = class {
    constructor(data2, init) {
      this.type = "DataWithResponseInit";
      this.data = data2;
      this.init = init || null;
    }
  };
  function data(data2, init) {
    return new DataWithResponseInit(
      data2,
      typeof init === "number" ? { status: init } : init
    );
  }
  var redirect = (url, init = 302) => {
    let responseInit = init;
    if (typeof responseInit === "number") {
      responseInit = { status: responseInit };
    } else if (typeof responseInit.status === "undefined") {
      responseInit.status = 302;
    }
    let headers = new Headers(responseInit.headers);
    headers.set("Location", url);
    return new Response(null, { ...responseInit, headers });
  };
  var redirectDocument = (url, init) => {
    let response = redirect(url, init);
    response.headers.set("X-Remix-Reload-Document", "true");
    return response;
  };
  var replace = (url, init) => {
    let response = redirect(url, init);
    response.headers.set("X-Remix-Replace", "true");
    return response;
  };
  var SUPPORTED_ERROR_TYPES = [
    "EvalError",
    "RangeError",
    "ReferenceError",
    "SyntaxError",
    "TypeError",
    "URIError"
  ];
  var ErrorResponseImpl = class {
    constructor(status, statusText, data2, internal = false) {
      this.status = status;
      this.statusText = statusText || "";
      this.internal = internal;
      if (data2 instanceof Error) {
        this.data = data2.toString();
        this.error = data2;
      } else {
        this.data = data2;
      }
    }
  };
  function isRouteErrorResponse(error) {
    return error != null && typeof error.status === "number" && typeof error.statusText === "string" && typeof error.internal === "boolean" && "data" in error;
  }
  function getRoutePattern(matches) {
    let parts = matches.map((m) => m.route.path).filter(Boolean);
    return joinPaths(parts) || "/";
  }
  var isBrowser = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
  function parseToInfo(_to, basename) {
    let to = _to;
    if (typeof to !== "string" || !ABSOLUTE_URL_REGEX.test(to)) {
      return {
        absoluteURL: void 0,
        isExternal: false,
        to
      };
    }
    let absoluteURL = to;
    let isExternal = false;
    if (isBrowser) {
      try {
        let currentUrl = new URL(window.location.href);
        let targetUrl = PROTOCOL_RELATIVE_URL_REGEX.test(to) ? new URL(normalizeProtocolRelativeUrl(to, currentUrl.protocol)) : new URL(to);
        let path = stripBasename(targetUrl.pathname, basename);
        if (targetUrl.origin === currentUrl.origin && path != null) {
          to = path + targetUrl.search + targetUrl.hash;
        } else {
          isExternal = true;
        }
      } catch (e) {
        warning(
          false,
          `<Link to="${to}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`
        );
      }
    }
    return {
      absoluteURL,
      isExternal,
      to
    };
  }
  var UninstrumentedSymbol = /* @__PURE__ */ Symbol("Uninstrumented");
  function getRouteInstrumentationUpdates(fns, route) {
    let aggregated = {
      lazy: [],
      "lazy.loader": [],
      "lazy.action": [],
      "lazy.middleware": [],
      middleware: [],
      loader: [],
      action: []
    };
    fns.forEach(
      (fn) => fn({
        id: route.id,
        index: route.index,
        path: route.path,
        instrument(i) {
          let keys = Object.keys(aggregated);
          for (let key of keys) {
            if (i[key]) {
              aggregated[key].push(i[key]);
            }
          }
        }
      })
    );
    let updates = {};
    if (typeof route.lazy === "function" && aggregated.lazy.length > 0) {
      let instrumented = wrapImpl(aggregated.lazy, route.lazy, () => void 0);
      if (instrumented) {
        updates.lazy = instrumented;
      }
    }
    if (typeof route.lazy === "object") {
      let lazyObject = route.lazy;
      ["middleware", "loader", "action"].forEach((key) => {
        let lazyFn = lazyObject[key];
        let instrumentations = aggregated[`lazy.${key}`];
        if (typeof lazyFn === "function" && instrumentations.length > 0) {
          let instrumented = wrapImpl(instrumentations, lazyFn, () => void 0);
          if (instrumented) {
            updates.lazy = Object.assign(updates.lazy || {}, {
              [key]: instrumented
            });
          }
        }
      });
    }
    ["loader", "action"].forEach((key) => {
      let handler = route[key];
      if (typeof handler === "function" && aggregated[key].length > 0) {
        let original = _nullishCoalesce(handler[UninstrumentedSymbol], () => handler);
        let instrumented = wrapImpl(
          aggregated[key],
          original,
          (...args) => getHandlerInfo(args[0])
        );
        if (instrumented) {
          if (key === "loader" && original.hydrate === true) {
            instrumented.hydrate = true;
          }
          instrumented[UninstrumentedSymbol] = original;
          updates[key] = instrumented;
        }
      }
    });
    if (route.middleware && route.middleware.length > 0 && aggregated.middleware.length > 0) {
      updates.middleware = route.middleware.map((middleware) => {
        let original = _nullishCoalesce(middleware[UninstrumentedSymbol], () => middleware);
        let instrumented = wrapImpl(
          aggregated.middleware,
          original,
          (...args) => getHandlerInfo(args[0])
        );
        if (instrumented) {
          instrumented[UninstrumentedSymbol] = original;
          return instrumented;
        }
        return middleware;
      });
    }
    return updates;
  }
  function instrumentClientSideRouter(router, fns) {
    let aggregated = {
      navigate: [],
      fetch: []
    };
    fns.forEach(
      (fn) => fn({
        instrument(i) {
          let keys = Object.keys(i);
          for (let key of keys) {
            if (i[key]) {
              aggregated[key].push(i[key]);
            }
          }
        }
      })
    );
    if (aggregated.navigate.length > 0) {
      let navigate = _nullishCoalesce(router.navigate[UninstrumentedSymbol], () => router.navigate);
      let instrumentedNavigate = wrapImpl(
        aggregated.navigate,
        navigate,
        (...args) => {
          let [to, opts] = args;
          return {
            to: typeof to === "number" || typeof to === "string" ? to : to ? createPath(to) : ".",
            ...getRouterInfo(router, _nullishCoalesce(opts, () => ({})))
          };
        }
      );
      if (instrumentedNavigate) {
        instrumentedNavigate[UninstrumentedSymbol] = navigate;
        router.navigate = instrumentedNavigate;
      }
    }
    if (aggregated.fetch.length > 0) {
      let fetch2 = _nullishCoalesce(router.fetch[UninstrumentedSymbol], () => router.fetch);
      let instrumentedFetch = wrapImpl(aggregated.fetch, fetch2, (...args) => {
        let [key, , href, opts] = args;
        return {
          href: _nullishCoalesce(href, () => "."),
          fetcherKey: key,
          ...getRouterInfo(router, _nullishCoalesce(opts, () => ({})))
        };
      });
      if (instrumentedFetch) {
        instrumentedFetch[UninstrumentedSymbol] = fetch2;
        router.fetch = instrumentedFetch;
      }
    }
    return router;
  }
  function instrumentHandler(handler, fns) {
    let aggregated = {
      request: []
    };
    fns.forEach(
      (fn) => fn({
        instrument(i) {
          let keys = Object.keys(i);
          for (let key of keys) {
            if (i[key]) {
              aggregated[key].push(i[key]);
            }
          }
        }
      })
    );
    let instrumentedHandler = handler;
    if (aggregated.request.length > 0) {
      instrumentedHandler = wrapImpl(aggregated.request, handler, (...args) => {
        let [request, context] = args;
        return {
          request: getReadonlyRequest(request),
          context: context != null ? getReadonlyContext(context) : context
        };
      });
    }
    return instrumentedHandler;
  }
  function wrapImpl(impls, handler, getInfo) {
    if (impls.length === 0) {
      return null;
    }
    return async (...args) => {
      let result = await recurseRight(
        impls,
        getInfo(...args),
        () => handler(...args),
        impls.length - 1
      );
      if (result.type === "error") {
        throw result.value;
      }
      return result.value;
    };
  }
  async function recurseRight(impls, info, handler, index) {
    let impl = impls[index];
    let result;
    if (!impl) {
      try {
        let value = await handler();
        result = { type: "success", value };
      } catch (e) {
        result = { type: "error", value: e };
      }
    } else {
      let handlerPromise = void 0;
      let callHandler = async () => {
        if (handlerPromise) {
          console.error("You cannot call instrumented handlers more than once");
        } else {
          handlerPromise = recurseRight(impls, info, handler, index - 1);
        }
        result = await handlerPromise;
        invariant(result, "Expected a result");
        if (result.type === "error" && result.value instanceof Error) {
          return { status: "error", error: result.value };
        }
        return { status: "success", error: void 0 };
      };
      try {
        await impl(callHandler, info);
      } catch (e) {
        console.error("An instrumentation function threw an error:", e);
      }
      if (!handlerPromise) {
        await callHandler();
      }
      await handlerPromise;
    }
    if (result) {
      return result;
    }
    return {
      type: "error",
      value: new Error("No result assigned in instrumentation chain.")
    };
  }
  function getHandlerInfo(args) {
    let { request, context, params, pattern } = args;
    return {
      request: getReadonlyRequest(request),
      params: { ...params },
      pattern,
      context: getReadonlyContext(context)
    };
  }
  function getRouterInfo(router, opts) {
    return {
      currentUrl: createPath(router.state.location),
      ..."formMethod" in opts ? { formMethod: opts.formMethod } : {},
      ..."formEncType" in opts ? { formEncType: opts.formEncType } : {},
      ..."formData" in opts ? { formData: opts.formData } : {},
      ..."body" in opts ? { body: opts.body } : {}
    };
  }
  function getReadonlyRequest(request) {
    return {
      method: request.method,
      url: request.url,
      headers: {
        get: (...args) => request.headers.get(...args)
      }
    };
  }
  function getReadonlyContext(context) {
    if (isPlainObject(context)) {
      let frozen = { ...context };
      Object.freeze(frozen);
      return frozen;
    } else {
      return {
        get: (ctx) => context.get(ctx)
      };
    }
  }
  var objectProtoNames = Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
  function isPlainObject(thing) {
    if (thing === null || typeof thing !== "object") {
      return false;
    }
    const proto = Object.getPrototypeOf(thing);
    return proto === Object.prototype || proto === null || Object.getOwnPropertyNames(proto).sort().join("\0") === objectProtoNames;
  }
  var DEFAULT_NAVIGATION_URL = new URL("http://localhost");
  function getNavigatorCurrentUrl(navigator) {
    if (navigator.createURL) {
      return navigator.createURL("/");
    }
    try {
      return new URL(navigator.createHref("/"), DEFAULT_NAVIGATION_URL);
    } catch (e2) {
      return DEFAULT_NAVIGATION_URL;
    }
  }
  function isSameOrigin(a, b) {
    return a.origin === b.origin && (a.origin !== "null" || a.protocol === b.protocol && a.host === b.host);
  }
  function isExplicitUrl(destination, target) {
    if (destination.startsWith("//")) {
      return true;
    }
    let protocol = target.protocol.toLowerCase();
    if (!destination.toLowerCase().startsWith(protocol)) {
      return false;
    }
    return target.host === "" || destination.slice(protocol.length).startsWith("//");
  }
  function validateNavigationTarget(original, resolved, currentUrl, externalPolicy) {
    let originalUrl = null;
    try {
      originalUrl = original == null ? null : new URL(original, currentUrl);
    } catch (e3) {
    }
    let resolvedUrl = new URL(resolved, currentUrl);
    let originalIsExternal = originalUrl != null && !isSameOrigin(originalUrl, currentUrl);
    let resolvedIsExternal = !isSameOrigin(resolvedUrl, currentUrl);
    if (externalPolicy === "reject") {
      if (originalIsExternal || resolvedIsExternal) {
        throw new Error("External navigation is not allowed");
      }
    } else if (resolvedIsExternal) {
      if (originalUrl == null || !isExplicitUrl(original, originalUrl) || !isSameOrigin(originalUrl, resolvedUrl)) {
        throw new Error("External navigation is not allowed");
      }
    }
  }
  var validMutationMethodsArr = [
    "POST",
    "PUT",
    "PATCH",
    "DELETE"
  ];
  var validMutationMethods = new Set(
    validMutationMethodsArr
  );
  var validRequestMethodsArr = [
    "GET",
    ...validMutationMethodsArr
  ];
  var validRequestMethods = new Set(validRequestMethodsArr);
  var redirectStatusCodes = /* @__PURE__ */ new Set([301, 302, 303, 307, 308]);
  var redirectPreserveMethodStatusCodes = /* @__PURE__ */ new Set([307, 308]);
  var IDLE_NAVIGATION = {
    state: "idle",
    location: void 0,
    matches: void 0,
    historyAction: void 0,
    formMethod: void 0,
    formAction: void 0,
    formEncType: void 0,
    formData: void 0,
    json: void 0,
    text: void 0
  };
  var IDLE_FETCHER = {
    state: "idle",
    data: void 0,
    formMethod: void 0,
    formAction: void 0,
    formEncType: void 0,
    formData: void 0,
    json: void 0,
    text: void 0
  };
  var IDLE_BLOCKER = {
    state: "unblocked",
    proceed: void 0,
    reset: void 0,
    location: void 0
  };
  var defaultMapRouteProperties = (route) => ({
    hasErrorBoundary: Boolean(route.hasErrorBoundary)
  });
  var TRANSITIONS_STORAGE_KEY = "remix-router-transitions";
  var ResetLoaderDataSymbol = /* @__PURE__ */ Symbol("ResetLoaderData");
  var _routes, _branches, _hmrRoutes, _hmrBranches;
  var DataRoutes = class {
    constructor(routes) {
      __privateAdd(this, _routes);
      __privateAdd(this, _branches);
      __privateAdd(this, _hmrRoutes);
      __privateAdd(this, _hmrBranches);
      __privateSet(this, _routes, routes);
      __privateSet(this, _branches, flattenAndRankRoutes(routes));
    }
    /** The stable route tree */
    get stableRoutes() {
      return __privateGet(this, _routes);
    }
    /** The in-flight route tree if one is active, otherwise the stable tree */
    get activeRoutes() {
      return _nullishCoalesce(__privateGet(this, _hmrRoutes), () => __privateGet(this, _routes));
    }
    /** Pre-computed branches */
    get branches() {
      return _nullishCoalesce(__privateGet(this, _hmrBranches), () => __privateGet(this, _branches));
    }
    get hasHMRRoutes() {
      return __privateGet(this, _hmrRoutes) != null;
    }
    /** Replace the stable route tree and recompute its branches */
    setRoutes(routes) {
      __privateSet(this, _routes, routes);
      __privateSet(this, _branches, flattenAndRankRoutes(routes));
    }
    /** Set a new in-flight route tree and recompute its branches */
    setHmrRoutes(routes) {
      __privateSet(this, _hmrRoutes, routes);
      __privateSet(this, _hmrBranches, flattenAndRankRoutes(routes));
    }
    /** Commit in-flight routes/branches to the stable slot and clear in-flight */
    commitHmrRoutes() {
      if (__privateGet(this, _hmrRoutes)) {
        __privateSet(this, _routes, __privateGet(this, _hmrRoutes));
        __privateSet(this, _branches, __privateGet(this, _hmrBranches));
        __privateSet(this, _hmrRoutes, void 0);
        __privateSet(this, _hmrBranches, void 0);
      }
    }
  };
  _routes = /* @__PURE__ */ new WeakMap();
  _branches = /* @__PURE__ */ new WeakMap();
  _hmrRoutes = /* @__PURE__ */ new WeakMap();
  _hmrBranches = /* @__PURE__ */ new WeakMap();
  function createRouter(init) {
    const routerWindow = init.window ? init.window : typeof window !== "undefined" ? window : void 0;
    const isBrowser2 = typeof routerWindow !== "undefined" && typeof routerWindow.document !== "undefined" && typeof routerWindow.document.createElement !== "undefined";
    invariant(
      init.routes.length > 0,
      "You must provide a non-empty routes array to createRouter"
    );
    let hydrationRouteProperties2 = init.hydrationRouteProperties || [];
    let _mapRouteProperties = init.mapRouteProperties || defaultMapRouteProperties;
    let mapRouteProperties2 = _mapRouteProperties;
    if (init.instrumentations) {
      let instrumentations = init.instrumentations;
      mapRouteProperties2 = (route) => {
        return {
          ..._mapRouteProperties(route),
          ...getRouteInstrumentationUpdates(
            instrumentations.map((i) => i.route).filter(Boolean),
            route
          )
        };
      };
    }
    let manifest = {};
    let dataRoutes = new DataRoutes(
      convertRoutesToDataRoutes(
        init.routes,
        mapRouteProperties2,
        void 0,
        manifest
      )
    );
    let basename = init.basename || "/";
    if (!basename.startsWith("/")) {
      basename = `/${basename}`;
    }
    let dataStrategyImpl = init.dataStrategy || defaultDataStrategyWithMiddleware;
    let future = {
      ...init.future
    };
    let unlistenHistory = null;
    let subscribers = /* @__PURE__ */ new Set();
    let bufferedInitialStateUpdate = null;
    let savedScrollPositions = null;
    let getScrollRestorationKey = null;
    let getScrollPosition = null;
    let initialScrollRestored = init.hydrationData != null;
    let initialMatches = matchRoutesImpl(
      dataRoutes.activeRoutes,
      init.history.location,
      basename,
      false,
      dataRoutes.branches
    );
    let initialMatchesIsFOW = false;
    let initialErrors = null;
    let initialized;
    let renderFallback;
    if (initialMatches == null && !init.patchRoutesOnNavigation) {
      let error = getInternalRouterError(404, {
        pathname: init.history.location.pathname
      });
      let { matches, route } = getShortCircuitMatches(dataRoutes.activeRoutes);
      initialized = true;
      renderFallback = !initialized;
      initialMatches = matches;
      initialErrors = { [route.id]: error };
    } else {
      if (initialMatches && !init.hydrationData) {
        let fogOfWar = checkFogOfWar(
          initialMatches,
          dataRoutes.activeRoutes,
          init.history.location.pathname
        );
        if (fogOfWar.active) {
          initialMatches = null;
        }
      }
      if (!initialMatches) {
        initialized = false;
        renderFallback = !initialized;
        initialMatches = [];
        let fogOfWar = checkFogOfWar(
          null,
          dataRoutes.activeRoutes,
          init.history.location.pathname
        );
        if (fogOfWar.active && fogOfWar.matches) {
          initialMatchesIsFOW = true;
          initialMatches = fogOfWar.matches;
        }
      } else if (initialMatches.some((m) => m.route.lazy)) {
        initialized = false;
        renderFallback = !initialized;
      } else if (!initialMatches.some((m) => routeHasLoaderOrMiddleware(m.route))) {
        initialized = true;
        renderFallback = !initialized;
      } else {
        let loaderData = init.hydrationData ? init.hydrationData.loaderData : null;
        let errors = init.hydrationData ? init.hydrationData.errors : null;
        let relevantMatches = initialMatches;
        if (errors) {
          let idx = initialMatches.findIndex(
            (m) => errors[m.route.id] !== void 0
          );
          relevantMatches = relevantMatches.slice(0, idx + 1);
        }
        renderFallback = false;
        initialized = true;
        relevantMatches.forEach((m) => {
          let status = getRouteHydrationStatus(m.route, loaderData, errors);
          renderFallback = renderFallback || status.renderFallback;
          initialized = initialized && !status.shouldLoad;
        });
      }
    }
    let router;
    let state = {
      historyAction: init.history.action,
      location: init.history.location,
      matches: initialMatches,
      initialized,
      renderFallback,
      navigation: IDLE_NAVIGATION,
      // Don't restore on initial updateState() if we were SSR'd
      restoreScrollPosition: init.hydrationData != null ? false : null,
      preventScrollReset: false,
      revalidation: "idle",
      loaderData: init.hydrationData && init.hydrationData.loaderData || {},
      actionData: init.hydrationData && init.hydrationData.actionData || null,
      errors: init.hydrationData && init.hydrationData.errors || initialErrors,
      fetchers: /* @__PURE__ */ new Map(),
      blockers: /* @__PURE__ */ new Map()
    };
    let pendingAction = "POP";
    let pendingPopstateNavigationDfd = null;
    let pendingPreventScrollReset = false;
    let pendingNavigationController;
    let pendingViewTransitionEnabled = false;
    let appliedViewTransitions = /* @__PURE__ */ new Map();
    let removePageHideEventListener = null;
    let isUninterruptedRevalidation = false;
    let isRevalidationRequired = false;
    let cancelledFetcherLoads = /* @__PURE__ */ new Set();
    let fetchControllers = /* @__PURE__ */ new Map();
    let incrementingLoadId = 0;
    let pendingNavigationLoadId = -1;
    let fetchReloadIds = /* @__PURE__ */ new Map();
    let fetchRedirectIds = /* @__PURE__ */ new Set();
    let fetchLoadMatches = /* @__PURE__ */ new Map();
    let activeFetchers = /* @__PURE__ */ new Map();
    let fetchersQueuedForDeletion = /* @__PURE__ */ new Set();
    let blockerFunctions = /* @__PURE__ */ new Map();
    let unblockBlockerHistoryUpdate = void 0;
    let pendingRevalidationDfd = null;
    function initialize() {
      unlistenHistory = init.history.listen(
        ({ action: historyAction, location: location2, delta }) => {
          if (unblockBlockerHistoryUpdate) {
            unblockBlockerHistoryUpdate();
            unblockBlockerHistoryUpdate = void 0;
            return;
          }
          warning(
            blockerFunctions.size === 0 || delta != null,
            "You are trying to use a blocker on a POP navigation to a location that was not created by @remix-run/router. This will fail silently in production. This can happen if you are navigating outside the router via `window.history.pushState`/`window.location.hash` instead of using router navigation APIs.  This can also happen if you are using createHashRouter and the user manually changes the URL."
          );
          let blockerKey = shouldBlockNavigation({
            currentLocation: state.location,
            nextLocation: location2,
            historyAction
          });
          if (blockerKey && delta != null) {
            let nextHistoryUpdatePromise = new Promise((resolve) => {
              unblockBlockerHistoryUpdate = resolve;
            });
            init.history.go(delta * -1);
            updateBlocker(blockerKey, {
              state: "blocked",
              location: location2,
              proceed() {
                updateBlocker(blockerKey, {
                  state: "proceeding",
                  proceed: void 0,
                  reset: void 0,
                  location: location2
                });
                nextHistoryUpdatePromise.then(() => init.history.go(delta));
              },
              reset() {
                let blockers = new Map(state.blockers);
                blockers.set(blockerKey, IDLE_BLOCKER);
                updateState({ blockers });
              }
            });
            _optionalChain([pendingPopstateNavigationDfd, "optionalAccess", (_7) => _7.resolve, "call", (_8) => _8()]);
            pendingPopstateNavigationDfd = null;
            return;
          }
          return startNavigation(historyAction, location2);
        }
      );
      if (isBrowser2) {
        restoreAppliedTransitions(routerWindow, appliedViewTransitions);
        let _saveAppliedTransitions = () => persistAppliedTransitions(routerWindow, appliedViewTransitions);
        routerWindow.addEventListener("pagehide", _saveAppliedTransitions);
        removePageHideEventListener = () => routerWindow.removeEventListener("pagehide", _saveAppliedTransitions);
      }
      if (!state.initialized) {
        startNavigation("POP", state.location, {
          initialHydration: true
        });
      }
      return router;
    }
    function dispose() {
      if (unlistenHistory) {
        unlistenHistory();
      }
      if (removePageHideEventListener) {
        removePageHideEventListener();
      }
      subscribers.clear();
      pendingNavigationController && pendingNavigationController.abort();
      state.fetchers.forEach((_, key) => deleteFetcher(state.fetchers, key));
      state.blockers.forEach((_, key) => deleteBlocker(key));
    }
    function subscribe(fn) {
      subscribers.add(fn);
      if (bufferedInitialStateUpdate) {
        let { newErrors } = bufferedInitialStateUpdate;
        bufferedInitialStateUpdate = null;
        fn(state, {
          deletedFetchers: [],
          newErrors,
          viewTransitionOpts: void 0,
          flushSync: false
        });
      }
      return () => subscribers.delete(fn);
    }
    function updateState(newState, opts = {}) {
      if (newState.matches) {
        newState.matches = newState.matches.map((m) => {
          let route = manifest[m.route.id];
          let matchRoute = m.route;
          if (matchRoute.element !== route.element || matchRoute.errorElement !== route.errorElement || matchRoute.hydrateFallbackElement !== route.hydrateFallbackElement) {
            return {
              ...m,
              route
            };
          }
          return m;
        });
      }
      state = {
        ...state,
        ...newState
      };
      let unmountedFetchers = [];
      let mountedFetchers = [];
      state.fetchers.forEach((fetcher, key) => {
        if (fetcher.state === "idle") {
          if (fetchersQueuedForDeletion.has(key)) {
            unmountedFetchers.push(key);
          } else {
            mountedFetchers.push(key);
          }
        }
      });
      fetchersQueuedForDeletion.forEach((key) => {
        if (!state.fetchers.has(key) && !fetchControllers.has(key)) {
          unmountedFetchers.push(key);
        }
      });
      if (subscribers.size === 0) {
        bufferedInitialStateUpdate = { newErrors: _nullishCoalesce(newState.errors, () => null) };
      }
      [...subscribers].forEach(
        (subscriber) => subscriber(state, {
          deletedFetchers: unmountedFetchers,
          newErrors: _nullishCoalesce(newState.errors, () => null),
          viewTransitionOpts: opts.viewTransitionOpts,
          flushSync: opts.flushSync === true
        })
      );
      unmountedFetchers.forEach((key) => deleteFetcher(state.fetchers, key));
      mountedFetchers.forEach((key) => state.fetchers.delete(key));
    }
    function completeNavigation(location2, newState, { flushSync } = {}) {
      let isActionReload = state.actionData != null && state.navigation.formMethod != null && isMutationMethod(state.navigation.formMethod) && state.navigation.state === "loading" && _optionalChain([location2, "access", (_9) => _9.state, "optionalAccess", (_10) => _10._isRedirect]) !== true;
      let actionData;
      if (newState.actionData) {
        if (Object.keys(newState.actionData).length > 0) {
          actionData = newState.actionData;
        } else {
          actionData = null;
        }
      } else if (isActionReload) {
        actionData = state.actionData;
      } else {
        actionData = null;
      }
      let loaderData = newState.loaderData ? mergeLoaderData(
        state.loaderData,
        newState.loaderData,
        newState.matches || [],
        newState.errors
      ) : state.loaderData;
      let blockers = state.blockers;
      if (blockers.size > 0) {
        blockers = new Map(blockers);
        blockers.forEach((_, k) => blockers.set(k, IDLE_BLOCKER));
      }
      let restoreScrollPosition = isUninterruptedRevalidation ? false : getSavedScrollPosition(location2, newState.matches || state.matches);
      let preventScrollReset = pendingPreventScrollReset === true || state.navigation.formMethod != null && isMutationMethod(state.navigation.formMethod) && _optionalChain([location2, "access", (_11) => _11.state, "optionalAccess", (_12) => _12._isRedirect]) !== true;
      dataRoutes.commitHmrRoutes();
      if (isUninterruptedRevalidation) ;
      else if (pendingAction === "POP") ;
      else if (pendingAction === "PUSH") {
        init.history.push(location2, location2.state);
      } else if (pendingAction === "REPLACE") {
        init.history.replace(location2, location2.state);
      }
      let viewTransitionOpts;
      if (pendingAction === "POP" && !isUninterruptedRevalidation && location2 !== state.location) {
        let priorPaths = appliedViewTransitions.get(state.location.pathname);
        if (priorPaths && priorPaths.has(location2.pathname)) {
          viewTransitionOpts = {
            currentLocation: state.location,
            nextLocation: location2
          };
        } else if (appliedViewTransitions.has(location2.pathname)) {
          viewTransitionOpts = {
            currentLocation: location2,
            nextLocation: state.location
          };
        }
      } else if (pendingViewTransitionEnabled) {
        let toPaths = appliedViewTransitions.get(state.location.pathname);
        if (toPaths) {
          toPaths.add(location2.pathname);
        } else {
          toPaths = /* @__PURE__ */ new Set([location2.pathname]);
          appliedViewTransitions.set(state.location.pathname, toPaths);
        }
        viewTransitionOpts = {
          currentLocation: state.location,
          nextLocation: location2
        };
      }
      updateState(
        {
          ...newState,
          // matches, errors, fetchers go through as-is
          actionData,
          loaderData,
          historyAction: pendingAction,
          location: location2,
          initialized: true,
          renderFallback: false,
          navigation: IDLE_NAVIGATION,
          revalidation: "idle",
          restoreScrollPosition,
          preventScrollReset,
          blockers
        },
        {
          viewTransitionOpts,
          flushSync: flushSync === true
        }
      );
      pendingAction = "POP";
      pendingPreventScrollReset = false;
      pendingViewTransitionEnabled = false;
      isUninterruptedRevalidation = false;
      isRevalidationRequired = false;
      _optionalChain([pendingPopstateNavigationDfd, "optionalAccess", (_13) => _13.resolve, "call", (_14) => _14()]);
      pendingPopstateNavigationDfd = null;
      _optionalChain([pendingRevalidationDfd, "optionalAccess", (_15) => _15.resolve, "call", (_16) => _16()]);
      pendingRevalidationDfd = null;
    }
    async function navigate(to, opts) {
      _optionalChain([pendingPopstateNavigationDfd, "optionalAccess", (_17) => _17.resolve, "call", (_18) => _18()]);
      pendingPopstateNavigationDfd = null;
      if (typeof to === "number") {
        if (!pendingPopstateNavigationDfd) {
          pendingPopstateNavigationDfd = createDeferred();
        }
        let promise = pendingPopstateNavigationDfd.promise;
        init.history.go(to);
        return promise;
      }
      let normalizedPath = normalizeTo(
        state.location,
        state.matches,
        basename,
        to,
        _optionalChain([opts, "optionalAccess", (_19) => _19.fromRouteId]),
        _optionalChain([opts, "optionalAccess", (_20) => _20.relative])
      );
      let { path, submission, error } = normalizeNavigateOptions(
        false,
        normalizedPath,
        opts
      );
      let maskPath;
      if (_optionalChain([opts, "optionalAccess", (_21) => _21.mask])) {
        let partialPath = typeof opts.mask === "string" ? parsePath(opts.mask) : {
          ...state.location.mask,
          ...opts.mask
        };
        maskPath = {
          pathname: _nullishCoalesce(partialPath.pathname, () => ""),
          search: _nullishCoalesce(partialPath.search, () => ""),
          hash: _nullishCoalesce(partialPath.hash, () => "")
        };
        if (PROTOCOL_RELATIVE_URL_REGEX.test(maskPath.pathname)) {
          throw new Error("External navigation is not allowed");
        } else if (maskPath.pathname.startsWith("\\")) {
          maskPath.pathname = maskPath.pathname.replace(/^\\+/, "/");
        }
        validateNavigationTarget(
          typeof opts.mask === "string" ? opts.mask : createPath(opts.mask),
          createPath(maskPath),
          init.history.createURL("/"),
          "reject"
        );
      }
      let currentLocation = state.location;
      let nextLocation = createLocation(
        currentLocation,
        path,
        opts && opts.state,
        void 0,
        maskPath
      );
      nextLocation = {
        ...nextLocation,
        ...init.history.encodeLocation(nextLocation)
      };
      validateNavigationTarget(
        to == null ? init.history.createHref(state.location) : typeof to === "string" ? to : createPath(to),
        init.history.createHref(nextLocation.mask || nextLocation),
        init.history.createURL("/"),
        "reject"
      );
      let userReplace = opts && opts.replace != null ? opts.replace : void 0;
      let historyAction = "PUSH";
      if (userReplace === true) {
        historyAction = "REPLACE";
      } else if (userReplace === false) ;
      else if (submission != null && isMutationMethod(submission.formMethod) && submission.formAction === state.location.pathname + state.location.search) {
        historyAction = "REPLACE";
      }
      let preventScrollReset = opts && "preventScrollReset" in opts ? opts.preventScrollReset === true : void 0;
      let flushSync = (opts && opts.flushSync) === true;
      let blockerKey = shouldBlockNavigation({
        currentLocation,
        nextLocation,
        historyAction
      });
      if (blockerKey) {
        updateBlocker(blockerKey, {
          state: "blocked",
          location: nextLocation,
          proceed() {
            updateBlocker(blockerKey, {
              state: "proceeding",
              proceed: void 0,
              reset: void 0,
              location: nextLocation
            });
            navigate(to, opts);
          },
          reset() {
            let blockers = new Map(state.blockers);
            blockers.set(blockerKey, IDLE_BLOCKER);
            updateState({ blockers });
          }
        });
        return;
      }
      await startNavigation(historyAction, nextLocation, {
        submission,
        // Send through the formData serialization error if we have one so we can
        // render at the right error boundary after we match routes
        pendingError: error,
        preventScrollReset,
        replace: opts && opts.replace,
        enableViewTransition: opts && opts.viewTransition,
        flushSync,
        callSiteDefaultShouldRevalidate: opts && opts.defaultShouldRevalidate
      });
    }
    function revalidate() {
      if (!pendingRevalidationDfd) {
        pendingRevalidationDfd = createDeferred();
      }
      interruptActiveLoads();
      updateState({ revalidation: "loading" });
      let promise = pendingRevalidationDfd.promise;
      if (state.navigation.state === "submitting") {
        return promise;
      }
      if (state.navigation.state === "idle") {
        startNavigation(state.historyAction, state.location, {
          startUninterruptedRevalidation: true
        });
        return promise;
      }
      startNavigation(
        pendingAction || state.historyAction,
        state.navigation.location,
        {
          overrideNavigation: state.navigation,
          // Proxy through any rending view transition
          enableViewTransition: pendingViewTransitionEnabled === true
        }
      );
      return promise;
    }
    async function startNavigation(historyAction, location2, opts) {
      pendingNavigationController && pendingNavigationController.abort();
      pendingNavigationController = null;
      pendingAction = historyAction;
      isUninterruptedRevalidation = (opts && opts.startUninterruptedRevalidation) === true;
      saveScrollPosition(state.location, state.matches);
      pendingPreventScrollReset = (opts && opts.preventScrollReset) === true;
      pendingViewTransitionEnabled = (opts && opts.enableViewTransition) === true;
      let routesToUse = dataRoutes.activeRoutes;
      let matches = _optionalChain([opts, "optionalAccess", (_22) => _22.initialHydration]) && state.matches && state.matches.length > 0 && !initialMatchesIsFOW ? (
        // `matchRoutes()` has already been called if we're in here via `router.initialize()`
        state.matches
      ) : matchRoutesImpl(
        routesToUse,
        location2,
        basename,
        false,
        dataRoutes.branches
      );
      let flushSync = (opts && opts.flushSync) === true;
      if (matches && state.initialized && !isRevalidationRequired && isHashChangeOnly(state.location, location2) && !(opts && opts.submission && isMutationMethod(opts.submission.formMethod))) {
        completeNavigation(location2, { matches }, { flushSync });
        return;
      }
      let fogOfWar = checkFogOfWar(matches, routesToUse, location2.pathname);
      if (fogOfWar.active && fogOfWar.matches) {
        matches = fogOfWar.matches;
      }
      if (!matches) {
        let { error, notFoundMatches, route } = handleNavigational404(
          location2.pathname
        );
        completeNavigation(
          location2,
          {
            matches: notFoundMatches,
            loaderData: {},
            errors: {
              [route.id]: error
            }
          },
          { flushSync }
        );
        return;
      }
      let loadingNavigation = opts && opts.overrideNavigation ? {
        ...opts.overrideNavigation,
        matches,
        historyAction
      } : void 0;
      pendingNavigationController = new AbortController();
      let request = createClientSideRequest(
        init.history,
        location2,
        pendingNavigationController.signal,
        opts && opts.submission
      );
      let scopedContext = init.getContext ? await init.getContext() : new RouterContextProvider();
      let pendingActionResult;
      if (opts && opts.pendingError) {
        pendingActionResult = [
          findNearestBoundary(matches).route.id,
          { type: "error", error: opts.pendingError }
        ];
      } else if (opts && opts.submission && isMutationMethod(opts.submission.formMethod)) {
        let actionResult = await handleAction(
          request,
          location2,
          opts.submission,
          matches,
          historyAction,
          scopedContext,
          fogOfWar.active,
          opts && opts.initialHydration === true,
          { replace: opts.replace, flushSync }
        );
        if (actionResult.shortCircuited) {
          return;
        }
        if (actionResult.pendingActionResult) {
          let [routeId, result] = actionResult.pendingActionResult;
          if (isErrorResult(result) && isRouteErrorResponse(result.error) && result.error.status === 404) {
            pendingNavigationController = null;
            completeNavigation(location2, {
              matches: actionResult.matches,
              loaderData: {},
              errors: {
                [routeId]: result.error
              }
            });
            return;
          }
        }
        matches = actionResult.matches || matches;
        pendingActionResult = actionResult.pendingActionResult;
        loadingNavigation = getLoadingNavigation(
          location2,
          matches,
          historyAction,
          opts.submission
        );
        flushSync = false;
        fogOfWar.active = false;
        request = createClientSideRequest(
          init.history,
          request.url,
          request.signal
        );
      }
      let {
        shortCircuited,
        matches: updatedMatches,
        loaderData,
        errors,
        workingFetchers
      } = await handleLoaders(
        request,
        location2,
        matches,
        historyAction,
        scopedContext,
        fogOfWar.active,
        loadingNavigation,
        opts && opts.submission,
        opts && opts.fetcherSubmission,
        opts && opts.replace,
        opts && opts.initialHydration === true,
        flushSync,
        pendingActionResult,
        opts && opts.callSiteDefaultShouldRevalidate
      );
      if (shortCircuited) {
        return;
      }
      pendingNavigationController = null;
      completeNavigation(location2, {
        matches: updatedMatches || matches,
        ...getActionDataForCommit(pendingActionResult),
        loaderData,
        errors,
        ...workingFetchers ? { fetchers: workingFetchers } : {}
      });
    }
    async function handleAction(request, location2, submission, matches, historyAction, scopedContext, isFogOfWar, initialHydration, opts = {}) {
      interruptActiveLoads();
      let navigation = getSubmittingNavigation(
        location2,
        matches,
        historyAction,
        submission
      );
      updateState({ navigation }, { flushSync: opts.flushSync === true });
      if (isFogOfWar) {
        let discoverResult = await discoverRoutes(
          matches,
          location2.pathname,
          request.signal
        );
        if (discoverResult.type === "aborted") {
          return { shortCircuited: true };
        } else if (discoverResult.type === "error") {
          if (discoverResult.partialMatches.length === 0) {
            let { matches: matches2, route } = getShortCircuitMatches(
              dataRoutes.activeRoutes
            );
            return {
              matches: matches2,
              pendingActionResult: [
                route.id,
                {
                  type: "error",
                  error: discoverResult.error
                }
              ]
            };
          }
          let boundaryId = findNearestBoundary(discoverResult.partialMatches).route.id;
          return {
            matches: discoverResult.partialMatches,
            pendingActionResult: [
              boundaryId,
              {
                type: "error",
                error: discoverResult.error
              }
            ]
          };
        } else if (!discoverResult.matches) {
          let { notFoundMatches, error, route } = handleNavigational404(
            location2.pathname
          );
          return {
            matches: notFoundMatches,
            pendingActionResult: [
              route.id,
              {
                type: "error",
                error
              }
            ]
          };
        } else {
          matches = discoverResult.matches;
        }
      }
      let result;
      let actionMatch = getTargetMatch(matches, location2);
      if (!actionMatch.route.action && !actionMatch.route.lazy) {
        result = {
          type: "error",
          error: getInternalRouterError(405, {
            method: request.method,
            pathname: location2.pathname,
            routeId: actionMatch.route.id
          })
        };
      } else {
        let dsMatches = getTargetedDataStrategyMatches(
          mapRouteProperties2,
          manifest,
          request,
          location2,
          matches,
          actionMatch,
          initialHydration ? [] : hydrationRouteProperties2,
          scopedContext
        );
        let results = await callDataStrategy(
          request,
          location2,
          dsMatches,
          scopedContext,
          null
        );
        result = results[actionMatch.route.id];
        if (!result) {
          for (let match of matches) {
            if (results[match.route.id]) {
              result = results[match.route.id];
              break;
            }
          }
        }
        if (request.signal.aborted) {
          return { shortCircuited: true };
        }
      }
      if (isRedirectResult(result)) {
        let replace2;
        if (opts && opts.replace != null) {
          replace2 = opts.replace;
        } else {
          let location22 = normalizeRedirectLocation(
            result.response.headers.get("Location"),
            new URL(request.url),
            basename,
            init.history
          );
          replace2 = location22 === state.location.pathname + state.location.search;
        }
        await startRedirectNavigation(request, result, true, {
          submission,
          replace: replace2
        });
        return { shortCircuited: true };
      }
      if (isErrorResult(result)) {
        let boundaryMatch = findNearestBoundary(matches, actionMatch.route.id);
        if ((opts && opts.replace) !== true) {
          pendingAction = "PUSH";
        }
        return {
          matches,
          pendingActionResult: [
            boundaryMatch.route.id,
            result,
            actionMatch.route.id
          ]
        };
      }
      return {
        matches,
        pendingActionResult: [actionMatch.route.id, result]
      };
    }
    async function handleLoaders(request, location2, matches, historyAction, scopedContext, isFogOfWar, overrideNavigation, submission, fetcherSubmission, replace2, initialHydration, flushSync, pendingActionResult, callSiteDefaultShouldRevalidate) {
      let loadingNavigation = overrideNavigation || getLoadingNavigation(location2, matches, historyAction, submission);
      let activeSubmission = submission || fetcherSubmission || getSubmissionFromNavigation(loadingNavigation);
      let shouldUpdateNavigationState = !isUninterruptedRevalidation && !initialHydration;
      if (isFogOfWar) {
        if (shouldUpdateNavigationState) {
          let actionData = getUpdatedActionData(pendingActionResult);
          updateState(
            {
              navigation: loadingNavigation,
              ...actionData !== void 0 ? { actionData } : {}
            },
            {
              flushSync
            }
          );
        }
        let discoverResult = await discoverRoutes(
          matches,
          location2.pathname,
          request.signal
        );
        if (discoverResult.type === "aborted") {
          return { shortCircuited: true };
        } else if (discoverResult.type === "error") {
          if (discoverResult.partialMatches.length === 0) {
            let { matches: matches2, route } = getShortCircuitMatches(
              dataRoutes.activeRoutes
            );
            return {
              matches: matches2,
              loaderData: {},
              errors: {
                [route.id]: discoverResult.error
              }
            };
          }
          let boundaryId = findNearestBoundary(discoverResult.partialMatches).route.id;
          return {
            matches: discoverResult.partialMatches,
            loaderData: {},
            errors: {
              [boundaryId]: discoverResult.error
            }
          };
        } else if (!discoverResult.matches) {
          let { error, notFoundMatches, route } = handleNavigational404(
            location2.pathname
          );
          return {
            matches: notFoundMatches,
            loaderData: {},
            errors: {
              [route.id]: error
            }
          };
        } else {
          matches = discoverResult.matches;
        }
      }
      let routesToUse = dataRoutes.activeRoutes;
      let { dsMatches, revalidatingFetchers } = getMatchesToLoad(
        request,
        scopedContext,
        mapRouteProperties2,
        manifest,
        init.history,
        state,
        matches,
        activeSubmission,
        location2,
        initialHydration ? [] : hydrationRouteProperties2,
        initialHydration === true,
        isRevalidationRequired,
        cancelledFetcherLoads,
        fetchersQueuedForDeletion,
        fetchLoadMatches,
        fetchRedirectIds,
        routesToUse,
        basename,
        init.patchRoutesOnNavigation != null,
        dataRoutes.branches,
        pendingActionResult,
        callSiteDefaultShouldRevalidate
      );
      pendingNavigationLoadId = ++incrementingLoadId;
      if (!init.dataStrategy && !dsMatches.some((m) => m.shouldLoad) && !dsMatches.some(
        (m) => m.route.middleware && m.route.middleware.length > 0
      ) && revalidatingFetchers.length === 0) {
        let workingFetchers2 = new Map(state.fetchers);
        let didUpdateFetcherRedirects2 = markFetchRedirectsDone(workingFetchers2);
        completeNavigation(
          location2,
          {
            matches,
            loaderData: {},
            // Commit pending error if we're short circuiting
            errors: pendingActionResult && isErrorResult(pendingActionResult[1]) ? { [pendingActionResult[0]]: pendingActionResult[1].error } : null,
            ...getActionDataForCommit(pendingActionResult),
            ...didUpdateFetcherRedirects2 ? { fetchers: workingFetchers2 } : {}
          },
          { flushSync }
        );
        return { shortCircuited: true };
      }
      if (shouldUpdateNavigationState) {
        let updates = {};
        if (!isFogOfWar) {
          updates.navigation = loadingNavigation;
          let actionData = getUpdatedActionData(pendingActionResult);
          if (actionData !== void 0) {
            updates.actionData = actionData;
          }
        }
        if (revalidatingFetchers.length > 0) {
          updates.fetchers = getUpdatedRevalidatingFetchers(revalidatingFetchers);
        }
        updateState(updates, { flushSync });
      }
      revalidatingFetchers.forEach((rf) => {
        abortFetcher(rf.key);
        if (rf.controller) {
          fetchControllers.set(rf.key, rf.controller);
        }
      });
      let abortPendingFetchRevalidations = () => revalidatingFetchers.forEach((f) => abortFetcher(f.key));
      if (pendingNavigationController) {
        pendingNavigationController.signal.addEventListener(
          "abort",
          abortPendingFetchRevalidations
        );
      }
      let { loaderResults, fetcherResults } = await callLoadersAndMaybeResolveData(
        dsMatches,
        revalidatingFetchers,
        request,
        location2,
        scopedContext
      );
      if (request.signal.aborted) {
        return { shortCircuited: true };
      }
      if (pendingNavigationController) {
        pendingNavigationController.signal.removeEventListener(
          "abort",
          abortPendingFetchRevalidations
        );
      }
      revalidatingFetchers.forEach((rf) => fetchControllers.delete(rf.key));
      let redirect2 = findRedirect(loaderResults);
      if (redirect2) {
        await startRedirectNavigation(request, redirect2.result, true, {
          replace: replace2
        });
        return { shortCircuited: true };
      }
      redirect2 = findRedirect(fetcherResults);
      if (redirect2) {
        fetchRedirectIds.add(redirect2.key);
        await startRedirectNavigation(request, redirect2.result, true, {
          replace: replace2
        });
        return { shortCircuited: true };
      }
      let workingFetchers = new Map(state.fetchers);
      let { loaderData, errors } = processLoaderData(
        state,
        matches,
        loaderResults,
        pendingActionResult,
        revalidatingFetchers,
        fetcherResults,
        workingFetchers
      );
      if (initialHydration && state.errors) {
        errors = { ...state.errors, ...errors };
      }
      let didUpdateFetcherRedirects = markFetchRedirectsDone(workingFetchers);
      let didAbortFetchLoads = abortStaleFetchLoads(
        pendingNavigationLoadId,
        workingFetchers
      );
      let shouldUpdateFetchers = didUpdateFetcherRedirects || didAbortFetchLoads || revalidatingFetchers.length > 0;
      return {
        matches,
        loaderData,
        errors,
        ...shouldUpdateFetchers ? { workingFetchers } : {}
      };
    }
    function getUpdatedActionData(pendingActionResult) {
      if (pendingActionResult && !isErrorResult(pendingActionResult[1])) {
        return {
          [pendingActionResult[0]]: pendingActionResult[1].data
        };
      } else if (state.actionData) {
        if (Object.keys(state.actionData).length === 0) {
          return null;
        } else {
          return state.actionData;
        }
      }
    }
    function getUpdatedRevalidatingFetchers(revalidatingFetchers) {
      let workingFetchers = new Map(state.fetchers);
      revalidatingFetchers.forEach((rf) => {
        let fetcher = workingFetchers.get(rf.key);
        let revalidatingFetcher = getLoadingFetcher(
          void 0,
          fetcher ? fetcher.data : void 0
        );
        workingFetchers.set(rf.key, revalidatingFetcher);
      });
      return workingFetchers;
    }
    async function fetch2(key, routeId, href, opts) {
      abortFetcher(key);
      let flushSync = (opts && opts.flushSync) === true;
      let routesToUse = dataRoutes.activeRoutes;
      let normalizedPath = normalizeTo(
        state.location,
        state.matches,
        basename,
        href,
        routeId,
        _optionalChain([opts, "optionalAccess", (_23) => _23.relative])
      );
      let matches = matchRoutesImpl(
        routesToUse,
        normalizedPath,
        basename,
        false,
        dataRoutes.branches
      );
      let fogOfWar = checkFogOfWar(matches, routesToUse, normalizedPath);
      if (fogOfWar.active && fogOfWar.matches) {
        matches = fogOfWar.matches;
      }
      if (!matches) {
        setFetcherError(
          key,
          routeId,
          getInternalRouterError(404, { pathname: normalizedPath }),
          { flushSync }
        );
        return;
      }
      let { path, submission, error } = normalizeNavigateOptions(
        true,
        normalizedPath,
        opts
      );
      if (error) {
        setFetcherError(key, routeId, error, { flushSync });
        return;
      }
      let scopedContext = init.getContext ? await init.getContext() : new RouterContextProvider();
      let preventScrollReset = (opts && opts.preventScrollReset) === true;
      if (submission && isMutationMethod(submission.formMethod)) {
        await handleFetcherAction(
          key,
          routeId,
          path,
          matches,
          scopedContext,
          fogOfWar.active,
          flushSync,
          preventScrollReset,
          submission,
          opts && opts.defaultShouldRevalidate
        );
        return;
      }
      fetchLoadMatches.set(key, { routeId, path });
      await handleFetcherLoader(
        key,
        routeId,
        path,
        matches,
        scopedContext,
        fogOfWar.active,
        flushSync,
        preventScrollReset,
        submission
      );
    }
    async function handleFetcherAction(key, routeId, path, requestMatches, scopedContext, isFogOfWar, flushSync, preventScrollReset, submission, callSiteDefaultShouldRevalidate) {
      interruptActiveLoads();
      fetchLoadMatches.delete(key);
      let existingFetcher = state.fetchers.get(key);
      updateFetcherState(key, getSubmittingFetcher(submission, existingFetcher), {
        flushSync
      });
      let abortController = new AbortController();
      let fetchRequest = createClientSideRequest(
        init.history,
        path,
        abortController.signal,
        submission
      );
      if (isFogOfWar) {
        let discoverResult = await discoverRoutes(
          requestMatches,
          new URL(fetchRequest.url).pathname,
          fetchRequest.signal,
          key
        );
        if (discoverResult.type === "aborted") {
          return;
        } else if (discoverResult.type === "error") {
          setFetcherError(key, routeId, discoverResult.error, { flushSync });
          return;
        } else if (!discoverResult.matches) {
          setFetcherError(
            key,
            routeId,
            getInternalRouterError(404, { pathname: path }),
            { flushSync }
          );
          return;
        } else {
          requestMatches = discoverResult.matches;
        }
      }
      let match = getTargetMatch(requestMatches, path);
      if (!match.route.action && !match.route.lazy) {
        let error = getInternalRouterError(405, {
          method: submission.formMethod,
          pathname: path,
          routeId
        });
        setFetcherError(key, routeId, error, { flushSync });
        return;
      }
      fetchControllers.set(key, abortController);
      let originatingLoadId = incrementingLoadId;
      let fetchMatches = getTargetedDataStrategyMatches(
        mapRouteProperties2,
        manifest,
        fetchRequest,
        path,
        requestMatches,
        match,
        hydrationRouteProperties2,
        scopedContext
      );
      let actionResults = await callDataStrategy(
        fetchRequest,
        path,
        fetchMatches,
        scopedContext,
        key
      );
      let actionResult = actionResults[match.route.id];
      if (!actionResult) {
        for (let match2 of fetchMatches) {
          if (actionResults[match2.route.id]) {
            actionResult = actionResults[match2.route.id];
            break;
          }
        }
      }
      if (fetchRequest.signal.aborted) {
        if (fetchControllers.get(key) === abortController) {
          fetchControllers.delete(key);
        }
        return;
      }
      if (fetchersQueuedForDeletion.has(key)) {
        if (isRedirectResult(actionResult) || isErrorResult(actionResult)) {
          updateFetcherState(key, getDoneFetcher(void 0));
          return;
        }
      } else {
        if (isRedirectResult(actionResult)) {
          fetchControllers.delete(key);
          if (pendingNavigationLoadId > originatingLoadId) {
            updateFetcherState(key, getDoneFetcher(void 0));
            return;
          } else {
            fetchRedirectIds.add(key);
            updateFetcherState(key, getLoadingFetcher(submission));
            return startRedirectNavigation(fetchRequest, actionResult, false, {
              fetcherSubmission: submission,
              preventScrollReset
            });
          }
        }
        if (isErrorResult(actionResult)) {
          setFetcherError(key, routeId, actionResult.error);
          return;
        }
      }
      let nextLocation = state.navigation.location || state.location;
      let revalidationRequest = createClientSideRequest(
        init.history,
        nextLocation,
        abortController.signal
      );
      let routesToUse = dataRoutes.activeRoutes;
      let matches = state.navigation.state !== "idle" ? matchRoutesImpl(
        routesToUse,
        state.navigation.location,
        basename,
        false,
        dataRoutes.branches
      ) : state.matches;
      invariant(matches, "Didn't find any matches after fetcher action");
      let loadId = ++incrementingLoadId;
      fetchReloadIds.set(key, loadId);
      let { dsMatches, revalidatingFetchers } = getMatchesToLoad(
        revalidationRequest,
        scopedContext,
        mapRouteProperties2,
        manifest,
        init.history,
        state,
        matches,
        submission,
        nextLocation,
        hydrationRouteProperties2,
        false,
        isRevalidationRequired,
        cancelledFetcherLoads,
        fetchersQueuedForDeletion,
        fetchLoadMatches,
        fetchRedirectIds,
        routesToUse,
        basename,
        init.patchRoutesOnNavigation != null,
        dataRoutes.branches,
        [match.route.id, actionResult],
        callSiteDefaultShouldRevalidate
      );
      let loadFetcher = getLoadingFetcher(submission, actionResult.data);
      let workingFetchers = new Map(state.fetchers);
      workingFetchers.set(key, loadFetcher);
      revalidatingFetchers.filter((rf) => rf.key !== key).forEach((rf) => {
        let staleKey = rf.key;
        let existingFetcher2 = workingFetchers.get(staleKey);
        let revalidatingFetcher = getLoadingFetcher(
          void 0,
          existingFetcher2 ? existingFetcher2.data : void 0
        );
        workingFetchers.set(staleKey, revalidatingFetcher);
        abortFetcher(staleKey);
        if (rf.controller) {
          fetchControllers.set(staleKey, rf.controller);
        }
      });
      updateState({ fetchers: workingFetchers });
      let abortPendingFetchRevalidations = () => revalidatingFetchers.forEach((rf) => abortFetcher(rf.key));
      abortController.signal.addEventListener(
        "abort",
        abortPendingFetchRevalidations
      );
      let { loaderResults, fetcherResults } = await callLoadersAndMaybeResolveData(
        dsMatches,
        revalidatingFetchers,
        revalidationRequest,
        nextLocation,
        scopedContext
      );
      if (abortController.signal.aborted) {
        return;
      }
      abortController.signal.removeEventListener(
        "abort",
        abortPendingFetchRevalidations
      );
      fetchReloadIds.delete(key);
      fetchControllers.delete(key);
      revalidatingFetchers.forEach((r) => fetchControllers.delete(r.key));
      let fetcherIsMounted = state.fetchers.has(key);
      let getRedirectStateWithDoneFetcher = (s) => {
        if (!fetcherIsMounted) return s;
        let workingFetchers2 = new Map(s.fetchers);
        workingFetchers2.set(key, getDoneFetcher(actionResult.data));
        return { ...s, fetchers: workingFetchers2 };
      };
      let redirect2 = findRedirect(loaderResults);
      if (redirect2) {
        state = getRedirectStateWithDoneFetcher(state);
        return startRedirectNavigation(
          revalidationRequest,
          redirect2.result,
          false,
          { preventScrollReset }
        );
      }
      redirect2 = findRedirect(fetcherResults);
      if (redirect2) {
        fetchRedirectIds.add(redirect2.key);
        state = getRedirectStateWithDoneFetcher(state);
        return startRedirectNavigation(
          revalidationRequest,
          redirect2.result,
          false,
          { preventScrollReset }
        );
      }
      let finalFetchers = new Map(state.fetchers);
      if (fetcherIsMounted) {
        finalFetchers.set(key, getDoneFetcher(actionResult.data));
      }
      let { loaderData, errors } = processLoaderData(
        state,
        matches,
        loaderResults,
        void 0,
        revalidatingFetchers,
        fetcherResults,
        finalFetchers
      );
      abortStaleFetchLoads(loadId, finalFetchers);
      if (state.navigation.state === "loading" && loadId > pendingNavigationLoadId) {
        invariant(pendingAction, "Expected pending action");
        pendingNavigationController && pendingNavigationController.abort();
        completeNavigation(state.navigation.location, {
          matches,
          loaderData,
          errors,
          fetchers: finalFetchers
        });
      } else {
        updateState({
          errors,
          loaderData: mergeLoaderData(
            state.loaderData,
            loaderData,
            matches,
            errors
          ),
          fetchers: finalFetchers
        });
        isRevalidationRequired = false;
      }
    }
    async function handleFetcherLoader(key, routeId, path, matches, scopedContext, isFogOfWar, flushSync, preventScrollReset, submission) {
      let existingFetcher = state.fetchers.get(key);
      updateFetcherState(
        key,
        getLoadingFetcher(
          submission,
          existingFetcher ? existingFetcher.data : void 0
        ),
        { flushSync }
      );
      let abortController = new AbortController();
      let fetchRequest = createClientSideRequest(
        init.history,
        path,
        abortController.signal
      );
      if (isFogOfWar) {
        let discoverResult = await discoverRoutes(
          matches,
          new URL(fetchRequest.url).pathname,
          fetchRequest.signal,
          key
        );
        if (discoverResult.type === "aborted") {
          return;
        } else if (discoverResult.type === "error") {
          setFetcherError(key, routeId, discoverResult.error, { flushSync });
          return;
        } else if (!discoverResult.matches) {
          setFetcherError(
            key,
            routeId,
            getInternalRouterError(404, { pathname: path }),
            { flushSync }
          );
          return;
        } else {
          matches = discoverResult.matches;
        }
      }
      let match = getTargetMatch(matches, path);
      fetchControllers.set(key, abortController);
      let originatingLoadId = incrementingLoadId;
      let dsMatches = getTargetedDataStrategyMatches(
        mapRouteProperties2,
        manifest,
        fetchRequest,
        path,
        matches,
        match,
        hydrationRouteProperties2,
        scopedContext
      );
      let results = await callDataStrategy(
        fetchRequest,
        path,
        dsMatches,
        scopedContext,
        key
      );
      let result = results[match.route.id];
      if (!result) {
        for (let match2 of matches) {
          if (results[match2.route.id]) {
            result = results[match2.route.id];
            break;
          }
        }
      }
      if (fetchControllers.get(key) === abortController) {
        fetchControllers.delete(key);
      }
      if (fetchRequest.signal.aborted) {
        return;
      }
      if (fetchersQueuedForDeletion.has(key)) {
        updateFetcherState(key, getDoneFetcher(void 0));
        return;
      }
      if (isRedirectResult(result)) {
        if (pendingNavigationLoadId > originatingLoadId) {
          updateFetcherState(key, getDoneFetcher(void 0));
          return;
        } else {
          fetchRedirectIds.add(key);
          await startRedirectNavigation(fetchRequest, result, false, {
            preventScrollReset
          });
          return;
        }
      }
      if (isErrorResult(result)) {
        setFetcherError(key, routeId, result.error);
        return;
      }
      updateFetcherState(key, getDoneFetcher(result.data));
    }
    async function startRedirectNavigation(request, redirect2, isNavigation, {
      submission,
      fetcherSubmission,
      preventScrollReset,
      replace: replace2
    } = {}) {
      if (!isNavigation) {
        _optionalChain([pendingPopstateNavigationDfd, "optionalAccess", (_24) => _24.resolve, "call", (_25) => _25()]);
        pendingPopstateNavigationDfd = null;
      }
      if (redirect2.response.headers.has("X-Remix-Revalidate")) {
        isRevalidationRequired = true;
      }
      let location2 = redirect2.response.headers.get("Location");
      invariant(location2, "Expected a Location header on the redirect Response");
      let originalLocation = location2;
      let currentUrl = new URL(request.url);
      location2 = normalizeRedirectLocation(
        location2,
        currentUrl,
        basename,
        init.history
      );
      validateNavigationTarget(
        originalLocation,
        location2,
        currentUrl,
        "allow-explicit"
      );
      let redirectLocation = createLocation(state.location, location2, {
        _isRedirect: true
      });
      if (isBrowser2) {
        let isDocumentReload = false;
        if (redirect2.response.headers.has("X-Remix-Reload-Document")) {
          isDocumentReload = true;
        } else if (isAbsoluteUrl(location2)) {
          const url = createBrowserURLImpl(routerWindow, location2, true);
          isDocumentReload = // Hard reload if it's an absolute URL to a new origin
          url.origin !== routerWindow.location.origin || // Hard reload if it's an absolute URL that does not match our basename
          stripBasename(url.pathname, basename) == null;
        }
        if (isDocumentReload) {
          if (replace2) {
            routerWindow.location.replace(location2);
          } else {
            routerWindow.location.assign(location2);
          }
          return;
        }
      }
      pendingNavigationController = null;
      let redirectNavigationType = replace2 === true || redirect2.response.headers.has("X-Remix-Replace") ? "REPLACE" : "PUSH";
      let { formMethod, formAction, formEncType } = state.navigation;
      if (!submission && !fetcherSubmission && formMethod && formAction && formEncType) {
        submission = getSubmissionFromNavigation(state.navigation);
      }
      let activeSubmission = submission || fetcherSubmission;
      if (redirectPreserveMethodStatusCodes.has(redirect2.response.status) && activeSubmission && isMutationMethod(activeSubmission.formMethod)) {
        await startNavigation(redirectNavigationType, redirectLocation, {
          submission: {
            ...activeSubmission,
            formAction: location2
          },
          // Preserve these flags across redirects
          preventScrollReset: preventScrollReset || pendingPreventScrollReset,
          enableViewTransition: isNavigation ? pendingViewTransitionEnabled : void 0
        });
      } else {
        let overrideNavigation = getLoadingNavigation(
          redirectLocation,
          [],
          redirectNavigationType,
          submission
        );
        await startNavigation(redirectNavigationType, redirectLocation, {
          overrideNavigation,
          // Send fetcher submissions through for shouldRevalidate
          fetcherSubmission,
          // Preserve these flags across redirects
          preventScrollReset: preventScrollReset || pendingPreventScrollReset,
          enableViewTransition: isNavigation ? pendingViewTransitionEnabled : void 0
        });
      }
    }
    async function callDataStrategy(request, path, matches, scopedContext, fetcherKey) {
      let results;
      let dataResults = {};
      try {
        results = await callDataStrategyImpl(
          dataStrategyImpl,
          request,
          path,
          matches,
          fetcherKey,
          scopedContext,
          false
        );
      } catch (e) {
        matches.filter((m) => m.shouldLoad).forEach((m) => {
          dataResults[m.route.id] = {
            type: "error",
            error: e
          };
        });
        return dataResults;
      }
      if (request.signal.aborted) {
        return dataResults;
      }
      if (!isMutationMethod(request.method)) {
        for (let match of matches) {
          if (_optionalChain([results, "access", (_26) => _26[match.route.id], "optionalAccess", (_27) => _27.type]) === "error") {
            break;
          }
          if (!results.hasOwnProperty(match.route.id) && !state.loaderData.hasOwnProperty(match.route.id) && (!state.errors || !state.errors.hasOwnProperty(match.route.id)) && match.shouldCallHandler()) {
            results[match.route.id] = {
              type: "error",
              result: new Error(
                `No result returned from dataStrategy for route ${match.route.id}`
              )
            };
          }
        }
      }
      for (let [routeId, result] of Object.entries(results)) {
        if (isRedirectDataStrategyResult(result)) {
          let response = result.result;
          dataResults[routeId] = {
            type: "redirect",
            response: normalizeRelativeRoutingRedirectResponse(
              response,
              request,
              routeId,
              matches,
              basename
            )
          };
        } else {
          dataResults[routeId] = await convertDataStrategyResultToDataResult(result);
        }
      }
      return dataResults;
    }
    async function callLoadersAndMaybeResolveData(matches, fetchersToLoad, request, location2, scopedContext) {
      let loaderResultsPromise = callDataStrategy(
        request,
        location2,
        matches,
        scopedContext,
        null
      );
      let fetcherResultsPromise = Promise.all(
        fetchersToLoad.map(async (f) => {
          if (f.matches && f.match && f.request && f.controller) {
            let results = await callDataStrategy(
              f.request,
              f.path,
              f.matches,
              scopedContext,
              f.key
            );
            let result = results[f.match.route.id];
            return { [f.key]: result };
          } else {
            return Promise.resolve({
              [f.key]: {
                type: "error",
                error: getInternalRouterError(404, {
                  pathname: f.path
                })
              }
            });
          }
        })
      );
      let loaderResults = await loaderResultsPromise;
      let fetcherResults = (await fetcherResultsPromise).reduce(
        (acc, r) => Object.assign(acc, r),
        {}
      );
      return {
        loaderResults,
        fetcherResults
      };
    }
    function interruptActiveLoads() {
      isRevalidationRequired = true;
      fetchLoadMatches.forEach((_, key) => {
        if (fetchControllers.has(key)) {
          cancelledFetcherLoads.add(key);
        }
        abortFetcher(key);
      });
    }
    function updateFetcherState(key, fetcher, opts = {}) {
      let workingFetchers = new Map(state.fetchers);
      workingFetchers.set(key, fetcher);
      updateState(
        { fetchers: workingFetchers },
        { flushSync: (opts && opts.flushSync) === true }
      );
    }
    function setFetcherError(key, routeId, error, opts = {}) {
      let boundaryMatch = findNearestBoundary(state.matches, routeId);
      let workingFetchers = new Map(state.fetchers);
      deleteFetcher(workingFetchers, key);
      updateState(
        {
          errors: {
            [boundaryMatch.route.id]: error
          },
          fetchers: workingFetchers
        },
        { flushSync: (opts && opts.flushSync) === true }
      );
    }
    function getFetcher(key) {
      activeFetchers.set(key, (activeFetchers.get(key) || 0) + 1);
      if (fetchersQueuedForDeletion.has(key)) {
        fetchersQueuedForDeletion.delete(key);
      }
      return state.fetchers.get(key) || IDLE_FETCHER;
    }
    function resetFetcher(key, opts) {
      abortFetcher(key, _optionalChain([opts, "optionalAccess", (_28) => _28.reason]));
      updateFetcherState(key, getDoneFetcher(null));
    }
    function deleteFetcher(fetchers, key) {
      let fetcher = state.fetchers.get(key);
      if (fetchControllers.has(key) && !(fetcher && fetcher.state === "loading" && fetchReloadIds.has(key))) {
        abortFetcher(key);
      }
      fetchLoadMatches.delete(key);
      fetchReloadIds.delete(key);
      fetchRedirectIds.delete(key);
      fetchersQueuedForDeletion.delete(key);
      cancelledFetcherLoads.delete(key);
      fetchers.delete(key);
    }
    function queueFetcherForDeletion(key) {
      let count = (activeFetchers.get(key) || 0) - 1;
      if (count <= 0) {
        activeFetchers.delete(key);
        fetchersQueuedForDeletion.add(key);
      } else {
        activeFetchers.set(key, count);
      }
      updateState({ fetchers: new Map(state.fetchers) });
    }
    function abortFetcher(key, reason) {
      let controller = fetchControllers.get(key);
      if (controller) {
        controller.abort(reason);
        fetchControllers.delete(key);
      }
    }
    function markFetchersDone(keys, fetchers) {
      for (let key of keys) {
        let fetcher = fetchers.get(key);
        invariant(fetcher, `Expected fetcher: ${key}`);
        let doneFetcher = getDoneFetcher(fetcher.data);
        fetchers.set(key, doneFetcher);
      }
    }
    function markFetchRedirectsDone(fetchers) {
      let doneKeys = [];
      let didUpdateFetchers = false;
      for (let key of fetchRedirectIds) {
        let fetcher = fetchers.get(key);
        invariant(fetcher, `Expected fetcher: ${key}`);
        if (fetcher.state === "loading") {
          fetchRedirectIds.delete(key);
          doneKeys.push(key);
          didUpdateFetchers = true;
        }
      }
      markFetchersDone(doneKeys, fetchers);
      return didUpdateFetchers;
    }
    function abortStaleFetchLoads(landedId, fetchers) {
      let yeetedKeys = [];
      for (let [key, id] of fetchReloadIds) {
        if (id < landedId) {
          let fetcher = fetchers.get(key);
          invariant(fetcher, `Expected fetcher: ${key}`);
          if (fetcher.state === "loading") {
            abortFetcher(key);
            fetchReloadIds.delete(key);
            yeetedKeys.push(key);
          }
        }
      }
      markFetchersDone(yeetedKeys, fetchers);
      return yeetedKeys.length > 0;
    }
    function getBlocker(key, fn) {
      let blocker = state.blockers.get(key) || IDLE_BLOCKER;
      if (blockerFunctions.get(key) !== fn) {
        blockerFunctions.set(key, fn);
      }
      return blocker;
    }
    function deleteBlocker(key) {
      state.blockers.delete(key);
      blockerFunctions.delete(key);
    }
    function updateBlocker(key, newBlocker) {
      let blocker = state.blockers.get(key) || IDLE_BLOCKER;
      invariant(
        blocker.state === "unblocked" && newBlocker.state === "blocked" || blocker.state === "blocked" && newBlocker.state === "blocked" || blocker.state === "blocked" && newBlocker.state === "proceeding" || blocker.state === "blocked" && newBlocker.state === "unblocked" || blocker.state === "proceeding" && newBlocker.state === "unblocked",
        `Invalid blocker state transition: ${blocker.state} -> ${newBlocker.state}`
      );
      let blockers = new Map(state.blockers);
      blockers.set(key, newBlocker);
      updateState({ blockers });
    }
    function shouldBlockNavigation({
      currentLocation,
      nextLocation,
      historyAction
    }) {
      if (blockerFunctions.size === 0) {
        return;
      }
      if (blockerFunctions.size > 1) {
        warning(false, "A router only supports one blocker at a time");
      }
      let entries = Array.from(blockerFunctions.entries());
      let [blockerKey, blockerFunction] = entries[entries.length - 1];
      let blocker = state.blockers.get(blockerKey);
      if (blocker && blocker.state === "proceeding") {
        return;
      }
      if (blockerFunction({ currentLocation, nextLocation, historyAction })) {
        return blockerKey;
      }
    }
    function handleNavigational404(pathname) {
      let error = getInternalRouterError(404, { pathname });
      let routesToUse = dataRoutes.activeRoutes;
      let { matches, route } = getShortCircuitMatches(routesToUse);
      return { notFoundMatches: matches, route, error };
    }
    function enableScrollRestoration(positions, getPosition, getKey) {
      savedScrollPositions = positions;
      getScrollPosition = getPosition;
      getScrollRestorationKey = getKey || null;
      if (!initialScrollRestored && state.navigation === IDLE_NAVIGATION) {
        initialScrollRestored = true;
        let y = getSavedScrollPosition(state.location, state.matches);
        if (y != null) {
          updateState({ restoreScrollPosition: y });
        }
      }
      return () => {
        savedScrollPositions = null;
        getScrollPosition = null;
        getScrollRestorationKey = null;
      };
    }
    function getScrollKey(location2, matches) {
      if (getScrollRestorationKey) {
        let key = getScrollRestorationKey(
          location2,
          matches.map((m) => convertRouteMatchToUiMatch(m, state.loaderData))
        );
        return key || location2.key;
      }
      return location2.key;
    }
    function saveScrollPosition(location2, matches) {
      if (savedScrollPositions && getScrollPosition) {
        let key = getScrollKey(location2, matches);
        savedScrollPositions[key] = getScrollPosition();
      }
    }
    function getSavedScrollPosition(location2, matches) {
      if (savedScrollPositions) {
        let key = getScrollKey(location2, matches);
        let y = savedScrollPositions[key];
        if (typeof y === "number") {
          return y;
        }
      }
      return null;
    }
    function checkFogOfWar(matches, routesToUse, pathname) {
      if (init.patchRoutesOnNavigation) {
        let activeBranches = dataRoutes.branches;
        if (!matches) {
          let fogMatches = matchRoutesImpl(
            routesToUse,
            pathname,
            basename,
            true,
            activeBranches
          );
          return { active: true, matches: fogMatches || [] };
        } else {
          if (Object.keys(matches[0].params).length > 0) {
            let partialMatches = matchRoutesImpl(
              routesToUse,
              pathname,
              basename,
              true,
              activeBranches
            );
            return { active: true, matches: partialMatches };
          }
        }
      }
      return { active: false, matches: null };
    }
    async function discoverRoutes(matches, pathname, signal, fetcherKey) {
      if (!init.patchRoutesOnNavigation) {
        return { type: "success", matches };
      }
      let partialMatches = matches;
      while (true) {
        let localManifest = manifest;
        try {
          await init.patchRoutesOnNavigation({
            signal,
            path: pathname,
            matches: partialMatches,
            fetcherKey,
            patch: (routeId, children) => {
              if (signal.aborted) return;
              patchRoutesImpl(
                routeId,
                children,
                dataRoutes,
                localManifest,
                mapRouteProperties2,
                false
              );
            }
          });
        } catch (e) {
          return { type: "error", error: e, partialMatches };
        }
        if (signal.aborted) {
          return { type: "aborted" };
        }
        let activeBranches = dataRoutes.branches;
        let newMatches = matchRoutesImpl(
          dataRoutes.activeRoutes,
          pathname,
          basename,
          false,
          activeBranches
        );
        let newPartialMatches = null;
        if (newMatches) {
          if (Object.keys(newMatches[0].params).length === 0) {
            return { type: "success", matches: newMatches };
          } else {
            newPartialMatches = matchRoutesImpl(
              dataRoutes.activeRoutes,
              pathname,
              basename,
              true,
              activeBranches
            );
            let matchedDeeper = newPartialMatches && partialMatches.length < newPartialMatches.length && compareMatches(
              partialMatches,
              newPartialMatches.slice(0, partialMatches.length)
            );
            if (!matchedDeeper) {
              return { type: "success", matches: newMatches };
            }
          }
        }
        if (!newPartialMatches) {
          newPartialMatches = matchRoutesImpl(
            dataRoutes.activeRoutes,
            pathname,
            basename,
            true,
            activeBranches
          );
        }
        if (!newPartialMatches || compareMatches(partialMatches, newPartialMatches)) {
          return { type: "success", matches: null };
        }
        partialMatches = newPartialMatches;
      }
    }
    function compareMatches(a, b) {
      return a.length === b.length && a.every((m, i) => m.route.id === b[i].route.id);
    }
    function _internalSetRoutes(newRoutes) {
      manifest = {};
      dataRoutes.setHmrRoutes(
        convertRoutesToDataRoutes(
          newRoutes,
          mapRouteProperties2,
          void 0,
          manifest
        )
      );
    }
    function patchRoutes(routeId, children, unstable_allowElementMutations = false) {
      patchRoutesImpl(
        routeId,
        children,
        dataRoutes,
        manifest,
        mapRouteProperties2,
        unstable_allowElementMutations
      );
      if (!dataRoutes.hasHMRRoutes) {
        updateState({});
      }
    }
    router = {
      get basename() {
        return basename;
      },
      get future() {
        return future;
      },
      get state() {
        return state;
      },
      get routes() {
        return dataRoutes.stableRoutes;
      },
      get branches() {
        return dataRoutes.branches;
      },
      get manifest() {
        return manifest;
      },
      get window() {
        return routerWindow;
      },
      initialize,
      subscribe,
      enableScrollRestoration,
      navigate,
      fetch: fetch2,
      revalidate,
      // Passthrough to history-aware createHref used by useHref so we get proper
      // hash-aware URLs in DOM paths
      createHref: (to) => init.history.createHref(to),
      createURL: (to) => init.history.createURL(to),
      encodeLocation: (to) => init.history.encodeLocation(to),
      getFetcher,
      resetFetcher,
      deleteFetcher: queueFetcherForDeletion,
      dispose,
      getBlocker,
      deleteBlocker,
      patchRoutes,
      _internalFetchControllers: fetchControllers,
      // TODO: Remove setRoutes, it's temporary to avoid dealing with
      // updating the tree while validating the update algorithm.
      _internalSetRoutes,
      _internalSetStateDoNotUseOrYouWillBreakYourApp(newState) {
        updateState(newState);
      }
    };
    if (init.instrumentations) {
      router = instrumentClientSideRouter(
        router,
        init.instrumentations.map((i) => i.router).filter(Boolean)
      );
    }
    return router;
  }
  function createStaticHandler(routes, opts) {
    invariant(
      routes.length > 0,
      "You must provide a non-empty routes array to createStaticHandler"
    );
    let manifest = {};
    let basename = (opts ? opts.basename : null) || "/";
    let _mapRouteProperties = _optionalChain([opts, "optionalAccess", (_29) => _29.mapRouteProperties]) || defaultMapRouteProperties;
    let mapRouteProperties2 = _mapRouteProperties;
    ({
      ..._optionalChain([opts, "optionalAccess", (_30) => _30.future])
    });
    if (_optionalChain([opts, "optionalAccess", (_31) => _31.instrumentations])) {
      let instrumentations = opts.instrumentations;
      mapRouteProperties2 = (route) => {
        return {
          ..._mapRouteProperties(route),
          ...getRouteInstrumentationUpdates(
            instrumentations.map((i) => i.route).filter(Boolean),
            route
          )
        };
      };
    }
    let dataRoutes = convertRoutesToDataRoutes(
      routes,
      mapRouteProperties2,
      void 0,
      manifest
    );
    let routeBranches = flattenAndRankRoutes(dataRoutes);
    async function query(request, {
      requestContext,
      filterMatchesToLoad,
      skipLoaderErrorBubbling,
      skipRevalidation,
      dataStrategy,
      generateMiddlewareResponse,
      normalizePath
    } = {}) {
      let normalizePathImpl = normalizePath || defaultNormalizePath;
      let method = request.method;
      let location2 = createLocation(
        "",
        normalizePathImpl(request),
        null,
        "default"
      );
      let matches = matchRoutesImpl(
        dataRoutes,
        location2,
        basename,
        false,
        routeBranches
      );
      requestContext = requestContext != null ? requestContext : new RouterContextProvider();
      if (!isValidMethod(method) && method !== "HEAD") {
        let error = getInternalRouterError(405, { method });
        let { matches: methodNotAllowedMatches, route } = getShortCircuitMatches(dataRoutes);
        let staticContext = {
          basename,
          location: location2,
          matches: methodNotAllowedMatches,
          loaderData: {},
          actionData: null,
          errors: {
            [route.id]: error
          },
          statusCode: error.status,
          loaderHeaders: {},
          actionHeaders: {}
        };
        return generateMiddlewareResponse ? generateMiddlewareResponse(() => Promise.resolve(staticContext)) : staticContext;
      } else if (!matches) {
        let error = getInternalRouterError(404, { pathname: location2.pathname });
        let { matches: notFoundMatches, route } = getShortCircuitMatches(dataRoutes);
        let staticContext = {
          basename,
          location: location2,
          matches: notFoundMatches,
          loaderData: {},
          actionData: null,
          errors: {
            [route.id]: error
          },
          statusCode: error.status,
          loaderHeaders: {},
          actionHeaders: {}
        };
        return generateMiddlewareResponse ? generateMiddlewareResponse(() => Promise.resolve(staticContext)) : staticContext;
      }
      if (generateMiddlewareResponse) {
        invariant(
          requestContext instanceof RouterContextProvider,
          "When using middleware in `staticHandler.query()`, any provided `requestContext` must be an instance of `RouterContextProvider`"
        );
        try {
          await loadLazyMiddlewareForMatches(
            matches,
            manifest,
            mapRouteProperties2
          );
          let renderedStaticContext;
          let response = await runServerMiddlewarePipeline(
            {
              request,
              url: createDataFunctionUrl(request, location2),
              pattern: getRoutePattern(matches),
              matches,
              params: matches[0].params,
              // If we're calling middleware then it must be enabled so we can cast
              // this to the proper type knowing it's not an `AppLoadContext`
              context: requestContext
            },
            async () => {
              let res = await generateMiddlewareResponse(
                async (revalidationRequest, opts2 = {}) => {
                  let result2 = await queryImpl(
                    revalidationRequest,
                    location2,
                    matches,
                    requestContext,
                    dataStrategy || null,
                    skipLoaderErrorBubbling === true,
                    null,
                    "filterMatchesToLoad" in opts2 ? _nullishCoalesce(opts2.filterMatchesToLoad, () => null) : _nullishCoalesce(filterMatchesToLoad, () => null),
                    skipRevalidation === true
                  );
                  if (isResponse(result2)) {
                    return result2;
                  }
                  renderedStaticContext = { location: location2, basename, ...result2 };
                  return renderedStaticContext;
                }
              );
              return res;
            },
            async (error, routeId) => {
              if (isRedirectResponse(error)) {
                return error;
              }
              if (isResponse(error)) {
                try {
                  error = new ErrorResponseImpl(
                    error.status,
                    error.statusText,
                    await parseResponseBody(error)
                  );
                } catch (e) {
                  error = e;
                }
              }
              if (isDataWithResponseInit(error)) {
                error = dataWithResponseInitToErrorResponse(error);
              }
              if (renderedStaticContext) {
                if (routeId in renderedStaticContext.loaderData) {
                  renderedStaticContext.loaderData[routeId] = void 0;
                }
                let staticContext = getStaticContextFromError(
                  dataRoutes,
                  renderedStaticContext,
                  error,
                  skipLoaderErrorBubbling ? routeId : findNearestBoundary(matches, routeId).route.id
                );
                return generateMiddlewareResponse(
                  () => Promise.resolve(staticContext)
                );
              } else {
                let boundaryRouteId = skipLoaderErrorBubbling ? routeId : findNearestBoundary(
                  matches,
                  _optionalChain([matches, "access", (_32) => _32.find, "call", (_33) => _33(
                    (m) => m.route.id === routeId || m.route.loader
                  ), "optionalAccess", (_34) => _34.route, "access", (_35) => _35.id]) || routeId
                ).route.id;
                let staticContext = {
                  matches,
                  location: location2,
                  basename,
                  loaderData: {},
                  actionData: null,
                  errors: {
                    [boundaryRouteId]: error
                  },
                  statusCode: isRouteErrorResponse(error) ? error.status : 500,
                  actionHeaders: {},
                  loaderHeaders: {}
                };
                return generateMiddlewareResponse(
                  () => Promise.resolve(staticContext)
                );
              }
            }
          );
          invariant(isResponse(response), "Expected a response in query()");
          return response;
        } catch (e) {
          if (isResponse(e)) {
            return e;
          }
          throw e;
        }
      }
      let result = await queryImpl(
        request,
        location2,
        matches,
        requestContext,
        dataStrategy || null,
        skipLoaderErrorBubbling === true,
        null,
        filterMatchesToLoad || null,
        skipRevalidation === true
      );
      if (isResponse(result)) {
        return result;
      }
      return { location: location2, basename, ...result };
    }
    async function queryRoute(request, {
      routeId,
      requestContext,
      dataStrategy,
      generateMiddlewareResponse,
      normalizePath
    } = {}) {
      let normalizePathImpl = normalizePath || defaultNormalizePath;
      let method = request.method;
      let location2 = createLocation(
        "",
        normalizePathImpl(request),
        null,
        "default"
      );
      let matches = matchRoutesImpl(
        dataRoutes,
        location2,
        basename,
        false,
        routeBranches
      );
      requestContext = requestContext != null ? requestContext : new RouterContextProvider();
      if (!isValidMethod(method) && method !== "HEAD" && method !== "OPTIONS") {
        throw getInternalRouterError(405, { method });
      } else if (!matches) {
        throw getInternalRouterError(404, { pathname: location2.pathname });
      }
      let match = routeId ? matches.find((m) => m.route.id === routeId) : getTargetMatch(matches, location2);
      if (routeId && !match) {
        throw getInternalRouterError(403, {
          pathname: location2.pathname,
          routeId
        });
      } else if (!match) {
        throw getInternalRouterError(404, { pathname: location2.pathname });
      }
      if (generateMiddlewareResponse) {
        invariant(
          requestContext instanceof RouterContextProvider,
          "When using middleware in `staticHandler.queryRoute()`, any provided `requestContext` must be an instance of `RouterContextProvider`"
        );
        await loadLazyMiddlewareForMatches(matches, manifest, mapRouteProperties2);
        let response = await runServerMiddlewarePipeline(
          {
            request,
            url: createDataFunctionUrl(request, location2),
            pattern: getRoutePattern(matches),
            matches,
            params: matches[0].params,
            // If we're calling middleware then it must be enabled so we can cast
            // this to the proper type knowing it's not an `AppLoadContext`
            context: requestContext
          },
          async () => {
            let res = await generateMiddlewareResponse(
              async (innerRequest) => {
                let result2 = await queryImpl(
                  innerRequest,
                  location2,
                  matches,
                  requestContext,
                  dataStrategy || null,
                  false,
                  match,
                  null,
                  false
                );
                let processed = handleQueryResult(result2);
                return isResponse(processed) ? processed : typeof processed === "string" ? new Response(processed) : Response.json(processed);
              }
            );
            return res;
          },
          (error) => {
            if (isDataWithResponseInit(error)) {
              return Promise.resolve(dataWithResponseInitToResponse(error));
            }
            if (isResponse(error)) {
              return Promise.resolve(error);
            }
            throw error;
          }
        );
        return response;
      }
      let result = await queryImpl(
        request,
        location2,
        matches,
        requestContext,
        dataStrategy || null,
        false,
        match,
        null,
        false
      );
      return handleQueryResult(result);
      function handleQueryResult(result2) {
        if (isResponse(result2)) {
          return result2;
        }
        let error = result2.errors ? Object.values(result2.errors)[0] : void 0;
        if (error !== void 0) {
          throw error;
        }
        if (result2.actionData) {
          return Object.values(result2.actionData)[0];
        }
        if (result2.loaderData) {
          return Object.values(result2.loaderData)[0];
        }
        return void 0;
      }
    }
    async function queryImpl(request, location2, matches, requestContext, dataStrategy, skipLoaderErrorBubbling, routeMatch, filterMatchesToLoad, skipRevalidation) {
      invariant(
        request.signal,
        "query()/queryRoute() requests must contain an AbortController signal"
      );
      try {
        if (isMutationMethod(request.method)) {
          let result2 = await submit(
            request,
            location2,
            matches,
            routeMatch || getTargetMatch(matches, location2),
            requestContext,
            dataStrategy,
            skipLoaderErrorBubbling,
            routeMatch != null,
            filterMatchesToLoad,
            skipRevalidation
          );
          return result2;
        }
        let result = await loadRouteData(
          request,
          location2,
          matches,
          requestContext,
          dataStrategy,
          skipLoaderErrorBubbling,
          routeMatch,
          filterMatchesToLoad
        );
        return isResponse(result) ? result : {
          ...result,
          actionData: null,
          actionHeaders: {}
        };
      } catch (e) {
        if (isDataStrategyResult(e) && isResponse(e.result)) {
          if (e.type === "error") {
            throw e.result;
          }
          return e.result;
        }
        if (isRedirectResponse(e)) {
          return e;
        }
        throw e;
      }
    }
    async function submit(request, location2, matches, actionMatch, requestContext, dataStrategy, skipLoaderErrorBubbling, isRouteRequest, filterMatchesToLoad, skipRevalidation) {
      let result;
      if (!actionMatch.route.action && !actionMatch.route.lazy) {
        let error = getInternalRouterError(405, {
          method: request.method,
          pathname: new URL(request.url).pathname,
          routeId: actionMatch.route.id
        });
        if (isRouteRequest) {
          throw error;
        }
        result = {
          type: "error",
          error
        };
      } else {
        let dsMatches = getTargetedDataStrategyMatches(
          mapRouteProperties2,
          manifest,
          request,
          location2,
          matches,
          actionMatch,
          [],
          requestContext
        );
        let results = await callDataStrategy(
          request,
          location2,
          dsMatches,
          isRouteRequest,
          requestContext,
          dataStrategy
        );
        result = results[actionMatch.route.id];
        if (request.signal.aborted) {
          throwStaticHandlerAbortedError(request, isRouteRequest);
        }
      }
      if (isRedirectResult(result)) {
        throw new Response(null, {
          status: result.response.status,
          headers: {
            Location: result.response.headers.get("Location")
          }
        });
      }
      if (isRouteRequest) {
        if (isErrorResult(result)) {
          throw result.error;
        }
        return {
          matches: [actionMatch],
          loaderData: {},
          actionData: { [actionMatch.route.id]: result.data },
          errors: null,
          // Note: statusCode + headers are unused here since queryRoute will
          // return the raw Response or value
          statusCode: 200,
          loaderHeaders: {},
          actionHeaders: {}
        };
      }
      if (skipRevalidation) {
        if (isErrorResult(result)) {
          let boundaryMatch = skipLoaderErrorBubbling ? actionMatch : findNearestBoundary(matches, actionMatch.route.id);
          return {
            statusCode: isRouteErrorResponse(result.error) ? result.error.status : result.statusCode != null ? result.statusCode : 500,
            actionData: null,
            actionHeaders: {
              ...result.headers ? { [actionMatch.route.id]: result.headers } : {}
            },
            matches,
            loaderData: {},
            errors: {
              [boundaryMatch.route.id]: result.error
            },
            loaderHeaders: {}
          };
        } else {
          return {
            actionData: {
              [actionMatch.route.id]: result.data
            },
            actionHeaders: result.headers ? { [actionMatch.route.id]: result.headers } : {},
            matches,
            loaderData: {},
            errors: null,
            statusCode: result.statusCode || 200,
            loaderHeaders: {}
          };
        }
      }
      let loaderRequest = new Request(request.url, {
        headers: request.headers,
        redirect: request.redirect,
        signal: request.signal
      });
      if (isErrorResult(result)) {
        let boundaryMatch = skipLoaderErrorBubbling ? actionMatch : findNearestBoundary(matches, actionMatch.route.id);
        let handlerContext2 = await loadRouteData(
          loaderRequest,
          location2,
          matches,
          requestContext,
          dataStrategy,
          skipLoaderErrorBubbling,
          null,
          filterMatchesToLoad,
          [boundaryMatch.route.id, result]
        );
        return {
          ...handlerContext2,
          statusCode: isRouteErrorResponse(result.error) ? result.error.status : result.statusCode != null ? result.statusCode : 500,
          actionData: null,
          actionHeaders: {
            ...result.headers ? { [actionMatch.route.id]: result.headers } : {}
          }
        };
      }
      let handlerContext = await loadRouteData(
        loaderRequest,
        location2,
        matches,
        requestContext,
        dataStrategy,
        skipLoaderErrorBubbling,
        null,
        filterMatchesToLoad
      );
      return {
        ...handlerContext,
        actionData: {
          [actionMatch.route.id]: result.data
        },
        // action status codes take precedence over loader status codes
        ...result.statusCode ? { statusCode: result.statusCode } : {},
        actionHeaders: result.headers ? { [actionMatch.route.id]: result.headers } : {}
      };
    }
    async function loadRouteData(request, location2, matches, requestContext, dataStrategy, skipLoaderErrorBubbling, routeMatch, filterMatchesToLoad, pendingActionResult) {
      let isRouteRequest = routeMatch != null;
      if (isRouteRequest && !_optionalChain([routeMatch, "optionalAccess", (_36) => _36.route, "access", (_37) => _37.loader]) && !_optionalChain([routeMatch, "optionalAccess", (_38) => _38.route, "access", (_39) => _39.lazy])) {
        throw getInternalRouterError(400, {
          method: request.method,
          pathname: new URL(request.url).pathname,
          routeId: _optionalChain([routeMatch, "optionalAccess", (_40) => _40.route, "access", (_41) => _41.id])
        });
      }
      let dsMatches;
      if (routeMatch) {
        dsMatches = getTargetedDataStrategyMatches(
          mapRouteProperties2,
          manifest,
          request,
          location2,
          matches,
          routeMatch,
          [],
          requestContext
        );
      } else {
        let maxIdx = pendingActionResult && isErrorResult(pendingActionResult[1]) ? (
          // Up to but not including the boundary
          matches.findIndex((m) => m.route.id === pendingActionResult[0]) - 1
        ) : void 0;
        let pattern = getRoutePattern(matches);
        dsMatches = matches.map((match, index) => {
          if (maxIdx != null && index > maxIdx) {
            return getDataStrategyMatch(
              mapRouteProperties2,
              manifest,
              request,
              location2,
              pattern,
              match,
              [],
              requestContext,
              false
            );
          }
          return getDataStrategyMatch(
            mapRouteProperties2,
            manifest,
            request,
            location2,
            pattern,
            match,
            [],
            requestContext,
            (match.route.loader || match.route.lazy) != null && (!filterMatchesToLoad || filterMatchesToLoad(match))
          );
        });
      }
      if (!dataStrategy && !dsMatches.some((m) => m.shouldLoad)) {
        return {
          matches,
          loaderData: {},
          errors: pendingActionResult && isErrorResult(pendingActionResult[1]) ? {
            [pendingActionResult[0]]: pendingActionResult[1].error
          } : null,
          statusCode: 200,
          loaderHeaders: {}
        };
      }
      let results = await callDataStrategy(
        request,
        location2,
        dsMatches,
        isRouteRequest,
        requestContext,
        dataStrategy
      );
      if (request.signal.aborted) {
        throwStaticHandlerAbortedError(request, isRouteRequest);
      }
      let handlerContext = processRouteLoaderData(
        matches,
        results,
        pendingActionResult,
        true,
        skipLoaderErrorBubbling
      );
      return {
        ...handlerContext,
        matches
      };
    }
    async function callDataStrategy(request, location2, matches, isRouteRequest, requestContext, dataStrategy) {
      let results = await callDataStrategyImpl(
        dataStrategy || defaultDataStrategy,
        request,
        location2,
        matches,
        null,
        requestContext,
        true
      );
      let dataResults = {};
      await Promise.all(
        matches.map(async (match) => {
          if (!(match.route.id in results)) {
            return;
          }
          let result = results[match.route.id];
          if (isRedirectDataStrategyResult(result)) {
            let response = result.result;
            throw normalizeRelativeRoutingRedirectResponse(
              response,
              request,
              match.route.id,
              matches,
              basename
            );
          }
          if (isRouteRequest) {
            if (isResponse(result.result)) {
              throw result;
            } else if (isDataWithResponseInit(result.result)) {
              throw dataWithResponseInitToResponse(result.result);
            }
          }
          dataResults[match.route.id] = await convertDataStrategyResultToDataResult(result);
        })
      );
      return dataResults;
    }
    return {
      dataRoutes,
      _internalRouteBranches: routeBranches,
      query,
      queryRoute
    };
  }
  function getStaticContextFromError(routes, handlerContext, error, boundaryId) {
    let errorBoundaryId = boundaryId || handlerContext._deepestRenderedBoundaryId || routes[0].id;
    return {
      ...handlerContext,
      statusCode: isRouteErrorResponse(error) ? error.status : 500,
      errors: {
        [errorBoundaryId]: error
      }
    };
  }
  function throwStaticHandlerAbortedError(request, isRouteRequest) {
    if (request.signal.reason !== void 0) {
      throw request.signal.reason;
    }
    let method = isRouteRequest ? "queryRoute" : "query";
    throw new Error(
      `${method}() call aborted without an \`AbortSignal.reason\`: ${request.method} ${request.url}`
    );
  }
  function isSubmissionNavigation(opts) {
    return opts != null && ("formData" in opts && opts.formData != null || "body" in opts && opts.body !== void 0);
  }
  function defaultNormalizePath(request) {
    let url = new URL(request.url);
    return {
      pathname: url.pathname,
      search: url.search,
      hash: url.hash
    };
  }
  function normalizeTo(location2, matches, basename, to, fromRouteId, relative) {
    let contextualMatches;
    let activeRouteMatch;
    if (fromRouteId) {
      contextualMatches = [];
      for (let match of matches) {
        contextualMatches.push(match);
        if (match.route.id === fromRouteId) {
          activeRouteMatch = match;
          break;
        }
      }
    } else {
      contextualMatches = matches;
      activeRouteMatch = matches[matches.length - 1];
    }
    let path = resolveTo(
      to ? to : ".",
      getResolveToMatches(contextualMatches),
      stripBasename(location2.pathname, basename) || location2.pathname,
      relative === "path"
    );
    if (to == null) {
      path.search = location2.search;
      path.hash = location2.hash;
    }
    if ((to == null || to === "" || to === ".") && activeRouteMatch) {
      let nakedIndex = hasNakedIndexQuery(path.search);
      if (activeRouteMatch.route.index && !nakedIndex) {
        path.search = path.search ? path.search.replace(/^\?/, "?index&") : "?index";
      } else if (!activeRouteMatch.route.index && nakedIndex) {
        let params = new URLSearchParams(path.search);
        let indexValues = params.getAll("index");
        params.delete("index");
        indexValues.filter((v) => v).forEach((v) => params.append("index", v));
        let qs = params.toString();
        path.search = qs ? `?${qs}` : "";
      }
    }
    if (basename !== "/") {
      path.pathname = prependBasename({ basename, pathname: path.pathname });
    }
    return createPath(path);
  }
  function normalizeNavigateOptions(isFetcher, path, opts) {
    if (!opts || !isSubmissionNavigation(opts)) {
      return { path };
    }
    if (opts.formMethod && !isValidMethod(opts.formMethod)) {
      return {
        path,
        error: getInternalRouterError(405, { method: opts.formMethod })
      };
    }
    let getInvalidBodyError = () => ({
      path,
      error: getInternalRouterError(400, { type: "invalid-body" })
    });
    let rawFormMethod = opts.formMethod || "get";
    let formMethod = rawFormMethod.toUpperCase();
    let formAction = stripHashFromPath(path);
    if (opts.body !== void 0) {
      if (opts.formEncType === "text/plain") {
        if (!isMutationMethod(formMethod)) {
          return getInvalidBodyError();
        }
        let text = typeof opts.body === "string" ? opts.body : opts.body instanceof FormData || opts.body instanceof URLSearchParams ? (
          // https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#plain-text-form-data
          Array.from(opts.body.entries()).reduce(
            (acc, [name, value]) => `${acc}${name}=${value}
`,
            ""
          )
        ) : String(opts.body);
        return {
          path,
          submission: {
            formMethod,
            formAction,
            formEncType: opts.formEncType,
            formData: void 0,
            json: void 0,
            text
          }
        };
      } else if (opts.formEncType === "application/json") {
        if (!isMutationMethod(formMethod)) {
          return getInvalidBodyError();
        }
        try {
          let json = typeof opts.body === "string" ? JSON.parse(opts.body) : opts.body;
          return {
            path,
            submission: {
              formMethod,
              formAction,
              formEncType: opts.formEncType,
              formData: void 0,
              json,
              text: void 0
            }
          };
        } catch (e) {
          return getInvalidBodyError();
        }
      }
    }
    invariant(
      typeof FormData === "function",
      "FormData is not available in this environment"
    );
    let searchParams;
    let formData;
    if (opts.formData) {
      searchParams = convertFormDataToSearchParams(opts.formData);
      formData = opts.formData;
    } else if (opts.body instanceof FormData) {
      searchParams = convertFormDataToSearchParams(opts.body);
      formData = opts.body;
    } else if (opts.body instanceof URLSearchParams) {
      searchParams = opts.body;
      formData = convertSearchParamsToFormData(searchParams);
    } else if (opts.body == null) {
      searchParams = new URLSearchParams();
      formData = new FormData();
    } else {
      try {
        searchParams = new URLSearchParams(opts.body);
        formData = convertSearchParamsToFormData(searchParams);
      } catch (e) {
        return getInvalidBodyError();
      }
    }
    let submission = {
      formMethod,
      formAction,
      formEncType: opts && opts.formEncType || "application/x-www-form-urlencoded",
      formData,
      json: void 0,
      text: void 0
    };
    if (isMutationMethod(submission.formMethod)) {
      return { path, submission };
    }
    let parsedPath = parsePath(path);
    if (isFetcher && parsedPath.search && hasNakedIndexQuery(parsedPath.search)) {
      searchParams.append("index", "");
    }
    parsedPath.search = `?${searchParams}`;
    return { path: createPath(parsedPath), submission };
  }
  function getMatchesToLoad(request, scopedContext, mapRouteProperties2, manifest, history, state, matches, submission, location2, lazyRoutePropertiesToSkip, initialHydration, isRevalidationRequired, cancelledFetcherLoads, fetchersQueuedForDeletion, fetchLoadMatches, fetchRedirectIds, routesToUse, basename, hasPatchRoutesOnNavigation, branches, pendingActionResult, callSiteDefaultShouldRevalidate) {
    let actionResult = pendingActionResult ? isErrorResult(pendingActionResult[1]) ? pendingActionResult[1].error : pendingActionResult[1].data : void 0;
    let currentUrl = history.createURL(state.location);
    let nextUrl = history.createURL(location2);
    let maxIdx;
    if (initialHydration && state.errors) {
      let boundaryId = Object.keys(state.errors)[0];
      maxIdx = matches.findIndex((m) => m.route.id === boundaryId);
    } else if (pendingActionResult && isErrorResult(pendingActionResult[1])) {
      let boundaryId = pendingActionResult[0];
      maxIdx = matches.findIndex((m) => m.route.id === boundaryId) - 1;
    }
    let actionStatus = pendingActionResult ? pendingActionResult[1].statusCode : void 0;
    let shouldSkipRevalidation = actionStatus && actionStatus >= 400;
    let baseShouldRevalidateArgs = {
      currentUrl,
      currentParams: _optionalChain([state, "access", (_42) => _42.matches, "access", (_43) => _43[0], "optionalAccess", (_44) => _44.params]) || {},
      nextUrl,
      nextParams: matches[0].params,
      ...submission,
      actionResult,
      actionStatus
    };
    let pattern = getRoutePattern(matches);
    let dsMatches = matches.map((match, index) => {
      let { route } = match;
      let forceShouldLoad = null;
      if (maxIdx != null && index > maxIdx) {
        forceShouldLoad = false;
      } else if (route.lazy) {
        forceShouldLoad = true;
      } else if (!routeHasLoaderOrMiddleware(route)) {
        forceShouldLoad = false;
      } else if (initialHydration) {
        let { shouldLoad: shouldLoad2 } = getRouteHydrationStatus(
          route,
          state.loaderData,
          state.errors
        );
        forceShouldLoad = shouldLoad2;
      } else if (isNewLoader(state.loaderData, state.matches[index], match)) {
        forceShouldLoad = true;
      }
      if (forceShouldLoad !== null) {
        return getDataStrategyMatch(
          mapRouteProperties2,
          manifest,
          request,
          location2,
          pattern,
          match,
          lazyRoutePropertiesToSkip,
          scopedContext,
          forceShouldLoad
        );
      }
      let defaultShouldRevalidate = false;
      if (typeof callSiteDefaultShouldRevalidate === "boolean") {
        defaultShouldRevalidate = callSiteDefaultShouldRevalidate;
      } else if (shouldSkipRevalidation) {
        defaultShouldRevalidate = false;
      } else if (isRevalidationRequired) {
        defaultShouldRevalidate = true;
      } else if (currentUrl.pathname + currentUrl.search === nextUrl.pathname + nextUrl.search) {
        defaultShouldRevalidate = true;
      } else if (currentUrl.search !== nextUrl.search) {
        defaultShouldRevalidate = true;
      } else if (isNewRouteInstance(state.matches[index], match)) {
        defaultShouldRevalidate = true;
      }
      let shouldRevalidateArgs = {
        ...baseShouldRevalidateArgs,
        defaultShouldRevalidate
      };
      let shouldLoad = shouldRevalidateLoader(match, shouldRevalidateArgs);
      return getDataStrategyMatch(
        mapRouteProperties2,
        manifest,
        request,
        location2,
        pattern,
        match,
        lazyRoutePropertiesToSkip,
        scopedContext,
        shouldLoad,
        shouldRevalidateArgs,
        callSiteDefaultShouldRevalidate
      );
    });
    let revalidatingFetchers = [];
    fetchLoadMatches.forEach((f, key) => {
      if (initialHydration || !matches.some((m) => m.route.id === f.routeId) || fetchersQueuedForDeletion.has(key)) {
        return;
      }
      let fetcher = state.fetchers.get(key);
      let isMidInitialLoad = fetcher && fetcher.state !== "idle" && fetcher.data === void 0;
      let fetcherMatches = matchRoutesImpl(
        routesToUse,
        f.path,
        _nullishCoalesce(basename, () => "/"),
        false,
        branches
      );
      if (!fetcherMatches) {
        if (hasPatchRoutesOnNavigation && isMidInitialLoad) {
          return;
        }
        revalidatingFetchers.push({
          key,
          routeId: f.routeId,
          path: f.path,
          matches: null,
          match: null,
          request: null,
          controller: null
        });
        return;
      }
      if (fetchRedirectIds.has(key)) {
        return;
      }
      let fetcherMatch = getTargetMatch(fetcherMatches, f.path);
      let fetchController = new AbortController();
      let fetchRequest = createClientSideRequest(
        history,
        f.path,
        fetchController.signal
      );
      let fetcherDsMatches = null;
      if (cancelledFetcherLoads.has(key)) {
        cancelledFetcherLoads.delete(key);
        fetcherDsMatches = getTargetedDataStrategyMatches(
          mapRouteProperties2,
          manifest,
          fetchRequest,
          f.path,
          fetcherMatches,
          fetcherMatch,
          lazyRoutePropertiesToSkip,
          scopedContext
        );
      } else if (isMidInitialLoad) {
        if (isRevalidationRequired) {
          fetcherDsMatches = getTargetedDataStrategyMatches(
            mapRouteProperties2,
            manifest,
            fetchRequest,
            f.path,
            fetcherMatches,
            fetcherMatch,
            lazyRoutePropertiesToSkip,
            scopedContext
          );
        }
      } else {
        let defaultShouldRevalidate;
        if (typeof callSiteDefaultShouldRevalidate === "boolean") {
          defaultShouldRevalidate = callSiteDefaultShouldRevalidate;
        } else if (shouldSkipRevalidation) {
          defaultShouldRevalidate = false;
        } else {
          defaultShouldRevalidate = isRevalidationRequired;
        }
        let shouldRevalidateArgs = {
          ...baseShouldRevalidateArgs,
          defaultShouldRevalidate
        };
        if (shouldRevalidateLoader(fetcherMatch, shouldRevalidateArgs)) {
          fetcherDsMatches = getTargetedDataStrategyMatches(
            mapRouteProperties2,
            manifest,
            fetchRequest,
            f.path,
            fetcherMatches,
            fetcherMatch,
            lazyRoutePropertiesToSkip,
            scopedContext,
            shouldRevalidateArgs
          );
        }
      }
      if (fetcherDsMatches) {
        revalidatingFetchers.push({
          key,
          routeId: f.routeId,
          path: f.path,
          matches: fetcherDsMatches,
          match: fetcherMatch,
          request: fetchRequest,
          controller: fetchController
        });
      }
    });
    return { dsMatches, revalidatingFetchers };
  }
  function routeHasLoaderOrMiddleware(route) {
    return route.loader != null || route.middleware != null && route.middleware.length > 0;
  }
  function getRouteHydrationStatus(route, loaderData, errors) {
    if (route.lazy) {
      return { shouldLoad: true, renderFallback: true };
    }
    if (!routeHasLoaderOrMiddleware(route)) {
      return { shouldLoad: false, renderFallback: false };
    }
    let hasData = loaderData != null && route.id in loaderData;
    let hasError = errors != null && errors[route.id] !== void 0;
    if (!hasData && hasError) {
      return { shouldLoad: false, renderFallback: false };
    }
    if (typeof route.loader === "function" && route.loader.hydrate === true) {
      return { shouldLoad: true, renderFallback: !hasData };
    }
    let shouldLoad = !hasData && !hasError;
    return { shouldLoad, renderFallback: shouldLoad };
  }
  function isNewLoader(currentLoaderData, currentMatch, match) {
    let isNew = (
      // [a] -> [a, b]
      !currentMatch || // [a, b] -> [a, c]
      match.route.id !== currentMatch.route.id
    );
    let isMissingData = !currentLoaderData.hasOwnProperty(match.route.id);
    return isNew || isMissingData;
  }
  function isNewRouteInstance(currentMatch, match) {
    let currentPath = currentMatch.route.path;
    return (
      // param change for this match, /users/123 -> /users/456
      currentMatch.pathname !== match.pathname || // splat param changed, which is not present in match.path
      // e.g. /files/images/avatar.jpg -> files/finances.xls
      currentPath != null && currentPath.endsWith("*") && currentMatch.params["*"] !== match.params["*"]
    );
  }
  function shouldRevalidateLoader(loaderMatch, arg) {
    if (loaderMatch.route.shouldRevalidate) {
      let routeChoice = loaderMatch.route.shouldRevalidate(arg);
      if (typeof routeChoice === "boolean") {
        return routeChoice;
      }
    }
    return arg.defaultShouldRevalidate;
  }
  function patchRoutesImpl(routeId, children, dataRoutes, manifest, mapRouteProperties2, allowElementMutations) {
    let childrenToPatch;
    if (routeId) {
      let route = manifest[routeId];
      invariant(
        route,
        `No route found to patch children into: routeId = ${routeId}`
      );
      if (!route.children) {
        route.children = [];
      }
      childrenToPatch = route.children;
    } else {
      childrenToPatch = dataRoutes.activeRoutes;
    }
    let uniqueChildren = [];
    let existingChildren = [];
    children.forEach((newRoute) => {
      let existingRoute = childrenToPatch.find(
        (existingRoute2) => isSameRoute(newRoute, existingRoute2)
      );
      if (existingRoute) {
        existingChildren.push({ existingRoute, newRoute });
      } else {
        uniqueChildren.push(newRoute);
      }
    });
    if (uniqueChildren.length > 0) {
      let newRoutes = convertRoutesToDataRoutes(
        uniqueChildren,
        mapRouteProperties2,
        [routeId || "_", "patch", String(_optionalChain([childrenToPatch, "optionalAccess", (_45) => _45.length]) || "0")],
        manifest
      );
      childrenToPatch.push(...newRoutes);
    }
    if (allowElementMutations && existingChildren.length > 0) {
      for (let i = 0; i < existingChildren.length; i++) {
        let { existingRoute, newRoute } = existingChildren[i];
        let existingRouteTyped = existingRoute;
        let [newRouteTyped] = convertRoutesToDataRoutes(
          [newRoute],
          mapRouteProperties2,
          [],
          // Doesn't matter for mutated routes since they already have an id
          {},
          // Don't touch the manifest here since we're updating in place
          true
        );
        Object.assign(existingRouteTyped, {
          element: newRouteTyped.element ? newRouteTyped.element : existingRouteTyped.element,
          errorElement: newRouteTyped.errorElement ? newRouteTyped.errorElement : existingRouteTyped.errorElement,
          hydrateFallbackElement: newRouteTyped.hydrateFallbackElement ? newRouteTyped.hydrateFallbackElement : existingRouteTyped.hydrateFallbackElement
        });
      }
    }
    if (!dataRoutes.hasHMRRoutes) {
      dataRoutes.setRoutes([...dataRoutes.activeRoutes]);
    }
  }
  function isSameRoute(newRoute, existingRoute) {
    if ("id" in newRoute && "id" in existingRoute && newRoute.id === existingRoute.id) {
      return true;
    }
    if (!(newRoute.index === existingRoute.index && newRoute.path === existingRoute.path && newRoute.caseSensitive === existingRoute.caseSensitive)) {
      return false;
    }
    if ((!newRoute.children || newRoute.children.length === 0) && (!existingRoute.children || existingRoute.children.length === 0)) {
      return true;
    }
    return _nullishCoalesce(_optionalChain([newRoute, "access", (_46) => _46.children, "optionalAccess", (_47) => _47.every, "call", (_48) => _48(
      (aChild, i) => _optionalChain([existingRoute, "access", (_49) => _49.children, "optionalAccess", (_50) => _50.some, "call", (_51) => _51((bChild) => isSameRoute(aChild, bChild))])
    )]), () => false);
  }
  var lazyRoutePropertyCache = /* @__PURE__ */ new WeakMap();
  var loadLazyRouteProperty = ({
    key,
    route,
    manifest,
    mapRouteProperties: mapRouteProperties2
  }) => {
    let routeToUpdate = manifest[route.id];
    invariant(routeToUpdate, "No route found in manifest");
    if (!routeToUpdate.lazy || typeof routeToUpdate.lazy !== "object") {
      return;
    }
    let lazyFn = routeToUpdate.lazy[key];
    if (!lazyFn) {
      return;
    }
    let cache = lazyRoutePropertyCache.get(routeToUpdate);
    if (!cache) {
      cache = {};
      lazyRoutePropertyCache.set(routeToUpdate, cache);
    }
    let cachedPromise = cache[key];
    if (cachedPromise) {
      return cachedPromise;
    }
    let propertyPromise = (async () => {
      let isUnsupported = isUnsupportedLazyRouteObjectKey(key);
      let staticRouteValue = routeToUpdate[key];
      let isStaticallyDefined = staticRouteValue !== void 0 && key !== "hasErrorBoundary";
      if (isUnsupported) {
        warning(
          !isUnsupported,
          "Route property " + key + " is not a supported lazy route property. This property will be ignored."
        );
        cache[key] = Promise.resolve();
      } else if (isStaticallyDefined) {
        warning(
          false,
          `Route "${routeToUpdate.id}" has a static property "${key}" defined. The lazy property will be ignored.`
        );
      } else {
        let value = await lazyFn();
        if (value != null) {
          Object.assign(routeToUpdate, { [key]: value });
          Object.assign(routeToUpdate, mapRouteProperties2(routeToUpdate));
        }
      }
      if (typeof routeToUpdate.lazy === "object") {
        routeToUpdate.lazy[key] = void 0;
        if (Object.values(routeToUpdate.lazy).every((value) => value === void 0)) {
          routeToUpdate.lazy = void 0;
        }
      }
    })();
    cache[key] = propertyPromise;
    return propertyPromise;
  };
  var lazyRouteFunctionCache = /* @__PURE__ */ new WeakMap();
  function loadLazyRoute(route, type, manifest, mapRouteProperties2, lazyRoutePropertiesToSkip) {
    let routeToUpdate = manifest[route.id];
    invariant(routeToUpdate, "No route found in manifest");
    if (!route.lazy) {
      return {
        lazyRoutePromise: void 0,
        lazyHandlerPromise: void 0
      };
    }
    if (typeof route.lazy === "function") {
      let cachedPromise = lazyRouteFunctionCache.get(routeToUpdate);
      if (cachedPromise) {
        return {
          lazyRoutePromise: cachedPromise,
          lazyHandlerPromise: cachedPromise
        };
      }
      let lazyRoutePromise2 = (async () => {
        invariant(
          typeof route.lazy === "function",
          "No lazy route function found"
        );
        let lazyRoute = await route.lazy();
        let routeUpdates = {};
        for (let lazyRouteProperty in lazyRoute) {
          let lazyValue = lazyRoute[lazyRouteProperty];
          if (lazyValue === void 0) {
            continue;
          }
          let isUnsupported = isUnsupportedLazyRouteFunctionKey(lazyRouteProperty);
          let staticRouteValue = routeToUpdate[lazyRouteProperty];
          let isStaticallyDefined = staticRouteValue !== void 0 && // This property isn't static since it should always be updated based
          // on the route updates
          lazyRouteProperty !== "hasErrorBoundary";
          if (isUnsupported) {
            warning(
              !isUnsupported,
              "Route property " + lazyRouteProperty + " is not a supported property to be returned from a lazy route function. This property will be ignored."
            );
          } else if (isStaticallyDefined) {
            warning(
              !isStaticallyDefined,
              `Route "${routeToUpdate.id}" has a static property "${lazyRouteProperty}" defined but its lazy function is also returning a value for this property. The lazy route property "${lazyRouteProperty}" will be ignored.`
            );
          } else {
            routeUpdates[lazyRouteProperty] = lazyValue;
          }
        }
        Object.assign(routeToUpdate, routeUpdates);
        Object.assign(routeToUpdate, {
          // To keep things framework agnostic, we use the provided `mapRouteProperties`
          // function to set the framework-aware properties (`element`/`hasErrorBoundary`)
          // since the logic will differ between frameworks.
          ...mapRouteProperties2(routeToUpdate),
          lazy: void 0
        });
      })();
      lazyRouteFunctionCache.set(routeToUpdate, lazyRoutePromise2);
      lazyRoutePromise2.catch(() => {
      });
      return {
        lazyRoutePromise: lazyRoutePromise2,
        lazyHandlerPromise: lazyRoutePromise2
      };
    }
    let lazyKeys = Object.keys(route.lazy);
    let lazyPropertyPromises = [];
    let lazyHandlerPromise = void 0;
    for (let key of lazyKeys) {
      if (lazyRoutePropertiesToSkip && lazyRoutePropertiesToSkip.includes(key)) {
        continue;
      }
      let promise = loadLazyRouteProperty({
        key,
        route,
        manifest,
        mapRouteProperties: mapRouteProperties2
      });
      if (promise) {
        lazyPropertyPromises.push(promise);
        if (key === type) {
          lazyHandlerPromise = promise;
        }
      }
    }
    let lazyRoutePromise = lazyPropertyPromises.length > 0 ? Promise.all(lazyPropertyPromises).then(() => {
    }) : void 0;
    _optionalChain([lazyRoutePromise, "optionalAccess", (_52) => _52.catch, "call", (_53) => _53(() => {
    })]);
    _optionalChain([lazyHandlerPromise, "optionalAccess", (_54) => _54.catch, "call", (_55) => _55(() => {
    })]);
    return {
      lazyRoutePromise,
      lazyHandlerPromise
    };
  }
  function isNonNullable(value) {
    return value !== void 0;
  }
  function loadLazyMiddlewareForMatches(matches, manifest, mapRouteProperties2) {
    let promises = matches.map(({ route }) => {
      if (typeof route.lazy !== "object" || !route.lazy.middleware) {
        return void 0;
      }
      return loadLazyRouteProperty({
        key: "middleware",
        route,
        manifest,
        mapRouteProperties: mapRouteProperties2
      });
    }).filter(isNonNullable);
    return promises.length > 0 ? Promise.all(promises) : void 0;
  }
  async function defaultDataStrategy(args) {
    let matchesToLoad = args.matches.filter((m) => m.shouldLoad);
    let keyedResults = {};
    let results = await Promise.all(matchesToLoad.map((m) => m.resolve()));
    results.forEach((result, i) => {
      keyedResults[matchesToLoad[i].route.id] = result;
    });
    return keyedResults;
  }
  async function defaultDataStrategyWithMiddleware(args) {
    if (!args.matches.some((m) => m.route.middleware)) {
      return defaultDataStrategy(args);
    }
    return runClientMiddlewarePipeline(args, () => defaultDataStrategy(args));
  }
  function runServerMiddlewarePipeline(args, handler, errorHandler) {
    return runMiddlewarePipeline(
      args,
      handler,
      processResult,
      isResponse,
      errorHandler
    );
    function processResult(result) {
      return isDataWithResponseInit(result) ? dataWithResponseInitToResponse(result) : result;
    }
  }
  function runClientMiddlewarePipeline(args, handler) {
    return runMiddlewarePipeline(
      args,
      handler,
      (r) => {
        if (isRedirectResponse(r)) {
          throw r;
        }
        return r;
      },
      isDataStrategyResults,
      errorHandler
    );
    function errorHandler(error, routeId, nextResult) {
      if (nextResult) {
        return Promise.resolve(
          Object.assign(nextResult.value, {
            [routeId]: { type: "error", result: error }
          })
        );
      } else {
        let { matches } = args;
        let maxBoundaryIdx = Math.min(
          // Throwing route
          Math.max(
            matches.findIndex((m) => m.route.id === routeId),
            0
          ),
          // or the shallowest route that needs to load data
          Math.max(
            matches.findIndex((m) => m.shouldCallHandler()),
            0
          )
        );
        let boundaryRouteId = findNearestBoundary(
          matches,
          matches[maxBoundaryIdx].route.id
        ).route.id;
        return Promise.resolve({
          [boundaryRouteId]: { type: "error", result: error }
        });
      }
    }
  }
  async function runMiddlewarePipeline(args, handler, processResult, isResult, errorHandler) {
    let { matches, ...dataFnArgs } = args;
    let tuples = matches.flatMap(
      (m) => m.route.middleware ? m.route.middleware.map((fn) => [m.route.id, fn]) : []
    );
    let result = await callRouteMiddleware(
      dataFnArgs,
      tuples,
      handler,
      processResult,
      isResult,
      errorHandler
    );
    return result;
  }
  async function callRouteMiddleware(args, middlewares, handler, processResult, isResult, errorHandler, idx = 0) {
    let { request } = args;
    if (request.signal.aborted) {
      throw _nullishCoalesce(request.signal.reason, () => new Error(`Request aborted: ${request.method} ${request.url}`));
    }
    let tuple = middlewares[idx];
    if (!tuple) {
      let result = await handler();
      return result;
    }
    let [routeId, middleware] = tuple;
    let nextResult;
    let next = async () => {
      if (nextResult) {
        throw new Error("You may only call `next()` once per middleware");
      }
      try {
        let result = await callRouteMiddleware(
          args,
          middlewares,
          handler,
          processResult,
          isResult,
          errorHandler,
          idx + 1
        );
        nextResult = { value: result };
        return nextResult.value;
      } catch (error) {
        nextResult = { value: await errorHandler(error, routeId, nextResult) };
        return nextResult.value;
      }
    };
    try {
      let value = await middleware(args, next);
      let result = value != null ? processResult(value) : void 0;
      if (isResult(result)) {
        return result;
      } else if (nextResult) {
        return _nullishCoalesce(result, () => nextResult.value);
      } else {
        nextResult = { value: await next() };
        return nextResult.value;
      }
    } catch (error) {
      let response = await errorHandler(error, routeId, nextResult);
      return response;
    }
  }
  function getDataStrategyMatchLazyPromises(mapRouteProperties2, manifest, request, match, lazyRoutePropertiesToSkip) {
    let lazyMiddlewarePromise = loadLazyRouteProperty({
      key: "middleware",
      route: match.route,
      manifest,
      mapRouteProperties: mapRouteProperties2
    });
    let lazyRoutePromises = loadLazyRoute(
      match.route,
      isMutationMethod(request.method) ? "action" : "loader",
      manifest,
      mapRouteProperties2,
      lazyRoutePropertiesToSkip
    );
    return {
      middleware: lazyMiddlewarePromise,
      route: lazyRoutePromises.lazyRoutePromise,
      handler: lazyRoutePromises.lazyHandlerPromise
    };
  }
  function getDataStrategyMatch(mapRouteProperties2, manifest, request, path, pattern, match, lazyRoutePropertiesToSkip, scopedContext, shouldLoad, shouldRevalidateArgs = null, callSiteDefaultShouldRevalidate) {
    let isUsingNewApi = false;
    let _lazyPromises = getDataStrategyMatchLazyPromises(
      mapRouteProperties2,
      manifest,
      request,
      match,
      lazyRoutePropertiesToSkip
    );
    return {
      ...match,
      _lazyPromises,
      shouldLoad,
      shouldRevalidateArgs,
      shouldCallHandler(defaultShouldRevalidate) {
        isUsingNewApi = true;
        if (!shouldRevalidateArgs) {
          return shouldLoad;
        }
        if (typeof callSiteDefaultShouldRevalidate === "boolean") {
          return shouldRevalidateLoader(match, {
            ...shouldRevalidateArgs,
            defaultShouldRevalidate: callSiteDefaultShouldRevalidate
          });
        }
        if (typeof defaultShouldRevalidate === "boolean") {
          return shouldRevalidateLoader(match, {
            ...shouldRevalidateArgs,
            defaultShouldRevalidate
          });
        }
        return shouldRevalidateLoader(match, shouldRevalidateArgs);
      },
      resolve(handlerOverride) {
        let { lazy, loader, middleware } = match.route;
        let callHandler = isUsingNewApi || shouldLoad || handlerOverride && !isMutationMethod(request.method) && (lazy || loader);
        let isMiddlewareOnlyRoute = middleware && middleware.length > 0 && !loader && !lazy;
        if (callHandler && (isMutationMethod(request.method) || !isMiddlewareOnlyRoute)) {
          return callLoaderOrAction({
            request,
            path,
            pattern,
            match,
            lazyHandlerPromise: _optionalChain([_lazyPromises, "optionalAccess", (_56) => _56.handler]),
            lazyRoutePromise: _optionalChain([_lazyPromises, "optionalAccess", (_57) => _57.route]),
            handlerOverride,
            scopedContext
          });
        }
        return Promise.resolve({ type: "data", result: void 0 });
      }
    };
  }
  function getTargetedDataStrategyMatches(mapRouteProperties2, manifest, request, path, matches, targetMatch, lazyRoutePropertiesToSkip, scopedContext, shouldRevalidateArgs = null) {
    return matches.map((match) => {
      if (match.route.id !== targetMatch.route.id) {
        return {
          ...match,
          shouldLoad: false,
          shouldRevalidateArgs,
          shouldCallHandler: () => false,
          _lazyPromises: getDataStrategyMatchLazyPromises(
            mapRouteProperties2,
            manifest,
            request,
            match,
            lazyRoutePropertiesToSkip
          ),
          resolve: () => Promise.resolve({ type: "data", result: void 0 })
        };
      }
      return getDataStrategyMatch(
        mapRouteProperties2,
        manifest,
        request,
        path,
        getRoutePattern(matches),
        match,
        lazyRoutePropertiesToSkip,
        scopedContext,
        true,
        shouldRevalidateArgs
      );
    });
  }
  async function callDataStrategyImpl(dataStrategyImpl, request, path, matches, fetcherKey, scopedContext, isStaticHandler) {
    if (matches.some((m) => _optionalChain([m, "access", (_58) => _58._lazyPromises, "optionalAccess", (_59) => _59.middleware]))) {
      await Promise.all(matches.map((m) => _optionalChain([m, "access", (_60) => _60._lazyPromises, "optionalAccess", (_61) => _61.middleware])));
    }
    let dataStrategyArgs = {
      request,
      url: createDataFunctionUrl(request, path),
      pattern: getRoutePattern(matches),
      params: matches[0].params,
      context: scopedContext,
      matches
    };
    let runClientMiddleware = isStaticHandler ? () => {
      throw new Error(
        "You cannot call `runClientMiddleware()` from a static handler `dataStrategy`. Middleware is run outside of `dataStrategy` during SSR in order to bubble up the Response.  You can enable middleware via the `respond` API in `query`/`queryRoute`"
      );
    } : (cb) => {
      let typedDataStrategyArgs = dataStrategyArgs;
      return runClientMiddlewarePipeline(typedDataStrategyArgs, () => {
        return cb({
          ...typedDataStrategyArgs,
          fetcherKey,
          runClientMiddleware: () => {
            throw new Error(
              "Cannot call `runClientMiddleware()` from within an `runClientMiddleware` handler"
            );
          }
        });
      });
    };
    let results = await dataStrategyImpl({
      ...dataStrategyArgs,
      fetcherKey,
      runClientMiddleware
    });
    try {
      await Promise.all(
        matches.flatMap((m) => [
          _optionalChain([m, "access", (_62) => _62._lazyPromises, "optionalAccess", (_63) => _63.handler]),
          _optionalChain([m, "access", (_64) => _64._lazyPromises, "optionalAccess", (_65) => _65.route])
        ])
      );
    } catch (e) {
    }
    return results;
  }
  async function callLoaderOrAction({
    request,
    path,
    pattern,
    match,
    lazyHandlerPromise,
    lazyRoutePromise,
    handlerOverride,
    scopedContext
  }) {
    let result;
    let onReject;
    let isAction = isMutationMethod(request.method);
    let type = isAction ? "action" : "loader";
    let runHandler = (handler) => {
      let reject;
      let abortPromise = new Promise((_, r) => reject = r);
      onReject = () => reject();
      request.signal.addEventListener("abort", onReject);
      let actualHandler = (ctx) => {
        if (typeof handler !== "function") {
          return Promise.reject(
            new Error(
              `You cannot call the handler for a route which defines a boolean "${type}" [routeId: ${match.route.id}]`
            )
          );
        }
        return handler(
          {
            request,
            url: createDataFunctionUrl(request, path),
            pattern,
            params: match.params,
            context: scopedContext
          },
          ...ctx !== void 0 ? [ctx] : []
        );
      };
      let handlerPromise = (async () => {
        try {
          let val = await (handlerOverride ? handlerOverride((ctx) => actualHandler(ctx)) : actualHandler());
          return { type: "data", result: val };
        } catch (e) {
          return { type: "error", result: e };
        }
      })();
      return Promise.race([handlerPromise, abortPromise]);
    };
    try {
      let handler = isAction ? match.route.action : match.route.loader;
      if (lazyHandlerPromise || lazyRoutePromise) {
        if (handler) {
          let handlerError;
          let [value] = await Promise.all([
            // If the handler throws, don't let it immediately bubble out,
            // since we need to let the lazy() execution finish so we know if this
            // route has a boundary that can handle the error
            runHandler(handler).catch((e) => {
              handlerError = e;
            }),
            // Ensure all lazy route promises are resolved before continuing
            lazyHandlerPromise,
            lazyRoutePromise
          ]);
          if (handlerError !== void 0) {
            throw handlerError;
          }
          result = value;
        } else {
          await lazyHandlerPromise;
          let handler2 = isAction ? match.route.action : match.route.loader;
          if (handler2) {
            [result] = await Promise.all([runHandler(handler2), lazyRoutePromise]);
          } else if (type === "action") {
            let url = new URL(request.url);
            let pathname = url.pathname + url.search;
            throw getInternalRouterError(405, {
              method: request.method,
              pathname,
              routeId: match.route.id
            });
          } else {
            return { type: "data", result: void 0 };
          }
        }
      } else if (!handler) {
        let url = new URL(request.url);
        let pathname = url.pathname + url.search;
        throw getInternalRouterError(404, {
          pathname
        });
      } else {
        result = await runHandler(handler);
      }
    } catch (e) {
      return { type: "error", result: e };
    } finally {
      if (onReject) {
        request.signal.removeEventListener("abort", onReject);
      }
    }
    return result;
  }
  async function parseResponseBody(response) {
    let contentType = response.headers.get("Content-Type");
    if (contentType && /\bapplication\/json\b/.test(contentType)) {
      return response.body == null ? null : response.json();
    }
    return response.text();
  }
  async function convertDataStrategyResultToDataResult(dataStrategyResult) {
    let { result, type } = dataStrategyResult;
    if (isResponse(result)) {
      let data2;
      try {
        data2 = await parseResponseBody(result);
      } catch (e) {
        return { type: "error", error: e };
      }
      if (type === "error") {
        return {
          type: "error",
          error: new ErrorResponseImpl(result.status, result.statusText, data2),
          statusCode: result.status,
          headers: result.headers
        };
      }
      return {
        type: "data",
        data: data2,
        statusCode: result.status,
        headers: result.headers
      };
    }
    if (type === "error") {
      if (isDataWithResponseInit(result)) {
        if (result.data instanceof Error) {
          return {
            type: "error",
            error: result.data,
            statusCode: _optionalChain([result, "access", (_66) => _66.init, "optionalAccess", (_67) => _67.status]),
            headers: _optionalChain([result, "access", (_68) => _68.init, "optionalAccess", (_69) => _69.headers]) ? new Headers(result.init.headers) : void 0
          };
        }
        return {
          type: "error",
          error: dataWithResponseInitToErrorResponse(result),
          statusCode: isRouteErrorResponse(result) ? result.status : void 0,
          headers: _optionalChain([result, "access", (_70) => _70.init, "optionalAccess", (_71) => _71.headers]) ? new Headers(result.init.headers) : void 0
        };
      }
      return {
        type: "error",
        error: result,
        statusCode: isRouteErrorResponse(result) ? result.status : void 0
      };
    }
    if (isDataWithResponseInit(result)) {
      return {
        type: "data",
        data: result.data,
        statusCode: _optionalChain([result, "access", (_72) => _72.init, "optionalAccess", (_73) => _73.status]),
        headers: _optionalChain([result, "access", (_74) => _74.init, "optionalAccess", (_75) => _75.headers]) ? new Headers(result.init.headers) : void 0
      };
    }
    return { type: "data", data: result };
  }
  function normalizeRelativeRoutingRedirectResponse(response, request, routeId, matches, basename) {
    let location2 = response.headers.get("Location");
    invariant(
      location2,
      "Redirects returned/thrown from loaders/actions must have a Location header"
    );
    if (!isAbsoluteUrl(location2)) {
      let trimmedMatches = matches.slice(
        0,
        matches.findIndex((m) => m.route.id === routeId) + 1
      );
      location2 = normalizeTo(
        new URL(request.url),
        trimmedMatches,
        basename,
        location2
      );
      response.headers.set("Location", location2);
    }
    return response;
  }
  var invalidProtocols = [
    "about:",
    "blob:",
    "chrome:",
    "chrome-untrusted:",
    "content:",
    "data:",
    "devtools:",
    "file:",
    "filesystem:",
    // eslint-disable-next-line no-script-url
    "javascript:"
  ];
  function hasInvalidProtocol(location2) {
    try {
      return invalidProtocols.includes(new URL(location2).protocol);
    } catch (e4) {
      return false;
    }
  }
  function normalizeRedirectLocation(location2, currentUrl, basename, historyInstance) {
    if (isAbsoluteUrl(location2)) {
      let normalizedLocation = location2;
      let url = PROTOCOL_RELATIVE_URL_REGEX.test(normalizedLocation) ? new URL(
        normalizeProtocolRelativeUrl(normalizedLocation, currentUrl.protocol)
      ) : new URL(normalizedLocation);
      if (hasInvalidProtocol(url.toString())) {
        throw new Error("Invalid redirect location");
      }
      let isSameBasename = stripBasename(url.pathname, basename) != null;
      if (url.origin === currentUrl.origin && isSameBasename) {
        return removeDoubleSlashes(url.pathname) + url.search + url.hash;
      }
    }
    try {
      let url = historyInstance.createURL(location2);
      if (hasInvalidProtocol(url.toString())) {
        throw new Error("Invalid redirect location");
      }
    } catch (e) {
    }
    return location2;
  }
  function createClientSideRequest(history, location2, signal, submission) {
    let url = history.createURL(stripHashFromPath(location2)).toString();
    let init = { signal };
    if (submission && isMutationMethod(submission.formMethod)) {
      let { formMethod, formEncType } = submission;
      init.method = formMethod.toUpperCase();
      if (formEncType === "application/json") {
        init.headers = new Headers({ "Content-Type": formEncType });
        init.body = JSON.stringify(submission.json);
      } else if (formEncType === "text/plain") {
        init.body = submission.text;
      } else if (formEncType === "application/x-www-form-urlencoded" && submission.formData) {
        init.body = convertFormDataToSearchParams(submission.formData);
      } else {
        init.body = submission.formData;
      }
    }
    return new Request(url, init);
  }
  function createDataFunctionUrl(request, path) {
    let url = new URL(request.url);
    let parsed = typeof path === "string" ? parsePath(path) : path;
    url.pathname = parsed.pathname || "/";
    if (parsed.search) {
      let searchParams = new URLSearchParams(parsed.search);
      let indexValues = searchParams.getAll("index");
      searchParams.delete("index");
      for (let value of indexValues.filter(Boolean)) {
        searchParams.append("index", value);
      }
      url.search = searchParams.size ? `?${searchParams.toString()}` : "";
    } else {
      url.search = "";
    }
    url.hash = parsed.hash || "";
    return url;
  }
  function convertFormDataToSearchParams(formData) {
    let searchParams = new URLSearchParams();
    for (let [key, value] of formData.entries()) {
      searchParams.append(key, typeof value === "string" ? value : value.name);
    }
    return searchParams;
  }
  function convertSearchParamsToFormData(searchParams) {
    let formData = new FormData();
    for (let [key, value] of searchParams.entries()) {
      formData.append(key, value);
    }
    return formData;
  }
  function processRouteLoaderData(matches, results, pendingActionResult, isStaticHandler = false, skipLoaderErrorBubbling = false) {
    let loaderData = {};
    let errors = null;
    let statusCode;
    let foundError = false;
    let loaderHeaders = {};
    let pendingError = pendingActionResult && isErrorResult(pendingActionResult[1]) ? pendingActionResult[1].error : void 0;
    matches.forEach((match) => {
      if (!(match.route.id in results)) {
        return;
      }
      let id = match.route.id;
      let result = results[id];
      invariant(
        !isRedirectResult(result),
        "Cannot handle redirect results in processLoaderData"
      );
      if (isErrorResult(result)) {
        let error = result.error;
        if (pendingError !== void 0) {
          error = pendingError;
          pendingError = void 0;
        }
        errors = errors || {};
        if (skipLoaderErrorBubbling) {
          errors[id] = error;
        } else {
          let boundaryMatch = findNearestBoundary(matches, id);
          if (errors[boundaryMatch.route.id] == null) {
            errors[boundaryMatch.route.id] = error;
          }
        }
        if (!isStaticHandler) {
          loaderData[id] = ResetLoaderDataSymbol;
        }
        if (!foundError) {
          foundError = true;
          statusCode = isRouteErrorResponse(result.error) ? result.error.status : 500;
        }
        if (result.headers) {
          loaderHeaders[id] = result.headers;
        }
      } else {
        loaderData[id] = result.data;
        if (result.statusCode && result.statusCode !== 200 && !foundError) {
          statusCode = result.statusCode;
        }
        if (result.headers) {
          loaderHeaders[id] = result.headers;
        }
      }
    });
    if (pendingError !== void 0 && pendingActionResult) {
      errors = { [pendingActionResult[0]]: pendingError };
      if (pendingActionResult[2]) {
        loaderData[pendingActionResult[2]] = void 0;
      }
    }
    return {
      loaderData,
      errors,
      statusCode: statusCode || 200,
      loaderHeaders
    };
  }
  function processLoaderData(state, matches, results, pendingActionResult, revalidatingFetchers, fetcherResults, workingFetchers) {
    let { loaderData, errors } = processRouteLoaderData(
      matches,
      results,
      pendingActionResult
    );
    revalidatingFetchers.filter((f) => !f.matches || f.matches.some((m) => m.shouldLoad)).forEach((rf) => {
      let { key, match, controller } = rf;
      if (controller && controller.signal.aborted) {
        return;
      }
      let result = fetcherResults[key];
      invariant(result, "Did not find corresponding fetcher result");
      if (isErrorResult(result)) {
        let boundaryMatch = findNearestBoundary(state.matches, _optionalChain([match, "optionalAccess", (_76) => _76.route, "access", (_77) => _77.id]));
        if (!(errors && errors[boundaryMatch.route.id])) {
          errors = {
            ...errors,
            [boundaryMatch.route.id]: result.error
          };
        }
        workingFetchers.delete(key);
      } else if (isRedirectResult(result)) {
        invariant(false, "Unhandled fetcher revalidation redirect");
      } else {
        let doneFetcher = getDoneFetcher(result.data);
        workingFetchers.set(key, doneFetcher);
      }
    });
    return { loaderData, errors };
  }
  function mergeLoaderData(loaderData, newLoaderData, matches, errors) {
    let mergedLoaderData = Object.entries(newLoaderData).filter(([, v]) => v !== ResetLoaderDataSymbol).reduce((merged, [k, v]) => {
      merged[k] = v;
      return merged;
    }, {});
    for (let match of matches) {
      let id = match.route.id;
      if (!newLoaderData.hasOwnProperty(id) && loaderData.hasOwnProperty(id) && match.route.loader) {
        mergedLoaderData[id] = loaderData[id];
      }
      if (errors && errors.hasOwnProperty(id)) {
        break;
      }
    }
    return mergedLoaderData;
  }
  function getActionDataForCommit(pendingActionResult) {
    if (!pendingActionResult) {
      return {};
    }
    return isErrorResult(pendingActionResult[1]) ? {
      // Clear out prior actionData on errors
      actionData: {}
    } : {
      actionData: {
        [pendingActionResult[0]]: pendingActionResult[1].data
      }
    };
  }
  function findNearestBoundary(matches, routeId) {
    let eligibleMatches = routeId ? matches.slice(0, matches.findIndex((m) => m.route.id === routeId) + 1) : [...matches];
    return eligibleMatches.reverse().find((m) => m.route.hasErrorBoundary === true) || matches[0];
  }
  function getShortCircuitMatches(routes) {
    let route = routes.length === 1 ? routes[0] : routes.find((r) => r.index || !r.path || r.path === "/") || {
      id: `__shim-error-route__`
    };
    return {
      matches: [
        {
          params: {},
          pathname: "",
          pathnameBase: "",
          route
        }
      ],
      route
    };
  }
  function getInternalRouterError(status, {
    pathname,
    routeId,
    method,
    type,
    message
  } = {}) {
    let statusText = "Unknown Server Error";
    let errorMessage = "Unknown @remix-run/router error";
    if (status === 400) {
      statusText = "Bad Request";
      if (method && pathname && routeId) {
        errorMessage = `You made a ${method} request to "${pathname}" but did not provide a \`loader\` for route "${routeId}", so there is no way to handle the request.`;
      } else if (type === "invalid-body") {
        errorMessage = "Unable to encode submission body";
      }
    } else if (status === 403) {
      statusText = "Forbidden";
      errorMessage = `Route "${routeId}" does not match URL "${pathname}"`;
    } else if (status === 404) {
      statusText = "Not Found";
      errorMessage = `No route matches URL "${pathname}"`;
    } else if (status === 405) {
      statusText = "Method Not Allowed";
      if (method && pathname && routeId) {
        errorMessage = `You made a ${method.toUpperCase()} request to "${pathname}" but did not provide an \`action\` for route "${routeId}", so there is no way to handle the request.`;
      } else if (method) {
        errorMessage = `Invalid request method "${method.toUpperCase()}"`;
      }
    }
    return new ErrorResponseImpl(
      status || 500,
      statusText,
      new Error(errorMessage),
      true
    );
  }
  function findRedirect(results) {
    let entries = Object.entries(results);
    for (let i = entries.length - 1; i >= 0; i--) {
      let [key, result] = entries[i];
      if (isRedirectResult(result)) {
        return { key, result };
      }
    }
  }
  function stripHashFromPath(path) {
    let parsedPath = typeof path === "string" ? parsePath(path) : path;
    return createPath({ ...parsedPath, hash: "" });
  }
  function isHashChangeOnly(a, b) {
    if (a.pathname !== b.pathname || a.search !== b.search) {
      return false;
    }
    if (a.hash === "") {
      return b.hash !== "";
    } else if (a.hash === b.hash) {
      return true;
    } else if (b.hash !== "") {
      return true;
    }
    return false;
  }
  function dataWithResponseInitToResponse(data2) {
    return Response.json(data2.data, _nullishCoalesce(data2.init, () => void 0));
  }
  function dataWithResponseInitToErrorResponse(data2) {
    return new ErrorResponseImpl(
      _nullishCoalesce(_optionalChain([data2, "access", (_78) => _78.init, "optionalAccess", (_79) => _79.status]), () => 500),
      _nullishCoalesce(_optionalChain([data2, "access", (_80) => _80.init, "optionalAccess", (_81) => _81.statusText]), () => "Internal Server Error"),
      data2.data
    );
  }
  function isDataStrategyResults(result) {
    return result != null && typeof result === "object" && Object.entries(result).every(
      ([key, value]) => typeof key === "string" && isDataStrategyResult(value)
    );
  }
  function isDataStrategyResult(result) {
    return result != null && typeof result === "object" && "type" in result && "result" in result && (result.type === "data" || result.type === "error");
  }
  function isRedirectDataStrategyResult(result) {
    return isResponse(result.result) && redirectStatusCodes.has(result.result.status);
  }
  function isErrorResult(result) {
    return result.type === "error";
  }
  function isRedirectResult(result) {
    return (result && result.type) === "redirect";
  }
  function isDataWithResponseInit(value) {
    return typeof value === "object" && value != null && "type" in value && "data" in value && "init" in value && value.type === "DataWithResponseInit";
  }
  function isResponse(value) {
    return value != null && typeof value.status === "number" && typeof value.statusText === "string" && typeof value.headers === "object" && typeof value.body !== "undefined";
  }
  function isRedirectStatusCode(statusCode) {
    return redirectStatusCodes.has(statusCode);
  }
  function isRedirectResponse(result) {
    return isResponse(result) && isRedirectStatusCode(result.status) && result.headers.has("Location");
  }
  function isValidMethod(method) {
    return validRequestMethods.has(method.toUpperCase());
  }
  function isMutationMethod(method) {
    return validMutationMethods.has(method.toUpperCase());
  }
  function hasNakedIndexQuery(search) {
    return new URLSearchParams(search).getAll("index").some((v) => v === "");
  }
  function getTargetMatch(matches, location2) {
    let search = typeof location2 === "string" ? parsePath(location2).search : location2.search;
    if (matches[matches.length - 1].route.index && hasNakedIndexQuery(search || "")) {
      return matches[matches.length - 1];
    }
    let pathMatches = getPathContributingMatches(matches);
    return pathMatches[pathMatches.length - 1];
  }
  function getSubmissionFromNavigation(navigation) {
    let { formMethod, formAction, formEncType, text, formData, json } = navigation;
    if (!formMethod || !formAction || !formEncType) {
      return;
    }
    if (text != null) {
      return {
        formMethod,
        formAction,
        formEncType,
        formData: void 0,
        json: void 0,
        text
      };
    } else if (formData != null) {
      return {
        formMethod,
        formAction,
        formEncType,
        formData,
        json: void 0,
        text: void 0
      };
    } else if (json !== void 0) {
      return {
        formMethod,
        formAction,
        formEncType,
        formData: void 0,
        json,
        text: void 0
      };
    }
  }
  function getLoadingNavigation(location2, matches, historyAction, submission) {
    if (submission) {
      let navigation = {
        state: "loading",
        location: location2,
        matches,
        historyAction,
        formMethod: submission.formMethod,
        formAction: submission.formAction,
        formEncType: submission.formEncType,
        formData: submission.formData,
        json: submission.json,
        text: submission.text
      };
      return navigation;
    } else {
      let navigation = {
        state: "loading",
        location: location2,
        matches,
        historyAction,
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0
      };
      return navigation;
    }
  }
  function getSubmittingNavigation(location2, matches, historyAction, submission) {
    let navigation = {
      state: "submitting",
      location: location2,
      matches,
      historyAction,
      formMethod: submission.formMethod,
      formAction: submission.formAction,
      formEncType: submission.formEncType,
      formData: submission.formData,
      json: submission.json,
      text: submission.text
    };
    return navigation;
  }
  function getLoadingFetcher(submission, data2) {
    if (submission) {
      let fetcher = {
        state: "loading",
        formMethod: submission.formMethod,
        formAction: submission.formAction,
        formEncType: submission.formEncType,
        formData: submission.formData,
        json: submission.json,
        text: submission.text,
        data: data2
      };
      return fetcher;
    } else {
      let fetcher = {
        state: "loading",
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0,
        data: data2
      };
      return fetcher;
    }
  }
  function getSubmittingFetcher(submission, existingFetcher) {
    let fetcher = {
      state: "submitting",
      formMethod: submission.formMethod,
      formAction: submission.formAction,
      formEncType: submission.formEncType,
      formData: submission.formData,
      json: submission.json,
      text: submission.text,
      data: existingFetcher ? existingFetcher.data : void 0
    };
    return fetcher;
  }
  function getDoneFetcher(data2) {
    let fetcher = {
      state: "idle",
      formMethod: void 0,
      formAction: void 0,
      formEncType: void 0,
      formData: void 0,
      json: void 0,
      text: void 0,
      data: data2
    };
    return fetcher;
  }
  function restoreAppliedTransitions(_window, transitions) {
    try {
      let sessionPositions = _window.sessionStorage.getItem(
        TRANSITIONS_STORAGE_KEY
      );
      if (sessionPositions) {
        let json = JSON.parse(sessionPositions);
        for (let [k, v] of Object.entries(json || {})) {
          if (v && Array.isArray(v)) {
            transitions.set(k, new Set(v || []));
          }
        }
      }
    } catch (e) {
    }
  }
  function persistAppliedTransitions(_window, transitions) {
    if (transitions.size > 0) {
      let json = {};
      for (let [k, v] of transitions) {
        json[k] = [...v];
      }
      try {
        _window.sessionStorage.setItem(
          TRANSITIONS_STORAGE_KEY,
          JSON.stringify(json)
        );
      } catch (error) {
        warning(
          false,
          `Failed to save applied view transitions in sessionStorage (${error}).`
        );
      }
    }
  }
  function createDeferred() {
    let resolve;
    let reject;
    let promise = new Promise((res, rej) => {
      resolve = async (val) => {
        res(val);
        try {
          await promise;
        } catch (e) {
        }
      };
      reject = async (error) => {
        rej(error);
        try {
          await promise;
        } catch (e) {
        }
      };
    });
    return {
      promise,
      //@ts-ignore
      resolve,
      //@ts-ignore
      reject
    };
  }
  var _react = requireReact();
  var React = _interopRequireWildcard(_react);
  var React2 = _interopRequireWildcard(_react);
  var React3 = _interopRequireWildcard(_react);
  var React8 = _interopRequireWildcard(_react);
  var React7 = _interopRequireWildcard(_react);
  var React6 = _interopRequireWildcard(_react);
  var React5 = _interopRequireWildcard(_react);
  var React4 = _interopRequireWildcard(_react);
  var React9 = _interopRequireWildcard(_react);
  var HOLE = -1;
  var NAN = -2;
  var NEGATIVE_INFINITY = -3;
  var NEGATIVE_ZERO = -4;
  var NULL = -5;
  var POSITIVE_INFINITY = -6;
  var UNDEFINED = -7;
  var TYPE_BIGINT = "B";
  var TYPE_DATE = "D";
  var TYPE_ERROR = "E";
  var TYPE_MAP = "M";
  var TYPE_NULL_OBJECT = "N";
  var TYPE_PROMISE = "P";
  var TYPE_REGEXP = "R";
  var TYPE_SET = "S";
  var TYPE_SYMBOL = "Y";
  var TYPE_URL = "U";
  var TYPE_PREVIOUS_RESOLVED = "Z";
  var Deferred = class {
    constructor() {
      this.promise = new Promise((resolve, reject) => {
        this.resolve = resolve;
        this.reject = reject;
      });
    }
  };
  function createLineSplittingTransform() {
    const decoder = new TextDecoder();
    let leftover = "";
    return new TransformStream({
      transform(chunk, controller) {
        const str = decoder.decode(chunk, { stream: true });
        const parts = (leftover + str).split("\n");
        leftover = parts.pop() || "";
        for (const part of parts) {
          controller.enqueue(part);
        }
      },
      flush(controller) {
        if (leftover) {
          controller.enqueue(leftover);
        }
      }
    });
  }
  var TIME_LIMIT_MS = 1;
  var getNow = () => Date.now();
  var yieldToMain = () => new Promise((resolve) => setTimeout(resolve, 0));
  async function flatten(input) {
    const { indices } = this;
    const existing = indices.get(input);
    if (existing) return [existing];
    if (input === void 0) return UNDEFINED;
    if (input === null) return NULL;
    if (Number.isNaN(input)) return NAN;
    if (input === Number.POSITIVE_INFINITY) return POSITIVE_INFINITY;
    if (input === Number.NEGATIVE_INFINITY) return NEGATIVE_INFINITY;
    if (input === 0 && 1 / input < 0) return NEGATIVE_ZERO;
    const index = this.index++;
    indices.set(input, index);
    const stack = [[input, index]];
    await stringify.call(this, stack);
    return index;
  }
  async function stringify(stack) {
    const { deferred, indices, plugins, postPlugins } = this;
    const str = this.stringified;
    let lastYieldTime = getNow();
    const flattenValue = (value) => {
      const existing = indices.get(value);
      if (existing) return [existing];
      if (value === void 0) return UNDEFINED;
      if (value === null) return NULL;
      if (Number.isNaN(value)) return NAN;
      if (value === Number.POSITIVE_INFINITY) return POSITIVE_INFINITY;
      if (value === Number.NEGATIVE_INFINITY) return NEGATIVE_INFINITY;
      if (value === 0 && 1 / value < 0) return NEGATIVE_ZERO;
      const index = this.index++;
      indices.set(value, index);
      stack.push([value, index]);
      return index;
    };
    let i = 0;
    while (stack.length > 0) {
      const now = getNow();
      if (++i % 6e3 === 0 && now - lastYieldTime >= TIME_LIMIT_MS) {
        await yieldToMain();
        lastYieldTime = getNow();
      }
      const [input, index] = stack.pop();
      const partsForObj = (obj) => Object.keys(obj).map((k) => `"_${flattenValue(k)}":${flattenValue(obj[k])}`).join(",");
      let error = null;
      switch (typeof input) {
        case "boolean":
        case "number":
        case "string":
          str[index] = JSON.stringify(input);
          break;
        case "bigint":
          str[index] = `["${TYPE_BIGINT}","${input}"]`;
          break;
        case "symbol": {
          const keyFor = Symbol.keyFor(input);
          if (!keyFor) {
            error = new Error(
              "Cannot encode symbol unless created with Symbol.for()"
            );
          } else {
            str[index] = `["${TYPE_SYMBOL}",${JSON.stringify(keyFor)}]`;
          }
          break;
        }
        case "object": {
          if (!input) {
            str[index] = `${NULL}`;
            break;
          }
          const isArray = Array.isArray(input);
          let pluginHandled = false;
          if (!isArray && plugins) {
            for (const plugin of plugins) {
              const pluginResult = plugin(input);
              if (Array.isArray(pluginResult)) {
                pluginHandled = true;
                const [pluginIdentifier, ...rest] = pluginResult;
                str[index] = `[${JSON.stringify(pluginIdentifier)}`;
                if (rest.length > 0) {
                  str[index] += `,${rest.map((v) => flattenValue(v)).join(",")}`;
                }
                str[index] += "]";
                break;
              }
            }
          }
          if (!pluginHandled) {
            let result = isArray ? "[" : "{";
            if (isArray) {
              for (let i2 = 0; i2 < input.length; i2++)
                result += (i2 ? "," : "") + (i2 in input ? flattenValue(input[i2]) : HOLE);
              str[index] = `${result}]`;
            } else if (input instanceof Date) {
              const dateTime = input.getTime();
              str[index] = `["${TYPE_DATE}",${Number.isNaN(dateTime) ? JSON.stringify("invalid") : dateTime}]`;
            } else if (input instanceof URL) {
              str[index] = `["${TYPE_URL}",${JSON.stringify(input.href)}]`;
            } else if (input instanceof RegExp) {
              str[index] = `["${TYPE_REGEXP}",${JSON.stringify(
                input.source
              )},${JSON.stringify(input.flags)}]`;
            } else if (input instanceof Set) {
              if (input.size > 0) {
                str[index] = `["${TYPE_SET}",${[...input].map((val) => flattenValue(val)).join(",")}]`;
              } else {
                str[index] = `["${TYPE_SET}"]`;
              }
            } else if (input instanceof Map) {
              if (input.size > 0) {
                str[index] = `["${TYPE_MAP}",${[...input].flatMap(([k, v]) => [flattenValue(k), flattenValue(v)]).join(",")}]`;
              } else {
                str[index] = `["${TYPE_MAP}"]`;
              }
            } else if (input instanceof Promise) {
              str[index] = `["${TYPE_PROMISE}",${index}]`;
              deferred[index] = input;
            } else if (input instanceof Error) {
              str[index] = `["${TYPE_ERROR}",${JSON.stringify(input.message)}`;
              if (input.name !== "Error") {
                str[index] += `,${JSON.stringify(input.name)}`;
              }
              str[index] += "]";
            } else if (Object.getPrototypeOf(input) === null) {
              str[index] = `["${TYPE_NULL_OBJECT}",{${partsForObj(input)}}]`;
            } else if (isPlainObject2(input)) {
              str[index] = `{${partsForObj(input)}}`;
            } else {
              error = new Error("Cannot encode object with prototype");
            }
          }
          break;
        }
        default: {
          const isArray = Array.isArray(input);
          let pluginHandled = false;
          if (!isArray && plugins) {
            for (const plugin of plugins) {
              const pluginResult = plugin(input);
              if (Array.isArray(pluginResult)) {
                pluginHandled = true;
                const [pluginIdentifier, ...rest] = pluginResult;
                str[index] = `[${JSON.stringify(pluginIdentifier)}`;
                if (rest.length > 0) {
                  str[index] += `,${rest.map((v) => flattenValue(v)).join(",")}`;
                }
                str[index] += "]";
                break;
              }
            }
          }
          if (!pluginHandled) {
            error = new Error("Cannot encode function or unexpected type");
          }
        }
      }
      if (error) {
        let pluginHandled = false;
        if (postPlugins) {
          for (const plugin of postPlugins) {
            const pluginResult = plugin(input);
            if (Array.isArray(pluginResult)) {
              pluginHandled = true;
              const [pluginIdentifier, ...rest] = pluginResult;
              str[index] = `[${JSON.stringify(pluginIdentifier)}`;
              if (rest.length > 0) {
                str[index] += `,${rest.map((v) => flattenValue(v)).join(",")}`;
              }
              str[index] += "]";
              break;
            }
          }
        }
        if (!pluginHandled) {
          throw error;
        }
      }
    }
  }
  var objectProtoNames2 = Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
  function isPlainObject2(thing) {
    const proto = Object.getPrototypeOf(thing);
    return proto === Object.prototype || proto === null || Object.getOwnPropertyNames(proto).sort().join("\0") === objectProtoNames2;
  }
  var globalObj = typeof window !== "undefined" ? window : typeof globalThis !== "undefined" ? globalThis : void 0;
  function unflatten(parsed) {
    const { hydrated, values } = this;
    if (typeof parsed === "number") return hydrate.call(this, parsed);
    if (!Array.isArray(parsed) || !parsed.length) throw new SyntaxError();
    const startIndex = values.length;
    for (const value of parsed) {
      values.push(value);
    }
    hydrated.length = values.length;
    return hydrate.call(this, startIndex);
  }
  function hydrate(index) {
    const { hydrated, values, deferred, plugins } = this;
    let result;
    const stack = [
      [
        index,
        (v) => {
          result = v;
        }
      ]
    ];
    let postRun = [];
    while (stack.length > 0) {
      const [index2, set] = stack.pop();
      switch (index2) {
        case UNDEFINED:
          set(void 0);
          continue;
        case NULL:
          set(null);
          continue;
        case NAN:
          set(NaN);
          continue;
        case POSITIVE_INFINITY:
          set(Infinity);
          continue;
        case NEGATIVE_INFINITY:
          set(-Infinity);
          continue;
        case NEGATIVE_ZERO:
          set(-0);
          continue;
      }
      if (hydrated[index2]) {
        set(hydrated[index2]);
        continue;
      }
      const value = values[index2];
      if (!value || typeof value !== "object") {
        hydrated[index2] = value;
        set(value);
        continue;
      }
      if (Array.isArray(value)) {
        if (typeof value[0] === "string") {
          const [type, b, c] = value;
          switch (type) {
            case TYPE_DATE:
              set(hydrated[index2] = new Date(b));
              continue;
            case TYPE_URL:
              set(hydrated[index2] = new URL(b));
              continue;
            case TYPE_BIGINT:
              set(hydrated[index2] = BigInt(b));
              continue;
            case TYPE_REGEXP:
              set(hydrated[index2] = new RegExp(b, c));
              continue;
            case TYPE_SYMBOL:
              set(hydrated[index2] = Symbol.for(b));
              continue;
            case TYPE_SET:
              const newSet = /* @__PURE__ */ new Set();
              hydrated[index2] = newSet;
              for (let i = value.length - 1; i > 0; i--)
                stack.push([
                  value[i],
                  (v) => {
                    newSet.add(v);
                  }
                ]);
              set(newSet);
              continue;
            case TYPE_MAP:
              const map = /* @__PURE__ */ new Map();
              hydrated[index2] = map;
              for (let i = value.length - 2; i > 0; i -= 2) {
                const r = [];
                stack.push([
                  value[i + 1],
                  (v) => {
                    r[1] = v;
                  }
                ]);
                stack.push([
                  value[i],
                  (k) => {
                    r[0] = k;
                  }
                ]);
                postRun.push(() => {
                  map.set(r[0], r[1]);
                });
              }
              set(map);
              continue;
            case TYPE_NULL_OBJECT:
              const obj = /* @__PURE__ */ Object.create(null);
              hydrated[index2] = obj;
              for (const key of Object.keys(b).reverse()) {
                const r = [];
                stack.push([
                  b[key],
                  (v) => {
                    r[1] = v;
                  }
                ]);
                stack.push([
                  Number(key.slice(1)),
                  (k) => {
                    r[0] = k;
                  }
                ]);
                postRun.push(() => {
                  obj[r[0]] = r[1];
                });
              }
              set(obj);
              continue;
            case TYPE_PROMISE:
              if (hydrated[b]) {
                set(hydrated[index2] = hydrated[b]);
              } else {
                const d = new Deferred();
                deferred[b] = d;
                set(hydrated[index2] = d.promise);
              }
              continue;
            case TYPE_ERROR:
              const [, message, errorType] = value;
              let error = errorType && globalObj && SUPPORTED_ERROR_TYPES.includes(errorType) && errorType in globalObj && typeof globalObj[errorType] === "function" ? new globalObj[errorType](message) : new Error(message);
              hydrated[index2] = error;
              set(error);
              continue;
            case TYPE_PREVIOUS_RESOLVED:
              set(hydrated[index2] = hydrated[b]);
              continue;
            default:
              if (Array.isArray(plugins)) {
                const r = [];
                const vals = value.slice(1);
                for (let i = 0; i < vals.length; i++) {
                  const v = vals[i];
                  stack.push([
                    v,
                    (v2) => {
                      r[i] = v2;
                    }
                  ]);
                }
                postRun.push(() => {
                  for (const plugin of plugins) {
                    const result2 = plugin(value[0], ...r);
                    if (result2) {
                      set(hydrated[index2] = result2.value);
                      return;
                    }
                  }
                  throw new SyntaxError();
                });
                continue;
              }
              throw new SyntaxError();
          }
        } else {
          const array = [];
          hydrated[index2] = array;
          for (let i = 0; i < value.length; i++) {
            const n = value[i];
            if (n !== HOLE) {
              stack.push([
                n,
                (v) => {
                  array[i] = v;
                }
              ]);
            }
          }
          set(array);
          continue;
        }
      } else {
        const object = {};
        hydrated[index2] = object;
        for (const key of Object.keys(value).reverse()) {
          const r = [];
          stack.push([
            value[key],
            (v) => {
              r[1] = v;
            }
          ]);
          stack.push([
            Number(key.slice(1)),
            (k) => {
              r[0] = k;
            }
          ]);
          postRun.push(() => {
            object[r[0]] = r[1];
          });
        }
        set(object);
        continue;
      }
    }
    while (postRun.length > 0) {
      postRun.pop()();
    }
    return result;
  }
  async function decode(readable, options) {
    const { plugins } = _nullishCoalesce(options, () => ({}));
    const done = new Deferred();
    const reader = readable.pipeThrough(createLineSplittingTransform()).getReader();
    const decoder = {
      values: [],
      hydrated: [],
      deferred: {},
      plugins
    };
    const decoded = await decodeInitial.call(decoder, reader);
    let donePromise = done.promise;
    if (decoded.done) {
      done.resolve();
    } else {
      donePromise = decodeDeferred.call(decoder, reader).then(done.resolve).catch((reason) => {
        for (const deferred of Object.values(decoder.deferred)) {
          deferred.reject(reason);
        }
        done.reject(reason);
      });
    }
    return {
      done: donePromise.then(() => reader.closed),
      value: decoded.value
    };
  }
  async function decodeInitial(reader) {
    const read = await reader.read();
    if (!read.value) {
      throw new SyntaxError();
    }
    let line;
    try {
      line = JSON.parse(read.value);
    } catch (reason) {
      throw new SyntaxError();
    }
    return {
      done: read.done,
      value: unflatten.call(this, line)
    };
  }
  async function decodeDeferred(reader) {
    let read = await reader.read();
    while (!read.done) {
      if (!read.value) continue;
      const line = read.value;
      switch (line[0]) {
        case TYPE_PROMISE: {
          const colonIndex = line.indexOf(":");
          const deferredId = Number(line.slice(1, colonIndex));
          const deferred = this.deferred[deferredId];
          if (!deferred) {
            throw new Error(`Deferred ID ${deferredId} not found in stream`);
          }
          const lineData = line.slice(colonIndex + 1);
          let jsonLine;
          try {
            jsonLine = JSON.parse(lineData);
          } catch (reason) {
            throw new SyntaxError();
          }
          const value = unflatten.call(this, jsonLine);
          deferred.resolve(value);
          break;
        }
        case TYPE_ERROR: {
          const colonIndex = line.indexOf(":");
          const deferredId = Number(line.slice(1, colonIndex));
          const deferred = this.deferred[deferredId];
          if (!deferred) {
            throw new Error(`Deferred ID ${deferredId} not found in stream`);
          }
          const lineData = line.slice(colonIndex + 1);
          let jsonLine;
          try {
            jsonLine = JSON.parse(lineData);
          } catch (reason) {
            throw new SyntaxError();
          }
          const value = unflatten.call(this, jsonLine);
          deferred.reject(value);
          break;
        }
        default:
          throw new SyntaxError();
      }
      read = await reader.read();
    }
  }
  function encode(input, options) {
    const { onComplete, plugins, postPlugins, signal } = _nullishCoalesce(options, () => ({}));
    const encoder = {
      deferred: {},
      index: 0,
      indices: /* @__PURE__ */ new Map(),
      stringified: [],
      plugins,
      postPlugins,
      signal
    };
    const textEncoder = new TextEncoder();
    let lastSentIndex = 0;
    const readable = new ReadableStream({
      async start(controller) {
        const id = await flatten.call(encoder, input);
        if (Array.isArray(id)) {
          throw new Error("This should never happen");
        }
        if (id < 0) {
          controller.enqueue(textEncoder.encode(`${id}
`));
        } else {
          controller.enqueue(
            textEncoder.encode(`[${encoder.stringified.join(",")}]
`)
          );
          lastSentIndex = encoder.stringified.length - 1;
        }
        const seenPromises = /* @__PURE__ */ new WeakSet();
        let processingChain = Promise.resolve();
        if (Object.keys(encoder.deferred).length) {
          let raceDone;
          const racePromise = new Promise((resolve, reject) => {
            raceDone = resolve;
            if (signal) {
              const rejectPromise = () => reject(signal.reason || new Error("Signal was aborted."));
              if (signal.aborted) {
                rejectPromise();
              } else {
                signal.addEventListener("abort", (event) => {
                  rejectPromise();
                });
              }
            }
          });
          while (Object.keys(encoder.deferred).length > 0) {
            for (const [deferredId, deferred] of Object.entries(
              encoder.deferred
            )) {
              if (seenPromises.has(deferred)) continue;
              seenPromises.add(
                // biome-ignore lint/suspicious/noAssignInExpressions: <explanation>
                encoder.deferred[Number(deferredId)] = Promise.race([
                  racePromise,
                  deferred
                ]).then(
                  (resolved) => {
                    processingChain = processingChain.then(async () => {
                      const id2 = await flatten.call(encoder, resolved);
                      if (Array.isArray(id2)) {
                        controller.enqueue(
                          textEncoder.encode(
                            `${TYPE_PROMISE}${deferredId}:[["${TYPE_PREVIOUS_RESOLVED}",${id2[0]}]]
`
                          )
                        );
                        encoder.index++;
                        lastSentIndex++;
                      } else if (id2 < 0) {
                        controller.enqueue(
                          textEncoder.encode(
                            `${TYPE_PROMISE}${deferredId}:${id2}
`
                          )
                        );
                      } else {
                        const values = encoder.stringified.slice(lastSentIndex + 1).join(",");
                        controller.enqueue(
                          textEncoder.encode(
                            `${TYPE_PROMISE}${deferredId}:[${values}]
`
                          )
                        );
                        lastSentIndex = encoder.stringified.length - 1;
                      }
                    });
                    return processingChain;
                  },
                  (reason) => {
                    processingChain = processingChain.then(async () => {
                      if (!reason || typeof reason !== "object" || !(reason instanceof Error)) {
                        reason = new Error("An unknown error occurred");
                      }
                      const id2 = await flatten.call(encoder, reason);
                      if (Array.isArray(id2)) {
                        controller.enqueue(
                          textEncoder.encode(
                            `${TYPE_ERROR}${deferredId}:[["${TYPE_PREVIOUS_RESOLVED}",${id2[0]}]]
`
                          )
                        );
                        encoder.index++;
                        lastSentIndex++;
                      } else if (id2 < 0) {
                        controller.enqueue(
                          textEncoder.encode(
                            `${TYPE_ERROR}${deferredId}:${id2}
`
                          )
                        );
                      } else {
                        const values = encoder.stringified.slice(lastSentIndex + 1).join(",");
                        controller.enqueue(
                          textEncoder.encode(
                            `${TYPE_ERROR}${deferredId}:[${values}]
`
                          )
                        );
                        lastSentIndex = encoder.stringified.length - 1;
                      }
                    });
                    return processingChain;
                  }
                ).finally(() => {
                  delete encoder.deferred[Number(deferredId)];
                })
              );
            }
            await Promise.race(Object.values(encoder.deferred));
          }
          raceDone();
        }
        await Promise.all(Object.values(encoder.deferred));
        await processingChain;
        controller.close();
        _optionalChain([onComplete, "optionalCall", (_82) => _82()]);
      }
    });
    return readable;
  }
  async function createRequestInit(request) {
    let init = { signal: request.signal };
    if (request.method !== "GET") {
      init.method = request.method;
      let contentType = request.headers.get("Content-Type");
      if (contentType && /\bapplication\/json\b/.test(contentType)) {
        init.headers = { "Content-Type": contentType };
        init.body = JSON.stringify(await request.json());
      } else if (contentType && /\btext\/plain\b/.test(contentType)) {
        init.headers = { "Content-Type": contentType };
        init.body = await request.text();
      } else if (contentType && /\bapplication\/x-www-form-urlencoded\b/.test(contentType)) {
        init.body = new URLSearchParams(await request.text());
      } else {
        init.body = await request.formData();
      }
    }
    return init;
  }
  var ESCAPE_LOOKUP = {
    "&": "\\u0026",
    ">": "\\u003e",
    "<": "\\u003c",
    "\u2028": "\\u2028",
    "\u2029": "\\u2029"
  };
  var ESCAPE_REGEX = /[&><\u2028\u2029]/g;
  function escapeHtml(html) {
    return html.replace(ESCAPE_REGEX, (match) => ESCAPE_LOOKUP[match]);
  }
  function escapeAttribute(value) {
    return value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function invariant2(value, message) {
    if (value === false || value === null || typeof value === "undefined") {
      throw new Error(message);
    }
  }
  var SingleFetchRedirectSymbol = /* @__PURE__ */ Symbol("SingleFetchRedirect");
  var SingleFetchNoResultError = class extends Error {
  };
  var SINGLE_FETCH_REDIRECT_STATUS = 202;
  var NO_BODY_STATUS_CODES = /* @__PURE__ */ new Set([100, 101, 204, 205]);
  function StreamTransfer({
    context,
    identifier,
    reader,
    textDecoder,
    nonce
  }) {
    if (!context.renderMeta || !context.renderMeta.didRenderScripts) {
      return null;
    }
    if (!context.renderMeta.streamCache) {
      context.renderMeta.streamCache = {};
    }
    let { streamCache } = context.renderMeta;
    let promise = streamCache[identifier];
    if (!promise) {
      promise = streamCache[identifier] = reader.read().then((result) => {
        streamCache[identifier].result = {
          done: result.done,
          value: textDecoder.decode(result.value, { stream: true })
        };
      }).catch((e) => {
        streamCache[identifier].error = e;
      });
    }
    if (promise.error) {
      throw promise.error;
    }
    if (promise.result === void 0) {
      throw promise;
    }
    let { done, value } = promise.result;
    let scriptTag = value ? /* @__PURE__ */ React.createElement(
      "script",
      {
        nonce,
        dangerouslySetInnerHTML: {
          __html: `window.__reactRouterContext.streamController.enqueue(${escapeHtml(
            JSON.stringify(value)
          )});`
        }
      }
    ) : null;
    if (done) {
      return /* @__PURE__ */ React.createElement(React.Fragment, null, scriptTag, /* @__PURE__ */ React.createElement(
        "script",
        {
          nonce,
          dangerouslySetInnerHTML: {
            __html: `window.__reactRouterContext.streamController.close();`
          }
        }
      ));
    } else {
      return /* @__PURE__ */ React.createElement(React.Fragment, null, scriptTag, /* @__PURE__ */ React.createElement(React.Suspense, null, /* @__PURE__ */ React.createElement(
        StreamTransfer,
        {
          context,
          identifier: identifier + 1,
          reader,
          textDecoder,
          nonce
        }
      )));
    }
  }
  function getTurboStreamSingleFetchDataStrategy(getRouter, manifest, routeModules, ssr, basename, trailingSlashAware) {
    let dataStrategy = getSingleFetchDataStrategyImpl(
      getRouter,
      (match) => {
        let manifestRoute = manifest.routes[match.route.id];
        invariant2(manifestRoute, "Route not found in manifest");
        return {
          hasLoader: manifestRoute.hasLoader,
          hasClientLoader: manifestRoute.hasClientLoader
        };
      },
      fetchAndDecodeViaTurboStream,
      ssr,
      basename,
      trailingSlashAware
    );
    return async (args) => args.runClientMiddleware(dataStrategy);
  }
  function getSingleFetchDataStrategyImpl(getRouter, getRouteInfo, fetchAndDecode, ssr, basename, trailingSlashAware, shouldAllowOptOut = () => true) {
    return async (args) => {
      let { request, matches, fetcherKey } = args;
      let router = getRouter();
      if (request.method !== "GET") {
        return singleFetchActionStrategy(
          args,
          fetchAndDecode,
          basename,
          trailingSlashAware
        );
      }
      let foundRevalidatingServerLoader = matches.some((m) => {
        let { hasLoader, hasClientLoader } = getRouteInfo(m);
        return m.shouldCallHandler() && hasLoader && !hasClientLoader;
      });
      if (!ssr && !foundRevalidatingServerLoader) {
        return nonSsrStrategy(
          args,
          getRouteInfo,
          fetchAndDecode,
          basename,
          trailingSlashAware
        );
      }
      if (fetcherKey) {
        return singleFetchLoaderFetcherStrategy(
          args,
          fetchAndDecode,
          basename,
          trailingSlashAware
        );
      }
      return singleFetchLoaderNavigationStrategy(
        args,
        router,
        getRouteInfo,
        fetchAndDecode,
        ssr,
        basename,
        trailingSlashAware,
        shouldAllowOptOut
      );
    };
  }
  async function singleFetchActionStrategy(args, fetchAndDecode, basename, trailingSlashAware) {
    let actionMatch = args.matches.find((m) => m.shouldCallHandler());
    invariant2(actionMatch, "No action match found");
    let actionStatus = void 0;
    let result = await actionMatch.resolve(async (handler) => {
      let result2 = await handler(async () => {
        let { data: data2, status } = await fetchAndDecode(
          args,
          basename,
          trailingSlashAware,
          [actionMatch.route.id]
        );
        actionStatus = status;
        return unwrapSingleFetchResult(data2, actionMatch.route.id);
      });
      return result2;
    });
    if (isResponse(result.result) || isRouteErrorResponse(result.result) || isDataWithResponseInit(result.result)) {
      return { [actionMatch.route.id]: result };
    }
    return {
      [actionMatch.route.id]: {
        type: result.type,
        result: data(result.result, actionStatus)
      }
    };
  }
  async function nonSsrStrategy(args, getRouteInfo, fetchAndDecode, basename, trailingSlashAware) {
    let matchesToLoad = args.matches.filter((m) => m.shouldCallHandler());
    let results = {};
    await Promise.all(
      matchesToLoad.map(
        (m) => m.resolve(async (handler) => {
          try {
            let { hasClientLoader } = getRouteInfo(m);
            let routeId = m.route.id;
            let result = hasClientLoader ? await handler(async () => {
              let { data: data2 } = await fetchAndDecode(
                args,
                basename,
                trailingSlashAware,
                [routeId]
              );
              return unwrapSingleFetchResult(data2, routeId);
            }) : await handler();
            results[m.route.id] = { type: "data", result };
          } catch (e) {
            results[m.route.id] = { type: "error", result: e };
          }
        })
      )
    );
    return results;
  }
  async function singleFetchLoaderNavigationStrategy(args, router, getRouteInfo, fetchAndDecode, ssr, basename, trailingSlashAware, shouldAllowOptOut = () => true) {
    let routesParams = /* @__PURE__ */ new Set();
    let foundOptOutRoute = false;
    let routeDfds = args.matches.map(() => createDeferred2());
    let singleFetchDfd = createDeferred2();
    let results = {};
    let resolvePromise = Promise.all(
      args.matches.map(
        async (m, i) => m.resolve(async (handler) => {
          routeDfds[i].resolve();
          let routeId = m.route.id;
          let { hasLoader, hasClientLoader } = getRouteInfo(m);
          let defaultShouldRevalidate = !m.shouldRevalidateArgs || m.shouldRevalidateArgs.actionStatus == null || m.shouldRevalidateArgs.actionStatus < 400;
          let shouldCall = m.shouldCallHandler(defaultShouldRevalidate);
          if (!shouldCall) {
            foundOptOutRoute || (foundOptOutRoute = m.shouldRevalidateArgs != null && // This is a revalidation,
            hasLoader);
            return;
          }
          if (shouldAllowOptOut(m) && hasClientLoader) {
            if (hasLoader) {
              foundOptOutRoute = true;
            }
            try {
              let result = await handler(async () => {
                let { data: data2 } = await fetchAndDecode(
                  args,
                  basename,
                  trailingSlashAware,
                  [routeId]
                );
                return unwrapSingleFetchResult(data2, routeId);
              });
              results[routeId] = { type: "data", result };
            } catch (e) {
              results[routeId] = { type: "error", result: e };
            }
            return;
          }
          if (hasLoader) {
            routesParams.add(routeId);
          }
          try {
            let result = await handler(async () => {
              let data2 = await singleFetchDfd.promise;
              return unwrapSingleFetchResult(data2, routeId);
            });
            results[routeId] = { type: "data", result };
          } catch (e) {
            results[routeId] = { type: "error", result: e };
          }
        })
      )
    );
    await Promise.all(routeDfds.map((d) => d.promise));
    let isInitialLoad = !router.state.initialized && router.state.navigation.state === "idle";
    if ((isInitialLoad || routesParams.size === 0) && !window.__reactRouterHdrActive) {
      singleFetchDfd.resolve({ routes: {} });
    } else {
      let targetRoutes = ssr && foundOptOutRoute && routesParams.size > 0 ? [...routesParams.keys()] : void 0;
      try {
        let data2 = await fetchAndDecode(
          args,
          basename,
          trailingSlashAware,
          targetRoutes
        );
        singleFetchDfd.resolve(data2.data);
      } catch (e) {
        singleFetchDfd.reject(e);
      }
    }
    await resolvePromise;
    await bubbleMiddlewareErrors(
      singleFetchDfd.promise,
      args.matches,
      routesParams,
      results
    );
    return results;
  }
  async function bubbleMiddlewareErrors(singleFetchPromise, matches, routesParams, results) {
    try {
      let middlewareError;
      let fetchedData = await singleFetchPromise;
      if ("routes" in fetchedData) {
        for (let match of matches) {
          if (match.route.id in fetchedData.routes) {
            let routeResult = fetchedData.routes[match.route.id];
            if ("error" in routeResult) {
              middlewareError = routeResult.error;
              if (_optionalChain([results, "access", (_83) => _83[match.route.id], "optionalAccess", (_84) => _84.result]) == null) {
                results[match.route.id] = {
                  type: "error",
                  result: middlewareError
                };
              }
              break;
            }
          }
        }
      }
      if (middlewareError !== void 0) {
        Array.from(routesParams.values()).forEach((routeId) => {
          if (results[routeId].result instanceof SingleFetchNoResultError) {
            results[routeId].result = middlewareError;
          }
        });
      }
    } catch (e) {
    }
  }
  async function singleFetchLoaderFetcherStrategy(args, fetchAndDecode, basename, trailingSlashAware) {
    let fetcherMatch = args.matches.find((m) => m.shouldCallHandler());
    invariant2(fetcherMatch, "No fetcher match found");
    let routeId = fetcherMatch.route.id;
    let result = await fetcherMatch.resolve(
      async (handler) => handler(async () => {
        let { data: data2 } = await fetchAndDecode(args, basename, trailingSlashAware, [
          routeId
        ]);
        return unwrapSingleFetchResult(data2, routeId);
      })
    );
    return { [fetcherMatch.route.id]: result };
  }
  function stripIndexParam(url) {
    let indexValues = url.searchParams.getAll("index");
    url.searchParams.delete("index");
    let indexValuesToKeep = [];
    for (let indexValue of indexValues) {
      if (indexValue) {
        indexValuesToKeep.push(indexValue);
      }
    }
    for (let toKeep of indexValuesToKeep) {
      url.searchParams.append("index", toKeep);
    }
    return url;
  }
  function singleFetchUrl(reqUrl, basename, trailingSlashAware, extension) {
    let url = typeof reqUrl === "string" ? new URL(
      reqUrl,
      // This can be called during the SSR flow via PrefetchPageLinksImpl so
      // don't assume window is available
      typeof window === "undefined" ? "server://singlefetch/" : window.location.origin
    ) : reqUrl;
    if (trailingSlashAware) {
      if (url.pathname.endsWith("/")) {
        url.pathname = `${url.pathname}_.${extension}`;
      } else {
        url.pathname = `${url.pathname}.${extension}`;
      }
    } else {
      if (url.pathname === "/") {
        url.pathname = `_root.${extension}`;
      } else if (basename && stripBasename(url.pathname, basename) === "/") {
        url.pathname = `${removeTrailingSlash(basename)}/_root.${extension}`;
      } else {
        url.pathname = `${removeTrailingSlash(url.pathname)}.${extension}`;
      }
    }
    return url;
  }
  async function fetchAndDecodeViaTurboStream(args, basename, trailingSlashAware, targetRoutes) {
    let { request } = args;
    let url = singleFetchUrl(request.url, basename, trailingSlashAware, "data");
    if (request.method === "GET") {
      url = stripIndexParam(url);
      if (targetRoutes) {
        url.searchParams.set("_routes", targetRoutes.join(","));
      }
    }
    let res = await fetch(url, await createRequestInit(request));
    if (res.status >= 400 && !res.headers.has("X-Remix-Response")) {
      throw new ErrorResponseImpl(res.status, res.statusText, await res.text());
    }
    if (res.status === 204 && res.headers.has("X-Remix-Redirect")) {
      return {
        status: SINGLE_FETCH_REDIRECT_STATUS,
        data: {
          redirect: {
            redirect: res.headers.get("X-Remix-Redirect"),
            status: Number(res.headers.get("X-Remix-Status") || "302"),
            revalidate: res.headers.get("X-Remix-Revalidate") === "true",
            reload: res.headers.get("X-Remix-Reload-Document") === "true",
            replace: res.headers.get("X-Remix-Replace") === "true"
          }
        }
      };
    }
    if (NO_BODY_STATUS_CODES.has(res.status)) {
      let routes = {};
      if (targetRoutes && request.method !== "GET") {
        routes[targetRoutes[0]] = { data: void 0 };
      }
      return {
        status: res.status,
        data: { routes }
      };
    }
    invariant2(res.body, "No response body to decode");
    try {
      let decoded = await decodeViaTurboStream(res.body, window);
      let data2;
      if (request.method === "GET") {
        let typed = decoded.value;
        if (SingleFetchRedirectSymbol in typed) {
          data2 = { redirect: typed[SingleFetchRedirectSymbol] };
        } else {
          data2 = { routes: typed };
        }
      } else {
        let typed = decoded.value;
        let routeId = _optionalChain([targetRoutes, "optionalAccess", (_85) => _85[0]]);
        invariant2(routeId, "No routeId found for single fetch call decoding");
        if ("redirect" in typed) {
          data2 = { redirect: typed };
        } else {
          data2 = { routes: { [routeId]: typed } };
        }
      }
      return { status: res.status, data: data2 };
    } catch (e) {
      throw new Error("Unable to decode turbo-stream response");
    }
  }
  function decodeViaTurboStream(body, global) {
    return decode(body, {
      plugins: [
        (type, ...rest) => {
          if (type === "SanitizedError") {
            let [name, message, stack] = rest;
            let Constructor = Error;
            if (name && SUPPORTED_ERROR_TYPES.includes(name) && name in global && // @ts-expect-error
            typeof global[name] === "function") {
              Constructor = global[name];
            }
            let error = new Constructor(message);
            error.stack = stack;
            return { value: error };
          }
          if (type === "ErrorResponse") {
            let [data2, status, statusText] = rest;
            return {
              value: new ErrorResponseImpl(status, statusText, data2)
            };
          }
          if (type === "SingleFetchRedirect") {
            return { value: { [SingleFetchRedirectSymbol]: rest[0] } };
          }
          if (type === "SingleFetchClassInstance") {
            return { value: rest[0] };
          }
          if (type === "SingleFetchFallback") {
            return { value: void 0 };
          }
        }
      ]
    });
  }
  function unwrapSingleFetchResult(result, routeId) {
    if ("redirect" in result) {
      let {
        redirect: location2,
        revalidate,
        reload,
        replace: replace2,
        status
      } = result.redirect;
      throw redirect(location2, {
        status,
        headers: {
          // Three R's of redirecting (lol Veep)
          ...revalidate ? { "X-Remix-Revalidate": "yes" } : null,
          ...reload ? { "X-Remix-Reload-Document": "yes" } : null,
          ...replace2 ? { "X-Remix-Replace": "yes" } : null
        }
      });
    }
    let routeResult = result.routes[routeId];
    if (routeResult == null) {
      throw new SingleFetchNoResultError(
        `No result found for routeId "${routeId}"`
      );
    } else if ("error" in routeResult) {
      throw routeResult.error;
    } else if ("data" in routeResult) {
      return routeResult.data;
    } else {
      throw new Error(`Invalid response found for routeId "${routeId}"`);
    }
  }
  function createDeferred2() {
    let resolve;
    let reject;
    let promise = new Promise((res, rej) => {
      resolve = async (val) => {
        res(val);
        try {
          await promise;
        } catch (e) {
        }
      };
      reject = async (error) => {
        rej(error);
        try {
          await promise;
        } catch (e) {
        }
      };
    });
    return {
      promise,
      //@ts-ignore
      resolve,
      //@ts-ignore
      reject
    };
  }
  var DataRouterContext = React2.createContext(null);
  DataRouterContext.displayName = "DataRouter";
  var DataRouterStateContext = React2.createContext(null);
  DataRouterStateContext.displayName = "DataRouterState";
  var RSCRouterContext = React2.createContext(false);
  function useIsRSCRouterContext() {
    return React2.useContext(RSCRouterContext);
  }
  var ViewTransitionContext = React2.createContext({
    isTransitioning: false
  });
  ViewTransitionContext.displayName = "ViewTransition";
  var FetchersContext = React2.createContext(
    /* @__PURE__ */ new Map()
  );
  FetchersContext.displayName = "Fetchers";
  var AwaitContext = React2.createContext(null);
  AwaitContext.displayName = "Await";
  var AwaitContextProvider = (props) => React2.createElement(AwaitContext.Provider, props);
  var NavigationContext = React2.createContext(
    null
  );
  NavigationContext.displayName = "Navigation";
  var LocationContext = React2.createContext(
    null
  );
  LocationContext.displayName = "Location";
  var RouteContext = React2.createContext({
    outlet: null,
    matches: [],
    isDataRoute: false
  });
  RouteContext.displayName = "Route";
  var RouteErrorContext = React2.createContext(null);
  RouteErrorContext.displayName = "RouteError";
  var ENABLE_DEV_WARNINGS = true;
  var ERROR_DIGEST_BASE = "REACT_ROUTER_ERROR";
  var ERROR_DIGEST_REDIRECT = "REDIRECT";
  var ERROR_DIGEST_ROUTE_ERROR_RESPONSE = "ROUTE_ERROR_RESPONSE";
  function decodeRedirectErrorDigest(digest) {
    if (digest.startsWith(`${ERROR_DIGEST_BASE}:${ERROR_DIGEST_REDIRECT}:{`)) {
      try {
        let parsed = JSON.parse(digest.slice(28));
        if (typeof parsed === "object" && parsed && typeof parsed.status === "number" && typeof parsed.statusText === "string" && typeof parsed.location === "string" && typeof parsed.reloadDocument === "boolean" && typeof parsed.replace === "boolean") {
          return parsed;
        }
      } catch (e5) {
      }
    }
  }
  function decodeRouteErrorResponseDigest(digest) {
    if (digest.startsWith(
      `${ERROR_DIGEST_BASE}:${ERROR_DIGEST_ROUTE_ERROR_RESPONSE}:{`
    )) {
      try {
        let parsed = JSON.parse(digest.slice(40));
        if (typeof parsed === "object" && parsed && typeof parsed.status === "number" && typeof parsed.statusText === "string") {
          return new ErrorResponseImpl(
            parsed.status,
            parsed.statusText,
            parsed.data
          );
        }
      } catch (e6) {
      }
    }
  }
  function useHref(to, { relative } = {}) {
    invariant(
      useInRouterContext(),
      // TODO: This error is probably because they somehow have 2 versions of the
      // router loaded. We can help them understand how to avoid that.
      `useHref() may be used only in the context of a <Router> component.`
    );
    let { basename, navigator } = React3.useContext(NavigationContext);
    let { hash, pathname, search } = useResolvedPath(to, { relative });
    let joinedPathname = pathname;
    if (basename !== "/") {
      joinedPathname = pathname === "/" ? basename : joinPaths([basename, pathname]);
    }
    return navigator.createHref({ pathname: joinedPathname, search, hash });
  }
  function useInRouterContext() {
    return React3.useContext(LocationContext) != null;
  }
  function useLocation() {
    invariant(
      useInRouterContext(),
      // TODO: This error is probably because they somehow have 2 versions of the
      // router loaded. We can help them understand how to avoid that.
      `useLocation() may be used only in the context of a <Router> component.`
    );
    return React3.useContext(LocationContext).location;
  }
  function useNavigationType() {
    return React3.useContext(LocationContext).navigationType;
  }
  function useMatch(pattern) {
    invariant(
      useInRouterContext(),
      // TODO: This error is probably because they somehow have 2 versions of the
      // router loaded. We can help them understand how to avoid that.
      `useMatch() may be used only in the context of a <Router> component.`
    );
    let { pathname } = useLocation();
    return React3.useMemo(
      () => matchPath(pattern, decodePath(pathname)),
      [pathname, pattern]
    );
  }
  var navigateEffectWarning = `You should call navigate() in a React.useEffect(), not when your component is first rendered.`;
  function useIsomorphicLayoutEffect(cb) {
    let isStatic = React3.useContext(NavigationContext).static;
    if (!isStatic) {
      React3.useLayoutEffect(cb);
    }
  }
  function useNavigate() {
    let { isDataRoute } = React3.useContext(RouteContext);
    return isDataRoute ? useNavigateStable() : useNavigateUnstable();
  }
  function useNavigateUnstable() {
    invariant(
      useInRouterContext(),
      // TODO: This error is probably because they somehow have 2 versions of the
      // router loaded. We can help them understand how to avoid that.
      `useNavigate() may be used only in the context of a <Router> component.`
    );
    let dataRouterContext = React3.useContext(DataRouterContext);
    let { basename, navigator } = React3.useContext(NavigationContext);
    let { matches } = React3.useContext(RouteContext);
    let { pathname: locationPathname } = useLocation();
    let routePathnamesJson = JSON.stringify(getResolveToMatches(matches));
    let activeRef = React3.useRef(false);
    useIsomorphicLayoutEffect(() => {
      activeRef.current = true;
    });
    let navigate = React3.useCallback(
      (to, options = {}) => {
        warning(activeRef.current, navigateEffectWarning);
        if (!activeRef.current) return;
        if (typeof to === "number") {
          navigator.go(to);
          return;
        }
        let path = resolveTo(
          to,
          JSON.parse(routePathnamesJson),
          locationPathname,
          options.relative === "path"
        );
        if (dataRouterContext == null && basename !== "/") {
          path.pathname = path.pathname === "/" ? basename : joinPaths([basename, path.pathname]);
        }
        validateNavigationTarget(
          typeof to === "string" ? to : createPath(to),
          navigator.createHref(path),
          getNavigatorCurrentUrl(navigator),
          "reject"
        );
        (!!options.replace ? navigator.replace : navigator.push)(
          path,
          options.state,
          options
        );
      },
      [
        basename,
        navigator,
        routePathnamesJson,
        locationPathname,
        dataRouterContext
      ]
    );
    return navigate;
  }
  var OutletContext = React3.createContext(null);
  function useOutletContext() {
    return React3.useContext(OutletContext);
  }
  function useOutlet(context) {
    let outlet = React3.useContext(RouteContext).outlet;
    return React3.useMemo(
      () => outlet && /* @__PURE__ */ React3.createElement(OutletContext.Provider, { value: context }, outlet),
      [outlet, context]
    );
  }
  function useParams() {
    let { matches } = React3.useContext(RouteContext);
    let routeMatch = matches[matches.length - 1];
    return _nullishCoalesce(_optionalChain([routeMatch, "optionalAccess", (_86) => _86.params]), () => ({}));
  }
  function useResolvedPath(to, { relative } = {}) {
    let { matches } = React3.useContext(RouteContext);
    let { pathname: locationPathname } = useLocation();
    let routePathnamesJson = JSON.stringify(getResolveToMatches(matches));
    return React3.useMemo(
      () => resolveTo(
        to,
        JSON.parse(routePathnamesJson),
        locationPathname,
        relative === "path"
      ),
      [to, routePathnamesJson, locationPathname, relative]
    );
  }
  function useRoutes(routes, locationArg) {
    return useRoutesImpl(routes, locationArg);
  }
  function useRoutesImpl(routes, locationArg, dataRouterOpts) {
    invariant(
      useInRouterContext(),
      // TODO: This error is probably because they somehow have 2 versions of the
      // router loaded. We can help them understand how to avoid that.
      `useRoutes() may be used only in the context of a <Router> component.`
    );
    let { navigator } = React3.useContext(NavigationContext);
    let { matches: parentMatches } = React3.useContext(RouteContext);
    let routeMatch = parentMatches[parentMatches.length - 1];
    let parentParams = routeMatch ? routeMatch.params : {};
    let parentPathname = routeMatch ? routeMatch.pathname : "/";
    let parentPathnameBase = routeMatch ? routeMatch.pathnameBase : "/";
    let parentRoute = routeMatch && routeMatch.route;
    {
      let parentPath = parentRoute && parentRoute.path || "";
      warningOnce(
        parentPathname,
        !parentRoute || parentPath.endsWith("*") || parentPath.endsWith("*?"),
        `You rendered descendant <Routes> (or called \`useRoutes()\`) at "${parentPathname}" (under <Route path="${parentPath}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${parentPath}"> to <Route path="${parentPath === "/" ? "*" : `${parentPath}/*`}">.`
      );
    }
    let locationFromContext = useLocation();
    let location2;
    if (locationArg) {
      let parsedLocationArg = typeof locationArg === "string" ? parsePath(locationArg) : locationArg;
      invariant(
        parentPathnameBase === "/" || _optionalChain([parsedLocationArg, "access", (_87) => _87.pathname, "optionalAccess", (_88) => _88.startsWith, "call", (_89) => _89(parentPathnameBase)]),
        `When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${parentPathnameBase}" but pathname "${parsedLocationArg.pathname}" was given in the \`location\` prop.`
      );
      location2 = parsedLocationArg;
    } else {
      location2 = locationFromContext;
    }
    let pathname = location2.pathname || "/";
    let remainingPathname = pathname;
    if (parentPathnameBase !== "/") {
      let parentSegments = parentPathnameBase.replace(/^\//, "").split("/");
      let segments = pathname.replace(/^\//, "").split("/");
      remainingPathname = "/" + segments.slice(parentSegments.length).join("/");
    }
    let matches = dataRouterOpts && dataRouterOpts.state.matches.length ? (
      // If we're in a data router, use the matches we've already identified but ensure
      // we have the latest route instances from the manifest in case elements have changed
      dataRouterOpts.state.matches.map(
        (m) => Object.assign(m, {
          route: dataRouterOpts.manifest[m.route.id] || m.route
        })
      )
    ) : matchRoutes(routes, { pathname: remainingPathname });
    {
      warning(
        parentRoute || matches != null,
        `No routes matched location "${location2.pathname}${location2.search}${location2.hash}" `
      );
      warning(
        matches == null || matches[matches.length - 1].route.element !== void 0 || matches[matches.length - 1].route.Component !== void 0 || matches[matches.length - 1].route.lazy !== void 0,
        `Matched leaf route at location "${location2.pathname}${location2.search}${location2.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`
      );
    }
    let renderedMatches = _renderMatches(
      matches && matches.map(
        (match) => Object.assign({}, match, {
          params: Object.assign({}, parentParams, match.params),
          pathname: joinPaths([
            parentPathnameBase,
            // Re-encode pathnames that were decoded inside matchRoutes.
            // Pre-encode `%`, `?` and `#` ahead of `encodeLocation` because it uses
            // `new URL()` internally and we need to prevent it from treating
            // them as separators
            navigator.encodeLocation ? navigator.encodeLocation(
              match.pathname.replace(/%/g, "%25").replace(/\?/g, "%3F").replace(/#/g, "%23")
            ).pathname : match.pathname
          ]),
          pathnameBase: match.pathnameBase === "/" ? parentPathnameBase : joinPaths([
            parentPathnameBase,
            // Re-encode pathnames that were decoded inside matchRoutes
            // Pre-encode `%`, `?` and `#` ahead of `encodeLocation` because it uses
            // `new URL()` internally and we need to prevent it from treating
            // them as separators
            navigator.encodeLocation ? navigator.encodeLocation(
              match.pathnameBase.replace(/%/g, "%25").replace(/\?/g, "%3F").replace(/#/g, "%23")
            ).pathname : match.pathnameBase
          ])
        })
      ),
      parentMatches,
      dataRouterOpts
    );
    if (locationArg && renderedMatches) {
      return /* @__PURE__ */ React3.createElement(
        LocationContext.Provider,
        {
          value: {
            location: {
              pathname: "/",
              search: "",
              hash: "",
              state: null,
              key: "default",
              mask: void 0,
              ...location2
            },
            navigationType: "POP"
            /* Pop */
          }
        },
        renderedMatches
      );
    }
    return renderedMatches;
  }
  function DefaultErrorComponent() {
    let error = useRouteError();
    let message = isRouteErrorResponse(error) ? `${error.status} ${error.statusText}` : error instanceof Error ? error.message : JSON.stringify(error);
    let stack = error instanceof Error ? error.stack : null;
    let lightgrey = "rgba(200,200,200, 0.5)";
    let preStyles = { padding: "0.5rem", backgroundColor: lightgrey };
    let codeStyles = { padding: "2px 4px", backgroundColor: lightgrey };
    let devInfo = null;
    {
      console.error(
        "Error handled by React Router default ErrorBoundary:",
        error
      );
      devInfo = /* @__PURE__ */ React3.createElement(React3.Fragment, null, /* @__PURE__ */ React3.createElement("p", null, "💿 Hey developer 👋"), /* @__PURE__ */ React3.createElement("p", null, "You can provide a way better UX than this when your app throws errors by providing your own ", /* @__PURE__ */ React3.createElement("code", { style: codeStyles }, "ErrorBoundary"), " or", " ", /* @__PURE__ */ React3.createElement("code", { style: codeStyles }, "errorElement"), " prop on your route."));
    }
    return /* @__PURE__ */ React3.createElement(React3.Fragment, null, /* @__PURE__ */ React3.createElement("h2", null, "Unexpected Application Error!"), /* @__PURE__ */ React3.createElement("h3", { style: { fontStyle: "italic" } }, message), stack ? /* @__PURE__ */ React3.createElement("pre", { style: preStyles }, stack) : null, devInfo);
  }
  var defaultErrorElement = /* @__PURE__ */ React3.createElement(DefaultErrorComponent, null);
  var RenderErrorBoundary = class extends React3.Component {
    constructor(props) {
      super(props);
      this.state = {
        location: props.location,
        revalidation: props.revalidation,
        error: props.error
      };
    }
    static getDerivedStateFromError(error) {
      return { error };
    }
    static getDerivedStateFromProps(props, state) {
      if (state.location !== props.location || state.revalidation !== "idle" && props.revalidation === "idle") {
        return {
          error: props.error,
          location: props.location,
          revalidation: props.revalidation
        };
      }
      return {
        error: props.error !== void 0 ? props.error : state.error,
        location: state.location,
        revalidation: props.revalidation || state.revalidation
      };
    }
    componentDidCatch(error, errorInfo) {
      if (this.props.onError) {
        this.props.onError(error, errorInfo);
      } else {
        console.error(
          "React Router caught the following error during render",
          error
        );
      }
    }
    render() {
      let error = this.state.error;
      if (this.context && typeof error === "object" && error && "digest" in error && typeof error.digest === "string") {
        const decoded = decodeRouteErrorResponseDigest(error.digest);
        if (decoded) error = decoded;
      }
      let result = error !== void 0 ? /* @__PURE__ */ React3.createElement(RouteContext.Provider, { value: this.props.routeContext }, /* @__PURE__ */ React3.createElement(
        RouteErrorContext.Provider,
        {
          value: error,
          children: this.props.component
        }
      )) : this.props.children;
      if (this.context) {
        return /* @__PURE__ */ React3.createElement(RSCErrorHandler, { error }, result);
      }
      return result;
    }
  };
  RenderErrorBoundary.contextType = RSCRouterContext;
  var errorRedirectHandledMap = /* @__PURE__ */ new WeakMap();
  function RSCErrorHandler({
    children,
    error
  }) {
    let { basename, navigator } = React3.useContext(NavigationContext);
    if (typeof error === "object" && error && "digest" in error && typeof error.digest === "string") {
      let redirect2 = decodeRedirectErrorDigest(error.digest);
      if (redirect2) {
        let existingRedirect = errorRedirectHandledMap.get(error);
        if (existingRedirect) throw existingRedirect;
        let parsed = parseToInfo(redirect2.location, basename);
        let target = parsed.absoluteURL || parsed.to;
        validateNavigationTarget(
          redirect2.location,
          target,
          getNavigatorCurrentUrl(navigator),
          "allow-explicit"
        );
        if (hasInvalidProtocol(target)) {
          throw new Error("Invalid redirect location");
        }
        if (isBrowser && !errorRedirectHandledMap.get(error)) {
          if (parsed.isExternal || redirect2.reloadDocument) {
            window.location.href = target;
          } else {
            const redirectPromise = Promise.resolve().then(
              () => window.__reactRouterDataRouter.navigate(parsed.to, {
                replace: redirect2.replace
              })
            );
            errorRedirectHandledMap.set(error, redirectPromise);
            throw redirectPromise;
          }
        }
        return /* @__PURE__ */ React3.createElement("meta", { httpEquiv: "refresh", content: `0;url=${target}` });
      }
    }
    return children;
  }
  function RenderedRoute({ routeContext, match, children }) {
    let dataRouterContext = React3.useContext(DataRouterContext);
    if (dataRouterContext && dataRouterContext.static && dataRouterContext.staticContext && (match.route.errorElement || match.route.ErrorBoundary)) {
      dataRouterContext.staticContext._deepestRenderedBoundaryId = match.route.id;
    }
    return /* @__PURE__ */ React3.createElement(RouteContext.Provider, { value: routeContext }, children);
  }
  function _renderMatches(matches, parentMatches = [], dataRouterOpts) {
    let dataRouterState = _optionalChain([dataRouterOpts, "optionalAccess", (_90) => _90.state]);
    if (matches == null) {
      if (!dataRouterState) {
        return null;
      }
      if (dataRouterState.errors) {
        matches = dataRouterState.matches;
      } else if (parentMatches.length === 0 && !dataRouterState.initialized && dataRouterState.matches.length > 0) {
        matches = dataRouterState.matches;
      } else {
        return null;
      }
    }
    let renderedMatches = matches;
    let errors = _optionalChain([dataRouterState, "optionalAccess", (_91) => _91.errors]);
    if (errors != null) {
      let errorIndex = renderedMatches.findIndex(
        (m) => m.route.id && _optionalChain([errors, "optionalAccess", (_92) => _92[m.route.id]]) !== void 0
      );
      invariant(
        errorIndex >= 0,
        `Could not find a matching route for errors on route IDs: ${Object.keys(
          errors
        ).join(",")}`
      );
      renderedMatches = renderedMatches.slice(
        0,
        Math.min(renderedMatches.length, errorIndex + 1)
      );
    }
    let renderFallback = false;
    let fallbackIndex = -1;
    if (dataRouterOpts && dataRouterState) {
      renderFallback = dataRouterState.renderFallback;
      for (let i = 0; i < renderedMatches.length; i++) {
        let match = renderedMatches[i];
        if (match.route.HydrateFallback || match.route.hydrateFallbackElement) {
          fallbackIndex = i;
        }
        if (match.route.id) {
          let { loaderData, errors: errors2 } = dataRouterState;
          let needsToRunLoader = match.route.loader && !loaderData.hasOwnProperty(match.route.id) && (!errors2 || errors2[match.route.id] === void 0);
          if (match.route.lazy || needsToRunLoader) {
            if (dataRouterOpts.isStatic) {
              renderFallback = true;
            }
            if (fallbackIndex >= 0) {
              renderedMatches = renderedMatches.slice(0, fallbackIndex + 1);
            } else {
              renderedMatches = [renderedMatches[0]];
            }
            break;
          }
        }
      }
    }
    let onErrorHandler = _optionalChain([dataRouterOpts, "optionalAccess", (_93) => _93.onError]);
    let onError = dataRouterState && onErrorHandler ? (error, errorInfo) => {
      onErrorHandler(error, {
        location: dataRouterState.location,
        params: _nullishCoalesce(_optionalChain([dataRouterState, "access", (_94) => _94.matches, "optionalAccess", (_95) => _95[0], "optionalAccess", (_96) => _96.params]), () => ({})),
        pattern: getRoutePattern(dataRouterState.matches),
        errorInfo
      });
    } : void 0;
    return renderedMatches.reduceRight(
      (outlet, match, index) => {
        let error;
        let shouldRenderHydrateFallback = false;
        let errorElement = null;
        let hydrateFallbackElement = null;
        if (dataRouterState) {
          error = errors && match.route.id ? errors[match.route.id] : void 0;
          errorElement = match.route.errorElement || defaultErrorElement;
          if (renderFallback) {
            if (fallbackIndex < 0 && index === 0) {
              warningOnce(
                "route-fallback",
                false,
                "No `HydrateFallback` element provided to render during initial hydration"
              );
              shouldRenderHydrateFallback = true;
              hydrateFallbackElement = null;
            } else if (fallbackIndex === index) {
              shouldRenderHydrateFallback = true;
              hydrateFallbackElement = match.route.hydrateFallbackElement || null;
            }
          }
        }
        let matches2 = parentMatches.concat(renderedMatches.slice(0, index + 1));
        let getChildren = () => {
          let children;
          if (error) {
            children = errorElement;
          } else if (shouldRenderHydrateFallback) {
            children = hydrateFallbackElement;
          } else if (match.route.Component) {
            children = /* @__PURE__ */ React3.createElement(match.route.Component, null);
          } else if (match.route.element) {
            children = match.route.element;
          } else {
            children = outlet;
          }
          return /* @__PURE__ */ React3.createElement(
            RenderedRoute,
            {
              match,
              routeContext: {
                outlet,
                matches: matches2,
                isDataRoute: dataRouterState != null
              },
              children
            }
          );
        };
        return dataRouterState && (match.route.ErrorBoundary || match.route.errorElement || index === 0) ? /* @__PURE__ */ React3.createElement(
          RenderErrorBoundary,
          {
            location: dataRouterState.location,
            revalidation: dataRouterState.revalidation,
            component: errorElement,
            error,
            children: getChildren(),
            routeContext: { outlet: null, matches: matches2, isDataRoute: true },
            onError
          }
        ) : getChildren();
      },
      null
    );
  }
  function getDataRouterConsoleError(hookName) {
    return `${hookName} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
  }
  function useDataRouterContext(hookName) {
    let ctx = React3.useContext(DataRouterContext);
    invariant(ctx, getDataRouterConsoleError(hookName));
    return ctx;
  }
  function useDataRouterState(hookName) {
    let state = React3.useContext(DataRouterStateContext);
    invariant(state, getDataRouterConsoleError(hookName));
    return state;
  }
  function useRouteContext(hookName) {
    let route = React3.useContext(RouteContext);
    invariant(route, getDataRouterConsoleError(hookName));
    return route;
  }
  function useCurrentRouteId(hookName) {
    let route = useRouteContext(hookName);
    let thisRoute = route.matches[route.matches.length - 1];
    invariant(
      thisRoute.route.id,
      `${hookName} can only be used on routes that contain a unique "id"`
    );
    return thisRoute.route.id;
  }
  function useRouteId() {
    return useCurrentRouteId(
      "useRouteId"
      /* UseRouteId */
    );
  }
  function useNavigation() {
    let state = useDataRouterState(
      "useNavigation"
      /* UseNavigation */
    );
    return React3.useMemo(() => {
      let { matches, historyAction, ...rest } = state.navigation;
      return rest;
    }, [state.navigation]);
  }
  function useRevalidator() {
    let dataRouterContext = useDataRouterContext(
      "useRevalidator"
      /* UseRevalidator */
    );
    let state = useDataRouterState(
      "useRevalidator"
      /* UseRevalidator */
    );
    let revalidate = React3.useCallback(async () => {
      await dataRouterContext.router.revalidate();
    }, [dataRouterContext.router]);
    return React3.useMemo(
      () => ({ revalidate, state: state.revalidation }),
      [revalidate, state.revalidation]
    );
  }
  function useMatches() {
    let { matches, loaderData } = useDataRouterState(
      "useMatches"
      /* UseMatches */
    );
    return React3.useMemo(
      () => matches.map((m) => convertRouteMatchToUiMatch(m, loaderData)),
      [matches, loaderData]
    );
  }
  function useLoaderData() {
    let state = useDataRouterState(
      "useLoaderData"
      /* UseLoaderData */
    );
    let routeId = useCurrentRouteId(
      "useLoaderData"
      /* UseLoaderData */
    );
    return state.loaderData[routeId];
  }
  function useRouteLoaderData(routeId) {
    let state = useDataRouterState(
      "useRouteLoaderData"
      /* UseRouteLoaderData */
    );
    return state.loaderData[routeId];
  }
  function useActionData() {
    let state = useDataRouterState(
      "useActionData"
      /* UseActionData */
    );
    let routeId = useCurrentRouteId(
      "useLoaderData"
      /* UseLoaderData */
    );
    return state.actionData ? state.actionData[routeId] : void 0;
  }
  function useRouteError() {
    let error = React3.useContext(RouteErrorContext);
    let state = useDataRouterState(
      "useRouteError"
      /* UseRouteError */
    );
    let routeId = useCurrentRouteId(
      "useRouteError"
      /* UseRouteError */
    );
    if (error !== void 0) {
      return error;
    }
    return _optionalChain([state, "access", (_97) => _97.errors, "optionalAccess", (_98) => _98[routeId]]);
  }
  function useAsyncValue() {
    let value = React3.useContext(AwaitContext);
    return _optionalChain([value, "optionalAccess", (_99) => _99._data]);
  }
  function useAsyncError() {
    let value = React3.useContext(AwaitContext);
    return _optionalChain([value, "optionalAccess", (_100) => _100._error]);
  }
  var blockerId = 0;
  function useBlocker(shouldBlock) {
    let { router, basename } = useDataRouterContext(
      "useBlocker"
      /* UseBlocker */
    );
    let state = useDataRouterState(
      "useBlocker"
      /* UseBlocker */
    );
    let [blockerKey, setBlockerKey] = React3.useState("");
    let blockerFunction = React3.useCallback(
      (arg) => {
        if (typeof shouldBlock !== "function") {
          return !!shouldBlock;
        }
        if (basename === "/") {
          return shouldBlock(arg);
        }
        let { currentLocation, nextLocation, historyAction } = arg;
        return shouldBlock({
          currentLocation: {
            ...currentLocation,
            pathname: stripBasename(currentLocation.pathname, basename) || currentLocation.pathname
          },
          nextLocation: {
            ...nextLocation,
            pathname: stripBasename(nextLocation.pathname, basename) || nextLocation.pathname
          },
          historyAction
        });
      },
      [basename, shouldBlock]
    );
    React3.useEffect(() => {
      let key = String(++blockerId);
      setBlockerKey(key);
      return () => router.deleteBlocker(key);
    }, [router]);
    React3.useEffect(() => {
      if (blockerKey !== "") {
        router.getBlocker(blockerKey, blockerFunction);
      }
    }, [router, blockerKey, blockerFunction]);
    return blockerKey && state.blockers.has(blockerKey) ? state.blockers.get(blockerKey) : IDLE_BLOCKER;
  }
  function useNavigateStable() {
    let { router } = useDataRouterContext(
      "useNavigate"
      /* UseNavigateStable */
    );
    let id = useCurrentRouteId(
      "useNavigate"
      /* UseNavigateStable */
    );
    let activeRef = React3.useRef(false);
    useIsomorphicLayoutEffect(() => {
      activeRef.current = true;
    });
    let navigate = React3.useCallback(
      async (to, options = {}) => {
        warning(activeRef.current, navigateEffectWarning);
        if (!activeRef.current) return;
        if (typeof to === "number") {
          await router.navigate(to);
        } else {
          await router.navigate(to, { fromRouteId: id, ...options });
        }
      },
      [router, id]
    );
    return navigate;
  }
  var alreadyWarned = {};
  function warningOnce(key, cond, message) {
    if (!cond && !alreadyWarned[key]) {
      alreadyWarned[key] = true;
      warning(false, message);
    }
  }
  function useRoute(...args) {
    const currentRouteId = useCurrentRouteId(
      "useRoute"
      /* UseRoute */
    );
    const id = _nullishCoalesce(args[0], () => currentRouteId);
    const state = useDataRouterState(
      "useRoute"
      /* UseRoute */
    );
    const route = state.matches.find(({ route: route2 }) => route2.id === id);
    if (route === void 0) return void 0;
    return {
      handle: route.route.handle,
      loaderData: state.loaderData[id],
      actionData: _optionalChain([state, "access", (_101) => _101.actionData, "optionalAccess", (_102) => _102[id]])
    };
  }
  function toRouterStateMatch(match) {
    return {
      id: match.route.id,
      pathname: match.pathname,
      params: match.params,
      handle: match.route.handle
    };
  }
  function useRouterState() {
    let {
      location: location2,
      historyAction: type,
      matches,
      navigation
    } = useDataRouterState(
      "unstable_useRouterState"
      /* UseRouterState */
    );
    let active = React3.useMemo(
      () => ({
        type,
        location: location2,
        searchParams: new URLSearchParams(location2.search),
        params: _nullishCoalesce(_optionalChain([matches, "access", (_103) => _103[matches.length - 1], "optionalAccess", (_104) => _104.params]), () => ({})),
        matches: matches.map((m) => toRouterStateMatch(m))
      }),
      [location2, matches, type]
    );
    let pending = React3.useMemo(() => {
      if (navigation.state === "idle") return null;
      let shared = {
        type: navigation.historyAction,
        location: navigation.location,
        searchParams: new URLSearchParams(navigation.location.search),
        params: _nullishCoalesce(_optionalChain([navigation, "access", (_105) => _105.matches, "access", (_106) => _106[navigation.matches.length - 1], "optionalAccess", (_107) => _107.params]), () => ({})),
        matches: navigation.matches.map((m) => toRouterStateMatch(m))
      };
      return navigation.state === "loading" ? {
        ...shared,
        state: "loading",
        formMethod: navigation.formMethod,
        formAction: navigation.formAction,
        formEncType: navigation.formEncType,
        formData: navigation.formData,
        json: navigation.json,
        text: navigation.text
      } : {
        ...shared,
        state: "submitting",
        formMethod: navigation.formMethod,
        formAction: navigation.formAction,
        formEncType: navigation.formEncType,
        formData: navigation.formData,
        json: navigation.json,
        text: navigation.text
      };
    }, [navigation]);
    return React3.useMemo(
      () => ({ active, pending }),
      [active, pending]
    );
  }
  async function loadRouteModule(route, routeModulesCache) {
    if (route.id in routeModulesCache) {
      return routeModulesCache[route.id];
    }
    try {
      let routeModule = await Promise.resolve().then(() => _interopRequireWildcard(commonjsRequire(
        /* @vite-ignore */
        /* webpackIgnore: true */
        route.module
      )));
      routeModulesCache[route.id] = routeModule;
      return routeModule;
    } catch (error) {
      console.error(
        `Error loading route module \`${route.module}\`, reloading page...`
      );
      console.error(error);
      if (window.__reactRouterContext && window.__reactRouterContext.isSpaMode && // @ts-expect-error
      void 0) ;
      window.location.reload();
      return new Promise(() => {
      });
    }
  }
  function getKeyedLinksForMatches(matches, routeModules, manifest) {
    let descriptors = matches.map((match) => {
      let module = routeModules[match.route.id];
      let route = manifest.routes[match.route.id];
      return [
        route && route.css ? route.css.map((href) => ({ rel: "stylesheet", href })) : [],
        _optionalChain([module, "optionalAccess", (_108) => _108.links, "optionalCall", (_109) => _109()]) || []
      ];
    }).flat(2);
    let preloads = getModuleLinkHrefs(matches, manifest);
    return dedupeLinkDescriptors(descriptors, preloads);
  }
  function getRouteCssDescriptors(route) {
    if (!route.css) return [];
    return route.css.map((href) => ({ rel: "stylesheet", href }));
  }
  async function prefetchRouteCss(route) {
    if (!route.css) return;
    let descriptors = getRouteCssDescriptors(route);
    await Promise.all(descriptors.map(prefetchStyleLink));
  }
  async function prefetchStyleLinks(route, routeModule) {
    if (!route.css && !routeModule.links || !isPreloadSupported()) return;
    let descriptors = [];
    if (route.css) {
      descriptors.push(...getRouteCssDescriptors(route));
    }
    if (routeModule.links) {
      descriptors.push(...routeModule.links());
    }
    if (descriptors.length === 0) return;
    let styleLinks = [];
    for (let descriptor of descriptors) {
      if (!isPageLinkDescriptor(descriptor) && descriptor.rel === "stylesheet") {
        styleLinks.push({
          ...descriptor,
          rel: "preload",
          as: "style"
        });
      }
    }
    await Promise.all(styleLinks.map(prefetchStyleLink));
  }
  async function prefetchStyleLink(descriptor) {
    return new Promise((resolve) => {
      if (descriptor.media && !window.matchMedia(descriptor.media).matches || document.querySelector(
        `link[rel="stylesheet"][href="${descriptor.href}"]`
      )) {
        return resolve();
      }
      let link = document.createElement("link");
      Object.assign(link, descriptor);
      function removeLink() {
        if (document.head.contains(link)) {
          document.head.removeChild(link);
        }
      }
      link.onload = () => {
        removeLink();
        resolve();
      };
      link.onerror = () => {
        removeLink();
        resolve();
      };
      document.head.appendChild(link);
    });
  }
  function isPageLinkDescriptor(object) {
    return object != null && typeof object.page === "string";
  }
  function isHtmlLinkDescriptor(object) {
    if (object == null) {
      return false;
    }
    if (object.href == null) {
      return object.rel === "preload" && typeof object.imageSrcSet === "string" && typeof object.imageSizes === "string";
    }
    return typeof object.rel === "string" && typeof object.href === "string";
  }
  async function getKeyedPrefetchLinks(matches, manifest, routeModules) {
    let links = await Promise.all(
      matches.map(async (match) => {
        let route = manifest.routes[match.route.id];
        if (route) {
          let mod = await loadRouteModule(route, routeModules);
          return mod.links ? mod.links() : [];
        }
        return [];
      })
    );
    return dedupeLinkDescriptors(
      links.flat(1).filter(isHtmlLinkDescriptor).filter((link) => link.rel === "stylesheet" || link.rel === "preload").map(
        (link) => link.rel === "stylesheet" ? { ...link, rel: "prefetch", as: "style" } : { ...link, rel: "prefetch" }
      )
    );
  }
  function getNewMatchesForLinks(page, nextMatches, currentMatches, manifest, location2, mode) {
    let isNew = (match, index) => {
      if (!currentMatches[index]) return true;
      return match.route.id !== currentMatches[index].route.id;
    };
    let matchPathChanged = (match, index) => {
      return (
        // param change, /users/123 -> /users/456
        currentMatches[index].pathname !== match.pathname || // splat param changed, which is not present in match.path
        // e.g. /files/images/avatar.jpg -> files/finances.xls
        _optionalChain([currentMatches, "access", (_110) => _110[index], "access", (_111) => _111.route, "access", (_112) => _112.path, "optionalAccess", (_113) => _113.endsWith, "call", (_114) => _114("*")]) && currentMatches[index].params["*"] !== match.params["*"]
      );
    };
    if (mode === "assets") {
      return nextMatches.filter(
        (match, index) => isNew(match, index) || matchPathChanged(match, index)
      );
    }
    if (mode === "data") {
      return nextMatches.filter((match, index) => {
        let manifestRoute = manifest.routes[match.route.id];
        if (!manifestRoute || !manifestRoute.hasLoader) {
          return false;
        }
        if (isNew(match, index) || matchPathChanged(match, index)) {
          return true;
        }
        if (match.route.shouldRevalidate) {
          let routeChoice = match.route.shouldRevalidate({
            currentUrl: new URL(
              location2.pathname + location2.search + location2.hash,
              window.origin
            ),
            currentParams: _optionalChain([currentMatches, "access", (_115) => _115[0], "optionalAccess", (_116) => _116.params]) || {},
            nextUrl: new URL(page, window.origin),
            nextParams: match.params,
            defaultShouldRevalidate: true
          });
          if (typeof routeChoice === "boolean") {
            return routeChoice;
          }
        }
        return true;
      });
    }
    return [];
  }
  function getModuleLinkHrefs(matches, manifest, { includeHydrateFallback } = {}) {
    return dedupeHrefs(
      matches.map((match) => {
        let route = manifest.routes[match.route.id];
        if (!route) return [];
        let hrefs = [route.module];
        if (route.clientActionModule) {
          hrefs = hrefs.concat(route.clientActionModule);
        }
        if (route.clientLoaderModule) {
          hrefs = hrefs.concat(route.clientLoaderModule);
        }
        if (includeHydrateFallback && route.hydrateFallbackModule) {
          hrefs = hrefs.concat(route.hydrateFallbackModule);
        }
        if (route.imports) {
          hrefs = hrefs.concat(route.imports);
        }
        return hrefs;
      }).flat(1)
    );
  }
  function dedupeHrefs(hrefs) {
    return [...new Set(hrefs)];
  }
  function sortKeys(obj) {
    let sorted = {};
    let keys = Object.keys(obj).sort();
    for (let key of keys) {
      sorted[key] = obj[key];
    }
    return sorted;
  }
  function dedupeLinkDescriptors(descriptors, preloads) {
    let set = /* @__PURE__ */ new Set();
    let preloadsSet = new Set(preloads);
    return descriptors.reduce((deduped, descriptor) => {
      let alreadyModulePreload = preloads && !isPageLinkDescriptor(descriptor) && descriptor.as === "script" && descriptor.href && preloadsSet.has(descriptor.href);
      if (alreadyModulePreload) {
        return deduped;
      }
      let key = JSON.stringify(sortKeys(descriptor));
      if (!set.has(key)) {
        set.add(key);
        deduped.push({ key, link: descriptor });
      }
      return deduped;
    }, []);
  }
  var _isPreloadSupported;
  function isPreloadSupported() {
    if (_isPreloadSupported !== void 0) {
      return _isPreloadSupported;
    }
    let el = document.createElement("link");
    _isPreloadSupported = el.relList.supports("preload");
    el = null;
    return _isPreloadSupported;
  }
  var alreadyWarned2 = {};
  function warnOnce(condition, message) {
    if (!condition && !alreadyWarned2[message]) {
      alreadyWarned2[message] = true;
      console.warn(message);
    }
  }
  function RemixRootDefaultHydrateFallback() {
    let { nonce } = useFrameworkContext();
    return /* @__PURE__ */ React4.createElement(BoundaryShell, { title: "Loading...", renderScripts: true }, /* @__PURE__ */ React4.createElement(
      "script",
      {
        nonce,
        dangerouslySetInnerHTML: {
          __html: `
              console.log(
                "💿 Hey developer 👋. You can provide a way better UX than this " +
                "when your app is loading JS modules and/or running \`clientLoader\` " +
                "functions. Check out https://reactrouter.com/start/framework/route-module#hydratefallback " +
                "for more information."
              );
            `
        }
      }
    ));
  }
  function groupRoutesByParentId(manifest) {
    let routes = {};
    Object.values(manifest).forEach((route) => {
      if (route) {
        let parentId = route.parentId || "";
        if (!routes[parentId]) {
          routes[parentId] = [];
        }
        routes[parentId].push(route);
      }
    });
    return routes;
  }
  function getRouteComponents(route, routeModule, isSpaMode) {
    let Component4 = getRouteModuleComponent(routeModule);
    let HydrateFallback = routeModule.HydrateFallback && (!isSpaMode || route.id === "root") ? routeModule.HydrateFallback : route.id === "root" ? RemixRootDefaultHydrateFallback : void 0;
    let ErrorBoundary = routeModule.ErrorBoundary ? routeModule.ErrorBoundary : route.id === "root" ? () => /* @__PURE__ */ React5.createElement(RemixRootDefaultErrorBoundary, { error: useRouteError() }) : void 0;
    if (route.id === "root" && routeModule.Layout) {
      return {
        ...Component4 ? {
          element: /* @__PURE__ */ React5.createElement(routeModule.Layout, null, /* @__PURE__ */ React5.createElement(Component4, null))
        } : { Component: Component4 },
        ...ErrorBoundary ? {
          errorElement: /* @__PURE__ */ React5.createElement(routeModule.Layout, null, /* @__PURE__ */ React5.createElement(ErrorBoundary, null))
        } : { ErrorBoundary },
        ...HydrateFallback ? {
          hydrateFallbackElement: /* @__PURE__ */ React5.createElement(routeModule.Layout, null, /* @__PURE__ */ React5.createElement(HydrateFallback, null))
        } : { HydrateFallback }
      };
    }
    return { Component: Component4, ErrorBoundary, HydrateFallback };
  }
  function createServerRoutes(manifest, routeModules, future, isSpaMode, parentId = "", routesByParentId = groupRoutesByParentId(manifest), spaModeLazyPromise = Promise.resolve({ Component: () => null })) {
    return (routesByParentId[parentId] || []).map((route) => {
      let routeModule = routeModules[route.id];
      invariant2(
        routeModule,
        "No `routeModule` available to create server routes"
      );
      let dataRoute = {
        ...getRouteComponents(route, routeModule, isSpaMode),
        caseSensitive: route.caseSensitive,
        id: route.id,
        index: route.index,
        path: route.path,
        handle: routeModule.handle,
        // For SPA Mode, all routes are lazy except root.  However we tell the
        // router root is also lazy here too since we don't need a full
        // implementation - we just need a `lazy` prop to tell the RR rendering
        // where to stop which is always at the root route in SPA mode
        lazy: isSpaMode ? () => spaModeLazyPromise : void 0,
        // For partial hydration rendering, we need to indicate when the route
        // has a loader/clientLoader, but it won't ever be called during the static
        // render, so just give it a no-op function so we can render down to the
        // proper fallback
        loader: route.hasLoader || route.hasClientLoader ? () => null : void 0
        // We don't need middleware/action/shouldRevalidate on these routes since
        // they're for a static render
      };
      let children = createServerRoutes(
        manifest,
        routeModules,
        future,
        isSpaMode,
        route.id,
        routesByParentId,
        spaModeLazyPromise
      );
      if (children.length > 0) dataRoute.children = children;
      return dataRoute;
    });
  }
  function createClientRoutesWithHMRRevalidationOptOut(needsRevalidation, manifest, routeModulesCache, initialState, ssr, isSpaMode) {
    return createClientRoutes(
      manifest,
      routeModulesCache,
      initialState,
      ssr,
      isSpaMode,
      "",
      groupRoutesByParentId(manifest),
      needsRevalidation
    );
  }
  function preventInvalidServerHandlerCall(type, route) {
    if (type === "loader" && !route.hasLoader || type === "action" && !route.hasAction) {
      let fn = type === "action" ? "serverAction()" : "serverLoader()";
      let msg = `You are trying to call ${fn} on a route that does not have a server ${type} (routeId: "${route.id}")`;
      console.error(msg);
      throw new ErrorResponseImpl(400, "Bad Request", new Error(msg), true);
    }
  }
  function noActionDefinedError(type, routeId) {
    let article = type === "clientAction" ? "a" : "an";
    let msg = `Route "${routeId}" does not have ${article} ${type}, but you are trying to submit to it. To fix this, please add ${article} \`${type}\` function to the route`;
    console.error(msg);
    throw new ErrorResponseImpl(405, "Method Not Allowed", new Error(msg), true);
  }
  function createClientRoutes(manifest, routeModulesCache, initialState, ssr, isSpaMode, parentId = "", routesByParentId = groupRoutesByParentId(manifest), needsRevalidation) {
    return (routesByParentId[parentId] || []).map((route) => {
      let routeModule = routeModulesCache[route.id];
      function fetchServerHandler(singleFetch) {
        invariant2(
          typeof singleFetch === "function",
          "No single fetch function available for route handler"
        );
        return singleFetch();
      }
      function fetchServerLoader(singleFetch) {
        if (!route.hasLoader) return Promise.resolve(null);
        return fetchServerHandler(singleFetch);
      }
      function fetchServerAction(singleFetch) {
        if (!route.hasAction) {
          throw noActionDefinedError("action", route.id);
        }
        return fetchServerHandler(singleFetch);
      }
      function prefetchModule(modulePath) {
        Promise.resolve().then(() => _interopRequireWildcard(commonjsRequire(
          /* @vite-ignore */
          /* webpackIgnore: true */
          modulePath
        )));
      }
      function prefetchRouteModuleChunks(route2) {
        if (route2.clientActionModule) {
          prefetchModule(route2.clientActionModule);
        }
        if (route2.clientLoaderModule) {
          prefetchModule(route2.clientLoaderModule);
        }
      }
      async function prefetchStylesAndCallHandler(handler) {
        let cachedModule = routeModulesCache[route.id];
        let linkPrefetchPromise = cachedModule ? prefetchStyleLinks(route, cachedModule) : Promise.resolve();
        try {
          return handler();
        } finally {
          await linkPrefetchPromise;
        }
      }
      let dataRoute = {
        id: route.id,
        index: route.index,
        path: route.path
      };
      if (routeModule) {
        Object.assign(dataRoute, {
          ...dataRoute,
          ...getRouteComponents(route, routeModule, isSpaMode),
          middleware: routeModule.clientMiddleware,
          handle: routeModule.handle,
          shouldRevalidate: getShouldRevalidateFunction(
            dataRoute.path,
            routeModule,
            route,
            ssr,
            needsRevalidation
          )
        });
        let hasInitialData = initialState && initialState.loaderData && route.id in initialState.loaderData;
        let initialData = hasInitialData ? _optionalChain([initialState, "optionalAccess", (_117) => _117.loaderData, "optionalAccess", (_118) => _118[route.id]]) : void 0;
        let hasInitialError = initialState && initialState.errors && route.id in initialState.errors;
        let initialError = hasInitialError ? _optionalChain([initialState, "optionalAccess", (_119) => _119.errors, "optionalAccess", (_120) => _120[route.id]]) : void 0;
        let isHydrationRequest = needsRevalidation == null && (_optionalChain([routeModule, "access", (_121) => _121.clientLoader, "optionalAccess", (_122) => _122.hydrate]) === true || !route.hasLoader);
        dataRoute.loader = async ({ request, params, context, pattern, url }, singleFetch) => {
          let _isHydrationRequest = isHydrationRequest;
          isHydrationRequest = false;
          let result = await prefetchStylesAndCallHandler(async () => {
            invariant2(
              routeModule,
              "No `routeModule` available for critical-route loader"
            );
            if (!routeModule.clientLoader) {
              return fetchServerLoader(singleFetch);
            }
            return routeModule.clientLoader({
              request,
              params,
              context,
              pattern,
              url,
              async serverLoader() {
                preventInvalidServerHandlerCall("loader", route);
                if (_isHydrationRequest) {
                  if (hasInitialData) {
                    return initialData;
                  }
                  if (hasInitialError) {
                    throw initialError;
                  }
                }
                return fetchServerLoader(singleFetch);
              }
            });
          });
          return result;
        };
        dataRoute.loader.hydrate = shouldHydrateRouteLoader(
          route.id,
          routeModule.clientLoader,
          route.hasLoader,
          isSpaMode
        );
        dataRoute.action = ({ request, params, context, pattern, url }, singleFetch) => {
          return prefetchStylesAndCallHandler(async () => {
            invariant2(
              routeModule,
              "No `routeModule` available for critical-route action"
            );
            if (!routeModule.clientAction) {
              if (isSpaMode) {
                throw noActionDefinedError("clientAction", route.id);
              }
              return fetchServerAction(singleFetch);
            }
            return routeModule.clientAction({
              request,
              params,
              context,
              pattern,
              url,
              async serverAction() {
                preventInvalidServerHandlerCall("action", route);
                return fetchServerAction(singleFetch);
              }
            });
          });
        };
      } else {
        if (!route.hasClientLoader) {
          dataRoute.loader = (_, singleFetch) => prefetchStylesAndCallHandler(() => {
            return fetchServerLoader(singleFetch);
          });
        }
        if (!route.hasClientAction) {
          dataRoute.action = (_, singleFetch) => prefetchStylesAndCallHandler(() => {
            if (isSpaMode) {
              throw noActionDefinedError("clientAction", route.id);
            }
            return fetchServerAction(singleFetch);
          });
        }
        let lazyRoutePromise;
        async function getLazyRoute() {
          if (lazyRoutePromise) {
            return await lazyRoutePromise;
          }
          lazyRoutePromise = (async () => {
            if (route.clientLoaderModule || route.clientActionModule) {
              await new Promise((resolve) => setTimeout(resolve, 0));
            }
            let routeModulePromise = loadRouteModuleWithBlockingLinks(
              route,
              routeModulesCache
            );
            prefetchRouteModuleChunks(route);
            return await routeModulePromise;
          })();
          return await lazyRoutePromise;
        }
        dataRoute.lazy = {
          loader: route.hasClientLoader ? async () => {
            let { clientLoader } = route.clientLoaderModule ? await Promise.resolve().then(() => _interopRequireWildcard(commonjsRequire(
              /* @vite-ignore */
              /* webpackIgnore: true */
              route.clientLoaderModule
            ))) : await getLazyRoute();
            invariant2(clientLoader, "No `clientLoader` export found");
            return (args, singleFetch) => clientLoader({
              ...args,
              async serverLoader() {
                preventInvalidServerHandlerCall("loader", route);
                return fetchServerLoader(singleFetch);
              }
            });
          } : void 0,
          action: route.hasClientAction ? async () => {
            let clientActionPromise = route.clientActionModule ? Promise.resolve().then(() => _interopRequireWildcard(commonjsRequire(
              /* @vite-ignore */
              /* webpackIgnore: true */
              route.clientActionModule
            ))) : getLazyRoute();
            prefetchRouteModuleChunks(route);
            let { clientAction } = await clientActionPromise;
            invariant2(clientAction, "No `clientAction` export found");
            return (args, singleFetch) => clientAction({
              ...args,
              async serverAction() {
                preventInvalidServerHandlerCall("action", route);
                return fetchServerAction(singleFetch);
              }
            });
          } : void 0,
          middleware: route.hasClientMiddleware ? async () => {
            let { clientMiddleware } = route.clientMiddlewareModule ? await Promise.resolve().then(() => _interopRequireWildcard(commonjsRequire(
              /* @vite-ignore */
              /* webpackIgnore: true */
              route.clientMiddlewareModule
            ))) : await getLazyRoute();
            invariant2(clientMiddleware, "No `clientMiddleware` export found");
            return clientMiddleware;
          } : void 0,
          shouldRevalidate: async () => {
            let lazyRoute = await getLazyRoute();
            return getShouldRevalidateFunction(
              dataRoute.path,
              lazyRoute,
              route,
              ssr,
              needsRevalidation
            );
          },
          handle: async () => (await getLazyRoute()).handle,
          // No need to wrap these in layout since the root route is never
          // loaded via route.lazy()
          Component: async () => (await getLazyRoute()).Component,
          ErrorBoundary: route.hasErrorBoundary ? async () => (await getLazyRoute()).ErrorBoundary : void 0
        };
      }
      let children = createClientRoutes(
        manifest,
        routeModulesCache,
        initialState,
        ssr,
        isSpaMode,
        route.id,
        routesByParentId,
        needsRevalidation
      );
      if (children.length > 0) dataRoute.children = children;
      return dataRoute;
    });
  }
  function getShouldRevalidateFunction(path, route, manifestRoute, ssr, needsRevalidation) {
    if (needsRevalidation) {
      return wrapShouldRevalidateForHdr(
        manifestRoute.id,
        route.shouldRevalidate,
        needsRevalidation
      );
    }
    if (!ssr && manifestRoute.hasLoader && !manifestRoute.hasClientLoader) {
      let myParams = path ? compilePath(path)[1].map((p) => p.paramName) : [];
      const didParamsChange = (opts) => myParams.some((p) => opts.currentParams[p] !== opts.nextParams[p]);
      if (route.shouldRevalidate) {
        let fn = route.shouldRevalidate;
        return (opts) => fn({
          ...opts,
          defaultShouldRevalidate: didParamsChange(opts)
        });
      } else {
        return (opts) => didParamsChange(opts);
      }
    }
    return route.shouldRevalidate;
  }
  function wrapShouldRevalidateForHdr(routeId, routeShouldRevalidate, needsRevalidation) {
    let handledRevalidation = false;
    return (arg) => {
      if (!handledRevalidation) {
        handledRevalidation = true;
        return needsRevalidation.has(routeId);
      }
      return routeShouldRevalidate ? routeShouldRevalidate(arg) : arg.defaultShouldRevalidate;
    };
  }
  async function loadRouteModuleWithBlockingLinks(route, routeModules) {
    let routeModulePromise = loadRouteModule(route, routeModules);
    let prefetchRouteCssPromise = prefetchRouteCss(route);
    let routeModule = await routeModulePromise;
    await Promise.all([
      prefetchRouteCssPromise,
      prefetchStyleLinks(route, routeModule)
    ]);
    return {
      Component: getRouteModuleComponent(routeModule),
      ErrorBoundary: routeModule.ErrorBoundary,
      clientMiddleware: routeModule.clientMiddleware,
      clientAction: routeModule.clientAction,
      clientLoader: routeModule.clientLoader,
      handle: routeModule.handle,
      links: routeModule.links,
      meta: routeModule.meta,
      shouldRevalidate: routeModule.shouldRevalidate
    };
  }
  function getRouteModuleComponent(routeModule) {
    if (routeModule.default == null) return void 0;
    let isEmptyObject = typeof routeModule.default === "object" && Object.keys(routeModule.default).length === 0;
    if (!isEmptyObject) {
      return routeModule.default;
    }
  }
  function shouldHydrateRouteLoader(routeId, clientLoader, hasLoader, isSpaMode) {
    return isSpaMode && routeId !== "root" || clientLoader != null && (clientLoader.hydrate === true || hasLoader !== true);
  }
  var nextPaths = /* @__PURE__ */ new Set();
  var discoveredPathsMaxSize = 1e3;
  var discoveredPaths = /* @__PURE__ */ new Set();
  var URL_LIMIT = 7680;
  function getPathsWithAncestors(paths) {
    let result = /* @__PURE__ */ new Set();
    paths.forEach((path) => {
      if (!path.startsWith("/")) {
        path = `/${path}`;
      }
      for (let i = 1; i < path.length; i++) {
        if (path[i] === "/") {
          result.add(path.slice(0, i));
        }
      }
      result.add(path);
    });
    return Array.from(result);
  }
  function isFogOfWarEnabled(routeDiscovery, ssr) {
    return routeDiscovery.mode === "lazy" && ssr === true;
  }
  function getPartialManifest({ sri, ...manifest }, router) {
    let routeIds = new Set(router.state.matches.map((m) => m.route.id));
    let segments = router.state.location.pathname.split("/").filter(Boolean);
    let paths = ["/"];
    segments.pop();
    while (segments.length > 0) {
      paths.push(`/${segments.join("/")}`);
      segments.pop();
    }
    paths.forEach((path) => {
      let matches = matchRoutesImpl(
        router.routes,
        path,
        router.basename || "/",
        false,
        router.branches
      );
      if (matches) {
        matches.forEach((m) => routeIds.add(m.route.id));
      }
    });
    let initialRoutes = [...routeIds].reduce(
      (acc, id) => Object.assign(acc, { [id]: manifest.routes[id] }),
      {}
    );
    return {
      ...manifest,
      routes: initialRoutes,
      sri: sri ? true : void 0
    };
  }
  function getPatchRoutesOnNavigationFunction(getRouter, manifest, routeModules, ssr, routeDiscovery, isSpaMode, basename) {
    if (!isFogOfWarEnabled(routeDiscovery, ssr)) {
      return void 0;
    }
    return async ({ path, patch, signal, fetcherKey }) => {
      if (discoveredPaths.has(path)) {
        return;
      }
      let { state } = getRouter();
      await fetchAndApplyManifestPatches(
        [path],
        // If we're patching for a fetcher call, reload the current location
        // Otherwise prefer any ongoing navigation location
        fetcherKey ? window.location.href : createPath(state.navigation.location || state.location),
        manifest,
        routeModules,
        ssr,
        isSpaMode,
        basename,
        routeDiscovery.manifestPath,
        patch,
        signal
      );
    };
  }
  function useFogOFWarDiscovery(router, manifest, routeModules, ssr, routeDiscovery, isSpaMode) {
    React6.useEffect(() => {
      if (!isFogOfWarEnabled(routeDiscovery, ssr) || // @ts-expect-error - TS doesn't know about this yet
      _optionalChain([window, "access", (_123) => _123.navigator, "optionalAccess", (_124) => _124.connection, "optionalAccess", (_125) => _125.saveData]) === true) {
        return;
      }
      function registerElement(el) {
        let path = el.tagName === "FORM" ? el.getAttribute("action") : el.getAttribute("href");
        if (!path) {
          return;
        }
        let pathname = el.tagName === "A" ? el.pathname : new URL(path, window.location.origin).pathname;
        if (!discoveredPaths.has(pathname)) {
          nextPaths.add(pathname);
        }
      }
      async function fetchPatches() {
        document.querySelectorAll("a[data-discover], form[data-discover]").forEach(registerElement);
        let lazyPaths = Array.from(nextPaths.keys()).filter((path) => {
          if (discoveredPaths.has(path)) {
            nextPaths.delete(path);
            return false;
          }
          return true;
        });
        if (lazyPaths.length === 0) {
          return;
        }
        try {
          await fetchAndApplyManifestPatches(
            lazyPaths,
            null,
            manifest,
            routeModules,
            ssr,
            isSpaMode,
            router.basename,
            routeDiscovery.manifestPath,
            router.patchRoutes
          );
        } catch (e) {
          console.error("Failed to fetch manifest patches", e);
        }
      }
      let debouncedFetchPatches = debounce(fetchPatches, 100);
      fetchPatches();
      let observer = new MutationObserver(() => debouncedFetchPatches());
      observer.observe(document.documentElement, {
        subtree: true,
        childList: true,
        attributes: true,
        attributeFilter: ["data-discover", "href", "action"]
      });
      return () => observer.disconnect();
    }, [ssr, isSpaMode, manifest, routeModules, router, routeDiscovery]);
  }
  function getManifestPath(_manifestPath, basename) {
    let manifestPath = _manifestPath || "/__manifest";
    return basename == null ? manifestPath : joinPaths([basename, manifestPath]);
  }
  var MANIFEST_VERSION_STORAGE_KEY = "react-router-manifest-version";
  async function fetchAndApplyManifestPatches(paths, errorReloadPath, manifest, routeModules, ssr, isSpaMode, basename, manifestPath, patchRoutes, signal) {
    paths = getPathsWithAncestors(paths);
    const searchParams = new URLSearchParams();
    searchParams.set("paths", paths.sort().join(","));
    searchParams.set("version", manifest.version);
    let url = new URL(
      getManifestPath(manifestPath, basename),
      window.location.origin
    );
    url.search = searchParams.toString();
    if (url.toString().length > URL_LIMIT) {
      nextPaths.clear();
      return;
    }
    let serverPatches;
    try {
      let res = await fetch(url, { signal });
      if (!res.ok) {
        throw new Error(`${res.status} ${res.statusText}`);
      } else if (res.status === 204 && res.headers.has("X-Remix-Reload-Document")) {
        if (!errorReloadPath) {
          console.warn(
            "Detected a manifest version mismatch during eager route discovery. The next navigation/fetch to an undiscovered route will result in a new document navigation to sync up with the latest manifest."
          );
          return;
        }
        try {
          if (sessionStorage.getItem(MANIFEST_VERSION_STORAGE_KEY) === manifest.version) {
            console.error(
              "Unable to discover routes due to manifest version mismatch."
            );
            return;
          }
          sessionStorage.setItem(MANIFEST_VERSION_STORAGE_KEY, manifest.version);
        } catch (e7) {
        }
        window.location.href = errorReloadPath;
        console.warn("Detected manifest version mismatch, reloading...");
        await new Promise(() => {
        });
      } else if (res.status >= 400) {
        throw new Error(await res.text());
      }
      try {
        sessionStorage.removeItem(MANIFEST_VERSION_STORAGE_KEY);
      } catch (e8) {
      }
      serverPatches = await res.json();
    } catch (e) {
      if (_optionalChain([signal, "optionalAccess", (_126) => _126.aborted])) return;
      throw e;
    }
    let knownRoutes = new Set(Object.keys(manifest.routes));
    let patches = Object.values(serverPatches).reduce((acc, route) => {
      if (route && !knownRoutes.has(route.id)) {
        acc[route.id] = route;
      }
      return acc;
    }, {});
    Object.assign(manifest.routes, patches);
    paths.forEach((p) => addToFifoQueue(p, discoveredPaths));
    let parentIds = /* @__PURE__ */ new Set();
    Object.values(patches).forEach((patch) => {
      if (patch && (!patch.parentId || !patches[patch.parentId])) {
        parentIds.add(patch.parentId);
      }
    });
    parentIds.forEach(
      (parentId) => patchRoutes(
        parentId || null,
        createClientRoutes(patches, routeModules, null, ssr, isSpaMode, parentId)
      )
    );
  }
  function addToFifoQueue(path, queue) {
    if (queue.size >= discoveredPathsMaxSize) {
      let first = queue.values().next().value;
      queue.delete(first);
    }
    queue.add(path);
  }
  function debounce(callback, wait) {
    let timeoutId;
    return (...args) => {
      window.clearTimeout(timeoutId);
      timeoutId = window.setTimeout(() => callback(...args), wait);
    };
  }
  function useDataRouterContext2() {
    let context = React7.useContext(DataRouterContext);
    invariant2(
      context,
      "You must render this element inside a <DataRouterContext.Provider> element"
    );
    return context;
  }
  function useDataRouterStateContext() {
    let context = React7.useContext(DataRouterStateContext);
    invariant2(
      context,
      "You must render this element inside a <DataRouterStateContext.Provider> element"
    );
    return context;
  }
  var FrameworkContext = React7.createContext(void 0);
  FrameworkContext.displayName = "FrameworkContext";
  function useFrameworkContext() {
    let context = React7.useContext(FrameworkContext);
    invariant2(
      context,
      "You must render this element inside a <HydratedRouter> element"
    );
    return context;
  }
  function usePrefetchBehavior(prefetch, theirElementProps) {
    let frameworkContext = React7.useContext(FrameworkContext);
    let [maybePrefetch, setMaybePrefetch] = React7.useState(false);
    let [shouldPrefetch, setShouldPrefetch] = React7.useState(false);
    let { onFocus, onBlur, onMouseEnter, onMouseLeave, onTouchStart } = theirElementProps;
    let ref = React7.useRef(null);
    React7.useEffect(() => {
      if (prefetch === "render") {
        setShouldPrefetch(true);
      }
      if (prefetch === "viewport") {
        let callback = (entries) => {
          entries.forEach((entry) => {
            setShouldPrefetch(entry.isIntersecting);
          });
        };
        let observer = new IntersectionObserver(callback, { threshold: 0.5 });
        if (ref.current) observer.observe(ref.current);
        return () => {
          observer.disconnect();
        };
      }
    }, [prefetch]);
    React7.useEffect(() => {
      if (maybePrefetch) {
        let id = setTimeout(() => {
          setShouldPrefetch(true);
        }, 100);
        return () => {
          clearTimeout(id);
        };
      }
    }, [maybePrefetch]);
    let setIntent = () => {
      setMaybePrefetch(true);
    };
    let cancelIntent = () => {
      setMaybePrefetch(false);
      setShouldPrefetch(false);
    };
    if (!frameworkContext) {
      return [false, ref, {}];
    }
    if (prefetch !== "intent") {
      return [shouldPrefetch, ref, {}];
    }
    return [
      shouldPrefetch,
      ref,
      {
        onFocus: composeEventHandlers(onFocus, setIntent),
        onBlur: composeEventHandlers(onBlur, cancelIntent),
        onMouseEnter: composeEventHandlers(onMouseEnter, setIntent),
        onMouseLeave: composeEventHandlers(onMouseLeave, cancelIntent),
        onTouchStart: composeEventHandlers(onTouchStart, setIntent)
      }
    ];
  }
  function composeEventHandlers(theirHandler, ourHandler) {
    return (event) => {
      theirHandler && theirHandler(event);
      if (!event.defaultPrevented) {
        ourHandler(event);
      }
    };
  }
  function getActiveMatches(matches, errors, isSpaMode) {
    if (isSpaMode && !isHydrated) {
      return [matches[0]];
    }
    if (errors) {
      let errorIdx = matches.findIndex((m) => errors[m.route.id] !== void 0);
      return matches.slice(0, errorIdx + 1);
    }
    return matches;
  }
  var CRITICAL_CSS_DATA_ATTRIBUTE = "data-react-router-critical-css";
  function Links({ nonce, crossOrigin }) {
    let {
      isSpaMode,
      manifest,
      routeModules,
      criticalCss,
      nonce: contextNonce
    } = useFrameworkContext();
    let { errors, matches: routerMatches } = useDataRouterStateContext();
    let matches = getActiveMatches(routerMatches, errors, isSpaMode);
    let keyedLinks = React7.useMemo(
      () => getKeyedLinksForMatches(matches, routeModules, manifest),
      [matches, routeModules, manifest]
    );
    if (nonce == null && contextNonce) {
      nonce = contextNonce;
    }
    return /* @__PURE__ */ React7.createElement(React7.Fragment, null, typeof criticalCss === "string" ? /* @__PURE__ */ React7.createElement(
      "style",
      {
        ...{ [CRITICAL_CSS_DATA_ATTRIBUTE]: "" },
        nonce,
        dangerouslySetInnerHTML: { __html: criticalCss }
      }
    ) : null, typeof criticalCss === "object" ? /* @__PURE__ */ React7.createElement(
      "link",
      {
        ...{ [CRITICAL_CSS_DATA_ATTRIBUTE]: "" },
        rel: "stylesheet",
        href: criticalCss.href,
        nonce,
        crossOrigin
      }
    ) : null, keyedLinks.map(
      ({ key, link }) => isPageLinkDescriptor(link) ? /* @__PURE__ */ React7.createElement(
        PrefetchPageLinks,
        {
          key,
          nonce,
          ...link,
          crossOrigin: _nullishCoalesce(link.crossOrigin, () => crossOrigin)
        }
      ) : /* @__PURE__ */ React7.createElement(
        "link",
        {
          key,
          nonce,
          ...link,
          crossOrigin: _nullishCoalesce(link.crossOrigin, () => crossOrigin)
        }
      )
    ));
  }
  function PrefetchPageLinks({ page, ...linkProps }) {
    let rsc = useIsRSCRouterContext();
    let { nonce: contextNonce } = useFrameworkContext();
    let { router } = useDataRouterContext2();
    let matches = React7.useMemo(
      () => matchRoutes(router.routes, page, router.basename),
      [router.routes, page, router.basename]
    );
    if (!matches) {
      return null;
    }
    if (linkProps.nonce == null && contextNonce) {
      linkProps = { ...linkProps, nonce: contextNonce };
    }
    if (rsc) {
      return /* @__PURE__ */ React7.createElement(RSCPrefetchPageLinksImpl, { page, matches, ...linkProps });
    }
    return /* @__PURE__ */ React7.createElement(PrefetchPageLinksImpl, { page, matches, ...linkProps });
  }
  function useKeyedPrefetchLinks(matches) {
    let { manifest, routeModules } = useFrameworkContext();
    let [keyedPrefetchLinks, setKeyedPrefetchLinks] = React7.useState([]);
    React7.useEffect(() => {
      let interrupted = false;
      void getKeyedPrefetchLinks(matches, manifest, routeModules).then(
        (links) => {
          if (!interrupted) {
            setKeyedPrefetchLinks(links);
          }
        }
      );
      return () => {
        interrupted = true;
      };
    }, [matches, manifest, routeModules]);
    return keyedPrefetchLinks;
  }
  function RSCPrefetchPageLinksImpl({
    page,
    matches: nextMatches,
    ...linkProps
  }) {
    let location2 = useLocation();
    let { future } = useFrameworkContext();
    let { basename } = useDataRouterContext2();
    let dataHrefs = React7.useMemo(() => {
      if (page === location2.pathname + location2.search + location2.hash) {
        return [];
      }
      let url = singleFetchUrl(
        page,
        basename,
        future.v8_trailingSlashAwareDataRequests,
        "rsc"
      );
      let hasSomeRoutesWithShouldRevalidate = false;
      let targetRoutes = [];
      for (let match of nextMatches) {
        if (typeof match.route.shouldRevalidate === "function") {
          hasSomeRoutesWithShouldRevalidate = true;
        } else {
          targetRoutes.push(match.route.id);
        }
      }
      if (hasSomeRoutesWithShouldRevalidate && targetRoutes.length > 0) {
        url.searchParams.set("_routes", targetRoutes.join(","));
      }
      return [url.pathname + url.search];
    }, [
      basename,
      future.v8_trailingSlashAwareDataRequests,
      page,
      location2,
      nextMatches
    ]);
    return /* @__PURE__ */ React7.createElement(React7.Fragment, null, dataHrefs.map((href) => /* @__PURE__ */ React7.createElement("link", { key: href, rel: "prefetch", as: "fetch", href, ...linkProps })));
  }
  function PrefetchPageLinksImpl({
    page,
    matches: nextMatches,
    ...linkProps
  }) {
    let location2 = useLocation();
    let { future, manifest, routeModules } = useFrameworkContext();
    let { basename } = useDataRouterContext2();
    let { loaderData, matches } = useDataRouterStateContext();
    let newMatchesForData = React7.useMemo(
      () => getNewMatchesForLinks(
        page,
        nextMatches,
        matches,
        manifest,
        location2,
        "data"
      ),
      [page, nextMatches, matches, manifest, location2]
    );
    let newMatchesForAssets = React7.useMemo(
      () => getNewMatchesForLinks(
        page,
        nextMatches,
        matches,
        manifest,
        location2,
        "assets"
      ),
      [page, nextMatches, matches, manifest, location2]
    );
    let dataHrefs = React7.useMemo(() => {
      if (page === location2.pathname + location2.search + location2.hash) {
        return [];
      }
      let routesParams = /* @__PURE__ */ new Set();
      let foundOptOutRoute = false;
      nextMatches.forEach((m) => {
        let manifestRoute = manifest.routes[m.route.id];
        if (!manifestRoute || !manifestRoute.hasLoader) {
          return;
        }
        if (!newMatchesForData.some((m2) => m2.route.id === m.route.id) && m.route.id in loaderData && _optionalChain([routeModules, "access", (_127) => _127[m.route.id], "optionalAccess", (_128) => _128.shouldRevalidate])) {
          foundOptOutRoute = true;
        } else if (manifestRoute.hasClientLoader) {
          foundOptOutRoute = true;
        } else {
          routesParams.add(m.route.id);
        }
      });
      if (routesParams.size === 0) {
        return [];
      }
      let url = singleFetchUrl(
        page,
        basename,
        future.v8_trailingSlashAwareDataRequests,
        "data"
      );
      if (foundOptOutRoute && routesParams.size > 0) {
        url.searchParams.set(
          "_routes",
          nextMatches.filter((m) => routesParams.has(m.route.id)).map((m) => m.route.id).join(",")
        );
      }
      return [url.pathname + url.search];
    }, [
      basename,
      future.v8_trailingSlashAwareDataRequests,
      loaderData,
      location2,
      manifest,
      newMatchesForData,
      nextMatches,
      page,
      routeModules
    ]);
    let moduleHrefs = React7.useMemo(
      () => getModuleLinkHrefs(newMatchesForAssets, manifest),
      [newMatchesForAssets, manifest]
    );
    let keyedPrefetchLinks = useKeyedPrefetchLinks(newMatchesForAssets);
    return /* @__PURE__ */ React7.createElement(React7.Fragment, null, dataHrefs.map((href) => /* @__PURE__ */ React7.createElement("link", { key: href, rel: "prefetch", as: "fetch", href, ...linkProps })), moduleHrefs.map((href) => /* @__PURE__ */ React7.createElement("link", { key: href, rel: "modulepreload", href, ...linkProps })), keyedPrefetchLinks.map(({ key, link }) => (
      // these don't spread `linkProps` because they are full link descriptors
      // already with their own props
      /* @__PURE__ */ React7.createElement(
        "link",
        {
          key,
          nonce: linkProps.nonce,
          ...link,
          crossOrigin: _nullishCoalesce(link.crossOrigin, () => linkProps.crossOrigin)
        }
      )
    )));
  }
  function Meta() {
    let { isSpaMode, routeModules } = useFrameworkContext();
    let {
      errors,
      matches: routerMatches,
      loaderData
    } = useDataRouterStateContext();
    let location2 = useLocation();
    let _matches = getActiveMatches(routerMatches, errors, isSpaMode);
    let error = null;
    if (errors) {
      error = errors[_matches[_matches.length - 1].route.id];
    }
    let meta = [];
    let leafMeta = null;
    let matches = [];
    for (let i = 0; i < _matches.length; i++) {
      let _match = _matches[i];
      let routeId = _match.route.id;
      let data2 = loaderData[routeId];
      let params = _match.params;
      let routeModule = routeModules[routeId];
      let routeMeta = [];
      let match = {
        id: routeId,
        data: data2,
        loaderData: data2,
        meta: [],
        params: _match.params,
        pathname: _match.pathname,
        handle: _match.route.handle,
        error
      };
      matches[i] = match;
      if (_optionalChain([routeModule, "optionalAccess", (_129) => _129.meta])) {
        routeMeta = typeof routeModule.meta === "function" ? routeModule.meta({
          data: data2,
          loaderData: data2,
          params,
          location: location2,
          matches,
          error
        }) : Array.isArray(routeModule.meta) ? [...routeModule.meta] : routeModule.meta;
      } else if (leafMeta) {
        routeMeta = [...leafMeta];
      }
      routeMeta = routeMeta || [];
      if (!Array.isArray(routeMeta)) {
        throw new Error(
          "The route at " + _match.route.path + " returns an invalid value. All route meta functions must return an array of meta objects.\n\nTo reference the meta function API, see https://reactrouter.com/start/framework/route-module#meta"
        );
      }
      match.meta = routeMeta;
      matches[i] = match;
      meta = [...routeMeta];
      leafMeta = meta;
    }
    return /* @__PURE__ */ React7.createElement(React7.Fragment, null, meta.flat().map((metaProps) => {
      if (!metaProps) {
        return null;
      }
      if ("tagName" in metaProps) {
        let { tagName, ...rest } = metaProps;
        if (!isValidMetaTag(tagName)) {
          console.warn(
            `A meta object uses an invalid tagName: ${tagName}. Expected either 'link' or 'meta'`
          );
          return null;
        }
        let Comp = tagName;
        return /* @__PURE__ */ React7.createElement(Comp, { key: JSON.stringify(rest), ...rest });
      }
      if ("title" in metaProps) {
        return /* @__PURE__ */ React7.createElement("title", { key: "title" }, String(metaProps.title));
      }
      if ("charset" in metaProps) {
        _nullishCoalesce(metaProps.charSet, () => metaProps.charSet = metaProps.charset);
        delete metaProps.charset;
      }
      if ("charSet" in metaProps && metaProps.charSet != null) {
        return typeof metaProps.charSet === "string" ? /* @__PURE__ */ React7.createElement("meta", { key: "charSet", charSet: metaProps.charSet }) : null;
      }
      if ("script:ld+json" in metaProps) {
        try {
          let json = JSON.stringify(metaProps["script:ld+json"]);
          return /* @__PURE__ */ React7.createElement(
            "script",
            {
              key: `script:ld+json:${json}`,
              type: "application/ld+json",
              dangerouslySetInnerHTML: { __html: escapeHtml(json) }
            }
          );
        } catch (e) {
          return null;
        }
      }
      return /* @__PURE__ */ React7.createElement("meta", { key: JSON.stringify(metaProps), ...metaProps });
    }));
  }
  function isValidMetaTag(tagName) {
    return typeof tagName === "string" && /^(meta|link)$/.test(tagName);
  }
  var isHydrated = false;
  function setIsHydrated() {
    isHydrated = true;
  }
  function Scripts(scriptProps) {
    let {
      manifest,
      serverHandoffString,
      isSpaMode,
      renderMeta,
      routeDiscovery,
      ssr,
      nonce: contextNonce
    } = useFrameworkContext();
    let { router, static: isStatic, staticContext } = useDataRouterContext2();
    let { matches: routerMatches } = useDataRouterStateContext();
    let isRSCRouterContext = useIsRSCRouterContext();
    let enableFogOfWar = isFogOfWarEnabled(routeDiscovery, ssr);
    if (scriptProps.nonce == null && contextNonce) {
      scriptProps = { ...scriptProps, nonce: contextNonce };
    }
    if (renderMeta) {
      renderMeta.didRenderScripts = true;
    }
    let matches = getActiveMatches(routerMatches, null, isSpaMode);
    React7.useEffect(() => {
      setIsHydrated();
    }, []);
    let initialScripts = React7.useMemo(() => {
      if (isRSCRouterContext) {
        return null;
      }
      let streamScript = "window.__reactRouterContext.stream = new ReadableStream({start(controller){window.__reactRouterContext.streamController = controller;}}).pipeThrough(new TextEncoderStream());";
      let contextScript = staticContext ? `window.__reactRouterContext = ${serverHandoffString};${streamScript}` : " ";
      let routeModulesScript = !isStatic ? " " : `${_optionalChain([manifest, "access", (_130) => _130.hmr, "optionalAccess", (_131) => _131.runtime]) ? `import ${JSON.stringify(manifest.hmr.runtime)};` : ""}${!enableFogOfWar ? `import ${JSON.stringify(manifest.url)}` : ""};
${matches.map((match, routeIndex) => {
        let routeVarName = `route${routeIndex}`;
        let manifestEntry = manifest.routes[match.route.id];
        invariant2(manifestEntry, `Route ${match.route.id} not found in manifest`);
        let {
          clientActionModule,
          clientLoaderModule,
          clientMiddlewareModule,
          hydrateFallbackModule,
          module
        } = manifestEntry;
        let chunks = [
          ...clientActionModule ? [
            {
              module: clientActionModule,
              varName: `${routeVarName}_clientAction`
            }
          ] : [],
          ...clientLoaderModule ? [
            {
              module: clientLoaderModule,
              varName: `${routeVarName}_clientLoader`
            }
          ] : [],
          ...clientMiddlewareModule ? [
            {
              module: clientMiddlewareModule,
              varName: `${routeVarName}_clientMiddleware`
            }
          ] : [],
          ...hydrateFallbackModule ? [
            {
              module: hydrateFallbackModule,
              varName: `${routeVarName}_HydrateFallback`
            }
          ] : [],
          { module, varName: `${routeVarName}_main` }
        ];
        if (chunks.length === 1) {
          return `import * as ${routeVarName} from ${JSON.stringify(module)};`;
        }
        let chunkImportsSnippet = chunks.map((chunk) => `import * as ${chunk.varName} from "${chunk.module}";`).join("\n");
        let mergedChunksSnippet = `const ${routeVarName} = {${chunks.map((chunk) => `...${chunk.varName}`).join(",")}};`;
        return [chunkImportsSnippet, mergedChunksSnippet].join("\n");
      }).join("\n")}
  ${enableFogOfWar ? (
        // Inline a minimal manifest with the SSR matches
        `window.__reactRouterManifest = ${JSON.stringify(
          getPartialManifest(manifest, router),
          null,
          2
        )};`
      ) : ""}
  window.__reactRouterRouteModules = {${matches.map((match, index) => `${JSON.stringify(match.route.id)}:route${index}`).join(",")}};

import(${JSON.stringify(manifest.entry.module)});`;
      return /* @__PURE__ */ React7.createElement(React7.Fragment, null, /* @__PURE__ */ React7.createElement(
        "script",
        {
          ...scriptProps,
          suppressHydrationWarning: true,
          dangerouslySetInnerHTML: { __html: contextScript },
          type: void 0
        }
      ), /* @__PURE__ */ React7.createElement(
        "script",
        {
          ...scriptProps,
          suppressHydrationWarning: true,
          dangerouslySetInnerHTML: { __html: routeModulesScript },
          type: "module",
          async: true
        }
      ));
    }, []);
    let preloads = isHydrated || isRSCRouterContext ? [] : [
      // Dedupe through a Set
      ...new Set(
        manifest.entry.imports.concat(
          getModuleLinkHrefs(matches, manifest, {
            includeHydrateFallback: true
          })
        )
      )
    ];
    let sri = typeof manifest.sri === "object" ? manifest.sri : {};
    warnOnce(
      !isRSCRouterContext,
      "The <Scripts /> element is a no-op when using RSC and can be safely removed."
    );
    return isHydrated || isRSCRouterContext ? null : /* @__PURE__ */ React7.createElement(React7.Fragment, null, typeof manifest.sri === "object" ? /* @__PURE__ */ React7.createElement(
      "script",
      {
        ...scriptProps,
        "rr-importmap": "",
        type: "importmap",
        suppressHydrationWarning: true,
        dangerouslySetInnerHTML: {
          __html: JSON.stringify({
            integrity: sri
          })
        }
      }
    ) : null, !enableFogOfWar ? /* @__PURE__ */ React7.createElement(
      "link",
      {
        rel: "modulepreload",
        href: manifest.url,
        crossOrigin: scriptProps.crossOrigin,
        integrity: sri[manifest.url],
        nonce: scriptProps.nonce,
        suppressHydrationWarning: true
      }
    ) : null, /* @__PURE__ */ React7.createElement(
      "link",
      {
        rel: "modulepreload",
        href: manifest.entry.module,
        crossOrigin: scriptProps.crossOrigin,
        integrity: sri[manifest.entry.module],
        nonce: scriptProps.nonce,
        suppressHydrationWarning: true
      }
    ), preloads.map((path) => /* @__PURE__ */ React7.createElement(
      "link",
      {
        key: path,
        rel: "modulepreload",
        href: path,
        crossOrigin: scriptProps.crossOrigin,
        integrity: sri[path],
        nonce: scriptProps.nonce,
        suppressHydrationWarning: true
      }
    )), initialScripts);
  }
  function mergeRefs(...refs) {
    return (value) => {
      refs.forEach((ref) => {
        if (typeof ref === "function") {
          ref(value);
        } else if (ref != null) {
          ref.current = value;
        }
      });
    };
  }
  var RemixErrorBoundary = class extends React8.Component {
    constructor(props) {
      super(props);
      this.state = { error: props.error || null, location: props.location };
    }
    static getDerivedStateFromError(error) {
      return { error };
    }
    static getDerivedStateFromProps(props, state) {
      if (state.location !== props.location) {
        return { error: props.error || null, location: props.location };
      }
      return { error: props.error || state.error, location: state.location };
    }
    render() {
      if (this.state.error) {
        return /* @__PURE__ */ React8.createElement(
          RemixRootDefaultErrorBoundary,
          {
            error: this.state.error,
            isOutsideRemixApp: true
          }
        );
      } else {
        return this.props.children;
      }
    }
  };
  function RemixRootDefaultErrorBoundary({
    error,
    isOutsideRemixApp
  }) {
    let { nonce } = useFrameworkContext();
    console.error(error);
    let heyDeveloper = /* @__PURE__ */ React8.createElement(
      "script",
      {
        nonce,
        dangerouslySetInnerHTML: {
          __html: `
        console.log(
          "💿 Hey developer 👋. You can provide a way better UX than this when your app throws errors. Check out https://reactrouter.com/how-to/error-boundary for more information."
        );
      `
        }
      }
    );
    if (isRouteErrorResponse(error)) {
      return /* @__PURE__ */ React8.createElement(BoundaryShell, { title: "Unhandled Thrown Response!" }, /* @__PURE__ */ React8.createElement("h1", { style: { fontSize: "24px" } }, error.status, " ", error.statusText), heyDeveloper);
    }
    let errorInstance;
    if (error instanceof Error) {
      errorInstance = error;
    } else {
      let errorString = error == null ? "Unknown Error" : typeof error === "object" && "toString" in error ? error.toString() : JSON.stringify(error);
      errorInstance = new Error(errorString);
    }
    return /* @__PURE__ */ React8.createElement(
      BoundaryShell,
      {
        title: "Application Error!",
        isOutsideRemixApp
      },
      /* @__PURE__ */ React8.createElement("h1", { style: { fontSize: "24px" } }, "Application Error"),
      /* @__PURE__ */ React8.createElement(
        "pre",
        {
          style: {
            padding: "2rem",
            background: "hsla(10, 50%, 50%, 0.1)",
            color: "red",
            overflow: "auto"
          }
        },
        errorInstance.stack
      ),
      heyDeveloper
    );
  }
  function BoundaryShell({
    title,
    renderScripts,
    isOutsideRemixApp,
    children
  }) {
    let { routeModules } = useFrameworkContext();
    if (_optionalChain([routeModules, "access", (_132) => _132.root, "optionalAccess", (_133) => _133.Layout]) && !isOutsideRemixApp) {
      return children;
    }
    return /* @__PURE__ */ React8.createElement("html", { lang: "en" }, /* @__PURE__ */ React8.createElement("head", null, /* @__PURE__ */ React8.createElement("meta", { charSet: "utf-8" }), /* @__PURE__ */ React8.createElement(
      "meta",
      {
        name: "viewport",
        content: "width=device-width,initial-scale=1,viewport-fit=cover"
      }
    ), /* @__PURE__ */ React8.createElement("title", null, title)), /* @__PURE__ */ React8.createElement("body", null, /* @__PURE__ */ React8.createElement("main", { style: { fontFamily: "system-ui, sans-serif", padding: "2rem" } }, children, renderScripts ? /* @__PURE__ */ React8.createElement(Scripts, null) : null)));
  }
  var USE_OPTIMISTIC = "useOptimistic";
  var useOptimisticImpl = React9[USE_OPTIMISTIC];
  var stableUseOptimisticSetter = () => void 0;
  function useOptimisticSafe(val) {
    if (useOptimisticImpl) {
      return useOptimisticImpl(val);
    } else {
      return [val, stableUseOptimisticSetter];
    }
  }
  function mapRouteProperties(route) {
    let updates = {
      // Note: this check also occurs in createRoutesFromChildren so update
      // there if you change this -- please and thank you!
      hasErrorBoundary: route.hasErrorBoundary || route.ErrorBoundary != null || route.errorElement != null
    };
    if (route.Component) {
      {
        if (route.element) {
          warning(
            false,
            "You should not include both `Component` and `element` on your route - `Component` will be used."
          );
        }
      }
      Object.assign(updates, {
        element: React9.createElement(route.Component),
        Component: void 0
      });
    }
    if (route.HydrateFallback) {
      {
        if (route.hydrateFallbackElement) {
          warning(
            false,
            "You should not include both `HydrateFallback` and `hydrateFallbackElement` on your route - `HydrateFallback` will be used."
          );
        }
      }
      Object.assign(updates, {
        hydrateFallbackElement: React9.createElement(route.HydrateFallback),
        HydrateFallback: void 0
      });
    }
    if (route.ErrorBoundary) {
      {
        if (route.errorElement) {
          warning(
            false,
            "You should not include both `ErrorBoundary` and `errorElement` on your route - `ErrorBoundary` will be used."
          );
        }
      }
      Object.assign(updates, {
        errorElement: React9.createElement(route.ErrorBoundary),
        ErrorBoundary: void 0
      });
    }
    return updates;
  }
  var hydrationRouteProperties = [
    "HydrateFallback",
    "hydrateFallbackElement"
  ];
  function createMemoryRouter(routes, opts) {
    return createRouter({
      basename: _optionalChain([opts, "optionalAccess", (_134) => _134.basename]),
      getContext: _optionalChain([opts, "optionalAccess", (_135) => _135.getContext]),
      future: _optionalChain([opts, "optionalAccess", (_136) => _136.future]),
      history: createMemoryHistory({
        initialEntries: _optionalChain([opts, "optionalAccess", (_137) => _137.initialEntries]),
        initialIndex: _optionalChain([opts, "optionalAccess", (_138) => _138.initialIndex])
      }),
      hydrationData: _optionalChain([opts, "optionalAccess", (_139) => _139.hydrationData]),
      routes,
      hydrationRouteProperties,
      mapRouteProperties,
      dataStrategy: _optionalChain([opts, "optionalAccess", (_140) => _140.dataStrategy]),
      patchRoutesOnNavigation: _optionalChain([opts, "optionalAccess", (_141) => _141.patchRoutesOnNavigation]),
      instrumentations: _optionalChain([opts, "optionalAccess", (_142) => _142.instrumentations])
    }).initialize();
  }
  var Deferred2 = class {
    constructor() {
      this.status = "pending";
      this.promise = new Promise((resolve, reject) => {
        this.resolve = (value) => {
          if (this.status === "pending") {
            this.status = "resolved";
            resolve(value);
          }
        };
        this.reject = (reason) => {
          if (this.status === "pending") {
            this.status = "rejected";
            reject(reason);
          }
        };
      });
    }
  };
  function RouterProvider({
    router,
    flushSync: reactDomFlushSyncImpl,
    onError,
    useTransitions
  }) {
    let unstable_rsc = useIsRSCRouterContext();
    useTransitions = unstable_rsc || useTransitions;
    let [_state, setStateImpl] = React9.useState(router.state);
    let [state, setOptimisticState] = useOptimisticSafe(_state);
    let [pendingState, setPendingState] = React9.useState();
    let [vtContext, setVtContext] = React9.useState({
      isTransitioning: false
    });
    let [renderDfd, setRenderDfd] = React9.useState();
    let [transition, setTransition] = React9.useState();
    let [interruption, setInterruption] = React9.useState();
    let fetcherData = React9.useRef(/* @__PURE__ */ new Map());
    let setState = React9.useCallback(
      (newState, { deletedFetchers, newErrors, flushSync, viewTransitionOpts }) => {
        if (newErrors && onError) {
          Object.values(newErrors).forEach(
            (error) => onError(error, {
              location: newState.location,
              params: _nullishCoalesce(_optionalChain([newState, "access", (_143) => _143.matches, "access", (_144) => _144[0], "optionalAccess", (_145) => _145.params]), () => ({})),
              pattern: getRoutePattern(newState.matches)
            })
          );
        }
        newState.fetchers.forEach((fetcher, key) => {
          if (fetcher.data !== void 0) {
            fetcherData.current.set(key, fetcher.data);
          }
        });
        deletedFetchers.forEach((key) => fetcherData.current.delete(key));
        warnOnce(
          flushSync === false || reactDomFlushSyncImpl != null,
          'You provided the `flushSync` option to a router update, but you are not using the `<RouterProvider>` from `react-router/dom` so `ReactDOM.flushSync()` is unavailable.  Please update your app to `import { RouterProvider } from "react-router/dom"` and ensure you have `react-dom` installed as a dependency to use the `flushSync` option.'
        );
        let isViewTransitionAvailable = router.window != null && router.window.document != null && typeof router.window.document.startViewTransition === "function";
        warnOnce(
          viewTransitionOpts == null || isViewTransitionAvailable,
          "You provided the `viewTransition` option to a router update, but you do not appear to be running in a DOM environment as `window.startViewTransition` is not available."
        );
        if (!viewTransitionOpts || !isViewTransitionAvailable) {
          if (reactDomFlushSyncImpl && flushSync) {
            reactDomFlushSyncImpl(() => setStateImpl(newState));
          } else if (useTransitions === false) {
            setStateImpl(newState);
          } else {
            React9.startTransition(() => {
              if (useTransitions === true) {
                setOptimisticState((s) => getOptimisticRouterState(s, newState));
              }
              setStateImpl(newState);
            });
          }
          return;
        }
        if (reactDomFlushSyncImpl && flushSync) {
          reactDomFlushSyncImpl(() => {
            if (transition) {
              _optionalChain([renderDfd, "optionalAccess", (_146) => _146.resolve, "call", (_147) => _147()]);
              transition.skipTransition();
            }
            setVtContext({
              isTransitioning: true,
              flushSync: true,
              currentLocation: viewTransitionOpts.currentLocation,
              nextLocation: viewTransitionOpts.nextLocation
            });
          });
          let t = router.window.document.startViewTransition(() => {
            reactDomFlushSyncImpl(() => setStateImpl(newState));
          });
          t.finished.finally(() => {
            reactDomFlushSyncImpl(() => {
              setRenderDfd(void 0);
              setTransition(void 0);
              setPendingState(void 0);
              setVtContext({ isTransitioning: false });
            });
          });
          reactDomFlushSyncImpl(() => setTransition(t));
          return;
        }
        if (transition) {
          _optionalChain([renderDfd, "optionalAccess", (_148) => _148.resolve, "call", (_149) => _149()]);
          transition.skipTransition();
          setInterruption({
            state: newState,
            currentLocation: viewTransitionOpts.currentLocation,
            nextLocation: viewTransitionOpts.nextLocation
          });
        } else {
          setPendingState(newState);
          setVtContext({
            isTransitioning: true,
            flushSync: false,
            currentLocation: viewTransitionOpts.currentLocation,
            nextLocation: viewTransitionOpts.nextLocation
          });
        }
      },
      [
        router.window,
        reactDomFlushSyncImpl,
        transition,
        renderDfd,
        useTransitions,
        setOptimisticState,
        onError
      ]
    );
    React9.useLayoutEffect(() => router.subscribe(setState), [router, setState]);
    React9.useEffect(() => {
      if (vtContext.isTransitioning && !vtContext.flushSync) {
        setRenderDfd(new Deferred2());
      }
    }, [vtContext]);
    React9.useEffect(() => {
      if (renderDfd && pendingState && router.window) {
        let newState = pendingState;
        let renderPromise = renderDfd.promise;
        let transition2 = router.window.document.startViewTransition(async () => {
          if (useTransitions === false) {
            setStateImpl(newState);
          } else {
            React9.startTransition(() => {
              if (useTransitions === true) {
                setOptimisticState((s) => getOptimisticRouterState(s, newState));
              }
              setStateImpl(newState);
            });
          }
          await renderPromise;
        });
        transition2.finished.finally(() => {
          setRenderDfd(void 0);
          setTransition(void 0);
          setPendingState(void 0);
          setVtContext({ isTransitioning: false });
        });
        setTransition(transition2);
      }
    }, [
      pendingState,
      renderDfd,
      router.window,
      useTransitions,
      setOptimisticState
    ]);
    React9.useEffect(() => {
      if (renderDfd && pendingState && state.location.key === pendingState.location.key) {
        renderDfd.resolve();
      }
    }, [renderDfd, transition, state.location, pendingState]);
    React9.useEffect(() => {
      if (!vtContext.isTransitioning && interruption) {
        setPendingState(interruption.state);
        setVtContext({
          isTransitioning: true,
          flushSync: false,
          currentLocation: interruption.currentLocation,
          nextLocation: interruption.nextLocation
        });
        setInterruption(void 0);
      }
    }, [vtContext.isTransitioning, interruption]);
    let navigator = React9.useMemo(() => {
      return {
        createHref: router.createHref,
        createURL: router.createURL,
        encodeLocation: router.encodeLocation,
        go: (n) => router.navigate(n),
        push: (to, state2, opts) => router.navigate(to, {
          state: state2,
          preventScrollReset: _optionalChain([opts, "optionalAccess", (_150) => _150.preventScrollReset])
        }),
        replace: (to, state2, opts) => router.navigate(to, {
          replace: true,
          state: state2,
          preventScrollReset: _optionalChain([opts, "optionalAccess", (_151) => _151.preventScrollReset])
        })
      };
    }, [router]);
    let basename = router.basename || "/";
    let dataRouterContext = React9.useMemo(
      () => ({
        router,
        navigator,
        static: false,
        basename,
        onError
      }),
      [router, navigator, basename, onError]
    );
    return /* @__PURE__ */ React9.createElement(React9.Fragment, null, /* @__PURE__ */ React9.createElement(DataRouterContext.Provider, { value: dataRouterContext }, /* @__PURE__ */ React9.createElement(DataRouterStateContext.Provider, { value: state }, /* @__PURE__ */ React9.createElement(FetchersContext.Provider, { value: fetcherData.current }, /* @__PURE__ */ React9.createElement(ViewTransitionContext.Provider, { value: vtContext }, /* @__PURE__ */ React9.createElement(
      Router,
      {
        basename,
        location: state.location,
        navigationType: state.historyAction,
        navigator,
        useTransitions
      },
      /* @__PURE__ */ React9.createElement(
        MemoizedDataRoutes,
        {
          routes: router.routes,
          manifest: router.manifest,
          future: router.future,
          state,
          isStatic: false,
          onError
        }
      )
    ))))), null);
  }
  function getOptimisticRouterState(currentState, newState) {
    return {
      // Don't surface "current location specific" stuff mid-navigation
      // (historyAction, location, matches, loaderData, errors, initialized,
      // restoreScroll, preventScrollReset, blockers, etc.)
      ...currentState,
      // Only surface "pending/in-flight stuff"
      // (navigation, revalidation, actionData, fetchers, )
      navigation: newState.navigation.state !== "idle" ? newState.navigation : currentState.navigation,
      revalidation: newState.revalidation !== "idle" ? newState.revalidation : currentState.revalidation,
      actionData: newState.navigation.state !== "submitting" ? newState.actionData : currentState.actionData,
      fetchers: newState.fetchers
    };
  }
  var MemoizedDataRoutes = React9.memo(DataRoutes2);
  function DataRoutes2({
    routes,
    manifest,
    future,
    state,
    isStatic,
    onError
  }) {
    return useRoutesImpl(routes, void 0, {
      manifest,
      state,
      isStatic,
      onError,
      future
    });
  }
  function MemoryRouter({
    basename,
    children,
    initialEntries,
    initialIndex,
    useTransitions
  }) {
    let historyRef = React9.useRef();
    if (historyRef.current == null) {
      historyRef.current = createMemoryHistory({
        initialEntries,
        initialIndex,
        v5Compat: true
      });
    }
    let history = historyRef.current;
    let [state, setStateImpl] = React9.useState({
      action: history.action,
      location: history.location
    });
    let setState = React9.useCallback(
      (newState) => {
        if (useTransitions === false) {
          setStateImpl(newState);
        } else {
          React9.startTransition(() => setStateImpl(newState));
        }
      },
      [useTransitions]
    );
    React9.useLayoutEffect(() => history.listen(setState), [history, setState]);
    return /* @__PURE__ */ React9.createElement(
      Router,
      {
        basename,
        children,
        location: state.location,
        navigationType: state.action,
        navigator: history,
        useTransitions
      }
    );
  }
  function Navigate({
    to,
    replace: replace2,
    state,
    relative
  }) {
    invariant(
      useInRouterContext(),
      // TODO: This error is probably because they somehow have 2 versions of
      // the router loaded. We can help them understand how to avoid that.
      `<Navigate> may be used only in the context of a <Router> component.`
    );
    let { static: isStatic, navigator } = React9.useContext(NavigationContext);
    warning(
      !isStatic,
      `<Navigate> must not be used on the initial render in a <StaticRouter>. This is a no-op, but you should modify your code so the <Navigate> is only ever rendered in response to some user interaction or state change.`
    );
    let { matches } = React9.useContext(RouteContext);
    let { pathname: locationPathname } = useLocation();
    let navigate = useNavigate();
    let path = resolveTo(
      to,
      getResolveToMatches(matches),
      locationPathname,
      relative === "path"
    );
    validateNavigationTarget(
      typeof to === "string" ? to : createPath(to),
      navigator.createHref(path),
      getNavigatorCurrentUrl(navigator),
      "reject"
    );
    let jsonPath = JSON.stringify(path);
    React9.useEffect(() => {
      navigate(JSON.parse(jsonPath), { replace: replace2, state, relative });
    }, [navigate, jsonPath, relative, replace2, state]);
    return null;
  }
  function Outlet(props) {
    return useOutlet(props.context);
  }
  function Route(props) {
    invariant(
      false,
      `A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.`
    );
  }
  function Router({
    basename: basenameProp = "/",
    children = null,
    location: locationProp,
    navigationType = "POP",
    navigator,
    static: staticProp = false,
    useTransitions
  }) {
    invariant(
      !useInRouterContext(),
      `You cannot render a <Router> inside another <Router>. You should never have more than one in your app.`
    );
    let basename = basenameProp.replace(/^\/*/, "/");
    let navigationContext = React9.useMemo(
      () => ({
        basename,
        navigator,
        static: staticProp,
        useTransitions,
        future: {}
      }),
      [basename, navigator, staticProp, useTransitions]
    );
    if (typeof locationProp === "string") {
      locationProp = parsePath(locationProp);
    }
    let {
      pathname = "/",
      search = "",
      hash = "",
      state = null,
      key = "default",
      mask
    } = locationProp;
    let locationContext = React9.useMemo(() => {
      let trailingPathname = stripBasename(pathname, basename);
      if (trailingPathname == null) {
        return null;
      }
      return {
        location: {
          pathname: trailingPathname,
          search,
          hash,
          state,
          key,
          mask
        },
        navigationType
      };
    }, [basename, pathname, search, hash, state, key, navigationType, mask]);
    warning(
      locationContext != null,
      `<Router basename="${basename}"> is not able to match the URL "${pathname}${search}${hash}" because it does not start with the basename, so the <Router> won't render anything.`
    );
    if (locationContext == null) {
      return null;
    }
    return /* @__PURE__ */ React9.createElement(NavigationContext.Provider, { value: navigationContext }, /* @__PURE__ */ React9.createElement(LocationContext.Provider, { children, value: locationContext }));
  }
  function Routes({
    children,
    location: location2
  }) {
    return useRoutes(createRoutesFromChildren(children), location2);
  }
  function Await({
    children,
    errorElement,
    resolve
  }) {
    let dataRouterContext = React9.useContext(DataRouterContext);
    let dataRouterStateContext = React9.useContext(DataRouterStateContext);
    let onError = React9.useCallback(
      (error, errorInfo) => {
        if (dataRouterContext && dataRouterContext.onError && dataRouterStateContext) {
          dataRouterContext.onError(error, {
            location: dataRouterStateContext.location,
            params: _optionalChain([dataRouterStateContext, "access", (_152) => _152.matches, "access", (_153) => _153[0], "optionalAccess", (_154) => _154.params]) || {},
            pattern: getRoutePattern(dataRouterStateContext.matches),
            errorInfo
          });
        }
      },
      [dataRouterContext, dataRouterStateContext]
    );
    return /* @__PURE__ */ React9.createElement(
      AwaitErrorBoundary,
      {
        resolve,
        errorElement,
        onError
      },
      /* @__PURE__ */ React9.createElement(ResolveAwait, null, children)
    );
  }
  var AwaitErrorBoundary = class extends React9.Component {
    constructor(props) {
      super(props);
      this.state = { error: null };
    }
    static getDerivedStateFromError(error) {
      return { error };
    }
    componentDidCatch(error, errorInfo) {
      if (this.props.onError) {
        this.props.onError(error, errorInfo);
      } else {
        console.error(
          "<Await> caught the following error during render",
          error,
          errorInfo
        );
      }
    }
    render() {
      let { children, errorElement, resolve } = this.props;
      let promise = null;
      let status = 0;
      if (!(resolve instanceof Promise)) {
        status = 1;
        promise = Promise.resolve();
        Object.defineProperty(promise, "_tracked", { get: () => true });
        Object.defineProperty(promise, "_data", { get: () => resolve });
      } else if (this.state.error) {
        status = 2;
        let renderError = this.state.error;
        promise = Promise.reject().catch(() => {
        });
        Object.defineProperty(promise, "_tracked", { get: () => true });
        Object.defineProperty(promise, "_error", { get: () => renderError });
      } else if (resolve._tracked) {
        promise = resolve;
        status = "_error" in promise ? 2 : "_data" in promise ? 1 : 0;
      } else {
        status = 0;
        Object.defineProperty(resolve, "_tracked", { get: () => true });
        promise = resolve.then(
          (data2) => Object.defineProperty(resolve, "_data", { get: () => data2 }),
          (error) => {
            _optionalChain([this, "access", (_155) => _155.props, "access", (_156) => _156.onError, "optionalCall", (_157) => _157(error)]);
            Object.defineProperty(resolve, "_error", { get: () => error });
          }
        );
      }
      if (status === 2 && !errorElement) {
        throw promise._error;
      }
      if (status === 2) {
        return /* @__PURE__ */ React9.createElement(AwaitContext.Provider, { value: promise, children: errorElement });
      }
      if (status === 1) {
        return /* @__PURE__ */ React9.createElement(AwaitContext.Provider, { value: promise, children });
      }
      throw promise;
    }
  };
  function ResolveAwait({
    children
  }) {
    let data2 = useAsyncValue();
    let toRender = typeof children === "function" ? children(data2) : children;
    return /* @__PURE__ */ React9.createElement(React9.Fragment, null, toRender);
  }
  function createRoutesFromChildren(children, parentPath = []) {
    let routes = [];
    React9.Children.forEach(children, (element, index) => {
      if (!React9.isValidElement(element)) {
        return;
      }
      let treePath = [...parentPath, index];
      if (element.type === React9.Fragment) {
        routes.push.apply(
          routes,
          createRoutesFromChildren(element.props.children, treePath)
        );
        return;
      }
      invariant(
        element.type === Route,
        `[${typeof element.type === "string" ? element.type : element.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`
      );
      invariant(
        !element.props.index || !element.props.children,
        "An index route cannot have child routes."
      );
      let route = {
        id: element.props.id || treePath.join("-"),
        caseSensitive: element.props.caseSensitive,
        element: element.props.element,
        Component: element.props.Component,
        index: element.props.index,
        path: element.props.path,
        middleware: element.props.middleware,
        loader: element.props.loader,
        action: element.props.action,
        hydrateFallbackElement: element.props.hydrateFallbackElement,
        HydrateFallback: element.props.HydrateFallback,
        errorElement: element.props.errorElement,
        ErrorBoundary: element.props.ErrorBoundary,
        hasErrorBoundary: element.props.hasErrorBoundary === true || element.props.ErrorBoundary != null || element.props.errorElement != null,
        shouldRevalidate: element.props.shouldRevalidate,
        handle: element.props.handle,
        lazy: element.props.lazy
      };
      if (element.props.children) {
        route.children = createRoutesFromChildren(
          element.props.children,
          treePath
        );
      }
      routes.push(route);
    });
    return routes;
  }
  var createRoutesFromElements = createRoutesFromChildren;
  function renderMatches(matches) {
    return _renderMatches(matches);
  }
  function useRouteComponentProps() {
    return {
      params: useParams(),
      loaderData: useLoaderData(),
      actionData: useActionData(),
      matches: useMatches()
    };
  }
  function WithComponentProps({
    children
  }) {
    const props = useRouteComponentProps();
    return React9.cloneElement(children, props);
  }
  function withComponentProps(Component4) {
    return function WithComponentProps2() {
      const props = useRouteComponentProps();
      return React9.createElement(Component4, props);
    };
  }
  function useHydrateFallbackProps() {
    return {
      params: useParams(),
      loaderData: useLoaderData(),
      actionData: useActionData()
    };
  }
  function WithHydrateFallbackProps({
    children
  }) {
    const props = useHydrateFallbackProps();
    return React9.cloneElement(children, props);
  }
  function withHydrateFallbackProps(HydrateFallback) {
    return function WithHydrateFallbackProps2() {
      const props = useHydrateFallbackProps();
      return React9.createElement(HydrateFallback, props);
    };
  }
  function useErrorBoundaryProps() {
    return {
      params: useParams(),
      loaderData: useLoaderData(),
      actionData: useActionData(),
      error: useRouteError()
    };
  }
  function WithErrorBoundaryProps({
    children
  }) {
    const props = useErrorBoundaryProps();
    return React9.cloneElement(children, props);
  }
  function withErrorBoundaryProps(ErrorBoundary) {
    return function WithErrorBoundaryProps2() {
      const props = useErrorBoundaryProps();
      return React9.createElement(ErrorBoundary, props);
    };
  }
  chunkGR4NQCSD.ABSOLUTE_URL_REGEX = ABSOLUTE_URL_REGEX;
  chunkGR4NQCSD.PROTOCOL_RELATIVE_URL_REGEX = PROTOCOL_RELATIVE_URL_REGEX;
  chunkGR4NQCSD.Action = Action;
  chunkGR4NQCSD.createMemoryHistory = createMemoryHistory;
  chunkGR4NQCSD.createBrowserHistory = createBrowserHistory;
  chunkGR4NQCSD.createHashHistory = createHashHistory;
  chunkGR4NQCSD.invariant = invariant;
  chunkGR4NQCSD.warning = warning;
  chunkGR4NQCSD.createPath = createPath;
  chunkGR4NQCSD.parsePath = parsePath;
  chunkGR4NQCSD.createContext = createContext;
  chunkGR4NQCSD.RouterContextProvider = RouterContextProvider;
  chunkGR4NQCSD.convertRoutesToDataRoutes = convertRoutesToDataRoutes;
  chunkGR4NQCSD.matchRoutes = matchRoutes;
  chunkGR4NQCSD.matchRoutesImpl = matchRoutesImpl;
  chunkGR4NQCSD.generatePath = generatePath;
  chunkGR4NQCSD.matchPath = matchPath;
  chunkGR4NQCSD.stripBasename = stripBasename;
  chunkGR4NQCSD.resolvePath = resolvePath;
  chunkGR4NQCSD.resolveTo = resolveTo;
  chunkGR4NQCSD.joinPaths = joinPaths;
  chunkGR4NQCSD.data = data;
  chunkGR4NQCSD.redirect = redirect;
  chunkGR4NQCSD.redirectDocument = redirectDocument;
  chunkGR4NQCSD.replace = replace;
  chunkGR4NQCSD.SUPPORTED_ERROR_TYPES = SUPPORTED_ERROR_TYPES;
  chunkGR4NQCSD.ErrorResponseImpl = ErrorResponseImpl;
  chunkGR4NQCSD.isRouteErrorResponse = isRouteErrorResponse;
  chunkGR4NQCSD.parseToInfo = parseToInfo;
  chunkGR4NQCSD.escapeHtml = escapeHtml;
  chunkGR4NQCSD.escapeAttribute = escapeAttribute;
  chunkGR4NQCSD.encode = encode;
  chunkGR4NQCSD.instrumentHandler = instrumentHandler;
  chunkGR4NQCSD.validateNavigationTarget = validateNavigationTarget;
  chunkGR4NQCSD.IDLE_NAVIGATION = IDLE_NAVIGATION;
  chunkGR4NQCSD.IDLE_FETCHER = IDLE_FETCHER;
  chunkGR4NQCSD.IDLE_BLOCKER = IDLE_BLOCKER;
  chunkGR4NQCSD.createRouter = createRouter;
  chunkGR4NQCSD.createStaticHandler = createStaticHandler;
  chunkGR4NQCSD.getStaticContextFromError = getStaticContextFromError;
  chunkGR4NQCSD.hasInvalidProtocol = hasInvalidProtocol;
  chunkGR4NQCSD.isDataWithResponseInit = isDataWithResponseInit;
  chunkGR4NQCSD.isResponse = isResponse;
  chunkGR4NQCSD.isRedirectStatusCode = isRedirectStatusCode;
  chunkGR4NQCSD.isRedirectResponse = isRedirectResponse;
  chunkGR4NQCSD.isMutationMethod = isMutationMethod;
  chunkGR4NQCSD.createRequestInit = createRequestInit;
  chunkGR4NQCSD.SingleFetchRedirectSymbol = SingleFetchRedirectSymbol;
  chunkGR4NQCSD.SINGLE_FETCH_REDIRECT_STATUS = SINGLE_FETCH_REDIRECT_STATUS;
  chunkGR4NQCSD.NO_BODY_STATUS_CODES = NO_BODY_STATUS_CODES;
  chunkGR4NQCSD.StreamTransfer = StreamTransfer;
  chunkGR4NQCSD.getTurboStreamSingleFetchDataStrategy = getTurboStreamSingleFetchDataStrategy;
  chunkGR4NQCSD.getSingleFetchDataStrategyImpl = getSingleFetchDataStrategyImpl;
  chunkGR4NQCSD.stripIndexParam = stripIndexParam;
  chunkGR4NQCSD.singleFetchUrl = singleFetchUrl;
  chunkGR4NQCSD.decodeViaTurboStream = decodeViaTurboStream;
  chunkGR4NQCSD.DataRouterContext = DataRouterContext;
  chunkGR4NQCSD.DataRouterStateContext = DataRouterStateContext;
  chunkGR4NQCSD.RSCRouterContext = RSCRouterContext;
  chunkGR4NQCSD.ViewTransitionContext = ViewTransitionContext;
  chunkGR4NQCSD.FetchersContext = FetchersContext;
  chunkGR4NQCSD.AwaitContextProvider = AwaitContextProvider;
  chunkGR4NQCSD.NavigationContext = NavigationContext;
  chunkGR4NQCSD.LocationContext = LocationContext;
  chunkGR4NQCSD.RouteContext = RouteContext;
  chunkGR4NQCSD.ENABLE_DEV_WARNINGS = ENABLE_DEV_WARNINGS;
  chunkGR4NQCSD.warnOnce = warnOnce;
  chunkGR4NQCSD.decodeRedirectErrorDigest = decodeRedirectErrorDigest;
  chunkGR4NQCSD.decodeRouteErrorResponseDigest = decodeRouteErrorResponseDigest;
  chunkGR4NQCSD.useHref = useHref;
  chunkGR4NQCSD.useInRouterContext = useInRouterContext;
  chunkGR4NQCSD.useLocation = useLocation;
  chunkGR4NQCSD.useNavigationType = useNavigationType;
  chunkGR4NQCSD.useMatch = useMatch;
  chunkGR4NQCSD.useNavigate = useNavigate;
  chunkGR4NQCSD.useOutletContext = useOutletContext;
  chunkGR4NQCSD.useOutlet = useOutlet;
  chunkGR4NQCSD.useParams = useParams;
  chunkGR4NQCSD.useResolvedPath = useResolvedPath;
  chunkGR4NQCSD.useRoutes = useRoutes;
  chunkGR4NQCSD.useRouteId = useRouteId;
  chunkGR4NQCSD.useNavigation = useNavigation;
  chunkGR4NQCSD.useRevalidator = useRevalidator;
  chunkGR4NQCSD.useMatches = useMatches;
  chunkGR4NQCSD.useLoaderData = useLoaderData;
  chunkGR4NQCSD.useRouteLoaderData = useRouteLoaderData;
  chunkGR4NQCSD.useActionData = useActionData;
  chunkGR4NQCSD.useRouteError = useRouteError;
  chunkGR4NQCSD.useAsyncValue = useAsyncValue;
  chunkGR4NQCSD.useAsyncError = useAsyncError;
  chunkGR4NQCSD.useBlocker = useBlocker;
  chunkGR4NQCSD.useRoute = useRoute;
  chunkGR4NQCSD.useRouterState = useRouterState;
  chunkGR4NQCSD.RemixErrorBoundary = RemixErrorBoundary;
  chunkGR4NQCSD.createServerRoutes = createServerRoutes;
  chunkGR4NQCSD.createClientRoutesWithHMRRevalidationOptOut = createClientRoutesWithHMRRevalidationOptOut;
  chunkGR4NQCSD.noActionDefinedError = noActionDefinedError;
  chunkGR4NQCSD.createClientRoutes = createClientRoutes;
  chunkGR4NQCSD.shouldHydrateRouteLoader = shouldHydrateRouteLoader;
  chunkGR4NQCSD.URL_LIMIT = URL_LIMIT;
  chunkGR4NQCSD.getPathsWithAncestors = getPathsWithAncestors;
  chunkGR4NQCSD.getPatchRoutesOnNavigationFunction = getPatchRoutesOnNavigationFunction;
  chunkGR4NQCSD.useFogOFWarDiscovery = useFogOFWarDiscovery;
  chunkGR4NQCSD.getManifestPath = getManifestPath;
  chunkGR4NQCSD.FrameworkContext = FrameworkContext;
  chunkGR4NQCSD.usePrefetchBehavior = usePrefetchBehavior;
  chunkGR4NQCSD.CRITICAL_CSS_DATA_ATTRIBUTE = CRITICAL_CSS_DATA_ATTRIBUTE;
  chunkGR4NQCSD.Links = Links;
  chunkGR4NQCSD.PrefetchPageLinks = PrefetchPageLinks;
  chunkGR4NQCSD.Meta = Meta;
  chunkGR4NQCSD.setIsHydrated = setIsHydrated;
  chunkGR4NQCSD.Scripts = Scripts;
  chunkGR4NQCSD.mergeRefs = mergeRefs;
  chunkGR4NQCSD.mapRouteProperties = mapRouteProperties;
  chunkGR4NQCSD.hydrationRouteProperties = hydrationRouteProperties;
  chunkGR4NQCSD.createMemoryRouter = createMemoryRouter;
  chunkGR4NQCSD.RouterProvider = RouterProvider;
  chunkGR4NQCSD.DataRoutes = DataRoutes2;
  chunkGR4NQCSD.MemoryRouter = MemoryRouter;
  chunkGR4NQCSD.Navigate = Navigate;
  chunkGR4NQCSD.Outlet = Outlet;
  chunkGR4NQCSD.Route = Route;
  chunkGR4NQCSD.Router = Router;
  chunkGR4NQCSD.Routes = Routes;
  chunkGR4NQCSD.Await = Await;
  chunkGR4NQCSD.createRoutesFromChildren = createRoutesFromChildren;
  chunkGR4NQCSD.createRoutesFromElements = createRoutesFromElements;
  chunkGR4NQCSD.renderMatches = renderMatches;
  chunkGR4NQCSD.WithComponentProps = WithComponentProps;
  chunkGR4NQCSD.withComponentProps = withComponentProps;
  chunkGR4NQCSD.WithHydrateFallbackProps = WithHydrateFallbackProps;
  chunkGR4NQCSD.withHydrateFallbackProps = withHydrateFallbackProps;
  chunkGR4NQCSD.WithErrorBoundaryProps = WithErrorBoundaryProps;
  chunkGR4NQCSD.withErrorBoundaryProps = withErrorBoundaryProps;
  return chunkGR4NQCSD;
}
var hasRequiredChunkLVPI3KDG;
function requireChunkLVPI3KDG() {
  if (hasRequiredChunkLVPI3KDG) return chunkLVPI3KDG;
  hasRequiredChunkLVPI3KDG = 1;
  Object.defineProperty(chunkLVPI3KDG, "__esModule", { value: true });
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : { default: obj };
  }
  var _chunkGR4NQCSDjs = /* @__PURE__ */ requireChunkGR4NQCSD();
  function getHydrationData({
    state,
    routes,
    getRouteInfo,
    location: location2,
    basename,
    isSpaMode
  }) {
    let hydrationData = {
      ...state,
      loaderData: { ...state.loaderData }
    };
    let initialMatches = _chunkGR4NQCSDjs.matchRoutes.call(void 0, routes, location2, basename);
    if (initialMatches) {
      for (let match of initialMatches) {
        let routeId = match.route.id;
        let routeInfo = getRouteInfo(routeId);
        if (_chunkGR4NQCSDjs.shouldHydrateRouteLoader.call(
          void 0,
          routeId,
          routeInfo.clientLoader,
          routeInfo.hasLoader,
          isSpaMode
        ) && (routeInfo.hasHydrateFallback || !routeInfo.hasLoader)) {
          delete hydrationData.loaderData[routeId];
        } else if (!routeInfo.hasLoader) {
          hydrationData.loaderData[routeId] = null;
        }
      }
    }
    return hydrationData;
  }
  var _react = requireReact();
  var _react2 = _interopRequireDefault(_react);
  var RSCRouterGlobalErrorBoundary = class extends _react2.default.Component {
    constructor(props) {
      super(props);
      this.state = { error: null, location: props.location };
    }
    static getDerivedStateFromError(error) {
      return { error };
    }
    static getDerivedStateFromProps(props, state) {
      if (state.location !== props.location) {
        return { error: null, location: props.location };
      }
      return { error: state.error, location: state.location };
    }
    render() {
      if (this.state.error) {
        return /* @__PURE__ */ _react2.default.createElement(
          RSCDefaultRootErrorBoundaryImpl,
          {
            error: this.state.error,
            renderAppShell: true
          }
        );
      } else {
        return this.props.children;
      }
    }
  };
  function ErrorWrapper({
    renderAppShell,
    title,
    children
  }) {
    if (!renderAppShell) {
      return children;
    }
    return /* @__PURE__ */ _react2.default.createElement("html", { lang: "en" }, /* @__PURE__ */ _react2.default.createElement("head", null, /* @__PURE__ */ _react2.default.createElement("meta", { charSet: "utf-8" }), /* @__PURE__ */ _react2.default.createElement(
      "meta",
      {
        name: "viewport",
        content: "width=device-width,initial-scale=1,viewport-fit=cover"
      }
    ), /* @__PURE__ */ _react2.default.createElement("title", null, title)), /* @__PURE__ */ _react2.default.createElement("body", null, /* @__PURE__ */ _react2.default.createElement("main", { style: { fontFamily: "system-ui, sans-serif", padding: "2rem" } }, children)));
  }
  function RSCDefaultRootErrorBoundaryImpl({
    error,
    renderAppShell
  }) {
    console.error(error);
    let heyDeveloper = /* @__PURE__ */ _react2.default.createElement(
      "script",
      {
        dangerouslySetInnerHTML: {
          __html: `
        console.log(
          "💿 Hey developer 👋. You can provide a way better UX than this when your app throws errors. Check out https://reactrouter.com/how-to/error-boundary for more information."
        );
      `
        }
      }
    );
    if (_chunkGR4NQCSDjs.isRouteErrorResponse.call(void 0, error)) {
      return /* @__PURE__ */ _react2.default.createElement(
        ErrorWrapper,
        {
          renderAppShell,
          title: "Unhandled Thrown Response!"
        },
        /* @__PURE__ */ _react2.default.createElement("h1", { style: { fontSize: "24px" } }, error.status, " ", error.statusText),
        _chunkGR4NQCSDjs.ENABLE_DEV_WARNINGS ? heyDeveloper : null
      );
    }
    let errorInstance;
    if (error instanceof Error) {
      errorInstance = error;
    } else {
      let errorString = error == null ? "Unknown Error" : typeof error === "object" && "toString" in error ? error.toString() : JSON.stringify(error);
      errorInstance = new Error(errorString);
    }
    return /* @__PURE__ */ _react2.default.createElement(ErrorWrapper, { renderAppShell, title: "Application Error!" }, /* @__PURE__ */ _react2.default.createElement("h1", { style: { fontSize: "24px" } }, "Application Error"), /* @__PURE__ */ _react2.default.createElement(
      "pre",
      {
        style: {
          padding: "2rem",
          background: "hsla(10, 50%, 50%, 0.1)",
          color: "red",
          overflow: "auto"
        }
      },
      errorInstance.stack
    ), heyDeveloper);
  }
  function RSCDefaultRootErrorBoundary({
    hasRootLayout
  }) {
    let error = _chunkGR4NQCSDjs.useRouteError.call(void 0);
    if (hasRootLayout === void 0) {
      throw new Error("Missing 'hasRootLayout' prop");
    }
    return /* @__PURE__ */ _react2.default.createElement(
      RSCDefaultRootErrorBoundaryImpl,
      {
        renderAppShell: !hasRootLayout,
        error
      }
    );
  }
  function createRSCRouteModules(payload) {
    const routeModules = {};
    for (const match of payload.matches) {
      populateRSCRouteModules(routeModules, match);
    }
    return routeModules;
  }
  function populateRSCRouteModules(routeModules, matches) {
    matches = Array.isArray(matches) ? matches : [matches];
    for (const match of matches) {
      routeModules[match.id] = {
        links: match.links,
        meta: match.meta,
        default: noopComponent
      };
    }
  }
  var noopComponent = () => null;
  chunkLVPI3KDG.getHydrationData = getHydrationData;
  chunkLVPI3KDG.RSCRouterGlobalErrorBoundary = RSCRouterGlobalErrorBoundary;
  chunkLVPI3KDG.RSCDefaultRootErrorBoundary = RSCDefaultRootErrorBoundary;
  chunkLVPI3KDG.createRSCRouteModules = createRSCRouteModules;
  chunkLVPI3KDG.populateRSCRouteModules = populateRSCRouteModules;
  return chunkLVPI3KDG;
}
var development = {};
var chunkHQO5H5CC = {};
var hasRequiredChunkHQO5H5CC;
function requireChunkHQO5H5CC() {
  if (hasRequiredChunkHQO5H5CC) return chunkHQO5H5CC;
  hasRequiredChunkHQO5H5CC = 1;
  Object.defineProperty(chunkHQO5H5CC, "__esModule", { value: true });
  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};
      if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) {
            newObj[key] = obj[key];
          }
        }
      }
      newObj.default = obj;
      return newObj;
    }
  }
  function _optionalChain(ops) {
    let lastAccessLHS = void 0;
    let value = ops[0];
    let i = 1;
    while (i < ops.length) {
      const op = ops[i];
      const fn = ops[i + 1];
      i += 2;
      if ((op === "optionalAccess" || op === "optionalCall") && value == null) {
        return void 0;
      }
      if (op === "access" || op === "optionalAccess") {
        lastAccessLHS = value;
        value = fn(value);
      } else if (op === "call" || op === "optionalCall") {
        value = fn((...args) => value.call(lastAccessLHS, ...args));
        lastAccessLHS = void 0;
      }
    }
    return value;
  }
  var _chunkGR4NQCSDjs = /* @__PURE__ */ requireChunkGR4NQCSD();
  var defaultMethod = "get";
  var defaultEncType = "application/x-www-form-urlencoded";
  function isHtmlElement(object) {
    return typeof HTMLElement !== "undefined" && object instanceof HTMLElement;
  }
  function isButtonElement(object) {
    return isHtmlElement(object) && object.tagName.toLowerCase() === "button";
  }
  function isFormElement(object) {
    return isHtmlElement(object) && object.tagName.toLowerCase() === "form";
  }
  function isInputElement(object) {
    return isHtmlElement(object) && object.tagName.toLowerCase() === "input";
  }
  function isModifiedEvent(event) {
    return !!(event.metaKey || event.altKey || event.ctrlKey || event.shiftKey);
  }
  function shouldProcessLinkClick(event, target) {
    return event.button === 0 && // Ignore everything but left clicks
    (!target || target === "_self") && // Let browser handle "target=_blank" etc.
    !isModifiedEvent(event);
  }
  function createSearchParams(init = "") {
    return new URLSearchParams(
      typeof init === "string" || Array.isArray(init) || init instanceof URLSearchParams ? init : Object.keys(init).reduce((memo, key) => {
        let value = init[key];
        return memo.concat(
          Array.isArray(value) ? value.map((v) => [key, v]) : [[key, value]]
        );
      }, [])
    );
  }
  function getSearchParamsForLocation(locationSearch, defaultSearchParams) {
    let searchParams = createSearchParams(locationSearch);
    if (defaultSearchParams) {
      defaultSearchParams.forEach((_, key) => {
        if (!searchParams.has(key)) {
          defaultSearchParams.getAll(key).forEach((value) => {
            searchParams.append(key, value);
          });
        }
      });
    }
    return searchParams;
  }
  var _formDataSupportsSubmitter = null;
  function isFormDataSubmitterSupported() {
    if (_formDataSupportsSubmitter === null) {
      try {
        new FormData(
          document.createElement("form"),
          // @ts-expect-error if FormData supports the submitter parameter, this will throw
          0
        );
        _formDataSupportsSubmitter = false;
      } catch (e) {
        _formDataSupportsSubmitter = true;
      }
    }
    return _formDataSupportsSubmitter;
  }
  var supportedFormEncTypes = /* @__PURE__ */ new Set([
    "application/x-www-form-urlencoded",
    "multipart/form-data",
    "text/plain"
  ]);
  function getFormEncType(encType) {
    if (encType != null && !supportedFormEncTypes.has(encType)) {
      _chunkGR4NQCSDjs.warning.call(
        void 0,
        false,
        `"${encType}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${defaultEncType}"`
      );
      return null;
    }
    return encType;
  }
  function getFormSubmissionInfo(target, basename) {
    let method;
    let action;
    let encType;
    let formData;
    let body;
    if (isFormElement(target)) {
      let attr = target.getAttribute("action");
      action = attr ? _chunkGR4NQCSDjs.stripBasename.call(void 0, attr, basename) : null;
      method = target.getAttribute("method") || defaultMethod;
      encType = getFormEncType(target.getAttribute("enctype")) || defaultEncType;
      formData = new FormData(target);
    } else if (isButtonElement(target) || isInputElement(target) && (target.type === "submit" || target.type === "image")) {
      let form = target.form;
      if (form == null) {
        throw new Error(
          `Cannot submit a <button> or <input type="submit"> without a <form>`
        );
      }
      let attr = target.getAttribute("formaction") || form.getAttribute("action");
      action = attr ? _chunkGR4NQCSDjs.stripBasename.call(void 0, attr, basename) : null;
      method = target.getAttribute("formmethod") || form.getAttribute("method") || defaultMethod;
      encType = getFormEncType(target.getAttribute("formenctype")) || getFormEncType(form.getAttribute("enctype")) || defaultEncType;
      formData = new FormData(form, target);
      if (!isFormDataSubmitterSupported()) {
        let { name, type, value } = target;
        if (type === "image") {
          let prefix = name ? `${name}.` : "";
          formData.append(`${prefix}x`, "0");
          formData.append(`${prefix}y`, "0");
        } else if (name) {
          formData.append(name, value);
        }
      }
    } else if (isHtmlElement(target)) {
      throw new Error(
        `Cannot submit element that is not <form>, <button>, or <input type="submit|image">`
      );
    } else {
      method = defaultMethod;
      action = null;
      encType = defaultEncType;
      body = target;
    }
    if (formData && encType === "text/plain") {
      body = formData;
      formData = void 0;
    }
    return { action, method: method.toLowerCase(), encType, formData, body };
  }
  var _react = requireReact();
  var React = _interopRequireWildcard(_react);
  var React2 = _interopRequireWildcard(_react);
  var isBrowser = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
  try {
    if (isBrowser) {
      window.__reactRouterVersion = // @ts-expect-error
      "7.18.4";
    }
  } catch (e) {
  }
  function createBrowserRouter(routes, opts) {
    return _chunkGR4NQCSDjs.createRouter.call(void 0, {
      basename: _optionalChain([opts, "optionalAccess", (_2) => _2.basename]),
      getContext: _optionalChain([opts, "optionalAccess", (_3) => _3.getContext]),
      future: _optionalChain([opts, "optionalAccess", (_4) => _4.future]),
      history: _chunkGR4NQCSDjs.createBrowserHistory.call(void 0, { window: _optionalChain([opts, "optionalAccess", (_5) => _5.window]) }),
      hydrationData: _optionalChain([opts, "optionalAccess", (_6) => _6.hydrationData]) || parseHydrationData(),
      routes,
      mapRouteProperties: _chunkGR4NQCSDjs.mapRouteProperties,
      hydrationRouteProperties: _chunkGR4NQCSDjs.hydrationRouteProperties,
      dataStrategy: _optionalChain([opts, "optionalAccess", (_7) => _7.dataStrategy]),
      patchRoutesOnNavigation: _optionalChain([opts, "optionalAccess", (_8) => _8.patchRoutesOnNavigation]),
      window: _optionalChain([opts, "optionalAccess", (_9) => _9.window]),
      instrumentations: _optionalChain([opts, "optionalAccess", (_10) => _10.instrumentations])
    }).initialize();
  }
  function createHashRouter(routes, opts) {
    return _chunkGR4NQCSDjs.createRouter.call(void 0, {
      basename: _optionalChain([opts, "optionalAccess", (_11) => _11.basename]),
      getContext: _optionalChain([opts, "optionalAccess", (_12) => _12.getContext]),
      future: _optionalChain([opts, "optionalAccess", (_13) => _13.future]),
      history: _chunkGR4NQCSDjs.createHashHistory.call(void 0, { window: _optionalChain([opts, "optionalAccess", (_14) => _14.window]) }),
      hydrationData: _optionalChain([opts, "optionalAccess", (_15) => _15.hydrationData]) || parseHydrationData(),
      routes,
      mapRouteProperties: _chunkGR4NQCSDjs.mapRouteProperties,
      hydrationRouteProperties: _chunkGR4NQCSDjs.hydrationRouteProperties,
      dataStrategy: _optionalChain([opts, "optionalAccess", (_16) => _16.dataStrategy]),
      patchRoutesOnNavigation: _optionalChain([opts, "optionalAccess", (_17) => _17.patchRoutesOnNavigation]),
      window: _optionalChain([opts, "optionalAccess", (_18) => _18.window]),
      instrumentations: _optionalChain([opts, "optionalAccess", (_19) => _19.instrumentations])
    }).initialize();
  }
  function parseHydrationData() {
    let state = _optionalChain([window, "optionalAccess", (_20) => _20.__staticRouterHydrationData]);
    if (state && state.errors) {
      state = {
        ...state,
        errors: deserializeErrors(state.errors)
      };
    }
    return state;
  }
  function deserializeErrors(errors) {
    if (!errors) return null;
    let entries = Object.entries(errors);
    let serialized = {};
    for (let [key, val] of entries) {
      if (val && val.__type === "RouteErrorResponse") {
        serialized[key] = new _chunkGR4NQCSDjs.ErrorResponseImpl(
          val.status,
          val.statusText,
          val.data,
          val.internal === true
        );
      } else if (val && val.__type === "Error") {
        if (typeof val.__subType === "string" && _chunkGR4NQCSDjs.SUPPORTED_ERROR_TYPES.includes(val.__subType)) {
          let ErrorConstructor = window[val.__subType];
          if (typeof ErrorConstructor === "function") {
            try {
              let error = new ErrorConstructor(val.message);
              error.stack = "";
              serialized[key] = error;
            } catch (e) {
            }
          }
        }
        if (serialized[key] == null) {
          let error = new Error(val.message);
          error.stack = "";
          serialized[key] = error;
        }
      } else {
        serialized[key] = val;
      }
    }
    return serialized;
  }
  function BrowserRouter({
    basename,
    children,
    useTransitions,
    window: window2
  }) {
    let historyRef = React.useRef();
    if (historyRef.current == null) {
      historyRef.current = _chunkGR4NQCSDjs.createBrowserHistory.call(void 0, { window: window2, v5Compat: true });
    }
    let history = historyRef.current;
    let [state, setStateImpl] = React.useState({
      action: history.action,
      location: history.location
    });
    let setState = React.useCallback(
      (newState) => {
        if (useTransitions === false) {
          setStateImpl(newState);
        } else {
          React.startTransition(() => setStateImpl(newState));
        }
      },
      [useTransitions]
    );
    React.useLayoutEffect(() => history.listen(setState), [history, setState]);
    return /* @__PURE__ */ React.createElement(
      _chunkGR4NQCSDjs.Router,
      {
        basename,
        children,
        location: state.location,
        navigationType: state.action,
        navigator: history,
        useTransitions
      }
    );
  }
  function HashRouter({
    basename,
    children,
    useTransitions,
    window: window2
  }) {
    let historyRef = React.useRef();
    if (historyRef.current == null) {
      historyRef.current = _chunkGR4NQCSDjs.createHashHistory.call(void 0, { window: window2, v5Compat: true });
    }
    let history = historyRef.current;
    let [state, setStateImpl] = React.useState({
      action: history.action,
      location: history.location
    });
    let setState = React.useCallback(
      (newState) => {
        if (useTransitions === false) {
          setStateImpl(newState);
        } else {
          React.startTransition(() => setStateImpl(newState));
        }
      },
      [useTransitions]
    );
    React.useLayoutEffect(() => history.listen(setState), [history, setState]);
    return /* @__PURE__ */ React.createElement(
      _chunkGR4NQCSDjs.Router,
      {
        basename,
        children,
        location: state.location,
        navigationType: state.action,
        navigator: history,
        useTransitions
      }
    );
  }
  function HistoryRouter({
    basename,
    children,
    history,
    useTransitions
  }) {
    let [state, setStateImpl] = React.useState({
      action: history.action,
      location: history.location
    });
    let setState = React.useCallback(
      (newState) => {
        if (useTransitions === false) {
          setStateImpl(newState);
        } else {
          React.startTransition(() => setStateImpl(newState));
        }
      },
      [useTransitions]
    );
    React.useLayoutEffect(() => history.listen(setState), [history, setState]);
    return /* @__PURE__ */ React.createElement(
      _chunkGR4NQCSDjs.Router,
      {
        basename,
        children,
        location: state.location,
        navigationType: state.action,
        navigator: history,
        useTransitions
      }
    );
  }
  HistoryRouter.displayName = "unstable_HistoryRouter";
  var Link = React.forwardRef(
    function LinkWithRef({
      onClick,
      discover = "render",
      prefetch = "none",
      relative,
      reloadDocument,
      replace,
      mask,
      state,
      target,
      to,
      preventScrollReset,
      viewTransition,
      defaultShouldRevalidate,
      ...rest
    }, forwardedRef) {
      let { basename, navigator, useTransitions } = React.useContext(_chunkGR4NQCSDjs.NavigationContext);
      let isAbsolute = typeof to === "string" && _chunkGR4NQCSDjs.ABSOLUTE_URL_REGEX.test(to);
      let parsed = _chunkGR4NQCSDjs.parseToInfo.call(void 0, to, basename);
      to = parsed.to;
      let href = _chunkGR4NQCSDjs.useHref.call(void 0, to, { relative });
      let location2 = _chunkGR4NQCSDjs.useLocation.call(void 0);
      let maskedHref = null;
      if (mask) {
        let resolved = _chunkGR4NQCSDjs.resolveTo.call(
          void 0,
          mask,
          [],
          location2.mask ? location2.mask.pathname : "/",
          true
        );
        if (basename !== "/") {
          resolved.pathname = resolved.pathname === "/" ? basename : _chunkGR4NQCSDjs.joinPaths.call(void 0, [basename, resolved.pathname]);
        }
        maskedHref = navigator.createHref(resolved);
      }
      let [shouldPrefetch, prefetchRef, prefetchHandlers] = _chunkGR4NQCSDjs.usePrefetchBehavior.call(
        void 0,
        prefetch,
        rest
      );
      let internalOnClick = useLinkClickHandler(to, {
        replace,
        mask,
        state,
        target,
        preventScrollReset,
        relative,
        viewTransition,
        defaultShouldRevalidate,
        useTransitions
      });
      function handleClick(event) {
        if (onClick) onClick(event);
        if (!event.defaultPrevented) {
          internalOnClick(event);
        }
      }
      let isSpaLink = !(parsed.isExternal || reloadDocument);
      let link = (
        // eslint-disable-next-line jsx-a11y/anchor-has-content
        /* @__PURE__ */ React.createElement(
          "a",
          {
            ...rest,
            ...prefetchHandlers,
            href: (isSpaLink ? maskedHref : void 0) || parsed.absoluteURL || href,
            onClick: isSpaLink ? handleClick : onClick,
            ref: _chunkGR4NQCSDjs.mergeRefs.call(void 0, forwardedRef, prefetchRef),
            target,
            "data-discover": !isAbsolute && discover === "render" ? "true" : void 0
          }
        )
      );
      return shouldPrefetch && !isAbsolute ? /* @__PURE__ */ React.createElement(React.Fragment, null, link, /* @__PURE__ */ React.createElement(_chunkGR4NQCSDjs.PrefetchPageLinks, { page: href })) : link;
    }
  );
  Link.displayName = "Link";
  var NavLink = React.forwardRef(
    function NavLinkWithRef({
      "aria-current": ariaCurrentProp = "page",
      caseSensitive = false,
      className: classNameProp = "",
      end = false,
      style: styleProp,
      to,
      viewTransition,
      children,
      ...rest
    }, ref) {
      let path = _chunkGR4NQCSDjs.useResolvedPath.call(void 0, to, { relative: rest.relative });
      let location2 = _chunkGR4NQCSDjs.useLocation.call(void 0);
      let routerState = React.useContext(_chunkGR4NQCSDjs.DataRouterStateContext);
      let { navigator, basename } = React.useContext(_chunkGR4NQCSDjs.NavigationContext);
      let isTransitioning = routerState != null && // Conditional usage is OK here because the usage of a data router is static
      // eslint-disable-next-line react-hooks/rules-of-hooks
      useViewTransitionState(path) && viewTransition === true;
      let toPathname = navigator.encodeLocation ? navigator.encodeLocation(path).pathname : path.pathname;
      let locationPathname = location2.pathname;
      let nextLocationPathname = routerState && routerState.navigation && routerState.navigation.location ? routerState.navigation.location.pathname : null;
      if (!caseSensitive) {
        locationPathname = locationPathname.toLowerCase();
        nextLocationPathname = nextLocationPathname ? nextLocationPathname.toLowerCase() : null;
        toPathname = toPathname.toLowerCase();
      }
      if (nextLocationPathname && basename) {
        nextLocationPathname = _chunkGR4NQCSDjs.stripBasename.call(void 0, nextLocationPathname, basename) || nextLocationPathname;
      }
      const endSlashPosition = toPathname !== "/" && toPathname.endsWith("/") ? toPathname.length - 1 : toPathname.length;
      let isActive = locationPathname === toPathname || !end && locationPathname.startsWith(toPathname) && locationPathname.charAt(endSlashPosition) === "/";
      let isPending = nextLocationPathname != null && (nextLocationPathname === toPathname || !end && nextLocationPathname.startsWith(toPathname) && nextLocationPathname.charAt(toPathname.length) === "/");
      let renderProps = {
        isActive,
        isPending,
        isTransitioning
      };
      let ariaCurrent = isActive ? ariaCurrentProp : void 0;
      let className;
      if (typeof classNameProp === "function") {
        className = classNameProp(renderProps);
      } else {
        className = [
          classNameProp,
          isActive ? "active" : null,
          isPending ? "pending" : null,
          isTransitioning ? "transitioning" : null
        ].filter(Boolean).join(" ");
      }
      let style = typeof styleProp === "function" ? styleProp(renderProps) : styleProp;
      return /* @__PURE__ */ React.createElement(
        Link,
        {
          ...rest,
          "aria-current": ariaCurrent,
          className,
          ref,
          style,
          to,
          viewTransition
        },
        typeof children === "function" ? children(renderProps) : children
      );
    }
  );
  NavLink.displayName = "NavLink";
  var Form = React.forwardRef(
    ({
      discover = "render",
      fetcherKey,
      navigate,
      reloadDocument,
      replace,
      state,
      method = defaultMethod,
      action,
      onSubmit,
      relative,
      preventScrollReset,
      viewTransition,
      defaultShouldRevalidate,
      ...props
    }, forwardedRef) => {
      let { useTransitions } = React.useContext(_chunkGR4NQCSDjs.NavigationContext);
      let submit = useSubmit();
      let formAction = useFormAction(action, { relative });
      let formMethod = method.toLowerCase() === "get" ? "get" : "post";
      let isAbsolute = typeof action === "string" && _chunkGR4NQCSDjs.ABSOLUTE_URL_REGEX.test(action);
      let submitHandler = (event) => {
        onSubmit && onSubmit(event);
        if (event.defaultPrevented) return;
        event.preventDefault();
        let submitter = event.nativeEvent.submitter;
        let submitMethod = _optionalChain([submitter, "optionalAccess", (_21) => _21.getAttribute, "call", (_22) => _22("formmethod")]) || method;
        let doSubmit = () => submit(submitter || event.currentTarget, {
          fetcherKey,
          method: submitMethod,
          navigate,
          replace,
          state,
          relative,
          preventScrollReset,
          viewTransition,
          defaultShouldRevalidate
        });
        if (useTransitions && navigate !== false) {
          React.startTransition(() => doSubmit());
        } else {
          doSubmit();
        }
      };
      return /* @__PURE__ */ React.createElement(
        "form",
        {
          ref: forwardedRef,
          method: formMethod,
          action: formAction,
          onSubmit: reloadDocument ? onSubmit : submitHandler,
          ...props,
          "data-discover": !isAbsolute && discover === "render" ? "true" : void 0
        }
      );
    }
  );
  Form.displayName = "Form";
  function ScrollRestoration({
    getKey,
    storageKey,
    ...props
  }) {
    let remixContext = React.useContext(_chunkGR4NQCSDjs.FrameworkContext);
    let { basename } = React.useContext(_chunkGR4NQCSDjs.NavigationContext);
    let location2 = _chunkGR4NQCSDjs.useLocation.call(void 0);
    let matches = _chunkGR4NQCSDjs.useMatches.call(void 0);
    useScrollRestoration({ getKey, storageKey });
    let ssrKey = React.useMemo(
      () => {
        if (!remixContext || !getKey) return null;
        let userKey = getScrollRestorationKey(
          location2,
          matches,
          basename,
          getKey
        );
        return userKey !== location2.key ? userKey : null;
      },
      // Nah, we only need this the first time for the SSR render
      // eslint-disable-next-line react-hooks/exhaustive-deps
      []
    );
    if (!remixContext || remixContext.isSpaMode) {
      return null;
    }
    let restoreScroll = ((storageKey2, restoreKey) => {
      if (!window.history.state || !window.history.state.key) {
        let key = Math.random().toString(32).slice(2);
        window.history.replaceState({ key }, "");
      }
      try {
        let positions = JSON.parse(sessionStorage.getItem(storageKey2) || "{}");
        let storedY = positions[restoreKey || window.history.state.key];
        if (typeof storedY === "number") {
          window.scrollTo(0, storedY);
        }
      } catch (error) {
        console.error(error);
        sessionStorage.removeItem(storageKey2);
      }
    }).toString();
    if (props.nonce == null && _optionalChain([remixContext, "optionalAccess", (_23) => _23.nonce])) {
      props.nonce = remixContext.nonce;
    }
    return /* @__PURE__ */ React.createElement(
      "script",
      {
        ...props,
        suppressHydrationWarning: true,
        dangerouslySetInnerHTML: {
          __html: `(${restoreScroll})(${_chunkGR4NQCSDjs.escapeHtml.call(
            void 0,
            JSON.stringify(storageKey || SCROLL_RESTORATION_STORAGE_KEY)
          )}, ${_chunkGR4NQCSDjs.escapeHtml.call(void 0, JSON.stringify(ssrKey))})`
        }
      }
    );
  }
  ScrollRestoration.displayName = "ScrollRestoration";
  function getDataRouterConsoleError(hookName) {
    return `${hookName} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
  }
  function useDataRouterContext(hookName) {
    let ctx = React.useContext(_chunkGR4NQCSDjs.DataRouterContext);
    _chunkGR4NQCSDjs.invariant.call(void 0, ctx, getDataRouterConsoleError(hookName));
    return ctx;
  }
  function useDataRouterState(hookName) {
    let state = React.useContext(_chunkGR4NQCSDjs.DataRouterStateContext);
    _chunkGR4NQCSDjs.invariant.call(void 0, state, getDataRouterConsoleError(hookName));
    return state;
  }
  function useLinkClickHandler(to, {
    target,
    replace: replaceProp,
    mask,
    state,
    preventScrollReset,
    relative,
    viewTransition,
    defaultShouldRevalidate,
    useTransitions
  } = {}) {
    let navigate = _chunkGR4NQCSDjs.useNavigate.call(void 0);
    let location2 = _chunkGR4NQCSDjs.useLocation.call(void 0);
    let path = _chunkGR4NQCSDjs.useResolvedPath.call(void 0, to, { relative });
    return React.useCallback(
      (event) => {
        if (shouldProcessLinkClick(event, target)) {
          event.preventDefault();
          let replace = replaceProp !== void 0 ? replaceProp : _chunkGR4NQCSDjs.createPath.call(void 0, location2) === _chunkGR4NQCSDjs.createPath.call(void 0, path);
          let doNavigate = () => navigate(to, {
            replace,
            mask,
            state,
            preventScrollReset,
            relative,
            viewTransition,
            defaultShouldRevalidate
          });
          if (useTransitions) {
            React.startTransition(() => doNavigate());
          } else {
            doNavigate();
          }
        }
      },
      [
        location2,
        navigate,
        path,
        replaceProp,
        mask,
        state,
        target,
        to,
        preventScrollReset,
        relative,
        viewTransition,
        defaultShouldRevalidate,
        useTransitions
      ]
    );
  }
  function useSearchParams(defaultInit) {
    _chunkGR4NQCSDjs.warning.call(
      void 0,
      typeof URLSearchParams !== "undefined",
      `You cannot use the \`useSearchParams\` hook in a browser that does not support the URLSearchParams API. If you need to support Internet Explorer 11, we recommend you load a polyfill such as https://github.com/ungap/url-search-params.`
    );
    let defaultSearchParamsRef = React.useRef(createSearchParams(defaultInit));
    let hasSetSearchParamsRef = React.useRef(false);
    let location2 = _chunkGR4NQCSDjs.useLocation.call(void 0);
    let searchParams = React.useMemo(
      () => (
        // Only merge in the defaults if we haven't yet called setSearchParams.
        // Once we call that we want those to take precedence, otherwise you can't
        // remove a param with setSearchParams({}) if it has an initial value
        getSearchParamsForLocation(
          location2.search,
          hasSetSearchParamsRef.current ? null : defaultSearchParamsRef.current
        )
      ),
      [location2.search]
    );
    let navigate = _chunkGR4NQCSDjs.useNavigate.call(void 0);
    let setSearchParams = React.useCallback(
      (nextInit, navigateOptions) => {
        const newSearchParams = createSearchParams(
          typeof nextInit === "function" ? nextInit(new URLSearchParams(searchParams)) : nextInit
        );
        hasSetSearchParamsRef.current = true;
        navigate("?" + newSearchParams, navigateOptions);
      },
      [navigate, searchParams]
    );
    return [searchParams, setSearchParams];
  }
  var fetcherId = 0;
  var getUniqueFetcherId = () => `__${String(++fetcherId)}__`;
  function useSubmit() {
    let { router } = useDataRouterContext(
      "useSubmit"
      /* UseSubmit */
    );
    let { basename } = React.useContext(_chunkGR4NQCSDjs.NavigationContext);
    let currentRouteId = _chunkGR4NQCSDjs.useRouteId.call(void 0);
    let routerFetch = router.fetch;
    let routerNavigate = router.navigate;
    return React.useCallback(
      async (target, options = {}) => {
        let { action, method, encType, formData, body } = getFormSubmissionInfo(
          target,
          basename
        );
        if (options.navigate === false) {
          let key = options.fetcherKey || getUniqueFetcherId();
          await routerFetch(key, currentRouteId, options.action || action, {
            defaultShouldRevalidate: options.defaultShouldRevalidate,
            preventScrollReset: options.preventScrollReset,
            formData,
            body,
            formMethod: options.method || method,
            formEncType: options.encType || encType,
            flushSync: options.flushSync
          });
        } else {
          await routerNavigate(options.action || action, {
            defaultShouldRevalidate: options.defaultShouldRevalidate,
            preventScrollReset: options.preventScrollReset,
            formData,
            body,
            formMethod: options.method || method,
            formEncType: options.encType || encType,
            replace: options.replace,
            state: options.state,
            fromRouteId: currentRouteId,
            flushSync: options.flushSync,
            viewTransition: options.viewTransition
          });
        }
      },
      [routerFetch, routerNavigate, basename, currentRouteId]
    );
  }
  function useFormAction(action, { relative } = {}) {
    let { basename } = React.useContext(_chunkGR4NQCSDjs.NavigationContext);
    let routeContext = React.useContext(_chunkGR4NQCSDjs.RouteContext);
    _chunkGR4NQCSDjs.invariant.call(void 0, routeContext, "useFormAction must be used inside a RouteContext");
    let [match] = routeContext.matches.slice(-1);
    let path = { ..._chunkGR4NQCSDjs.useResolvedPath.call(void 0, action ? action : ".", { relative }) };
    let location2 = _chunkGR4NQCSDjs.useLocation.call(void 0);
    if (action == null) {
      path.search = location2.search;
      let params = new URLSearchParams(path.search);
      let indexValues = params.getAll("index");
      let hasNakedIndexParam = indexValues.some((v) => v === "");
      if (hasNakedIndexParam) {
        params.delete("index");
        indexValues.filter((v) => v).forEach((v) => params.append("index", v));
        let qs = params.toString();
        path.search = qs ? `?${qs}` : "";
      }
    }
    if ((!action || action === ".") && match.route.index) {
      path.search = path.search ? path.search.replace(/^\?/, "?index&") : "?index";
    }
    if (basename !== "/") {
      path.pathname = path.pathname === "/" ? basename : _chunkGR4NQCSDjs.joinPaths.call(void 0, [basename, path.pathname]);
    }
    return _chunkGR4NQCSDjs.createPath.call(void 0, path);
  }
  function useFetcher({
    key
  } = {}) {
    let { router } = useDataRouterContext(
      "useFetcher"
      /* UseFetcher */
    );
    let state = useDataRouterState(
      "useFetcher"
      /* UseFetcher */
    );
    let fetcherData = React.useContext(_chunkGR4NQCSDjs.FetchersContext);
    let route = React.useContext(_chunkGR4NQCSDjs.RouteContext);
    let routeId = _optionalChain([route, "access", (_24) => _24.matches, "access", (_25) => _25[route.matches.length - 1], "optionalAccess", (_26) => _26.route, "access", (_27) => _27.id]);
    _chunkGR4NQCSDjs.invariant.call(void 0, fetcherData, `useFetcher must be used inside a FetchersContext`);
    _chunkGR4NQCSDjs.invariant.call(void 0, route, `useFetcher must be used inside a RouteContext`);
    _chunkGR4NQCSDjs.invariant.call(
      void 0,
      routeId != null,
      `useFetcher can only be used on routes that contain a unique "id"`
    );
    let defaultKey = React.useId();
    let [fetcherKey, setFetcherKey] = React.useState(key || defaultKey);
    if (key && key !== fetcherKey) {
      setFetcherKey(key);
    }
    let { deleteFetcher, getFetcher, resetFetcher, fetch: routerFetch } = router;
    React.useEffect(() => {
      getFetcher(fetcherKey);
      return () => deleteFetcher(fetcherKey);
    }, [deleteFetcher, getFetcher, fetcherKey]);
    let load = React.useCallback(
      async (href, opts) => {
        _chunkGR4NQCSDjs.invariant.call(void 0, routeId, "No routeId available for fetcher.load()");
        await routerFetch(fetcherKey, routeId, href, opts);
      },
      [fetcherKey, routeId, routerFetch]
    );
    let submitImpl = useSubmit();
    let submit = React.useCallback(
      async (target, opts) => {
        await submitImpl(target, {
          ...opts,
          navigate: false,
          fetcherKey
        });
      },
      [fetcherKey, submitImpl]
    );
    let reset = React.useCallback(
      (opts) => resetFetcher(fetcherKey, opts),
      [resetFetcher, fetcherKey]
    );
    let FetcherForm = React.useMemo(() => {
      let FetcherForm2 = React.forwardRef(
        (props, ref) => {
          return /* @__PURE__ */ React.createElement(Form, { ...props, navigate: false, fetcherKey, ref });
        }
      );
      FetcherForm2.displayName = "fetcher.Form";
      return FetcherForm2;
    }, [fetcherKey]);
    let fetcher = state.fetchers.get(fetcherKey) || _chunkGR4NQCSDjs.IDLE_FETCHER;
    let data = fetcherData.get(fetcherKey);
    let fetcherWithComponents = React.useMemo(
      () => ({
        Form: FetcherForm,
        submit,
        load,
        reset,
        ...fetcher,
        data
      }),
      [FetcherForm, submit, load, reset, fetcher, data]
    );
    return fetcherWithComponents;
  }
  function useFetchers() {
    let state = useDataRouterState(
      "useFetchers"
      /* UseFetchers */
    );
    return React.useMemo(
      () => Array.from(state.fetchers.entries()).map(([key, fetcher]) => ({
        ...fetcher,
        key
      })),
      [state.fetchers]
    );
  }
  var SCROLL_RESTORATION_STORAGE_KEY = "react-router-scroll-positions";
  var savedScrollPositions = {};
  function getScrollRestorationKey(location2, matches, basename, getKey) {
    let key = null;
    if (getKey) {
      if (basename !== "/") {
        key = getKey(
          {
            ...location2,
            pathname: _chunkGR4NQCSDjs.stripBasename.call(void 0, location2.pathname, basename) || location2.pathname
          },
          matches
        );
      } else {
        key = getKey(location2, matches);
      }
    }
    if (key == null) {
      key = location2.key;
    }
    return key;
  }
  function useScrollRestoration({
    getKey,
    storageKey
  } = {}) {
    let { router } = useDataRouterContext(
      "useScrollRestoration"
      /* UseScrollRestoration */
    );
    let { restoreScrollPosition, preventScrollReset } = useDataRouterState(
      "useScrollRestoration"
      /* UseScrollRestoration */
    );
    let { basename } = React.useContext(_chunkGR4NQCSDjs.NavigationContext);
    let location2 = _chunkGR4NQCSDjs.useLocation.call(void 0);
    let matches = _chunkGR4NQCSDjs.useMatches.call(void 0);
    let navigation = _chunkGR4NQCSDjs.useNavigation.call(void 0);
    React.useEffect(() => {
      window.history.scrollRestoration = "manual";
      return () => {
        window.history.scrollRestoration = "auto";
      };
    }, []);
    usePageHide(
      React.useCallback(() => {
        if (navigation.state === "idle") {
          let key = getScrollRestorationKey(location2, matches, basename, getKey);
          savedScrollPositions[key] = window.scrollY;
        }
        try {
          sessionStorage.setItem(
            storageKey || SCROLL_RESTORATION_STORAGE_KEY,
            JSON.stringify(savedScrollPositions)
          );
        } catch (error) {
          _chunkGR4NQCSDjs.warning.call(
            void 0,
            false,
            `Failed to save scroll positions in sessionStorage, <ScrollRestoration /> will not work properly (${error}).`
          );
        }
        window.history.scrollRestoration = "auto";
      }, [navigation.state, getKey, basename, location2, matches, storageKey])
    );
    if (typeof document !== "undefined") {
      React.useLayoutEffect(() => {
        try {
          let sessionPositions = sessionStorage.getItem(
            storageKey || SCROLL_RESTORATION_STORAGE_KEY
          );
          if (sessionPositions) {
            savedScrollPositions = JSON.parse(sessionPositions);
          }
        } catch (e) {
        }
      }, [storageKey]);
      React.useLayoutEffect(() => {
        let disableScrollRestoration = _optionalChain([router, "optionalAccess", (_28) => _28.enableScrollRestoration, "call", (_29) => _29(
          savedScrollPositions,
          () => window.scrollY,
          getKey ? (location22, matches2) => getScrollRestorationKey(location22, matches2, basename, getKey) : void 0
        )]);
        return () => disableScrollRestoration && disableScrollRestoration();
      }, [router, basename, getKey]);
      React.useLayoutEffect(() => {
        if (restoreScrollPosition === false) {
          return;
        }
        if (typeof restoreScrollPosition === "number") {
          window.scrollTo(0, restoreScrollPosition);
          return;
        }
        try {
          if (location2.hash) {
            let el = document.getElementById(
              decodeURIComponent(location2.hash.slice(1))
            );
            if (el) {
              el.scrollIntoView();
              return;
            }
          }
        } catch (e2) {
          _chunkGR4NQCSDjs.warning.call(
            void 0,
            false,
            `"${location2.hash.slice(
              1
            )}" is not a decodable element ID. The view will not scroll to it.`
          );
        }
        if (preventScrollReset === true) {
          return;
        }
        window.scrollTo(0, 0);
      }, [location2, restoreScrollPosition, preventScrollReset]);
    }
  }
  function useBeforeUnload(callback, options) {
    let { capture } = options || {};
    React.useEffect(() => {
      let opts = capture != null ? { capture } : void 0;
      window.addEventListener("beforeunload", callback, opts);
      return () => {
        window.removeEventListener("beforeunload", callback, opts);
      };
    }, [callback, capture]);
  }
  function usePageHide(callback, options) {
    let { capture } = {};
    React.useEffect(() => {
      let opts = capture != null ? { capture } : void 0;
      window.addEventListener("pagehide", callback, opts);
      return () => {
        window.removeEventListener("pagehide", callback, opts);
      };
    }, [callback, capture]);
  }
  function usePrompt({
    when,
    message
  }) {
    let blocker = _chunkGR4NQCSDjs.useBlocker.call(void 0, when);
    React.useEffect(() => {
      if (blocker.state === "blocked") {
        let proceed = window.confirm(message);
        if (proceed) {
          setTimeout(blocker.proceed, 0);
        } else {
          blocker.reset();
        }
      }
    }, [blocker, message]);
    React.useEffect(() => {
      if (blocker.state === "blocked" && !when) {
        blocker.reset();
      }
    }, [blocker, when]);
  }
  function useViewTransitionState(to, { relative } = {}) {
    let vtContext = React.useContext(_chunkGR4NQCSDjs.ViewTransitionContext);
    _chunkGR4NQCSDjs.invariant.call(
      void 0,
      vtContext != null,
      "`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?"
    );
    let { basename } = useDataRouterContext(
      "useViewTransitionState"
      /* useViewTransitionState */
    );
    let path = _chunkGR4NQCSDjs.useResolvedPath.call(void 0, to, { relative });
    if (!vtContext.isTransitioning) {
      return false;
    }
    let currentPath = _chunkGR4NQCSDjs.stripBasename.call(void 0, vtContext.currentLocation.pathname, basename) || vtContext.currentLocation.pathname;
    let nextPath = _chunkGR4NQCSDjs.stripBasename.call(void 0, vtContext.nextLocation.pathname, basename) || vtContext.nextLocation.pathname;
    return _chunkGR4NQCSDjs.matchPath.call(void 0, path.pathname, nextPath) != null || _chunkGR4NQCSDjs.matchPath.call(void 0, path.pathname, currentPath) != null;
  }
  function StaticRouter({
    basename,
    children,
    location: locationProp = "/"
  }) {
    if (typeof locationProp === "string") {
      locationProp = _chunkGR4NQCSDjs.parsePath.call(void 0, locationProp);
    }
    let action = "POP";
    let location2 = {
      pathname: locationProp.pathname || "/",
      search: locationProp.search || "",
      hash: locationProp.hash || "",
      state: locationProp.state != null ? locationProp.state : null,
      key: locationProp.key || "default",
      mask: void 0
    };
    let staticNavigator = getStatelessNavigator();
    return /* @__PURE__ */ React2.createElement(
      _chunkGR4NQCSDjs.Router,
      {
        basename,
        children,
        location: location2,
        navigationType: action,
        navigator: staticNavigator,
        static: true,
        useTransitions: false
      }
    );
  }
  function StaticRouterProvider({
    context,
    router,
    hydrate = true,
    nonce
  }) {
    _chunkGR4NQCSDjs.invariant.call(
      void 0,
      router && context,
      "You must provide `router` and `context` to <StaticRouterProvider>"
    );
    let dataRouterContext = {
      router,
      navigator: getStatelessNavigator(),
      static: true,
      staticContext: context,
      basename: context.basename || "/"
    };
    let fetchersContext = /* @__PURE__ */ new Map();
    let hydrateScript = "";
    if (hydrate !== false) {
      let data = {
        loaderData: context.loaderData,
        actionData: context.actionData,
        errors: serializeErrors(context.errors)
      };
      let json = _chunkGR4NQCSDjs.escapeHtml.call(void 0, JSON.stringify(JSON.stringify(data)));
      hydrateScript = `window.__staticRouterHydrationData = JSON.parse(${json});`;
    }
    let { state } = dataRouterContext.router;
    return /* @__PURE__ */ React2.createElement(React2.Fragment, null, /* @__PURE__ */ React2.createElement(_chunkGR4NQCSDjs.DataRouterContext.Provider, { value: dataRouterContext }, /* @__PURE__ */ React2.createElement(_chunkGR4NQCSDjs.DataRouterStateContext.Provider, { value: state }, /* @__PURE__ */ React2.createElement(_chunkGR4NQCSDjs.FetchersContext.Provider, { value: fetchersContext }, /* @__PURE__ */ React2.createElement(_chunkGR4NQCSDjs.ViewTransitionContext.Provider, { value: { isTransitioning: false } }, /* @__PURE__ */ React2.createElement(
      _chunkGR4NQCSDjs.Router,
      {
        basename: dataRouterContext.basename,
        location: state.location,
        navigationType: state.historyAction,
        navigator: dataRouterContext.navigator,
        static: dataRouterContext.static,
        useTransitions: false
      },
      /* @__PURE__ */ React2.createElement(
        _chunkGR4NQCSDjs.DataRoutes,
        {
          manifest: router.manifest,
          routes: router.routes,
          future: router.future,
          state,
          isStatic: true
        }
      )
    ))))), hydrateScript ? /* @__PURE__ */ React2.createElement(
      "script",
      {
        suppressHydrationWarning: true,
        nonce,
        dangerouslySetInnerHTML: { __html: hydrateScript }
      }
    ) : null);
  }
  function serializeErrors(errors) {
    if (!errors) return null;
    let entries = Object.entries(errors);
    let serialized = {};
    for (let [key, val] of entries) {
      if (_chunkGR4NQCSDjs.isRouteErrorResponse.call(void 0, val)) {
        serialized[key] = { ...val, __type: "RouteErrorResponse" };
      } else if (val instanceof Error) {
        serialized[key] = {
          message: val.message,
          __type: "Error",
          // If this is a subclass (i.e., ReferenceError), send up the type so we
          // can re-create the same type during hydration.
          ...val.name !== "Error" ? {
            __subType: val.name
          } : {}
        };
      } else {
        serialized[key] = val;
      }
    }
    return serialized;
  }
  function getStatelessNavigator() {
    return {
      createHref,
      encodeLocation,
      push(to) {
        throw new Error(
          `You cannot use navigator.push() on the server because it is a stateless environment. This error was probably triggered when you did a \`navigate(${JSON.stringify(to)})\` somewhere in your app.`
        );
      },
      replace(to) {
        throw new Error(
          `You cannot use navigator.replace() on the server because it is a stateless environment. This error was probably triggered when you did a \`navigate(${JSON.stringify(to)}, { replace: true })\` somewhere in your app.`
        );
      },
      go(delta) {
        throw new Error(
          `You cannot use navigator.go() on the server because it is a stateless environment. This error was probably triggered when you did a \`navigate(${delta})\` somewhere in your app.`
        );
      },
      back() {
        throw new Error(
          `You cannot use navigator.back() on the server because it is a stateless environment.`
        );
      },
      forward() {
        throw new Error(
          `You cannot use navigator.forward() on the server because it is a stateless environment.`
        );
      }
    };
  }
  function createStaticHandler2(routes, opts) {
    return _chunkGR4NQCSDjs.createStaticHandler.call(void 0, routes, {
      ...opts,
      mapRouteProperties: _chunkGR4NQCSDjs.mapRouteProperties
    });
  }
  function createStaticRouter(routes, context, opts = {}) {
    let manifest = {};
    let dataRoutes = _chunkGR4NQCSDjs.convertRoutesToDataRoutes.call(
      void 0,
      routes,
      _chunkGR4NQCSDjs.mapRouteProperties,
      void 0,
      manifest
    );
    let matches = context.matches.map((match) => {
      let route = manifest[match.route.id] || match.route;
      return {
        ...match,
        route
      };
    });
    let msg = (method) => `You cannot use router.${method}() on the server because it is a stateless environment`;
    return {
      get basename() {
        return context.basename;
      },
      get future() {
        return {
          v8_middleware: false,
          v8_passThroughRequests: false,
          v8_trailingSlashAwareDataRequests: false,
          ..._optionalChain([opts, "optionalAccess", (_30) => _30.future])
        };
      },
      get state() {
        return {
          historyAction: "POP",
          location: context.location,
          matches,
          loaderData: context.loaderData,
          actionData: context.actionData,
          errors: context.errors,
          initialized: true,
          renderFallback: false,
          navigation: _chunkGR4NQCSDjs.IDLE_NAVIGATION,
          restoreScrollPosition: null,
          preventScrollReset: false,
          revalidation: "idle",
          fetchers: /* @__PURE__ */ new Map(),
          blockers: /* @__PURE__ */ new Map()
        };
      },
      get routes() {
        return dataRoutes;
      },
      get branches() {
        return opts.branches;
      },
      get manifest() {
        return manifest;
      },
      get window() {
        return void 0;
      },
      initialize() {
        throw msg("initialize");
      },
      subscribe() {
        throw msg("subscribe");
      },
      enableScrollRestoration() {
        throw msg("enableScrollRestoration");
      },
      navigate() {
        throw msg("navigate");
      },
      fetch() {
        throw msg("fetch");
      },
      revalidate() {
        throw msg("revalidate");
      },
      createHref,
      encodeLocation,
      getFetcher() {
        return _chunkGR4NQCSDjs.IDLE_FETCHER;
      },
      deleteFetcher() {
        throw msg("deleteFetcher");
      },
      resetFetcher() {
        throw msg("resetFetcher");
      },
      dispose() {
        throw msg("dispose");
      },
      getBlocker() {
        return _chunkGR4NQCSDjs.IDLE_BLOCKER;
      },
      deleteBlocker() {
        throw msg("deleteBlocker");
      },
      patchRoutes() {
        throw msg("patchRoutes");
      },
      _internalFetchControllers: /* @__PURE__ */ new Map(),
      _internalSetRoutes() {
        throw msg("_internalSetRoutes");
      },
      _internalSetStateDoNotUseOrYouWillBreakYourApp() {
        throw msg("_internalSetStateDoNotUseOrYouWillBreakYourApp");
      }
    };
  }
  function createHref(to) {
    return typeof to === "string" ? to : _chunkGR4NQCSDjs.createPath.call(void 0, to);
  }
  function encodeLocation(to) {
    let href = typeof to === "string" ? to : _chunkGR4NQCSDjs.createPath.call(void 0, to);
    href = href.replace(/ $/, "%20");
    let encoded = _chunkGR4NQCSDjs.ABSOLUTE_URL_REGEX.test(href) ? new URL(href) : new URL(href, "http://localhost");
    return {
      pathname: encoded.pathname,
      search: encoded.search,
      hash: encoded.hash
    };
  }
  chunkHQO5H5CC.createSearchParams = createSearchParams;
  chunkHQO5H5CC.createBrowserRouter = createBrowserRouter;
  chunkHQO5H5CC.createHashRouter = createHashRouter;
  chunkHQO5H5CC.BrowserRouter = BrowserRouter;
  chunkHQO5H5CC.HashRouter = HashRouter;
  chunkHQO5H5CC.HistoryRouter = HistoryRouter;
  chunkHQO5H5CC.Link = Link;
  chunkHQO5H5CC.NavLink = NavLink;
  chunkHQO5H5CC.Form = Form;
  chunkHQO5H5CC.ScrollRestoration = ScrollRestoration;
  chunkHQO5H5CC.useLinkClickHandler = useLinkClickHandler;
  chunkHQO5H5CC.useSearchParams = useSearchParams;
  chunkHQO5H5CC.useSubmit = useSubmit;
  chunkHQO5H5CC.useFormAction = useFormAction;
  chunkHQO5H5CC.useFetcher = useFetcher;
  chunkHQO5H5CC.useFetchers = useFetchers;
  chunkHQO5H5CC.useScrollRestoration = useScrollRestoration;
  chunkHQO5H5CC.useBeforeUnload = useBeforeUnload;
  chunkHQO5H5CC.usePrompt = usePrompt;
  chunkHQO5H5CC.useViewTransitionState = useViewTransitionState;
  chunkHQO5H5CC.StaticRouter = StaticRouter;
  chunkHQO5H5CC.StaticRouterProvider = StaticRouterProvider;
  chunkHQO5H5CC.createStaticHandler = createStaticHandler2;
  chunkHQO5H5CC.createStaticRouter = createStaticRouter;
  return chunkHQO5H5CC;
}
var hasRequiredDevelopment;
function requireDevelopment() {
  if (hasRequiredDevelopment) return development;
  hasRequiredDevelopment = 1;
  Object.defineProperty(development, "__esModule", { value: true });
  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};
      if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) {
            newObj[key] = obj[key];
          }
        }
      }
      newObj.default = obj;
      return newObj;
    }
  }
  function _nullishCoalesce(lhs, rhsFn) {
    if (lhs != null) {
      return lhs;
    } else {
      return rhsFn();
    }
  }
  function _optionalChain(ops) {
    let lastAccessLHS = void 0;
    let value = ops[0];
    let i = 1;
    while (i < ops.length) {
      const op = ops[i];
      const fn = ops[i + 1];
      i += 2;
      if ((op === "optionalAccess" || op === "optionalCall") && value == null) {
        return void 0;
      }
      if (op === "access" || op === "optionalAccess") {
        lastAccessLHS = value;
        value = fn(value);
      } else if (op === "call" || op === "optionalCall") {
        value = fn((...args) => value.call(lastAccessLHS, ...args));
        lastAccessLHS = void 0;
      }
    }
    return value;
  }
  var _chunkLVPI3KDGjs = /* @__PURE__ */ requireChunkLVPI3KDG();
  var _chunkHQO5H5CCjs = /* @__PURE__ */ requireChunkHQO5H5CC();
  var _chunkGR4NQCSDjs = /* @__PURE__ */ requireChunkGR4NQCSD();
  var _react = requireReact();
  var React = _interopRequireWildcard(_react);
  var React2 = _interopRequireWildcard(_react);
  var React3 = _interopRequireWildcard(_react);
  function ServerRouter({
    context,
    url,
    nonce
  }) {
    if (typeof url === "string") {
      url = new URL(url);
    }
    let { manifest, routeModules, criticalCss, serverHandoffString } = context;
    let routes = _chunkGR4NQCSDjs.createServerRoutes.call(
      void 0,
      manifest.routes,
      routeModules,
      context.future,
      context.isSpaMode
    );
    context.staticHandlerContext.loaderData = {
      ...context.staticHandlerContext.loaderData
    };
    for (let match of context.staticHandlerContext.matches) {
      let routeId = match.route.id;
      let route = routeModules[routeId];
      let manifestRoute = context.manifest.routes[routeId];
      if (route && manifestRoute && _chunkGR4NQCSDjs.shouldHydrateRouteLoader.call(
        void 0,
        routeId,
        route.clientLoader,
        manifestRoute.hasLoader,
        context.isSpaMode
      ) && (route.HydrateFallback || !manifestRoute.hasLoader)) {
        delete context.staticHandlerContext.loaderData[routeId];
      }
    }
    let router = _chunkHQO5H5CCjs.createStaticRouter.call(void 0, routes, context.staticHandlerContext, {
      branches: context.branches
    });
    return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(
      _chunkGR4NQCSDjs.FrameworkContext.Provider,
      {
        value: {
          manifest,
          routeModules,
          criticalCss,
          serverHandoffString,
          future: context.future,
          ssr: context.ssr,
          isSpaMode: context.isSpaMode,
          routeDiscovery: context.routeDiscovery,
          nonce,
          serializeError: context.serializeError,
          renderMeta: context.renderMeta
        }
      },
      /* @__PURE__ */ React.createElement(_chunkGR4NQCSDjs.RemixErrorBoundary, { location: router.state.location }, /* @__PURE__ */ React.createElement(
        _chunkHQO5H5CCjs.StaticRouterProvider,
        {
          router,
          context: context.staticHandlerContext,
          hydrate: false
        }
      ))
    ), context.serverHandoffStream ? /* @__PURE__ */ React.createElement(React.Suspense, null, /* @__PURE__ */ React.createElement(
      _chunkGR4NQCSDjs.StreamTransfer,
      {
        context,
        identifier: 0,
        reader: context.serverHandoffStream.getReader(),
        textDecoder: new TextDecoder(),
        nonce
      }
    )) : null);
  }
  function createRoutesStub(routes, _context) {
    return function RoutesTestStub({
      initialEntries,
      initialIndex,
      hydrationData,
      future
    }) {
      let routerRef = React2.useRef();
      let frameworkContextRef = React2.useRef();
      if (routerRef.current == null) {
        frameworkContextRef.current = {
          future: {
            v8_passThroughRequests: _optionalChain([future, "optionalAccess", (_2) => _2.v8_passThroughRequests]) === true,
            v8_middleware: _optionalChain([future, "optionalAccess", (_3) => _3.v8_middleware]) === true,
            v8_trailingSlashAwareDataRequests: _optionalChain([future, "optionalAccess", (_4) => _4.v8_trailingSlashAwareDataRequests]) === true
          },
          manifest: {
            routes: {},
            entry: { imports: [], module: "" },
            url: "",
            version: ""
          },
          routeModules: {},
          ssr: false,
          isSpaMode: false,
          routeDiscovery: { mode: "lazy", manifestPath: "/__manifest" }
        };
        let patched = processRoutes(
          // @ts-expect-error `StubRouteObject` is stricter about `loader`/`action`
          // types compared to `RouteObject`
          _chunkGR4NQCSDjs.convertRoutesToDataRoutes.call(void 0, routes, (r) => r),
          _context !== void 0 ? _context : _optionalChain([future, "optionalAccess", (_5) => _5.v8_middleware]) ? new _chunkGR4NQCSDjs.RouterContextProvider() : {},
          frameworkContextRef.current.manifest,
          frameworkContextRef.current.routeModules
        );
        routerRef.current = _chunkGR4NQCSDjs.createMemoryRouter.call(void 0, patched, {
          initialEntries,
          initialIndex,
          hydrationData
        });
      }
      return /* @__PURE__ */ React2.createElement(_chunkGR4NQCSDjs.FrameworkContext.Provider, { value: frameworkContextRef.current }, /* @__PURE__ */ React2.createElement(_chunkGR4NQCSDjs.RouterProvider, { router: routerRef.current }));
    };
  }
  function processRoutes(routes, context, manifest, routeModules, parentId) {
    return routes.map((route) => {
      if (!route.id) {
        throw new Error(
          "Expected a route.id in react-router processRoutes() function"
        );
      }
      let newRoute = {
        id: route.id,
        path: route.path,
        index: route.index,
        Component: route.Component ? _chunkGR4NQCSDjs.withComponentProps.call(void 0, route.Component) : void 0,
        HydrateFallback: route.HydrateFallback ? _chunkGR4NQCSDjs.withHydrateFallbackProps.call(void 0, route.HydrateFallback) : void 0,
        ErrorBoundary: route.ErrorBoundary ? _chunkGR4NQCSDjs.withErrorBoundaryProps.call(void 0, route.ErrorBoundary) : void 0,
        action: route.action ? (args) => route.action({ ...args, context }) : void 0,
        loader: route.loader ? (args) => route.loader({ ...args, context }) : void 0,
        middleware: route.middleware ? route.middleware.map(
          (mw) => (...args) => mw(
            { ...args[0], context },
            args[1]
          )
        ) : void 0,
        handle: route.handle,
        shouldRevalidate: route.shouldRevalidate
      };
      let entryRoute = {
        id: route.id,
        path: route.path,
        index: route.index,
        parentId,
        hasAction: route.action != null,
        hasLoader: route.loader != null,
        // When testing routes, you should be stubbing loader/action/middleware,
        // not trying to re-implement the full loader/clientLoader/SSR/hydration
        // flow. That is better tested via E2E tests.
        hasClientAction: false,
        hasClientLoader: false,
        hasClientMiddleware: false,
        hasErrorBoundary: route.ErrorBoundary != null,
        // any need for these?
        module: "build/stub-path-to-module.js",
        clientActionModule: void 0,
        clientLoaderModule: void 0,
        clientMiddlewareModule: void 0,
        hydrateFallbackModule: void 0
      };
      manifest.routes[newRoute.id] = entryRoute;
      routeModules[route.id] = {
        default: newRoute.Component || _chunkGR4NQCSDjs.Outlet,
        ErrorBoundary: newRoute.ErrorBoundary || void 0,
        handle: route.handle,
        links: route.links,
        meta: route.meta,
        shouldRevalidate: route.shouldRevalidate
      };
      if (route.children) {
        newRoute.children = processRoutes(
          route.children,
          context,
          manifest,
          routeModules,
          newRoute.id
        );
      }
      return newRoute;
    });
  }
  var _cookie = /* @__PURE__ */ requireDist();
  var encoder = /* @__PURE__ */ new TextEncoder();
  var sign = async (value, secret) => {
    let data2 = encoder.encode(value);
    let key = await createKey(secret, ["sign"]);
    let signature = await crypto.subtle.sign("HMAC", key, data2);
    let hash = btoa(String.fromCharCode(...new Uint8Array(signature))).replace(
      /=+$/,
      ""
    );
    return value + "." + hash;
  };
  var unsign = async (cookie, secret) => {
    let index = cookie.lastIndexOf(".");
    let value = cookie.slice(0, index);
    let hash = cookie.slice(index + 1);
    let data2 = encoder.encode(value);
    let key = await createKey(secret, ["verify"]);
    try {
      let signature = byteStringToUint8Array(atob(hash));
      let valid = await crypto.subtle.verify("HMAC", key, signature, data2);
      return valid ? value : false;
    } catch (e) {
      return false;
    }
  };
  var createKey = async (secret, usages) => crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    usages
  );
  function byteStringToUint8Array(byteString) {
    let array = new Uint8Array(byteString.length);
    for (let i = 0; i < byteString.length; i++) {
      array[i] = byteString.charCodeAt(i);
    }
    return array;
  }
  var createCookie = (name, cookieOptions = {}) => {
    let { secrets = [], ...options } = {
      path: "/",
      sameSite: "lax",
      ...cookieOptions
    };
    warnOnceAboutExpiresCookie(name, options.expires);
    return {
      get name() {
        return name;
      },
      get isSigned() {
        return secrets.length > 0;
      },
      get expires() {
        return typeof options.maxAge !== "undefined" ? new Date(Date.now() + options.maxAge * 1e3) : options.expires;
      },
      async parse(cookieHeader, parseOptions) {
        if (!cookieHeader) return null;
        let cookies = _cookie.parse.call(void 0, cookieHeader, { ...options, ...parseOptions });
        if (name in cookies) {
          let value = cookies[name];
          if (typeof value === "string" && value !== "") {
            let decoded = await decodeCookieValue(value, secrets);
            return decoded;
          } else {
            return "";
          }
        } else {
          return null;
        }
      },
      async serialize(value, serializeOptions) {
        return _cookie.serialize.call(
          void 0,
          name,
          value === "" ? "" : await encodeCookieValue(value, secrets),
          {
            ...options,
            ...serializeOptions
          }
        );
      }
    };
  };
  var isCookie = (object) => {
    return object != null && typeof object.name === "string" && typeof object.isSigned === "boolean" && typeof object.parse === "function" && typeof object.serialize === "function";
  };
  async function encodeCookieValue(value, secrets) {
    let encoded = encodeData(value);
    if (secrets.length > 0) {
      encoded = await sign(encoded, secrets[0]);
    }
    return encoded;
  }
  async function decodeCookieValue(value, secrets) {
    if (secrets.length > 0) {
      for (let secret of secrets) {
        let unsignedValue = await unsign(value, secret);
        if (unsignedValue !== false) {
          return decodeData(unsignedValue);
        }
      }
      return null;
    }
    return decodeData(value);
  }
  function encodeData(value) {
    return btoa(myUnescape(encodeURIComponent(JSON.stringify(value))));
  }
  function decodeData(value) {
    try {
      return JSON.parse(decodeURIComponent(myEscape(atob(value))));
    } catch (e) {
      return {};
    }
  }
  function myEscape(value) {
    let str = value.toString();
    let result = "";
    let index = 0;
    let chr, code;
    while (index < str.length) {
      chr = str.charAt(index++);
      if (/[\w*+\-./@]/.exec(chr)) {
        result += chr;
      } else {
        code = chr.charCodeAt(0);
        if (code < 256) {
          result += "%" + hex(code, 2);
        } else {
          result += "%u" + hex(code, 4).toUpperCase();
        }
      }
    }
    return result;
  }
  function hex(code, length) {
    let result = code.toString(16);
    while (result.length < length) result = "0" + result;
    return result;
  }
  function myUnescape(value) {
    let str = value.toString();
    let result = "";
    let index = 0;
    let chr, part;
    while (index < str.length) {
      chr = str.charAt(index++);
      if (chr === "%") {
        if (str.charAt(index) === "u") {
          part = str.slice(index + 1, index + 5);
          if (/^[\da-f]{4}$/i.exec(part)) {
            result += String.fromCharCode(parseInt(part, 16));
            index += 5;
            continue;
          }
        } else {
          part = str.slice(index, index + 2);
          if (/^[\da-f]{2}$/i.exec(part)) {
            result += String.fromCharCode(parseInt(part, 16));
            index += 2;
            continue;
          }
        }
      }
      result += chr;
    }
    return result;
  }
  function warnOnceAboutExpiresCookie(name, expires) {
    _chunkGR4NQCSDjs.warnOnce.call(
      void 0,
      !expires,
      `The "${name}" cookie has an "expires" property set. This will cause the expires value to not be updated when the session is committed. Instead, you should set the expires value when serializing the cookie. You can use \`commitSession(session, { expires })\` if using a session storage object, or \`cookie.serialize("value", { expires })\` if you're using the cookie directly.`
    );
  }
  function createEntryRouteModules(manifest) {
    return Object.keys(manifest).reduce((memo, routeId) => {
      let route = manifest[routeId];
      if (route) {
        memo[routeId] = route.module;
      }
      return memo;
    }, {});
  }
  var ServerMode = /* @__PURE__ */ ((ServerMode2) => {
    ServerMode2["Development"] = "development";
    ServerMode2["Production"] = "production";
    ServerMode2["Test"] = "test";
    return ServerMode2;
  })(ServerMode || {});
  function isServerMode(value) {
    return value === "development" || value === "production" || value === "test";
  }
  function sanitizeError(error, serverMode) {
    if (error instanceof Error && serverMode !== "development") {
      let sanitized = new Error("Unexpected Server Error");
      sanitized.stack = void 0;
      return sanitized;
    }
    return error;
  }
  function sanitizeErrors(errors, serverMode) {
    return Object.entries(errors).reduce((acc, [routeId, error]) => {
      return Object.assign(acc, { [routeId]: sanitizeError(error, serverMode) });
    }, {});
  }
  function serializeError(error, serverMode) {
    let sanitized = sanitizeError(error, serverMode);
    return {
      message: sanitized.message,
      stack: sanitized.stack
    };
  }
  function invariant2(value, message) {
    if (value === false || value === null || typeof value === "undefined") {
      console.error(
        "The following error is a bug in React Router; please open an issue! https://github.com/remix-run/react-router/issues/new/choose"
      );
      throw new Error(message);
    }
  }
  function matchServerRoutes(manifest, dataRoutes, branches, pathname, basename) {
    let matches = _chunkGR4NQCSDjs.matchRoutesImpl.call(
      void 0,
      dataRoutes,
      pathname,
      _nullishCoalesce(basename, () => "/"),
      false,
      branches
    );
    if (!matches) return null;
    return matches.map((match) => {
      let route = manifest[match.route.id];
      invariant2(
        route,
        `Route with id "${match.route.id}" not found in manifest.`
      );
      return {
        params: match.params,
        pathname: match.pathname,
        route
      };
    });
  }
  async function callRouteHandler(handler, args, future) {
    let result = await handler({
      request: future.v8_passThroughRequests ? args.request : stripRoutesParam(stripIndexParam(args.request)),
      url: args.url,
      params: args.params,
      context: args.context,
      pattern: args.pattern
    });
    if (_chunkGR4NQCSDjs.isDataWithResponseInit.call(void 0, result) && result.init && result.init.status && _chunkGR4NQCSDjs.isRedirectStatusCode.call(void 0, result.init.status)) {
      throw new Response(null, result.init);
    }
    return result;
  }
  function stripIndexParam(request) {
    let url = new URL(request.url);
    let indexValues = url.searchParams.getAll("index");
    url.searchParams.delete("index");
    let indexValuesToKeep = [];
    for (let indexValue of indexValues) {
      if (indexValue) {
        indexValuesToKeep.push(indexValue);
      }
    }
    for (let toKeep of indexValuesToKeep) {
      url.searchParams.append("index", toKeep);
    }
    let init = {
      method: request.method,
      body: request.body,
      headers: request.headers,
      signal: request.signal
    };
    if (init.body) {
      init.duplex = "half";
    }
    return new Request(url.href, init);
  }
  function stripRoutesParam(request) {
    let url = new URL(request.url);
    url.searchParams.delete("_routes");
    let init = {
      method: request.method,
      body: request.body,
      headers: request.headers,
      signal: request.signal
    };
    if (init.body) {
      init.duplex = "half";
    }
    return new Request(url.href, init);
  }
  var globalDevServerHooksKey = "__reactRouterDevServerHooks";
  function setDevServerHooks(devServerHooks) {
    globalThis[globalDevServerHooksKey] = devServerHooks;
  }
  function getDevServerHooks() {
    return globalThis[globalDevServerHooksKey];
  }
  function getBuildTimeHeader(request, headerName) {
    if (typeof process !== "undefined") {
      try {
        if (process.env.hasOwnProperty("IS_RR_BUILD_REQUEST") && process.env.IS_RR_BUILD_REQUEST === "yes") {
          return request.headers.get(headerName);
        }
      } catch (e) {
      }
    }
    return null;
  }
  function groupRoutesByParentId(manifest) {
    let routes = {};
    Object.values(manifest).forEach((route) => {
      if (route) {
        let parentId = route.parentId || "";
        if (!routes[parentId]) {
          routes[parentId] = [];
        }
        routes[parentId].push(route);
      }
    });
    return routes;
  }
  function createStaticHandlerDataRoutes(manifest, future, parentId = "", routesByParentId = groupRoutesByParentId(manifest)) {
    return (routesByParentId[parentId] || []).map((route) => {
      let commonRoute = {
        // Always include root due to default boundaries
        hasErrorBoundary: route.id === "root" || route.module.ErrorBoundary != null,
        id: route.id,
        path: route.path,
        middleware: route.module.middleware,
        // Need to use RR's version in the param typed here to permit the optional
        // context even though we know it'll always be provided in remix
        loader: route.module.loader ? async (args) => {
          let preRenderedData = getBuildTimeHeader(
            args.request,
            "X-React-Router-Prerender-Data"
          );
          if (preRenderedData != null) {
            let encoded = preRenderedData ? decodeURI(preRenderedData) : preRenderedData;
            invariant2(encoded, "Missing prerendered data for route");
            let uint8array = new TextEncoder().encode(encoded);
            let stream = new ReadableStream({
              start(controller) {
                controller.enqueue(uint8array);
                controller.close();
              }
            });
            let decoded = await _chunkGR4NQCSDjs.decodeViaTurboStream.call(void 0, stream, commonjsGlobal);
            let data2 = decoded.value;
            if (data2 && _chunkGR4NQCSDjs.SingleFetchRedirectSymbol in data2) {
              let result = data2[_chunkGR4NQCSDjs.SingleFetchRedirectSymbol];
              let init = { status: result.status };
              if (result.reload) {
                throw _chunkGR4NQCSDjs.redirectDocument.call(void 0, result.redirect, init);
              } else if (result.replace) {
                throw _chunkGR4NQCSDjs.replace.call(void 0, result.redirect, init);
              } else {
                throw _chunkGR4NQCSDjs.redirect.call(void 0, result.redirect, init);
              }
            } else {
              invariant2(
                data2 && route.id in data2,
                "Unable to decode prerendered data"
              );
              let result = data2[route.id];
              invariant2(
                "data" in result,
                "Unable to process prerendered data"
              );
              return result.data;
            }
          }
          let val = await callRouteHandler(
            route.module.loader,
            args,
            future
          );
          return val;
        } : void 0,
        action: route.module.action ? (args) => callRouteHandler(route.module.action, args, future) : void 0,
        handle: route.module.handle
      };
      return route.index ? {
        index: true,
        ...commonRoute
      } : {
        caseSensitive: route.caseSensitive,
        children: createStaticHandlerDataRoutes(
          manifest,
          future,
          route.id,
          routesByParentId
        ),
        ...commonRoute
      };
    });
  }
  function createServerHandoffString(serverHandoff) {
    return _chunkGR4NQCSDjs.escapeHtml.call(void 0, JSON.stringify(serverHandoff));
  }
  var _setcookieparser = /* @__PURE__ */ requireSetCookie();
  function getDocumentHeaders(context, build) {
    return getDocumentHeadersImpl(context, (m) => {
      let route = build.routes[m.route.id];
      invariant2(route, `Route with id "${m.route.id}" not found in build`);
      return route.module.headers;
    });
  }
  function getDocumentHeadersImpl(context, getRouteHeadersFn, _defaultHeaders) {
    let boundaryIdx = context.errors ? context.matches.findIndex((m) => context.errors[m.route.id]) : -1;
    let matches = boundaryIdx >= 0 ? context.matches.slice(0, boundaryIdx + 1) : context.matches;
    let errorHeaders;
    if (boundaryIdx >= 0) {
      let { actionHeaders, actionData, loaderHeaders, loaderData } = context;
      context.matches.slice(boundaryIdx).some((match) => {
        let id = match.route.id;
        if (actionHeaders[id] && (!actionData || !actionData.hasOwnProperty(id))) {
          errorHeaders = actionHeaders[id];
        } else if (loaderHeaders[id] && !loaderData.hasOwnProperty(id)) {
          errorHeaders = loaderHeaders[id];
        }
        return errorHeaders != null;
      });
    }
    const defaultHeaders = new Headers(_defaultHeaders);
    return matches.reduce((parentHeaders, match, idx) => {
      let { id } = match.route;
      let loaderHeaders = context.loaderHeaders[id] || new Headers();
      let actionHeaders = context.actionHeaders[id] || new Headers();
      let includeErrorHeaders = errorHeaders != null && idx === matches.length - 1;
      let includeErrorCookies = includeErrorHeaders && errorHeaders !== loaderHeaders && errorHeaders !== actionHeaders;
      let headersFn = getRouteHeadersFn(match);
      if (headersFn == null) {
        let headers2 = new Headers(parentHeaders);
        if (includeErrorCookies) {
          prependCookies(errorHeaders, headers2);
        }
        prependCookies(actionHeaders, headers2);
        prependCookies(loaderHeaders, headers2);
        return headers2;
      }
      let headers = new Headers(
        typeof headersFn === "function" ? headersFn({
          loaderHeaders,
          parentHeaders,
          actionHeaders,
          errorHeaders: includeErrorHeaders ? errorHeaders : void 0
        }) : headersFn
      );
      if (includeErrorCookies) {
        prependCookies(errorHeaders, headers);
      }
      prependCookies(actionHeaders, headers);
      prependCookies(loaderHeaders, headers);
      prependCookies(parentHeaders, headers);
      return headers;
    }, new Headers(defaultHeaders));
  }
  function prependCookies(parentHeaders, childHeaders) {
    let parentSetCookieString = parentHeaders.get("Set-Cookie");
    if (parentSetCookieString) {
      let cookies = _setcookieparser.splitCookiesString.call(void 0, parentSetCookieString);
      let childCookies = new Set(childHeaders.getSetCookie());
      cookies.forEach((cookie) => {
        if (!childCookies.has(cookie)) {
          childHeaders.append("Set-Cookie", cookie);
        }
      });
    }
  }
  function throwIfPotentialCSRFAttack(request, allowedActionOrigins) {
    let originHeader = request.headers.get("origin");
    let originDomain = null;
    let originUrl = null;
    try {
      if (typeof originHeader === "string" && originHeader !== "null") {
        originUrl = new URL(originHeader);
        originDomain = originUrl.host;
      } else {
        originDomain = originHeader;
      }
    } catch (e2) {
      throw new Error(
        `\`origin\` header is not a valid URL. Aborting the action.`
      );
    }
    let requestUrl = new URL(request.url);
    let originMatchesRequest = originUrl ? originUrl.origin === requestUrl.origin : originDomain === requestUrl.host;
    if (originDomain && !originMatchesRequest) {
      if (!isAllowedOrigin(originDomain, allowedActionOrigins)) {
        throw new Error(
          "The `request.url` origin does not match `origin` header from a forwarded action request. Aborting the action."
        );
      }
    }
  }
  function matchWildcardDomain(domain, pattern) {
    const domainParts = domain.split(".");
    const patternParts = pattern.split(".");
    if (patternParts.length < 1) {
      return false;
    }
    if (domainParts.length < patternParts.length) {
      return false;
    }
    while (patternParts.length) {
      const patternPart = patternParts.pop();
      const domainPart = domainParts.pop();
      switch (patternPart) {
        case "": {
          return false;
        }
        case "*": {
          if (domainPart) {
            continue;
          } else {
            return false;
          }
        }
        case "**": {
          if (patternParts.length > 0) {
            return false;
          }
          return domainPart !== void 0;
        }
        case void 0:
        default: {
          if (domainPart !== patternPart) {
            return false;
          }
        }
      }
    }
    return domainParts.length === 0;
  }
  function isAllowedOrigin(originDomain, allowedActionOrigins = []) {
    return allowedActionOrigins.some(
      (allowedOrigin) => allowedOrigin && (allowedOrigin === originDomain || matchWildcardDomain(originDomain, allowedOrigin))
    );
  }
  function getNormalizedPath(request, basename, future) {
    basename = basename || "/";
    let url = new URL(request.url);
    let pathname = url.pathname;
    if (_optionalChain([future, "optionalAccess", (_6) => _6.v8_trailingSlashAwareDataRequests])) {
      if (pathname.endsWith("/_.data")) {
        pathname = pathname.replace(/_\.data$/, "");
      } else {
        pathname = pathname.replace(/\.data$/, "");
      }
    } else {
      if (_chunkGR4NQCSDjs.stripBasename.call(void 0, pathname, basename) === "/_root.data") {
        pathname = basename;
      } else if (pathname.endsWith(".data")) {
        pathname = pathname.replace(/\.data$/, "");
      }
      if (_chunkGR4NQCSDjs.stripBasename.call(void 0, pathname, basename) !== "/" && pathname.endsWith("/")) {
        pathname = pathname.slice(0, -1);
      }
    }
    let searchParams = new URLSearchParams(url.search);
    searchParams.delete("_routes");
    let search = searchParams.toString();
    if (search) {
      search = `?${search}`;
    }
    return {
      pathname,
      search,
      // No hashes on the server
      hash: ""
    };
  }
  var SERVER_NO_BODY_STATUS_CODES = /* @__PURE__ */ new Set([
    ..._chunkGR4NQCSDjs.NO_BODY_STATUS_CODES,
    304
  ]);
  async function singleFetchAction(build, serverMode, staticHandler, request, handlerUrl, loadContext, handleError) {
    try {
      try {
        throwIfPotentialCSRFAttack(
          request,
          Array.isArray(build.allowedActionOrigins) ? build.allowedActionOrigins : []
        );
      } catch (e) {
        return handleQueryError(new Error("Bad Request"), 400);
      }
      let handlerRequest = build.future.v8_passThroughRequests ? request : new Request(handlerUrl, {
        method: request.method,
        body: request.body,
        headers: request.headers,
        signal: request.signal,
        ...request.body ? { duplex: "half" } : void 0
      });
      let result = await staticHandler.query(handlerRequest, {
        requestContext: loadContext,
        skipLoaderErrorBubbling: true,
        skipRevalidation: true,
        generateMiddlewareResponse: build.future.v8_middleware ? async (query) => {
          try {
            let innerResult = await query(handlerRequest);
            return handleQueryResult(innerResult);
          } catch (error) {
            return handleQueryError(error);
          }
        } : void 0,
        normalizePath: (r) => getNormalizedPath(r, build.basename, build.future)
      });
      return handleQueryResult(result);
    } catch (error) {
      return handleQueryError(error);
    }
    function handleQueryResult(result) {
      return _chunkGR4NQCSDjs.isResponse.call(void 0, result) ? result : staticContextToResponse(result);
    }
    function handleQueryError(error, status = 500) {
      handleError(error);
      return generateSingleFetchResponse(request, build, serverMode, {
        result: { error },
        headers: new Headers(),
        status
      });
    }
    function staticContextToResponse(context) {
      let headers = getDocumentHeaders(context, build);
      if (_chunkGR4NQCSDjs.isRedirectStatusCode.call(void 0, context.statusCode) && headers.has("Location")) {
        return new Response(null, { status: context.statusCode, headers });
      }
      if (context.errors) {
        Object.values(context.errors).forEach((err) => {
          if (!_chunkGR4NQCSDjs.isRouteErrorResponse.call(void 0, err) || err.error) {
            handleError(err);
          }
        });
        context.errors = sanitizeErrors(context.errors, serverMode);
      }
      let singleFetchResult;
      if (context.errors) {
        singleFetchResult = { error: Object.values(context.errors)[0] };
      } else {
        singleFetchResult = {
          data: Object.values(context.actionData || {})[0]
        };
      }
      return generateSingleFetchResponse(request, build, serverMode, {
        result: singleFetchResult,
        headers,
        status: context.statusCode
      });
    }
  }
  async function singleFetchLoaders(build, serverMode, staticHandler, request, handlerUrl, loadContext, handleError) {
    let routesParam = new URL(request.url).searchParams.get("_routes");
    let loadRouteIds = routesParam ? new Set(routesParam.split(",")) : null;
    try {
      let handlerRequest = build.future.v8_passThroughRequests ? request : new Request(handlerUrl, {
        headers: request.headers,
        signal: request.signal
      });
      let result = await staticHandler.query(handlerRequest, {
        requestContext: loadContext,
        filterMatchesToLoad: (m) => !loadRouteIds || loadRouteIds.has(m.route.id),
        skipLoaderErrorBubbling: true,
        generateMiddlewareResponse: build.future.v8_middleware ? async (query) => {
          try {
            let innerResult = await query(handlerRequest);
            return handleQueryResult(innerResult);
          } catch (error) {
            return handleQueryError(error);
          }
        } : void 0,
        normalizePath: (r) => getNormalizedPath(r, build.basename, build.future)
      });
      return handleQueryResult(result);
    } catch (error) {
      return handleQueryError(error);
    }
    function handleQueryResult(result) {
      return _chunkGR4NQCSDjs.isResponse.call(void 0, result) ? result : staticContextToResponse(result);
    }
    function handleQueryError(error) {
      handleError(error);
      return generateSingleFetchResponse(request, build, serverMode, {
        result: { error },
        headers: new Headers(),
        status: 500
      });
    }
    function staticContextToResponse(context) {
      let headers = getDocumentHeaders(context, build);
      if (_chunkGR4NQCSDjs.isRedirectStatusCode.call(void 0, context.statusCode) && headers.has("Location")) {
        return new Response(null, { status: context.statusCode, headers });
      }
      if (context.errors) {
        Object.values(context.errors).forEach((err) => {
          if (!_chunkGR4NQCSDjs.isRouteErrorResponse.call(void 0, err) || err.error) {
            handleError(err);
          }
        });
        context.errors = sanitizeErrors(context.errors, serverMode);
      }
      let results = {};
      let loadedMatches = new Set(
        context.matches.filter(
          (m) => loadRouteIds ? loadRouteIds.has(m.route.id) : m.route.loader != null
        ).map((m) => m.route.id)
      );
      if (context.errors) {
        for (let [id, error] of Object.entries(context.errors)) {
          results[id] = { error };
        }
      }
      for (let [id, data2] of Object.entries(context.loaderData)) {
        if (!(id in results) && loadedMatches.has(id)) {
          results[id] = { data: data2 };
        }
      }
      return generateSingleFetchResponse(request, build, serverMode, {
        result: results,
        headers,
        status: context.statusCode
      });
    }
  }
  function generateSingleFetchResponse(request, build, serverMode, {
    result,
    headers,
    status
  }) {
    let resultHeaders = new Headers(headers);
    resultHeaders.set("X-Remix-Response", "yes");
    if (SERVER_NO_BODY_STATUS_CODES.has(status)) {
      return new Response(null, { status, headers: resultHeaders });
    }
    resultHeaders.set("Content-Type", "text/x-script");
    resultHeaders.delete("Content-Length");
    return new Response(
      encodeViaTurboStream(
        result,
        request.signal,
        build.entry.module.streamTimeout,
        serverMode
      ),
      {
        status: status || 200,
        headers: resultHeaders
      }
    );
  }
  function generateSingleFetchRedirectResponse(redirectResponse, request, build, serverMode) {
    let redirect2 = getSingleFetchRedirect(
      redirectResponse.status,
      redirectResponse.headers,
      build.basename
    );
    let headers = new Headers(redirectResponse.headers);
    headers.delete("Location");
    headers.set("Content-Type", "text/x-script");
    return generateSingleFetchResponse(request, build, serverMode, {
      result: request.method === "GET" ? { [_chunkGR4NQCSDjs.SingleFetchRedirectSymbol]: redirect2 } : redirect2,
      headers,
      status: _chunkGR4NQCSDjs.SINGLE_FETCH_REDIRECT_STATUS
    });
  }
  function getSingleFetchRedirect(status, headers, basename) {
    let redirect2 = headers.get("Location");
    if (basename) {
      redirect2 = _chunkGR4NQCSDjs.stripBasename.call(void 0, redirect2, basename) || redirect2;
    }
    return {
      redirect: redirect2,
      status,
      revalidate: (
        // Technically X-Remix-Revalidate isn't needed here - that was an implementation
        // detail of ?_data requests as our way to tell the front end to revalidate when
        // we didn't have a response body to include that information in.
        // With single fetch, we tell the front end via this revalidate boolean field.
        // However, we're respecting it for now because it may be something folks have
        // used in their own responses
        // TODO(v3): Consider removing or making this official public API
        headers.has("X-Remix-Revalidate") || headers.has("Set-Cookie")
      ),
      reload: headers.has("X-Remix-Reload-Document"),
      replace: headers.has("X-Remix-Replace")
    };
  }
  function encodeViaTurboStream(data2, requestSignal, streamTimeout, serverMode) {
    let controller = new AbortController();
    let timeoutId = setTimeout(
      () => {
        controller.abort(new Error("Server Timeout"));
        cleanupCallbacks();
      },
      typeof streamTimeout === "number" ? streamTimeout : 4950
    );
    let abortControllerOnRequestAbort = () => {
      controller.abort(requestSignal.reason);
      cleanupCallbacks();
    };
    requestSignal.addEventListener("abort", abortControllerOnRequestAbort);
    let cleanupCallbacks = () => {
      clearTimeout(timeoutId);
      requestSignal.removeEventListener("abort", abortControllerOnRequestAbort);
    };
    return _chunkGR4NQCSDjs.encode.call(void 0, data2, {
      signal: controller.signal,
      onComplete: cleanupCallbacks,
      plugins: [
        (value) => {
          if (value instanceof Error) {
            let { name, message, stack } = serverMode === "production" ? sanitizeError(value, serverMode) : value;
            return ["SanitizedError", name, message, stack];
          }
          if (value instanceof _chunkGR4NQCSDjs.ErrorResponseImpl) {
            let { data: data3, status, statusText } = value;
            return ["ErrorResponse", data3, status, statusText];
          }
          if (value && typeof value === "object" && _chunkGR4NQCSDjs.SingleFetchRedirectSymbol in value) {
            return ["SingleFetchRedirect", value[_chunkGR4NQCSDjs.SingleFetchRedirectSymbol]];
          }
        }
      ],
      postPlugins: [
        (value) => {
          if (!value) return;
          if (typeof value !== "object") return;
          return [
            "SingleFetchClassInstance",
            Object.fromEntries(Object.entries(value))
          ];
        },
        () => ["SingleFetchFallback"]
      ]
    });
  }
  function derive(build, mode) {
    let dataRoutes = createStaticHandlerDataRoutes(build.routes, build.future);
    let serverMode = isServerMode(mode) ? mode : "production";
    let staticHandler = _chunkGR4NQCSDjs.createStaticHandler.call(void 0, dataRoutes, {
      basename: build.basename,
      instrumentations: build.entry.module.instrumentations,
      future: build.future
    });
    let errorHandler = build.entry.module.handleError || ((error, { request }) => {
      if (serverMode !== "test" && !request.signal.aborted) {
        console.error(
          // @ts-expect-error This is "private" from users but intended for internal use
          _chunkGR4NQCSDjs.isRouteErrorResponse.call(void 0, error) && error.error ? error.error : error
        );
      }
    });
    let requestHandler = async (request, initialContext) => {
      let params = {};
      let loadContext;
      let handleError = (error) => {
        if (mode === "development") {
          _optionalChain([getDevServerHooks, "call", (_7) => _7(), "optionalAccess", (_8) => _8.processRequestError, "optionalCall", (_9) => _9(error)]);
        }
        errorHandler(error, {
          context: loadContext,
          params,
          request
        });
      };
      if (build.future.v8_middleware) {
        if (initialContext && !(initialContext instanceof _chunkGR4NQCSDjs.RouterContextProvider)) {
          let error = new Error(
            "Invalid `context` value provided to `handleRequest`. When middleware is enabled you must return an instance of `RouterContextProvider` from your `getLoadContext` function."
          );
          handleError(error);
          return returnLastResortErrorResponse(error, serverMode);
        }
        loadContext = initialContext || new _chunkGR4NQCSDjs.RouterContextProvider();
      } else {
        loadContext = initialContext || {};
      }
      let requestUrl = new URL(request.url);
      let normalizedPathname = getNormalizedPath(
        request,
        build.basename,
        build.future
      ).pathname;
      let isSpaMode = getBuildTimeHeader(request, "X-React-Router-SPA-Mode") === "yes";
      if (!build.ssr) {
        let decodedPath = decodeURI(normalizedPathname);
        if (build.basename && build.basename !== "/") {
          let strippedPath = _chunkGR4NQCSDjs.stripBasename.call(void 0, decodedPath, build.basename);
          if (strippedPath == null) {
            errorHandler(
              new _chunkGR4NQCSDjs.ErrorResponseImpl(
                404,
                "Not Found",
                `Refusing to prerender the \`${decodedPath}\` path because it does not start with the basename \`${build.basename}\``
              ),
              {
                context: loadContext,
                params,
                request
              }
            );
            return new Response("Not Found", {
              status: 404,
              statusText: "Not Found"
            });
          }
          decodedPath = strippedPath;
        }
        if (build.prerender.length === 0) {
          isSpaMode = true;
        } else if (!build.prerender.includes(decodedPath.replace(/\/$/, "")) && !build.prerender.includes(decodedPath.replace(/[^/]$/, "/"))) {
          if (requestUrl.pathname.endsWith(".data")) {
            errorHandler(
              new _chunkGR4NQCSDjs.ErrorResponseImpl(
                404,
                "Not Found",
                `Refusing to SSR the path \`${decodedPath}\` because \`ssr:false\` is set and the path is not included in the \`prerender\` config, so in production the path will be a 404.`
              ),
              {
                context: loadContext,
                params,
                request
              }
            );
            return new Response("Not Found", {
              status: 404,
              statusText: "Not Found"
            });
          } else {
            isSpaMode = true;
          }
        }
      }
      let manifestUrl = _chunkGR4NQCSDjs.getManifestPath.call(
        void 0,
        build.routeDiscovery.manifestPath,
        build.basename
      );
      if (build.routeDiscovery.mode === "lazy" && requestUrl.pathname === manifestUrl) {
        try {
          let res = await handleManifestRequest(
            build,
            staticHandler.dataRoutes,
            staticHandler._internalRouteBranches,
            requestUrl
          );
          return res;
        } catch (e) {
          handleError(e);
          return new Response("Unknown Server Error", { status: 500 });
        }
      }
      let matches = matchServerRoutes(
        build.routes,
        staticHandler.dataRoutes,
        staticHandler._internalRouteBranches,
        normalizedPathname,
        build.basename
      );
      if (matches && matches.length > 0) {
        Object.assign(params, matches[0].params);
      }
      let response;
      if (requestUrl.pathname.endsWith(".data")) {
        response = await handleSingleFetchRequest(
          serverMode,
          build,
          staticHandler,
          request,
          normalizedPathname,
          loadContext,
          handleError
        );
        if (_chunkGR4NQCSDjs.isRedirectResponse.call(void 0, response)) {
          response = generateSingleFetchRedirectResponse(
            response,
            request,
            build,
            serverMode
          );
        }
        if (build.entry.module.handleDataRequest) {
          response = await build.entry.module.handleDataRequest(response, {
            context: loadContext,
            params: matches ? matches[0].params : {},
            request
          });
          if (_chunkGR4NQCSDjs.isRedirectResponse.call(void 0, response)) {
            response = generateSingleFetchRedirectResponse(
              response,
              request,
              build,
              serverMode
            );
          }
        }
      } else if (!isSpaMode && matches && matches[matches.length - 1].route.module.default == null && matches[matches.length - 1].route.module.ErrorBoundary == null) {
        response = await handleResourceRequest(
          serverMode,
          build,
          staticHandler,
          matches.slice(-1)[0].route.id,
          request,
          loadContext,
          handleError
        );
      } else {
        let { pathname } = requestUrl;
        let criticalCss = void 0;
        if (build.unstable_getCriticalCss) {
          criticalCss = await build.unstable_getCriticalCss({ pathname });
        } else if (mode === "development" && _optionalChain([getDevServerHooks, "call", (_10) => _10(), "optionalAccess", (_11) => _11.getCriticalCss])) {
          criticalCss = await _optionalChain([getDevServerHooks, "call", (_12) => _12(), "optionalAccess", (_13) => _13.getCriticalCss, "optionalCall", (_14) => _14(pathname)]);
        }
        response = await handleDocumentRequest(
          serverMode,
          build,
          staticHandler,
          request,
          loadContext,
          handleError,
          isSpaMode,
          criticalCss
        );
      }
      if (request.method === "HEAD") {
        return new Response(null, {
          headers: response.headers,
          status: response.status,
          statusText: response.statusText
        });
      }
      return response;
    };
    if (build.entry.module.instrumentations) {
      requestHandler = _chunkGR4NQCSDjs.instrumentHandler.call(
        void 0,
        requestHandler,
        build.entry.module.instrumentations.map((i) => i.handler).filter(Boolean)
      );
    }
    return {
      serverMode,
      staticHandler,
      errorHandler,
      requestHandler
    };
  }
  var createRequestHandler = (build, mode) => {
    let _build;
    let serverMode;
    let staticHandler;
    let errorHandler;
    let _requestHandler;
    return async function requestHandler(request, initialContext) {
      _build = typeof build === "function" ? await build() : build;
      if (typeof build === "function") {
        let derived = derive(_build, mode);
        serverMode = derived.serverMode;
        staticHandler = derived.staticHandler;
        errorHandler = derived.errorHandler;
        _requestHandler = derived.requestHandler;
      } else if (!serverMode || !staticHandler || !errorHandler || !_requestHandler) {
        let derived = derive(_build, mode);
        serverMode = derived.serverMode;
        staticHandler = derived.staticHandler;
        errorHandler = derived.errorHandler;
        _requestHandler = derived.requestHandler;
      }
      return _requestHandler(request, initialContext);
    };
  };
  async function handleManifestRequest(build, dataRoutes, branches, url) {
    if (url.toString().length > _chunkGR4NQCSDjs.URL_LIMIT) {
      return new Response(null, {
        statusText: "Bad Request",
        status: 400
      });
    }
    if (build.assets.version !== url.searchParams.get("version")) {
      return new Response(null, {
        status: 204,
        headers: {
          "X-Remix-Reload-Document": "true"
        }
      });
    }
    let patches = {};
    if (url.searchParams.has("paths")) {
      let pathParam = url.searchParams.get("paths") || "";
      let paths = new Set(pathParam.split(",").filter(Boolean));
      for (let path of paths) {
        if (!path.startsWith("/")) {
          path = `/${path}`;
        }
        let matches = matchServerRoutes(
          build.routes,
          dataRoutes,
          branches,
          path,
          build.basename
        );
        if (matches) {
          for (let match of matches) {
            let routeId = match.route.id;
            let route = build.assets.routes[routeId];
            if (route) {
              patches[routeId] = route;
            }
          }
        }
      }
      return Response.json(patches, {
        headers: {
          "Cache-Control": "public, max-age=31536000, immutable"
        }
      });
    }
    return new Response("Invalid Request", { status: 400 });
  }
  async function handleSingleFetchRequest(serverMode, build, staticHandler, request, normalizedPath, loadContext, handleError) {
    let handlerUrl = new URL(request.url);
    handlerUrl.pathname = normalizedPath;
    let response = _chunkGR4NQCSDjs.isMutationMethod.call(void 0, request.method) ? await singleFetchAction(
      build,
      serverMode,
      staticHandler,
      request,
      handlerUrl,
      loadContext,
      handleError
    ) : await singleFetchLoaders(
      build,
      serverMode,
      staticHandler,
      request,
      handlerUrl,
      loadContext,
      handleError
    );
    return response;
  }
  async function handleDocumentRequest(serverMode, build, staticHandler, request, loadContext, handleError, isSpaMode, criticalCss) {
    try {
      if (_chunkGR4NQCSDjs.isMutationMethod.call(void 0, request.method)) {
        try {
          throwIfPotentialCSRFAttack(
            request,
            Array.isArray(build.allowedActionOrigins) ? build.allowedActionOrigins : []
          );
        } catch (e) {
          handleError(e);
          return new Response("Bad Request", { status: 400 });
        }
      }
      let result = await staticHandler.query(request, {
        requestContext: loadContext,
        generateMiddlewareResponse: build.future.v8_middleware ? async (query) => {
          try {
            let innerResult = await query(request);
            if (!_chunkGR4NQCSDjs.isResponse.call(void 0, innerResult)) {
              innerResult = await renderHtml(innerResult, isSpaMode);
            }
            return innerResult;
          } catch (error) {
            handleError(error);
            return new Response(null, { status: 500 });
          }
        } : void 0,
        normalizePath: (r) => getNormalizedPath(r, build.basename, build.future)
      });
      if (!_chunkGR4NQCSDjs.isResponse.call(void 0, result)) {
        result = await renderHtml(result, isSpaMode);
      }
      return result;
    } catch (error) {
      handleError(error);
      return new Response(null, { status: 500 });
    }
    async function renderHtml(context, isSpaMode2) {
      let headers = getDocumentHeaders(context, build);
      if (SERVER_NO_BODY_STATUS_CODES.has(context.statusCode)) {
        return new Response(null, { status: context.statusCode, headers });
      }
      if (context.errors) {
        Object.values(context.errors).forEach((err) => {
          if (!_chunkGR4NQCSDjs.isRouteErrorResponse.call(void 0, err) || err.error) {
            handleError(err);
          }
        });
        context.errors = sanitizeErrors(context.errors, serverMode);
      }
      let state = {
        loaderData: context.loaderData,
        actionData: context.actionData,
        errors: context.errors
      };
      let baseServerHandoff = {
        basename: build.basename,
        future: build.future,
        routeDiscovery: build.routeDiscovery,
        ssr: build.ssr,
        isSpaMode: isSpaMode2
      };
      let entryContext = {
        manifest: build.assets,
        branches: staticHandler._internalRouteBranches,
        routeModules: createEntryRouteModules(build.routes),
        staticHandlerContext: context,
        criticalCss,
        serverHandoffString: createServerHandoffString({
          ...baseServerHandoff,
          criticalCss
        }),
        serverHandoffStream: encodeViaTurboStream(
          state,
          request.signal,
          build.entry.module.streamTimeout,
          serverMode
        ),
        renderMeta: {},
        future: build.future,
        ssr: build.ssr,
        routeDiscovery: build.routeDiscovery,
        isSpaMode: isSpaMode2,
        serializeError: (err) => serializeError(err, serverMode)
      };
      let handleDocumentRequestFunction = build.entry.module.default;
      try {
        return await handleDocumentRequestFunction(
          request,
          context.statusCode,
          headers,
          entryContext,
          loadContext
        );
      } catch (error) {
        handleError(error);
        let errorForSecondRender = error;
        if (_chunkGR4NQCSDjs.isResponse.call(void 0, error)) {
          try {
            let data2 = await unwrapResponse(error);
            errorForSecondRender = new (0, _chunkGR4NQCSDjs.ErrorResponseImpl)(
              error.status,
              error.statusText,
              data2
            );
          } catch (e) {
          }
        }
        context = _chunkGR4NQCSDjs.getStaticContextFromError.call(
          void 0,
          staticHandler.dataRoutes,
          context,
          errorForSecondRender
        );
        if (context.errors) {
          context.errors = sanitizeErrors(context.errors, serverMode);
        }
        let state2 = {
          loaderData: context.loaderData,
          actionData: context.actionData,
          errors: context.errors
        };
        entryContext = {
          ...entryContext,
          staticHandlerContext: context,
          serverHandoffString: createServerHandoffString(baseServerHandoff),
          serverHandoffStream: encodeViaTurboStream(
            state2,
            request.signal,
            build.entry.module.streamTimeout,
            serverMode
          ),
          renderMeta: {}
        };
        try {
          return await handleDocumentRequestFunction(
            request,
            context.statusCode,
            headers,
            entryContext,
            loadContext
          );
        } catch (error2) {
          handleError(error2);
          return returnLastResortErrorResponse(error2, serverMode);
        }
      }
    }
  }
  async function handleResourceRequest(serverMode, build, staticHandler, routeId, request, loadContext, handleError) {
    try {
      let result = await staticHandler.queryRoute(request, {
        routeId,
        requestContext: loadContext,
        generateMiddlewareResponse: build.future.v8_middleware ? async (queryRoute) => {
          try {
            let innerResult = await queryRoute(request);
            return handleQueryRouteResult(innerResult);
          } catch (error) {
            return handleQueryRouteError(error);
          }
        } : void 0,
        normalizePath: (r) => getNormalizedPath(r, build.basename, build.future)
      });
      return handleQueryRouteResult(result);
    } catch (error) {
      return handleQueryRouteError(error);
    }
    function handleQueryRouteResult(result) {
      if (_chunkGR4NQCSDjs.isResponse.call(void 0, result)) {
        return result;
      }
      if (typeof result === "string") {
        return new Response(result);
      }
      return Response.json(result);
    }
    function handleQueryRouteError(error) {
      if (_chunkGR4NQCSDjs.isResponse.call(void 0, error)) {
        return error;
      }
      if (_chunkGR4NQCSDjs.isRouteErrorResponse.call(void 0, error)) {
        handleError(error);
        return errorResponseToJson(error, serverMode);
      }
      if (error instanceof Error && error.message === "Expected a response from queryRoute") {
        let newError = new Error(
          "Expected a Response to be returned from resource route handler"
        );
        handleError(newError);
        return returnLastResortErrorResponse(newError, serverMode);
      }
      handleError(error);
      return returnLastResortErrorResponse(error, serverMode);
    }
  }
  function errorResponseToJson(errorResponse, serverMode) {
    return Response.json(
      serializeError(
        // @ts-expect-error This is "private" from users but intended for internal use
        errorResponse.error || new Error("Unexpected Server Error"),
        serverMode
      ),
      {
        status: errorResponse.status,
        statusText: errorResponse.statusText
      }
    );
  }
  function returnLastResortErrorResponse(error, serverMode) {
    let message = "Unexpected Server Error";
    if (serverMode !== "production") {
      message += `

${String(error)}`;
    }
    return new Response(message, {
      status: 500,
      headers: {
        "Content-Type": "text/plain"
      }
    });
  }
  function unwrapResponse(response) {
    let contentType = response.headers.get("Content-Type");
    return contentType && /\bapplication\/json\b/.test(contentType) ? response.body == null ? null : response.json() : response.text();
  }
  function flash(name) {
    return `__flash_${name}__`;
  }
  var createSession = (initialData = {}, id = "") => {
    let map = new Map(Object.entries(initialData));
    return {
      get id() {
        return id;
      },
      get data() {
        return Object.fromEntries(map);
      },
      has(name) {
        return map.has(name) || map.has(flash(name));
      },
      get(name) {
        if (map.has(name)) return map.get(name);
        let flashName = flash(name);
        if (map.has(flashName)) {
          let value = map.get(flashName);
          map.delete(flashName);
          return value;
        }
        return void 0;
      },
      set(name, value) {
        map.set(name, value);
      },
      flash(name, value) {
        map.set(flash(name), value);
      },
      unset(name) {
        map.delete(name);
      }
    };
  };
  var isSession = (object) => {
    return object != null && typeof object.id === "string" && typeof object.data !== "undefined" && typeof object.has === "function" && typeof object.get === "function" && typeof object.set === "function" && typeof object.flash === "function" && typeof object.unset === "function";
  };
  function createSessionStorage({
    cookie: cookieArg,
    createData,
    readData,
    updateData,
    deleteData
  }) {
    let cookie = isCookie(cookieArg) ? cookieArg : createCookie(_optionalChain([cookieArg, "optionalAccess", (_15) => _15.name]) || "__session", cookieArg);
    warnOnceAboutSigningSessionCookie(cookie);
    return {
      async getSession(cookieHeader, options) {
        let id = cookieHeader && await cookie.parse(cookieHeader, options);
        let data2 = id && await readData(id);
        return createSession(data2 || {}, id || "");
      },
      async commitSession(session, options) {
        let { id, data: data2 } = session;
        let expires = _optionalChain([options, "optionalAccess", (_16) => _16.maxAge]) != null ? new Date(Date.now() + options.maxAge * 1e3) : _optionalChain([options, "optionalAccess", (_17) => _17.expires]) != null ? options.expires : cookie.expires;
        if (id) {
          await updateData(id, data2, expires);
        } else {
          id = await createData(data2, expires);
        }
        return cookie.serialize(id, options);
      },
      async destroySession(session, options) {
        await deleteData(session.id);
        return cookie.serialize("", {
          ...options,
          maxAge: void 0,
          expires: /* @__PURE__ */ new Date(0)
        });
      }
    };
  }
  function warnOnceAboutSigningSessionCookie(cookie) {
    _chunkGR4NQCSDjs.warnOnce.call(
      void 0,
      cookie.isSigned,
      `The "${cookie.name}" cookie is not signed, but session cookies should be signed to prevent tampering on the client before they are sent back to the server. See https://reactrouter.com/explanation/sessions-and-cookies#signing-cookies for more information.`
    );
  }
  function createCookieSessionStorage({ cookie: cookieArg } = {}) {
    let cookie = isCookie(cookieArg) ? cookieArg : createCookie(_optionalChain([cookieArg, "optionalAccess", (_18) => _18.name]) || "__session", cookieArg);
    warnOnceAboutSigningSessionCookie(cookie);
    return {
      async getSession(cookieHeader, options) {
        return createSession(
          cookieHeader && await cookie.parse(cookieHeader, options) || {}
        );
      },
      async commitSession(session, options) {
        let serializedCookie = await cookie.serialize(session.data, options);
        if (serializedCookie.length > 4096) {
          throw new Error(
            "Cookie length will exceed browser maximum. Length: " + serializedCookie.length
          );
        }
        return serializedCookie;
      },
      async destroySession(_session, options) {
        return cookie.serialize("", {
          ...options,
          maxAge: void 0,
          expires: /* @__PURE__ */ new Date(0)
        });
      }
    };
  }
  function createMemorySessionStorage({ cookie } = {}) {
    let map = /* @__PURE__ */ new Map();
    return createSessionStorage({
      cookie,
      async createData(data2, expires) {
        let id = Math.random().toString(36).substring(2, 10);
        map.set(id, { data: data2, expires });
        return id;
      },
      async readData(id) {
        if (map.has(id)) {
          let { data: data2, expires } = map.get(id);
          if (!expires || expires > /* @__PURE__ */ new Date()) {
            return data2;
          }
          if (expires) map.delete(id);
        }
        return null;
      },
      async updateData(id, data2, expires) {
        map.set(id, { data: data2, expires });
      },
      async deleteData(id) {
        map.delete(id);
      }
    });
  }
  function href(path, ...args) {
    let params = args[0];
    let result = trimTrailingSplat(path).replace(
      /\/:([\w-]+)(\?)?/g,
      // same regex as in .\router\utils.ts: compilePath().
      (_, param, questionMark) => {
        const isRequired = questionMark === void 0;
        const value = _optionalChain([params, "optionalAccess", (_19) => _19[param]]);
        if (isRequired && value === void 0) {
          throw new Error(
            `Path '${path}' requires param '${param}' but it was not provided`
          );
        }
        return value === void 0 ? "" : "/" + value;
      }
    );
    if (path.endsWith("*")) {
      const value = _optionalChain([params, "optionalAccess", (_20) => _20["*"]]);
      if (value !== void 0) {
        result += "/" + value;
      }
    }
    return result || "/";
  }
  function trimTrailingSplat(path) {
    let i = path.length - 1;
    let char = path[i];
    if (char !== "*" && char !== "/") return path;
    i--;
    for (; i >= 0; i--) {
      if (path[i] !== "/") break;
    }
    return path.slice(0, i + 1);
  }
  var encoder2 = new TextEncoder();
  var trailer = "</body></html>";
  function injectRSCPayload(rscStream) {
    let decoder = new TextDecoder();
    let resolveFlightDataPromise;
    let flightDataPromise = new Promise(
      (resolve) => resolveFlightDataPromise = resolve
    );
    let startedRSC = false;
    let buffered = [];
    let timeout = null;
    function flushBufferedChunks(controller) {
      for (let chunk of buffered) {
        let buf = decoder.decode(chunk, { stream: true });
        if (buf.endsWith(trailer)) {
          buf = buf.slice(0, -trailer.length);
        }
        controller.enqueue(encoder2.encode(buf));
      }
      buffered.length = 0;
      timeout = null;
    }
    return new TransformStream({
      transform(chunk, controller) {
        buffered.push(chunk);
        if (timeout) {
          return;
        }
        timeout = setTimeout(async () => {
          flushBufferedChunks(controller);
          if (!startedRSC) {
            startedRSC = true;
            writeRSCStream(rscStream, controller).catch((err) => controller.error(err)).then(resolveFlightDataPromise);
          }
        }, 0);
      },
      async flush(controller) {
        await flightDataPromise;
        if (timeout) {
          clearTimeout(timeout);
          flushBufferedChunks(controller);
        }
        controller.enqueue(encoder2.encode("</body></html>"));
      }
    });
  }
  async function writeRSCStream(rscStream, controller) {
    let decoder = new TextDecoder("utf-8", { fatal: true });
    const reader = rscStream.getReader();
    try {
      let read;
      while ((read = await reader.read()) && !read.done) {
        const chunk = read.value;
        try {
          writeChunk(
            JSON.stringify(decoder.decode(chunk, { stream: true })),
            controller
          );
        } catch (e) {
          let base64 = JSON.stringify(btoa(String.fromCodePoint(...chunk)));
          writeChunk(
            `Uint8Array.from(atob(${base64}), m => m.codePointAt(0))`,
            controller
          );
        }
      }
    } finally {
      reader.releaseLock();
    }
    let remaining = decoder.decode();
    if (remaining.length) {
      writeChunk(JSON.stringify(remaining), controller);
    }
  }
  function writeChunk(chunk, controller) {
    controller.enqueue(
      encoder2.encode(
        `<script>${escapeScript(
          `(self.__FLIGHT_DATA||=[]).push(${chunk})`
        )}<\/script>`
      )
    );
  }
  function escapeScript(script) {
    return script.replace(/<!--/g, "<\\!--").replace(/<\/(script)/gi, "</\\$1");
  }
  var defaultManifestPath = "/__manifest";
  var REACT_USE = "use";
  var useImpl = React3[REACT_USE];
  function useSafe(promise) {
    if (useImpl) {
      return useImpl(promise);
    }
    throw new Error("React Router v7 requires React 19+ for RSC features.");
  }
  async function routeRSCServerRequest({
    request,
    serverResponse,
    createFromReadableStream,
    renderHTML,
    hydrate = true
  }) {
    const url = new URL(request.url);
    const isDataRequest = isReactServerRequest(url);
    const respondWithRSCPayload = isDataRequest || isManifestRequest(url) || request.headers.has("rsc-action-id");
    if (respondWithRSCPayload || serverResponse.headers.get("React-Router-Resource") === "true") {
      return serverResponse;
    }
    if (!serverResponse.body) {
      throw new Error("Missing body in server response");
    }
    const detectRedirectResponse = serverResponse.clone();
    let serverResponseB = null;
    if (hydrate) {
      serverResponseB = serverResponse.clone();
    }
    const body = serverResponse.body;
    let buffer;
    let streamControllers = [];
    const createStream = () => {
      if (!buffer) {
        buffer = [];
        return body.pipeThrough(
          new TransformStream({
            transform(chunk, controller) {
              buffer.push(chunk);
              controller.enqueue(chunk);
              streamControllers.forEach((c) => c.enqueue(chunk));
            },
            flush() {
              streamControllers.forEach((c) => c.close());
              streamControllers = [];
            }
          })
        );
      }
      return new ReadableStream({
        start(controller) {
          buffer.forEach((chunk) => controller.enqueue(chunk));
          streamControllers.push(controller);
        }
      });
    };
    let deepestRenderedBoundaryId = null;
    const getPayload = () => {
      const payloadPromise = Promise.resolve(
        createFromReadableStream(createStream())
      );
      return Object.defineProperties(payloadPromise, {
        _deepestRenderedBoundaryId: {
          get() {
            return deepestRenderedBoundaryId;
          },
          set(boundaryId) {
            deepestRenderedBoundaryId = boundaryId;
          }
        },
        formState: {
          get() {
            return payloadPromise.then(
              (payload) => payload.type === "render" ? payload.formState : void 0
            );
          }
        }
      });
    };
    let renderRedirect;
    let renderError;
    try {
      if (!detectRedirectResponse.body) {
        throw new Error("Failed to clone server response");
      }
      const payload = await createFromReadableStream(
        detectRedirectResponse.body
      );
      if (serverResponse.status === _chunkGR4NQCSDjs.SINGLE_FETCH_REDIRECT_STATUS && payload.type === "redirect") {
        if (_chunkGR4NQCSDjs.hasInvalidProtocol.call(void 0, payload.location)) {
          throw new Error("Invalid redirect location");
        }
        const headers2 = new Headers(serverResponse.headers);
        headers2.delete("Content-Encoding");
        headers2.delete("Content-Length");
        headers2.delete("Content-Type");
        headers2.delete("X-Remix-Response");
        headers2.set("Location", payload.location);
        return new Response(_optionalChain([serverResponseB, "optionalAccess", (_21) => _21.body]) || "", {
          headers: headers2,
          status: payload.status,
          statusText: serverResponse.statusText
        });
      }
      let reactHeaders = new Headers();
      let status = serverResponse.status;
      let statusText = serverResponse.statusText;
      let html = await renderHTML(getPayload, {
        onError(error) {
          if (typeof error === "object" && error && "digest" in error && typeof error.digest === "string") {
            renderRedirect = _chunkGR4NQCSDjs.decodeRedirectErrorDigest.call(void 0, error.digest);
            if (renderRedirect) {
              return error.digest;
            }
            let routeErrorResponse = _chunkGR4NQCSDjs.decodeRouteErrorResponseDigest.call(void 0, error.digest);
            if (routeErrorResponse) {
              renderError = routeErrorResponse;
              status = routeErrorResponse.status;
              statusText = routeErrorResponse.statusText;
              return error.digest;
            }
          }
        },
        onHeaders(headers2) {
          for (const [key, value] of headers2) {
            reactHeaders.append(key, value);
          }
        }
      });
      const headers = new Headers(reactHeaders);
      for (const [key, value] of serverResponse.headers) {
        headers.append(key, value);
      }
      headers.set("Content-Type", "text/html; charset=utf-8");
      if (renderRedirect) {
        if (_chunkGR4NQCSDjs.hasInvalidProtocol.call(void 0, renderRedirect.location)) {
          throw new Error("Invalid redirect location");
        }
        headers.set("Location", renderRedirect.location);
        return new Response(html, {
          status: renderRedirect.status,
          headers
        });
      }
      const redirectTransform = new TransformStream({
        flush(controller) {
          if (renderRedirect) {
            if (_chunkGR4NQCSDjs.hasInvalidProtocol.call(void 0, renderRedirect.location)) {
              return;
            }
            controller.enqueue(
              new TextEncoder().encode(
                `<meta http-equiv="refresh" content="0;url=${_chunkGR4NQCSDjs.escapeAttribute.call(void 0, renderRedirect.location)}"/>`
              )
            );
          }
        }
      });
      if (!hydrate) {
        return new Response(html.pipeThrough(redirectTransform), {
          status,
          statusText,
          headers
        });
      }
      if (!_optionalChain([serverResponseB, "optionalAccess", (_22) => _22.body])) {
        throw new Error("Failed to clone server response");
      }
      const body2 = html.pipeThrough(injectRSCPayload(serverResponseB.body)).pipeThrough(redirectTransform);
      return new Response(body2, {
        status,
        statusText,
        headers
      });
    } catch (error) {
      if (error instanceof Response) {
        return error;
      }
      if (renderRedirect) {
        if (_chunkGR4NQCSDjs.hasInvalidProtocol.call(void 0, renderRedirect.location)) {
          throw new Error("Invalid redirect location");
        }
        return new Response(`Redirect: ${renderRedirect.location}`, {
          status: renderRedirect.status,
          headers: {
            Location: renderRedirect.location
          }
        });
      }
      try {
        let normalizedError = _nullishCoalesce(renderError, () => error);
        let [status, statusText] = _chunkGR4NQCSDjs.isRouteErrorResponse.call(void 0, normalizedError) ? [normalizedError.status, normalizedError.statusText] : [500, ""];
        let retryRedirect;
        let reactHeaders = new Headers();
        const html = await renderHTML(
          () => {
            const decoded = Promise.resolve(
              createFromReadableStream(createStream())
            );
            const payloadPromise = decoded.then(
              (payload) => Object.assign(payload, {
                status,
                errors: deepestRenderedBoundaryId ? {
                  [deepestRenderedBoundaryId]: normalizedError
                } : {}
              })
            );
            return Object.defineProperties(payloadPromise, {
              _deepestRenderedBoundaryId: {
                get() {
                  return deepestRenderedBoundaryId;
                },
                set(boundaryId) {
                  deepestRenderedBoundaryId = boundaryId;
                }
              },
              formState: {
                get() {
                  return payloadPromise.then(
                    (payload) => payload.type === "render" ? payload.formState : void 0
                  );
                }
              }
            });
          },
          {
            onError(error2) {
              if (typeof error2 === "object" && error2 && "digest" in error2 && typeof error2.digest === "string") {
                retryRedirect = _chunkGR4NQCSDjs.decodeRedirectErrorDigest.call(void 0, error2.digest);
                if (retryRedirect) {
                  return error2.digest;
                }
                let routeErrorResponse = _chunkGR4NQCSDjs.decodeRouteErrorResponseDigest.call(
                  void 0,
                  error2.digest
                );
                if (routeErrorResponse) {
                  status = routeErrorResponse.status;
                  statusText = routeErrorResponse.statusText;
                  return error2.digest;
                }
              }
            },
            onHeaders(headers2) {
              for (const [key, value] of headers2) {
                reactHeaders.append(key, value);
              }
            }
          }
        );
        const headers = new Headers(reactHeaders);
        for (const [key, value] of serverResponse.headers) {
          headers.append(key, value);
        }
        headers.set("Content-Type", "text/html; charset=utf-8");
        if (retryRedirect) {
          if (_chunkGR4NQCSDjs.hasInvalidProtocol.call(void 0, retryRedirect.location)) {
            throw new Error("Invalid redirect location");
          }
          headers.set("Location", retryRedirect.location);
          return new Response(html, {
            status: retryRedirect.status,
            headers
          });
        }
        const retryRedirectTransform = new TransformStream({
          flush(controller) {
            if (retryRedirect) {
              if (_chunkGR4NQCSDjs.hasInvalidProtocol.call(void 0, retryRedirect.location)) {
                return;
              }
              controller.enqueue(
                new TextEncoder().encode(
                  `<meta http-equiv="refresh" content="0;url=${_chunkGR4NQCSDjs.escapeAttribute.call(void 0, retryRedirect.location)}"/>`
                )
              );
            }
          }
        });
        if (!hydrate) {
          return new Response(html.pipeThrough(retryRedirectTransform), {
            status,
            statusText,
            headers
          });
        }
        if (!_optionalChain([serverResponseB, "optionalAccess", (_23) => _23.body])) {
          throw new Error("Failed to clone server response");
        }
        const body2 = html.pipeThrough(injectRSCPayload(serverResponseB.body)).pipeThrough(retryRedirectTransform);
        return new Response(body2, {
          status,
          statusText,
          headers
        });
      } catch (error2) {
      }
      throw error;
    }
  }
  function RSCStaticRouter({ getPayload }) {
    const decoded = getPayload();
    const payload = useSafe(decoded);
    if (payload.type === "redirect") {
      if (_chunkGR4NQCSDjs.hasInvalidProtocol.call(void 0, payload.location)) {
        throw new Error("Invalid redirect location");
      }
      throw new Response(null, {
        status: payload.status,
        headers: {
          Location: payload.location
        }
      });
    }
    if (payload.type !== "render") return null;
    let patchedLoaderData = { ...payload.loaderData };
    for (const match of payload.matches) {
      if (_chunkGR4NQCSDjs.shouldHydrateRouteLoader.call(
        void 0,
        match.id,
        match.clientLoader,
        match.hasLoader,
        false
      ) && (match.hydrateFallbackElement || !match.hasLoader)) {
        delete patchedLoaderData[match.id];
      }
    }
    const context = {
      get _deepestRenderedBoundaryId() {
        return _nullishCoalesce(decoded._deepestRenderedBoundaryId, () => null);
      },
      set _deepestRenderedBoundaryId(boundaryId) {
        decoded._deepestRenderedBoundaryId = boundaryId;
      },
      actionData: payload.actionData,
      actionHeaders: {},
      basename: payload.basename,
      errors: payload.errors,
      loaderData: patchedLoaderData,
      loaderHeaders: {},
      location: payload.location,
      statusCode: 200,
      matches: payload.matches.map((match) => ({
        params: match.params,
        pathname: match.pathname,
        pathnameBase: match.pathnameBase,
        route: {
          id: match.id,
          action: match.hasAction || !!match.clientAction,
          handle: match.handle,
          hasErrorBoundary: match.hasErrorBoundary,
          loader: match.hasLoader || !!match.clientLoader,
          index: match.index,
          path: match.path,
          shouldRevalidate: match.shouldRevalidate
        }
      }))
    };
    const router = _chunkHQO5H5CCjs.createStaticRouter.call(
      void 0,
      payload.matches.reduceRight((previous, match) => {
        const route = {
          id: match.id,
          action: match.hasAction || !!match.clientAction,
          element: match.element,
          errorElement: match.errorElement,
          handle: match.handle,
          hasErrorBoundary: !!match.errorElement,
          hydrateFallbackElement: match.hydrateFallbackElement,
          index: match.index,
          loader: match.hasLoader || !!match.clientLoader,
          path: match.path,
          shouldRevalidate: match.shouldRevalidate
        };
        if (previous.length > 0) {
          route.children = previous;
        }
        return [route];
      }, []),
      context
    );
    const frameworkContext = {
      future: {
        // These flags have no runtime impact so can always be false.  If we add
        // flags that drive runtime behavior they'll need to be proxied through.
        v8_middleware: false,
        v8_trailingSlashAwareDataRequests: true,
        // always on for RSC
        v8_passThroughRequests: true
        // always on for RSC
      },
      isSpaMode: false,
      ssr: true,
      criticalCss: "",
      manifest: {
        routes: {},
        version: "1",
        url: "",
        entry: {
          module: "",
          imports: []
        }
      },
      routeDiscovery: payload.routeDiscovery.mode === "initial" ? { mode: "initial", manifestPath: defaultManifestPath } : {
        mode: "lazy",
        manifestPath: payload.routeDiscovery.manifestPath || defaultManifestPath
      },
      routeModules: _chunkLVPI3KDGjs.createRSCRouteModules.call(void 0, payload)
    };
    return /* @__PURE__ */ React3.createElement(_chunkGR4NQCSDjs.RSCRouterContext.Provider, { value: true }, /* @__PURE__ */ React3.createElement(_chunkLVPI3KDGjs.RSCRouterGlobalErrorBoundary, { location: payload.location }, /* @__PURE__ */ React3.createElement(_chunkGR4NQCSDjs.FrameworkContext.Provider, { value: frameworkContext }, /* @__PURE__ */ React3.createElement(
      _chunkHQO5H5CCjs.StaticRouterProvider,
      {
        context,
        router,
        hydrate: false,
        nonce: payload.nonce
      }
    ))));
  }
  function isReactServerRequest(url) {
    return url.pathname.endsWith(".rsc");
  }
  function isManifestRequest(url) {
    return url.pathname.endsWith(".manifest");
  }
  development.Await = _chunkGR4NQCSDjs.Await;
  development.BrowserRouter = _chunkHQO5H5CCjs.BrowserRouter;
  development.Form = _chunkHQO5H5CCjs.Form;
  development.HashRouter = _chunkHQO5H5CCjs.HashRouter;
  development.IDLE_BLOCKER = _chunkGR4NQCSDjs.IDLE_BLOCKER;
  development.IDLE_FETCHER = _chunkGR4NQCSDjs.IDLE_FETCHER;
  development.IDLE_NAVIGATION = _chunkGR4NQCSDjs.IDLE_NAVIGATION;
  development.Link = _chunkHQO5H5CCjs.Link;
  development.Links = _chunkGR4NQCSDjs.Links;
  development.MemoryRouter = _chunkGR4NQCSDjs.MemoryRouter;
  development.Meta = _chunkGR4NQCSDjs.Meta;
  development.NavLink = _chunkHQO5H5CCjs.NavLink;
  development.Navigate = _chunkGR4NQCSDjs.Navigate;
  development.NavigationType = _chunkGR4NQCSDjs.Action;
  development.Outlet = _chunkGR4NQCSDjs.Outlet;
  development.PrefetchPageLinks = _chunkGR4NQCSDjs.PrefetchPageLinks;
  development.Route = _chunkGR4NQCSDjs.Route;
  development.Router = _chunkGR4NQCSDjs.Router;
  development.RouterContextProvider = _chunkGR4NQCSDjs.RouterContextProvider;
  development.RouterProvider = _chunkGR4NQCSDjs.RouterProvider;
  development.Routes = _chunkGR4NQCSDjs.Routes;
  development.Scripts = _chunkGR4NQCSDjs.Scripts;
  development.ScrollRestoration = _chunkHQO5H5CCjs.ScrollRestoration;
  development.ServerRouter = ServerRouter;
  development.StaticRouter = _chunkHQO5H5CCjs.StaticRouter;
  development.StaticRouterProvider = _chunkHQO5H5CCjs.StaticRouterProvider;
  development.UNSAFE_AwaitContextProvider = _chunkGR4NQCSDjs.AwaitContextProvider;
  development.UNSAFE_DataRouterContext = _chunkGR4NQCSDjs.DataRouterContext;
  development.UNSAFE_DataRouterStateContext = _chunkGR4NQCSDjs.DataRouterStateContext;
  development.UNSAFE_ErrorResponseImpl = _chunkGR4NQCSDjs.ErrorResponseImpl;
  development.UNSAFE_FetchersContext = _chunkGR4NQCSDjs.FetchersContext;
  development.UNSAFE_FrameworkContext = _chunkGR4NQCSDjs.FrameworkContext;
  development.UNSAFE_LocationContext = _chunkGR4NQCSDjs.LocationContext;
  development.UNSAFE_NavigationContext = _chunkGR4NQCSDjs.NavigationContext;
  development.UNSAFE_RSCDefaultRootErrorBoundary = _chunkLVPI3KDGjs.RSCDefaultRootErrorBoundary;
  development.UNSAFE_RemixErrorBoundary = _chunkGR4NQCSDjs.RemixErrorBoundary;
  development.UNSAFE_RouteContext = _chunkGR4NQCSDjs.RouteContext;
  development.UNSAFE_ServerMode = ServerMode;
  development.UNSAFE_SingleFetchRedirectSymbol = _chunkGR4NQCSDjs.SingleFetchRedirectSymbol;
  development.UNSAFE_ViewTransitionContext = _chunkGR4NQCSDjs.ViewTransitionContext;
  development.UNSAFE_WithComponentProps = _chunkGR4NQCSDjs.WithComponentProps;
  development.UNSAFE_WithErrorBoundaryProps = _chunkGR4NQCSDjs.WithErrorBoundaryProps;
  development.UNSAFE_WithHydrateFallbackProps = _chunkGR4NQCSDjs.WithHydrateFallbackProps;
  development.UNSAFE_createBrowserHistory = _chunkGR4NQCSDjs.createBrowserHistory;
  development.UNSAFE_createClientRoutes = _chunkGR4NQCSDjs.createClientRoutes;
  development.UNSAFE_createClientRoutesWithHMRRevalidationOptOut = _chunkGR4NQCSDjs.createClientRoutesWithHMRRevalidationOptOut;
  development.UNSAFE_createHashHistory = _chunkGR4NQCSDjs.createHashHistory;
  development.UNSAFE_createMemoryHistory = _chunkGR4NQCSDjs.createMemoryHistory;
  development.UNSAFE_createRouter = _chunkGR4NQCSDjs.createRouter;
  development.UNSAFE_decodeViaTurboStream = _chunkGR4NQCSDjs.decodeViaTurboStream;
  development.UNSAFE_getHydrationData = _chunkLVPI3KDGjs.getHydrationData;
  development.UNSAFE_getPatchRoutesOnNavigationFunction = _chunkGR4NQCSDjs.getPatchRoutesOnNavigationFunction;
  development.UNSAFE_getTurboStreamSingleFetchDataStrategy = _chunkGR4NQCSDjs.getTurboStreamSingleFetchDataStrategy;
  development.UNSAFE_hydrationRouteProperties = _chunkGR4NQCSDjs.hydrationRouteProperties;
  development.UNSAFE_invariant = _chunkGR4NQCSDjs.invariant;
  development.UNSAFE_mapRouteProperties = _chunkGR4NQCSDjs.mapRouteProperties;
  development.UNSAFE_shouldHydrateRouteLoader = _chunkGR4NQCSDjs.shouldHydrateRouteLoader;
  development.UNSAFE_useFogOFWarDiscovery = _chunkGR4NQCSDjs.useFogOFWarDiscovery;
  development.UNSAFE_useScrollRestoration = _chunkHQO5H5CCjs.useScrollRestoration;
  development.UNSAFE_withComponentProps = _chunkGR4NQCSDjs.withComponentProps;
  development.UNSAFE_withErrorBoundaryProps = _chunkGR4NQCSDjs.withErrorBoundaryProps;
  development.UNSAFE_withHydrateFallbackProps = _chunkGR4NQCSDjs.withHydrateFallbackProps;
  development.createBrowserRouter = _chunkHQO5H5CCjs.createBrowserRouter;
  development.createContext = _chunkGR4NQCSDjs.createContext;
  development.createCookie = createCookie;
  development.createCookieSessionStorage = createCookieSessionStorage;
  development.createHashRouter = _chunkHQO5H5CCjs.createHashRouter;
  development.createMemoryRouter = _chunkGR4NQCSDjs.createMemoryRouter;
  development.createMemorySessionStorage = createMemorySessionStorage;
  development.createPath = _chunkGR4NQCSDjs.createPath;
  development.createRequestHandler = createRequestHandler;
  development.createRoutesFromChildren = _chunkGR4NQCSDjs.createRoutesFromChildren;
  development.createRoutesFromElements = _chunkGR4NQCSDjs.createRoutesFromElements;
  development.createRoutesStub = createRoutesStub;
  development.createSearchParams = _chunkHQO5H5CCjs.createSearchParams;
  development.createSession = createSession;
  development.createSessionStorage = createSessionStorage;
  development.createStaticHandler = _chunkHQO5H5CCjs.createStaticHandler;
  development.createStaticRouter = _chunkHQO5H5CCjs.createStaticRouter;
  development.data = _chunkGR4NQCSDjs.data;
  development.generatePath = _chunkGR4NQCSDjs.generatePath;
  development.href = href;
  development.isCookie = isCookie;
  development.isRouteErrorResponse = _chunkGR4NQCSDjs.isRouteErrorResponse;
  development.isSession = isSession;
  development.matchPath = _chunkGR4NQCSDjs.matchPath;
  development.matchRoutes = _chunkGR4NQCSDjs.matchRoutes;
  development.parsePath = _chunkGR4NQCSDjs.parsePath;
  development.redirect = _chunkGR4NQCSDjs.redirect;
  development.redirectDocument = _chunkGR4NQCSDjs.redirectDocument;
  development.renderMatches = _chunkGR4NQCSDjs.renderMatches;
  development.replace = _chunkGR4NQCSDjs.replace;
  development.resolvePath = _chunkGR4NQCSDjs.resolvePath;
  development.unstable_HistoryRouter = _chunkHQO5H5CCjs.HistoryRouter;
  development.unstable_RSCStaticRouter = RSCStaticRouter;
  development.unstable_routeRSCServerRequest = routeRSCServerRequest;
  development.unstable_setDevServerHooks = setDevServerHooks;
  development.unstable_usePrompt = _chunkHQO5H5CCjs.usePrompt;
  development.unstable_useRoute = _chunkGR4NQCSDjs.useRoute;
  development.unstable_useRouterState = _chunkGR4NQCSDjs.useRouterState;
  development.useActionData = _chunkGR4NQCSDjs.useActionData;
  development.useAsyncError = _chunkGR4NQCSDjs.useAsyncError;
  development.useAsyncValue = _chunkGR4NQCSDjs.useAsyncValue;
  development.useBeforeUnload = _chunkHQO5H5CCjs.useBeforeUnload;
  development.useBlocker = _chunkGR4NQCSDjs.useBlocker;
  development.useFetcher = _chunkHQO5H5CCjs.useFetcher;
  development.useFetchers = _chunkHQO5H5CCjs.useFetchers;
  development.useFormAction = _chunkHQO5H5CCjs.useFormAction;
  development.useHref = _chunkGR4NQCSDjs.useHref;
  development.useInRouterContext = _chunkGR4NQCSDjs.useInRouterContext;
  development.useLinkClickHandler = _chunkHQO5H5CCjs.useLinkClickHandler;
  development.useLoaderData = _chunkGR4NQCSDjs.useLoaderData;
  development.useLocation = _chunkGR4NQCSDjs.useLocation;
  development.useMatch = _chunkGR4NQCSDjs.useMatch;
  development.useMatches = _chunkGR4NQCSDjs.useMatches;
  development.useNavigate = _chunkGR4NQCSDjs.useNavigate;
  development.useNavigation = _chunkGR4NQCSDjs.useNavigation;
  development.useNavigationType = _chunkGR4NQCSDjs.useNavigationType;
  development.useOutlet = _chunkGR4NQCSDjs.useOutlet;
  development.useOutletContext = _chunkGR4NQCSDjs.useOutletContext;
  development.useParams = _chunkGR4NQCSDjs.useParams;
  development.useResolvedPath = _chunkGR4NQCSDjs.useResolvedPath;
  development.useRevalidator = _chunkGR4NQCSDjs.useRevalidator;
  development.useRouteError = _chunkGR4NQCSDjs.useRouteError;
  development.useRouteLoaderData = _chunkGR4NQCSDjs.useRouteLoaderData;
  development.useRoutes = _chunkGR4NQCSDjs.useRoutes;
  development.useSearchParams = _chunkHQO5H5CCjs.useSearchParams;
  development.useSubmit = _chunkHQO5H5CCjs.useSubmit;
  development.useViewTransitionState = _chunkHQO5H5CCjs.useViewTransitionState;
  return development;
}
var hasRequiredDomExport;
function requireDomExport() {
  if (hasRequiredDomExport) return domExport;
  hasRequiredDomExport = 1;
  Object.defineProperty(domExport, "__esModule", { value: true });
  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
      return obj;
    } else {
      var newObj = {};
      if (obj != null) {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) {
            newObj[key] = obj[key];
          }
        }
      }
      newObj.default = obj;
      return newObj;
    }
  }
  function _nullishCoalesce(lhs, rhsFn) {
    if (lhs != null) {
      return lhs;
    } else {
      return rhsFn();
    }
  }
  function _optionalChain(ops) {
    let lastAccessLHS = void 0;
    let value = ops[0];
    let i = 1;
    while (i < ops.length) {
      const op = ops[i];
      const fn = ops[i + 1];
      i += 2;
      if ((op === "optionalAccess" || op === "optionalCall") && value == null) {
        return void 0;
      }
      if (op === "access" || op === "optionalAccess") {
        lastAccessLHS = value;
        value = fn(value);
      } else if (op === "call" || op === "optionalCall") {
        value = fn((...args) => value.call(lastAccessLHS, ...args));
        lastAccessLHS = void 0;
      }
    }
    return value;
  }
  var _chunkLVPI3KDGjs = /* @__PURE__ */ requireChunkLVPI3KDG();
  var _chunkGR4NQCSDjs = /* @__PURE__ */ requireChunkGR4NQCSD();
  var _react = requireReact();
  var React = _interopRequireWildcard(_react);
  var React2 = _interopRequireWildcard(_react);
  var React3 = _interopRequireWildcard(_react);
  var _reactdom = requireReactDom();
  var ReactDOM = _interopRequireWildcard(_reactdom);
  var ReactDOM2 = _interopRequireWildcard(_reactdom);
  var _reactrouter = /* @__PURE__ */ requireDevelopment();
  function RouterProvider2(props) {
    return /* @__PURE__ */ React.createElement(_reactrouter.RouterProvider, { flushSync: ReactDOM.flushSync, ...props });
  }
  var ssrInfo = null;
  var router = null;
  function initSsrInfo() {
    if (!ssrInfo && window.__reactRouterContext && window.__reactRouterManifest && window.__reactRouterRouteModules) {
      if (window.__reactRouterManifest.sri === true) {
        const importMap = document.querySelector("script[rr-importmap]");
        if (_optionalChain([importMap, "optionalAccess", (_2) => _2.textContent])) {
          try {
            window.__reactRouterManifest.sri = JSON.parse(
              importMap.textContent
            ).integrity;
          } catch (err) {
            console.error("Failed to parse import map", err);
          }
        }
      }
      ssrInfo = {
        context: window.__reactRouterContext,
        manifest: window.__reactRouterManifest,
        routeModules: window.__reactRouterRouteModules,
        stateDecodingPromise: void 0,
        router: void 0,
        routerInitialized: false
      };
    }
  }
  function createHydratedRouter({
    getContext,
    instrumentations
  }) {
    initSsrInfo();
    if (!ssrInfo) {
      throw new Error(
        "You must be using the SSR features of React Router in order to skip passing a `router` prop to `<RouterProvider>`"
      );
    }
    let localSsrInfo = ssrInfo;
    if (!ssrInfo.stateDecodingPromise) {
      let stream = ssrInfo.context.stream;
      _reactrouter.UNSAFE_invariant.call(void 0, stream, "No stream found for single fetch decoding");
      ssrInfo.context.stream = void 0;
      ssrInfo.stateDecodingPromise = _reactrouter.UNSAFE_decodeViaTurboStream.call(void 0, stream, window).then((value) => {
        ssrInfo.context.state = value.value;
        localSsrInfo.stateDecodingPromise.value = true;
      }).catch((e) => {
        localSsrInfo.stateDecodingPromise.error = e;
      });
    }
    if (ssrInfo.stateDecodingPromise.error) {
      throw ssrInfo.stateDecodingPromise.error;
    }
    if (!ssrInfo.stateDecodingPromise.value) {
      throw ssrInfo.stateDecodingPromise;
    }
    let routes = _reactrouter.UNSAFE_createClientRoutes.call(
      void 0,
      ssrInfo.manifest.routes,
      ssrInfo.routeModules,
      ssrInfo.context.state,
      ssrInfo.context.ssr,
      ssrInfo.context.isSpaMode
    );
    let hydrationData = void 0;
    if (ssrInfo.context.isSpaMode) {
      let { loaderData } = ssrInfo.context.state;
      if (_optionalChain([ssrInfo, "access", (_3) => _3.manifest, "access", (_4) => _4.routes, "access", (_5) => _5.root, "optionalAccess", (_6) => _6.hasLoader]) && loaderData && "root" in loaderData) {
        hydrationData = {
          loaderData: {
            root: loaderData.root
          }
        };
      }
    } else {
      hydrationData = _reactrouter.UNSAFE_getHydrationData.call(void 0, {
        state: ssrInfo.context.state,
        routes,
        getRouteInfo: (routeId) => ({
          clientLoader: _optionalChain([ssrInfo, "access", (_7) => _7.routeModules, "access", (_8) => _8[routeId], "optionalAccess", (_9) => _9.clientLoader]),
          hasLoader: _optionalChain([ssrInfo, "access", (_10) => _10.manifest, "access", (_11) => _11.routes, "access", (_12) => _12[routeId], "optionalAccess", (_13) => _13.hasLoader]) === true,
          hasHydrateFallback: _optionalChain([ssrInfo, "access", (_14) => _14.routeModules, "access", (_15) => _15[routeId], "optionalAccess", (_16) => _16.HydrateFallback]) != null
        }),
        location: window.location,
        basename: _optionalChain([window, "access", (_17) => _17.__reactRouterContext, "optionalAccess", (_18) => _18.basename]),
        isSpaMode: ssrInfo.context.isSpaMode
      });
    }
    if (window.history.state && window.history.state.masked) {
      window.history.replaceState(
        { ...window.history.state, masked: void 0 },
        ""
      );
    }
    let router2 = _reactrouter.UNSAFE_createRouter.call(void 0, {
      routes,
      history: _reactrouter.UNSAFE_createBrowserHistory.call(void 0),
      basename: ssrInfo.context.basename,
      getContext,
      hydrationData,
      hydrationRouteProperties: _reactrouter.UNSAFE_hydrationRouteProperties,
      instrumentations,
      mapRouteProperties: _reactrouter.UNSAFE_mapRouteProperties,
      future: {
        v8_passThroughRequests: ssrInfo.context.future.v8_passThroughRequests
      },
      dataStrategy: _reactrouter.UNSAFE_getTurboStreamSingleFetchDataStrategy.call(
        void 0,
        () => router2,
        ssrInfo.manifest,
        ssrInfo.routeModules,
        ssrInfo.context.ssr,
        ssrInfo.context.basename,
        ssrInfo.context.future.v8_trailingSlashAwareDataRequests
      ),
      patchRoutesOnNavigation: _reactrouter.UNSAFE_getPatchRoutesOnNavigationFunction.call(
        void 0,
        () => router2,
        ssrInfo.manifest,
        ssrInfo.routeModules,
        ssrInfo.context.ssr,
        ssrInfo.context.routeDiscovery,
        ssrInfo.context.isSpaMode,
        ssrInfo.context.basename
      )
    });
    ssrInfo.router = router2;
    if (router2.state.initialized) {
      ssrInfo.routerInitialized = true;
      router2.initialize();
    }
    router2.createRoutesForHMR = /* spacer so ts-ignore does not affect the right hand of the assignment */
    _reactrouter.UNSAFE_createClientRoutesWithHMRRevalidationOptOut;
    window.__reactRouterDataRouter = router2;
    return router2;
  }
  function HydratedRouter(props) {
    if (!router) {
      router = createHydratedRouter({
        getContext: props.getContext,
        instrumentations: props.instrumentations
      });
    }
    let [criticalCss, setCriticalCss] = React2.useState(
      void 0
    );
    React2.useEffect(() => {
    }, []);
    React2.useEffect(() => {
    }, [criticalCss]);
    let [location2, setLocation] = React2.useState(router.state.location);
    React2.useLayoutEffect(() => {
      if (ssrInfo && ssrInfo.router && !ssrInfo.routerInitialized) {
        ssrInfo.routerInitialized = true;
        ssrInfo.router.initialize();
      }
    }, []);
    React2.useLayoutEffect(() => {
      if (ssrInfo && ssrInfo.router) {
        return ssrInfo.router.subscribe((newState) => {
          if (newState.location !== location2) {
            setLocation(newState.location);
          }
        });
      }
    }, [location2]);
    _reactrouter.UNSAFE_invariant.call(void 0, ssrInfo, "ssrInfo unavailable for HydratedRouter");
    _reactrouter.UNSAFE_useFogOFWarDiscovery.call(
      void 0,
      router,
      ssrInfo.manifest,
      ssrInfo.routeModules,
      ssrInfo.context.ssr,
      ssrInfo.context.routeDiscovery,
      ssrInfo.context.isSpaMode
    );
    return (
      // This fragment is important to ensure we match the <ServerRouter> JSX
      // structure so that useId values hydrate correctly
      /* @__PURE__ */ React2.createElement(React2.Fragment, null, /* @__PURE__ */ React2.createElement(
        _reactrouter.UNSAFE_FrameworkContext.Provider,
        {
          value: {
            manifest: ssrInfo.manifest,
            routeModules: ssrInfo.routeModules,
            future: ssrInfo.context.future,
            criticalCss,
            ssr: ssrInfo.context.ssr,
            isSpaMode: ssrInfo.context.isSpaMode,
            routeDiscovery: ssrInfo.context.routeDiscovery
          }
        },
        /* @__PURE__ */ React2.createElement(_reactrouter.UNSAFE_RemixErrorBoundary, { location: location2 }, /* @__PURE__ */ React2.createElement(
          RouterProvider2,
          {
            router,
            useTransitions: props.useTransitions,
            onError: props.onError
          }
        ))
      ), /* @__PURE__ */ React2.createElement(React2.Fragment, null))
    );
  }
  var defaultManifestPath = "/__manifest";
  function createCallServer({
    createFromReadableStream,
    createTemporaryReferenceSet,
    encodeReply,
    fetch: fetchImplementation = fetch
  }) {
    const globalVar = window;
    let landedActionId = 0;
    return async (id, args) => {
      let actionId = globalVar.__routerActionID = _nullishCoalesce(globalVar.__routerActionID, () => globalVar.__routerActionID = 0) + 1;
      const temporaryReferences = createTemporaryReferenceSet();
      const payloadPromise = fetchImplementation(
        new Request(location.href, {
          body: await encodeReply(args, { temporaryReferences }),
          method: "POST",
          headers: {
            Accept: "text/x-component",
            "rsc-action-id": id
          }
        })
      ).then((response) => {
        if (!response.body) {
          throw new Error("No response body");
        }
        return createFromReadableStream(response.body, {
          temporaryReferences
        });
      });
      React3.startTransition(
        () => (
          // @ts-expect-error - Needs React 19 types
          Promise.resolve(payloadPromise).then(async (payload) => {
            if (payload.type === "redirect") {
              let location2 = normalizeRedirectLocation(payload.location);
              _chunkGR4NQCSDjs.validateNavigationTarget.call(
                void 0,
                payload.location,
                location2,
                new URL(window.location.href),
                "allow-explicit"
              );
              if (payload.reload || isExternalLocation(location2)) {
                if (_chunkGR4NQCSDjs.hasInvalidProtocol.call(void 0, location2)) {
                  throw new Error("Invalid redirect location");
                }
                window.location.href = location2;
                return;
              }
              React3.startTransition(() => {
                globalVar.__reactRouterDataRouter.navigate(location2, {
                  replace: payload.replace
                });
              });
              return;
            }
            if (payload.type !== "action") {
              throw new Error("Unexpected payload type");
            }
            const rerender = await payload.rerender;
            if (rerender && landedActionId < actionId && globalVar.__routerActionID <= actionId) {
              if (rerender.type === "redirect") {
                let location2 = normalizeRedirectLocation(rerender.location);
                _chunkGR4NQCSDjs.validateNavigationTarget.call(
                  void 0,
                  rerender.location,
                  location2,
                  new URL(window.location.href),
                  "allow-explicit"
                );
                if (rerender.reload || isExternalLocation(location2)) {
                  if (_chunkGR4NQCSDjs.hasInvalidProtocol.call(void 0, location2)) {
                    throw new Error("Invalid redirect location");
                  }
                  window.location.href = location2;
                  return;
                }
                React3.startTransition(() => {
                  globalVar.__reactRouterDataRouter.navigate(location2, {
                    replace: rerender.replace
                  });
                });
                return;
              }
              React3.startTransition(() => {
                let lastMatch;
                for (const match of rerender.matches) {
                  globalVar.__reactRouterDataRouter.patchRoutes(
                    _nullishCoalesce(_optionalChain([lastMatch, "optionalAccess", (_21) => _21.id]), () => null),
                    [createRouteFromServerManifest(match)],
                    true
                  );
                  lastMatch = match;
                }
                window.__reactRouterDataRouter._internalSetStateDoNotUseOrYouWillBreakYourApp(
                  {
                    loaderData: Object.assign(
                      {},
                      globalVar.__reactRouterDataRouter.state.loaderData,
                      rerender.loaderData
                    ),
                    errors: rerender.errors ? Object.assign(
                      {},
                      globalVar.__reactRouterDataRouter.state.errors,
                      rerender.errors
                    ) : null
                  }
                );
              });
            }
          }).catch(() => {
          })
        )
      );
      return payloadPromise.then((payload) => {
        if (payload.type !== "action" && payload.type !== "redirect") {
          throw new Error("Unexpected payload type");
        }
        return payload.actionResult;
      });
    };
  }
  function createRouterFromPayload({
    fetchImplementation,
    createFromReadableStream,
    getContext,
    payload
  }) {
    const globalVar = window;
    if (globalVar.__reactRouterDataRouter && globalVar.__reactRouterRouteModules)
      return {
        router: globalVar.__reactRouterDataRouter,
        routeModules: globalVar.__reactRouterRouteModules
      };
    if (payload.type !== "render") throw new Error("Invalid payload type");
    globalVar.__reactRouterRouteModules = _nullishCoalesce(globalVar.__reactRouterRouteModules, () => ({}));
    _chunkLVPI3KDGjs.populateRSCRouteModules.call(void 0, globalVar.__reactRouterRouteModules, payload.matches);
    let routes = payload.matches.reduceRight((previous, match) => {
      const route = createRouteFromServerManifest(
        match,
        payload
      );
      if (previous.length > 0) {
        route.children = previous;
      } else if (!route.index) {
        route.children = [];
      }
      return [route];
    }, []);
    let applyPatchesPromise;
    globalVar.__reactRouterDataRouter = _chunkGR4NQCSDjs.createRouter.call(void 0, {
      routes,
      getContext,
      basename: payload.basename,
      history: _chunkGR4NQCSDjs.createBrowserHistory.call(void 0),
      hydrationData: _chunkLVPI3KDGjs.getHydrationData.call(void 0, {
        state: {
          loaderData: payload.loaderData,
          actionData: payload.actionData,
          errors: payload.errors
        },
        routes,
        getRouteInfo: (routeId) => {
          let match = payload.matches.find((m) => m.id === routeId);
          _chunkGR4NQCSDjs.invariant.call(void 0, match, "Route not found in payload");
          return {
            clientLoader: match.clientLoader,
            hasLoader: match.hasLoader,
            hasHydrateFallback: match.hydrateFallbackElement != null
          };
        },
        location: payload.location,
        basename: payload.basename,
        isSpaMode: false
      }),
      async patchRoutesOnNavigation({ path, signal }) {
        if (payload.routeDiscovery.mode === "initial") {
          if (!applyPatchesPromise) {
            applyPatchesPromise = (async () => {
              if (!payload.patches) return;
              let patches = await payload.patches;
              React3.startTransition(() => {
                patches.forEach((p) => {
                  window.__reactRouterDataRouter.patchRoutes(_nullishCoalesce(p.parentId, () => null), [
                    createRouteFromServerManifest(p)
                  ]);
                });
              });
            })();
          }
          await applyPatchesPromise;
          return;
        }
        if (discoveredPaths.has(path)) {
          return;
        }
        await fetchAndApplyManifestPatches(
          [path],
          createFromReadableStream,
          fetchImplementation,
          signal
        );
      },
      // FIXME: Pass `build.ssr` into this function
      dataStrategy: getRSCSingleFetchDataStrategy(
        () => globalVar.__reactRouterDataRouter,
        true,
        payload.basename,
        createFromReadableStream,
        fetchImplementation
      )
    });
    if (globalVar.__reactRouterDataRouter.state.initialized) {
      globalVar.__routerInitialized = true;
      globalVar.__reactRouterDataRouter.initialize();
    } else {
      globalVar.__routerInitialized = false;
    }
    let lastLoaderData = void 0;
    globalVar.__reactRouterDataRouter.subscribe(({ loaderData, actionData }) => {
      if (lastLoaderData !== loaderData) {
        globalVar.__routerActionID = _nullishCoalesce(globalVar.__routerActionID, () => globalVar.__routerActionID = 0) + 1;
      }
    });
    globalVar.__reactRouterDataRouter._updateRoutesForHMR = (routeUpdateByRouteId) => {
      const oldRoutes = window.__reactRouterDataRouter.routes;
      const newRoutes = [];
      function walkRoutes(routes2, parentId) {
        return routes2.map((route) => {
          const routeUpdate = routeUpdateByRouteId.get(route.id);
          if (routeUpdate) {
            const {
              routeModule,
              hasAction,
              hasComponent,
              hasErrorBoundary,
              hasLoader
            } = routeUpdate;
            const newRoute = createRouteFromServerManifest({
              clientAction: routeModule.clientAction,
              clientLoader: routeModule.clientLoader,
              element: route.element,
              errorElement: route.errorElement,
              handle: route.handle,
              hasAction,
              hasComponent,
              hasErrorBoundary,
              hasLoader,
              hydrateFallbackElement: route.hydrateFallbackElement,
              id: route.id,
              index: route.index,
              links: routeModule.links,
              meta: routeModule.meta,
              parentId,
              path: route.path,
              shouldRevalidate: routeModule.shouldRevalidate
            });
            if (route.children) {
              newRoute.children = walkRoutes(route.children, route.id);
            }
            return newRoute;
          }
          const updatedRoute = { ...route };
          if (route.children) {
            updatedRoute.children = walkRoutes(route.children, route.id);
          }
          return updatedRoute;
        });
      }
      newRoutes.push(
        ...walkRoutes(oldRoutes, void 0)
      );
      window.__reactRouterDataRouter._internalSetRoutes(newRoutes);
    };
    return {
      router: globalVar.__reactRouterDataRouter,
      routeModules: globalVar.__reactRouterRouteModules
    };
  }
  var renderedRoutesContext = _chunkGR4NQCSDjs.createContext.call(void 0);
  function getRSCSingleFetchDataStrategy(getRouter, ssr, basename, createFromReadableStream, fetchImplementation) {
    let dataStrategy = _chunkGR4NQCSDjs.getSingleFetchDataStrategyImpl.call(
      void 0,
      getRouter,
      (match) => {
        let M = match;
        return {
          hasLoader: M.route.hasLoader,
          hasClientLoader: M.route.hasClientLoader,
          hasComponent: M.route.hasComponent,
          hasAction: M.route.hasAction,
          hasClientAction: M.route.hasClientAction
        };
      },
      // pass map into fetchAndDecode so it can add payloads
      getFetchAndDecodeViaRSC(createFromReadableStream, fetchImplementation),
      ssr,
      basename,
      // .rsc requests are always trailing slash aware
      true,
      // If the route has a component but we don't have an element, we need to hit
      // the server loader flow regardless of whether the client loader calls
      // `serverLoader` or not, otherwise we'll have nothing to render.
      (match) => {
        let M = match;
        return M.route.hasComponent && !M.route.element;
      }
    );
    return async (args) => args.runClientMiddleware(async () => {
      let context = args.context;
      context.set(renderedRoutesContext, []);
      let results = await dataStrategy(args);
      const renderedRoutesById = /* @__PURE__ */ new Map();
      for (const route of context.get(renderedRoutesContext)) {
        if (!renderedRoutesById.has(route.id)) {
          renderedRoutesById.set(route.id, []);
        }
        renderedRoutesById.get(route.id).push(route);
      }
      React3.startTransition(() => {
        for (const match of args.matches) {
          const renderedRoutes = renderedRoutesById.get(match.route.id);
          if (renderedRoutes) {
            for (const rendered of renderedRoutes) {
              window.__reactRouterDataRouter.patchRoutes(
                _nullishCoalesce(rendered.parentId, () => null),
                [createRouteFromServerManifest(rendered)],
                true
              );
            }
          }
        }
      });
      return results;
    });
  }
  function getFetchAndDecodeViaRSC(createFromReadableStream, fetchImplementation) {
    return async (args, basename, trailingSlashAware, targetRoutes) => {
      let { request, context } = args;
      let url = _chunkGR4NQCSDjs.singleFetchUrl.call(void 0, request.url, basename, trailingSlashAware, "rsc");
      if (request.method === "GET") {
        url = _chunkGR4NQCSDjs.stripIndexParam.call(void 0, url);
        if (targetRoutes) {
          url.searchParams.set("_routes", targetRoutes.join(","));
        }
      }
      let res = await fetchImplementation(
        new Request(url, await _chunkGR4NQCSDjs.createRequestInit.call(void 0, request))
      );
      if (res.status >= 400 && !res.headers.has("X-Remix-Response")) {
        throw new _chunkGR4NQCSDjs.ErrorResponseImpl(res.status, res.statusText, await res.text());
      }
      _chunkGR4NQCSDjs.invariant.call(void 0, res.body, "No response body to decode");
      try {
        const payload = await createFromReadableStream(res.body, {
          temporaryReferences: void 0
        });
        if (payload.type === "redirect") {
          return {
            status: res.status,
            data: {
              redirect: {
                redirect: payload.location,
                reload: payload.reload,
                replace: payload.replace,
                revalidate: false,
                status: payload.status
              }
            }
          };
        }
        if (payload.type !== "render") {
          throw new Error("Unexpected payload type");
        }
        context.get(renderedRoutesContext).push(...payload.matches);
        let results = { routes: {} };
        const dataKey = _chunkGR4NQCSDjs.isMutationMethod.call(void 0, request.method) ? "actionData" : "loaderData";
        for (let [routeId, data] of Object.entries(payload[dataKey] || {})) {
          results.routes[routeId] = { data };
        }
        if (payload.errors) {
          for (let [routeId, error] of Object.entries(payload.errors)) {
            results.routes[routeId] = { error };
          }
        }
        return { status: res.status, data: results };
      } catch (cause) {
        throw new Error("Unable to decode RSC response", { cause });
      }
    };
  }
  function RSCHydratedRouter({
    createFromReadableStream,
    fetch: fetchImplementation = fetch,
    payload,
    getContext
  }) {
    if (payload.type !== "render") throw new Error("Invalid payload type");
    let { routeDiscovery } = payload;
    let { router: router2, routeModules } = React3.useMemo(
      () => createRouterFromPayload({
        payload,
        fetchImplementation,
        getContext,
        createFromReadableStream
      }),
      [createFromReadableStream, payload, fetchImplementation, getContext]
    );
    React3.useEffect(() => {
      _chunkGR4NQCSDjs.setIsHydrated.call(void 0);
    }, []);
    React3.useLayoutEffect(() => {
      const globalVar = window;
      if (!globalVar.__routerInitialized) {
        globalVar.__routerInitialized = true;
        globalVar.__reactRouterDataRouter.initialize();
      }
    }, []);
    let [{ routes, state }, setState] = React3.useState(() => ({
      routes: cloneRoutes(router2.routes),
      state: router2.state
    }));
    React3.useLayoutEffect(
      () => router2.subscribe((newState) => {
        if (diffRoutes(router2.routes, routes))
          React3.startTransition(() => {
            setState({
              routes: cloneRoutes(router2.routes),
              state: newState
            });
          });
      }),
      [router2.subscribe, routes, router2]
    );
    const transitionEnabledRouter = React3.useMemo(
      () => ({
        ...router2,
        state,
        routes
      }),
      [router2, routes, state]
    );
    React3.useEffect(() => {
      if (routeDiscovery.mode === "initial" || // @ts-expect-error - TS doesn't know about this yet
      _optionalChain([window, "access", (_22) => _22.navigator, "optionalAccess", (_23) => _23.connection, "optionalAccess", (_24) => _24.saveData]) === true) {
        return;
      }
      function registerElement(el) {
        let path = el.tagName === "FORM" ? el.getAttribute("action") : el.getAttribute("href");
        if (!path) {
          return;
        }
        let pathname = el.tagName === "A" ? el.pathname : new URL(path, window.location.origin).pathname;
        if (!discoveredPaths.has(pathname)) {
          nextPaths.add(pathname);
        }
      }
      async function fetchPatches() {
        document.querySelectorAll("a[data-discover], form[data-discover]").forEach(registerElement);
        let paths = Array.from(nextPaths.keys()).filter((path) => {
          if (discoveredPaths.has(path)) {
            nextPaths.delete(path);
            return false;
          }
          return true;
        });
        if (paths.length === 0) {
          return;
        }
        try {
          await fetchAndApplyManifestPatches(
            paths,
            createFromReadableStream,
            fetchImplementation
          );
        } catch (e) {
          console.error("Failed to fetch manifest patches", e);
        }
      }
      let debouncedFetchPatches = debounce(fetchPatches, 100);
      fetchPatches();
      let observer = new MutationObserver(() => debouncedFetchPatches());
      observer.observe(document.documentElement, {
        subtree: true,
        childList: true,
        attributes: true,
        attributeFilter: ["data-discover", "href", "action"]
      });
    }, [routeDiscovery, createFromReadableStream, fetchImplementation]);
    const frameworkContext = {
      future: {
        // These flags have no runtime impact so can always be false.  If we add
        // flags that drive runtime behavior they'll need to be proxied through.
        v8_middleware: false,
        v8_trailingSlashAwareDataRequests: true,
        // always on for RSC
        v8_passThroughRequests: true
        // always on for RSC
      },
      isSpaMode: false,
      ssr: true,
      criticalCss: "",
      manifest: {
        routes: {},
        version: "1",
        url: "",
        entry: {
          module: "",
          imports: []
        }
      },
      routeDiscovery: payload.routeDiscovery.mode === "initial" ? { mode: "initial", manifestPath: defaultManifestPath } : {
        mode: "lazy",
        manifestPath: payload.routeDiscovery.manifestPath || defaultManifestPath
      },
      routeModules
    };
    return /* @__PURE__ */ React3.createElement(_chunkGR4NQCSDjs.RSCRouterContext.Provider, { value: true }, /* @__PURE__ */ React3.createElement(_chunkLVPI3KDGjs.RSCRouterGlobalErrorBoundary, { location: state.location }, /* @__PURE__ */ React3.createElement(_chunkGR4NQCSDjs.FrameworkContext.Provider, { value: frameworkContext }, /* @__PURE__ */ React3.createElement(
      _chunkGR4NQCSDjs.RouterProvider,
      {
        router: transitionEnabledRouter,
        flushSync: ReactDOM2.flushSync
      }
    ))));
  }
  function createRouteFromServerManifest(match, payload) {
    let hasInitialData = payload && match.id in payload.loaderData;
    let initialData = _optionalChain([payload, "optionalAccess", (_25) => _25.loaderData, "access", (_26) => _26[match.id]]);
    let hasInitialError = _optionalChain([payload, "optionalAccess", (_27) => _27.errors]) && match.id in payload.errors;
    let initialError = _optionalChain([payload, "optionalAccess", (_28) => _28.errors, "optionalAccess", (_29) => _29[match.id]]);
    let isHydrationRequest = _optionalChain([match, "access", (_30) => _30.clientLoader, "optionalAccess", (_31) => _31.hydrate]) === true || !match.hasLoader || // If the route has a component but we don't have an element, we need to hit
    // the server loader flow regardless of whether the client loader calls
    // `serverLoader` or not, otherwise we'll have nothing to render.
    match.hasComponent && !match.element;
    _chunkGR4NQCSDjs.invariant.call(void 0, window.__reactRouterRouteModules);
    _chunkLVPI3KDGjs.populateRSCRouteModules.call(void 0, window.__reactRouterRouteModules, match);
    let dataRoute = {
      id: match.id,
      element: match.element,
      errorElement: match.errorElement,
      handle: match.handle,
      hasErrorBoundary: match.hasErrorBoundary,
      hydrateFallbackElement: match.hydrateFallbackElement,
      index: match.index,
      loader: match.clientLoader ? async (args, singleFetch) => {
        let _isHydrationRequest = isHydrationRequest;
        isHydrationRequest = false;
        let result = await match.clientLoader({
          ...args,
          serverLoader: () => {
            preventInvalidServerHandlerCall(
              "loader",
              match.id,
              match.hasLoader
            );
            if (_isHydrationRequest) {
              if (hasInitialData) {
                return initialData;
              }
              if (hasInitialError) {
                throw initialError;
              }
            }
            return callSingleFetch(singleFetch);
          }
        });
        return result;
      } : (
        // We always make the call in this RSC world since even if we don't
        // have a `loader` we may need to get the `element` implementation
        ((_, singleFetch) => callSingleFetch(singleFetch))
      ),
      action: match.clientAction ? (args, singleFetch) => match.clientAction({
        ...args,
        serverAction: async () => {
          preventInvalidServerHandlerCall(
            "action",
            match.id,
            match.hasLoader
          );
          return await callSingleFetch(singleFetch);
        }
      }) : match.hasAction ? (_, singleFetch) => callSingleFetch(singleFetch) : () => {
        throw _chunkGR4NQCSDjs.noActionDefinedError.call(void 0, "action", match.id);
      },
      path: match.path,
      shouldRevalidate: match.shouldRevalidate,
      // We always have a "loader" in this RSC world since even if we don't
      // have a `loader` we may need to get the `element` implementation
      hasLoader: true,
      hasClientLoader: match.clientLoader != null,
      hasAction: match.hasAction,
      hasClientAction: match.clientAction != null
    };
    if (typeof dataRoute.loader === "function") {
      dataRoute.loader.hydrate = _chunkGR4NQCSDjs.shouldHydrateRouteLoader.call(
        void 0,
        match.id,
        match.clientLoader,
        match.hasLoader,
        false
      );
    }
    return dataRoute;
  }
  function callSingleFetch(singleFetch) {
    _chunkGR4NQCSDjs.invariant.call(void 0, typeof singleFetch === "function", "Invalid singleFetch parameter");
    return singleFetch();
  }
  function preventInvalidServerHandlerCall(type, routeId, hasHandler) {
    if (!hasHandler) {
      let fn = type === "action" ? "serverAction()" : "serverLoader()";
      let msg = `You are trying to call ${fn} on a route that does not have a server ${type} (routeId: "${routeId}")`;
      console.error(msg);
      throw new _chunkGR4NQCSDjs.ErrorResponseImpl(400, "Bad Request", new Error(msg), true);
    }
  }
  var nextPaths = /* @__PURE__ */ new Set();
  var discoveredPathsMaxSize = 1e3;
  var discoveredPaths = /* @__PURE__ */ new Set();
  function getManifestUrl(paths) {
    if (paths.length === 0) {
      return null;
    }
    if (paths.length === 1) {
      return new URL(`${paths[0]}.manifest`, window.location.origin);
    }
    const globalVar = window;
    let basename = _nullishCoalesce(globalVar.__reactRouterDataRouter.basename, () => "").replace(
      /^\/|\/$/g,
      ""
    );
    let url = new URL(`${basename}/.manifest`, window.location.origin);
    url.searchParams.set("paths", paths.sort().join(","));
    return url;
  }
  async function fetchAndApplyManifestPatches(paths, createFromReadableStream, fetchImplementation, signal) {
    paths = _chunkGR4NQCSDjs.getPathsWithAncestors.call(void 0, paths);
    let url = getManifestUrl(paths);
    if (url == null) {
      return;
    }
    if (url.toString().length > _chunkGR4NQCSDjs.URL_LIMIT) {
      nextPaths.clear();
      return;
    }
    let response = await fetchImplementation(new Request(url, { signal }));
    if (!response.body || response.status < 200 || response.status >= 300) {
      throw new Error("Unable to fetch new route matches from the server");
    }
    let payload = await createFromReadableStream(response.body, {
      temporaryReferences: void 0
    });
    if (payload.type !== "manifest") {
      throw new Error("Failed to patch routes");
    }
    paths.forEach((p) => addToFifoQueue(p, discoveredPaths));
    let patches = await payload.patches;
    React3.startTransition(() => {
      patches.forEach((p) => {
        window.__reactRouterDataRouter.patchRoutes(
          _nullishCoalesce(p.parentId, () => null),
          [createRouteFromServerManifest(p)]
        );
      });
    });
  }
  function addToFifoQueue(path, queue) {
    if (queue.size >= discoveredPathsMaxSize) {
      let first = queue.values().next().value;
      if (typeof first === "string") queue.delete(first);
    }
    queue.add(path);
  }
  function debounce(callback, wait) {
    let timeoutId;
    return (...args) => {
      window.clearTimeout(timeoutId);
      timeoutId = window.setTimeout(() => callback(...args), wait);
    };
  }
  function isExternalLocation(location2) {
    const newLocation = new URL(location2, window.location.href);
    return newLocation.origin !== window.location.origin;
  }
  function normalizeRedirectLocation(location2) {
    if (_chunkGR4NQCSDjs.PROTOCOL_RELATIVE_URL_REGEX.test(location2)) {
      let path = _chunkGR4NQCSDjs.resolvePath.call(void 0, location2);
      return path.pathname + path.search + path.hash;
    }
    return location2;
  }
  function cloneRoutes(routes) {
    if (!routes) return void 0;
    return routes.map((route) => ({
      ...route,
      children: cloneRoutes(route.children)
    }));
  }
  function diffRoutes(a, b) {
    if (a.length !== b.length) return true;
    return a.some((route, index) => {
      if (route.element !== b[index].element) return true;
      if (route.errorElement !== b[index].errorElement)
        return true;
      if (route.hydrateFallbackElement !== b[index].hydrateFallbackElement)
        return true;
      if (route.hasErrorBoundary !== b[index].hasErrorBoundary)
        return true;
      if (route.hasLoader !== b[index].hasLoader) return true;
      if (route.hasClientLoader !== b[index].hasClientLoader)
        return true;
      if (route.hasAction !== b[index].hasAction) return true;
      if (route.hasClientAction !== b[index].hasClientAction)
        return true;
      return diffRoutes(route.children || [], b[index].children || []);
    });
  }
  function getRSCStream() {
    let encoder = new TextEncoder();
    let streamController = null;
    let rscStream = new ReadableStream({
      start(controller) {
        if (typeof window === "undefined") {
          return;
        }
        let handleChunk = (chunk) => {
          if (typeof chunk === "string") {
            controller.enqueue(encoder.encode(chunk));
          } else {
            controller.enqueue(chunk);
          }
        };
        window.__FLIGHT_DATA || (window.__FLIGHT_DATA = []);
        window.__FLIGHT_DATA.forEach(handleChunk);
        window.__FLIGHT_DATA.push = (chunk) => {
          handleChunk(chunk);
          return 0;
        };
        streamController = controller;
      }
    });
    if (typeof document !== "undefined" && document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => {
        _optionalChain([streamController, "optionalAccess", (_32) => _32.close, "call", (_33) => _33()]);
      });
    } else {
      _optionalChain([streamController, "optionalAccess", (_34) => _34.close, "call", (_35) => _35()]);
    }
    return rscStream;
  }
  domExport.HydratedRouter = HydratedRouter;
  domExport.RouterProvider = RouterProvider2;
  domExport.unstable_RSCHydratedRouter = RSCHydratedRouter;
  domExport.unstable_createCallServer = createCallServer;
  domExport.unstable_getRSCStream = getRSCStream;
  return domExport;
}
export {
  requireDevelopment as a,
  requireDomExport as r
};
