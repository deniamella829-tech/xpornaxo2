import{j as o,A as p}from"./index-BS8Y-n20.js";const s=()=>o.jsx(p,{});export{s as component};
